"""
启迪·白泽 统合体 — 系统入口

数据流:
  浏览器感知 → 白泽V10向量化 → 记忆L1 → worm大脑决策 → Skill/Agent执行
              ↓
         知识树学习 → 记忆晋升
"""
import os
import sys
import time
import logging
from pathlib import Path

# 设置项目根目录
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT / 'src'))

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s',
    handlers=[logging.StreamHandler()]
)

logger = logging.getLogger('Baize')


class BaizeSystem:
    """启迪·白泽 统合体主类"""

    def __init__(self, config=None):
        self.config = config or {}
        self.history = []
        self.cycle_count = 0
        self._last_success_rate = 0.0
        self._init_components()
        logger.info('白泽统合体初始化完成')

    def _init_components(self):
        """初始化所有核心组件"""
        # 存储后端（SQLite，所有记忆组件共享）
        from storage.sqlite_backend import SQLiteBackend
        db_path = PROJECT_ROOT / 'data' / 'baize.db'
        self.storage = SQLiteBackend(str(db_path))
        logger.info(f'[存储后端] SQLite就绪: {db_path}')

        # 记忆系统（四层 + 持久化 + 遗忘/晋升）
        from memory.memory_system import MemorySystem, MemoryLevel
        self.MemorySystem = MemorySystem
        self.MemoryLevel = MemoryLevel
        self.memory = MemorySystem(storage_backend=self.storage)
        logger.info('[记忆系统] 四层记忆架构就绪（SQLite持久化）')

        # 知识树
        from memory.knowledge_tree import KnowledgeTree
        knowledge_path = PROJECT_ROOT / 'data' / 'knowledge_tree.json'
        self.knowledge_tree = KnowledgeTree(str(knowledge_path), storage_backend=self.storage)
        stats = self.knowledge_tree.get_stats()
        logger.info(f'[知识树] 已加载 {stats["total_nodes"]} 个节点')

        # 向量存储
        from memory.embeddings_store import EmbeddingsStore
        self.embeddings = EmbeddingsStore(storage_backend=self.storage)
        logger.info(f'[向量存储] {self.embeddings.get_stats()["total_vectors"]} 个向量')

        # V10嵌入引擎
        from models.baize_embed import embed, embed_with_pools
        self.baize_embed = embed
        self.baize_embed_with_pools = embed_with_pools
        logger.info('[V10嵌入] 引擎就绪')

        # 蠕虫大脑（关联知识树）
        from brain.worm_brain import WormBrain
        self.brain = WormBrain(knowledge_tree=self.knowledge_tree)
        logger.info('[蠕虫大脑] 群体思维系统就绪')

        # 大脑路由器
        try:
            from brain.decision import BrainRouter
            self.decision = BrainRouter(
                worm_brain=self.brain,
                baize_embed=self.baize_embed,
                knowledge_tree=self.knowledge_tree
            )
            logger.info('[大脑路由] 决策路由系统就绪')
        except ImportError:
            self.decision = None
            logger.warning('[大脑路由] 未找到decision模块，使用直接决策模式')

        # 联网学习器
        from perception.web_learner import WebLearner
        self.web_learner = WebLearner()
        logger.info('[联网学习] Bing+DDG搜索引擎就绪')

        # 浏览器传感器（可选，需要Playwright）
        try:
            from perception.browser_sensor import BrowserSensor
            self.browser = BrowserSensor(
                profiles_dir=PROJECT_ROOT / 'data' / 'browser_profiles'
            )
            logger.info('[浏览器感知] Playwright Edge就绪')
        except ImportError:
            self.browser = None
            logger.warning('[浏览器感知] Playwright未安装，降级使用联网搜索')

        # 页面提取器
        try:
            from perception.page_extractor import PageExtractor
            self.page_extractor = PageExtractor()
            logger.info('[页面提取] DOM结构化就绪')
        except ImportError:
            self.page_extractor = None
            logger.info('[页面提取] 使用默认提取')

        # 源池门控
        from agents.source_pool import SourcePool
        self.source_pool = SourcePool()
        logger.info('[源池门控] 32维能力向量就绪')

        # 磁场监控
        from control.magnetic_monitor import MagneticMonitor
        self.monitor = MagneticMonitor()
        logger.info('[磁场监控] 健康检测就绪')

        # 进化引擎
        from evolution.evolution_engine import EvolutionEngine
        self.evolution = EvolutionEngine()
        logger.info('[进化引擎] 规则匹配+评估+回滚就绪')

        # 动态角色
        from agents.dynamic_role import Role
        self.role = Role.ROOT
        logger.info(f'[动态身份] 当前角色: {self.role.name}')

        # 代码自生长（可选）
        try:
            from growth.self_evolve import SelfEvolve
            self.self_evolve = SelfEvolve(organism=self)
            logger.info('[代码自生长] SelfEvolve就绪')
        except Exception as e:
            self.self_evolve = None
            logger.warning(f'[代码自生长] 初始化失败: {e}')

        # Qidi Bridge（可选）
        try:
            from bridge.qidi_bridge import QidiBridge
            self.qidi_bridge = QidiBridge()
            if self.qidi_bridge.connect():
                logger.info('[Qidi Bridge] 已连接到Qidi Agent')
                self.decision.qidi_bridge = self.qidi_bridge
            else:
                logger.warning('[Qidi Bridge] 连接失败，使用本地决策模式')
        except Exception as e:
            self.qidi_bridge = None
            logger.warning(f'[Qidi Bridge] 初始化失败: {e}')

        # Skill 系统 — 共现分析 + 能力树 + 涌现测量
        from skills.cooccurrence import CooccurrenceAnalyzer
        from capability.registry import CapabilityRegistry
        from evolution.emergence_meter import EmergenceMeter
        from evolution.capability_tree import CapabilityTree

        self.cooccurrence = CooccurrenceAnalyzer()
        logger.info('[共现分析] 时序滑动窗口就绪')

        # CapabilityRegistry 统一管理 Skill + MCP 服务（继承 SkillRegistry，兼容现有进化机制）
        self.capability_registry = CapabilityRegistry(
            storage_backend=self.storage,
            cooccurrence_analyzer=self.cooccurrence
        )
        self.skill_registry = self.capability_registry  # 别名，现有引用零改动
        logger.info('[能力注册中心] CapabilityRegistry就绪（含Skill+MCP）')

        self.emergence_meter = EmergenceMeter(qidi_bridge=self.qidi_bridge)
        logger.info('[涌现测量] F/G/M 三模态就绪')

        self.capability_tree = CapabilityTree(
            qidi_bridge=self.qidi_bridge,
            storage_backend=self.storage
        )
        logger.info(f'[能力树] {self.capability_tree.get_stats()["total_skills"]} 个Skill已评估')

        # 代码自生长 — Teacher 注入 + EvolutionEngine 补充
        from growth.qidi_teacher_adapter import QidiTeacherAdapter
        self.teacher = QidiTeacherAdapter(qidi_bridge=self.qidi_bridge)
        if self.self_evolve:
            self.self_evolve.teacher = self.teacher
            logger.info('[代码自生长] Teacher已注入SelfEvolve')
        if self.evolution:
            self.evolution.emergence_meter = self.emergence_meter
            logger.info('[进化引擎] EmergenceMeter已注入')

        # HoloGram Bridge（可选）— 代码图谱分析
        try:
            from bridge.hologram_bridge import HologramBridge
            self.hologram = HologramBridge()
            if self.hologram.connect():
                logger.info('[HoloGram] 代码图谱引擎已连接')
                if self.decision:
                    self.decision.hologram = self.hologram
                if self.self_evolve:
                    self.self_evolve.hologram = self.hologram
            else:
                logger.warning('[HoloGram] 连接失败，代码理解能力降级')
        except Exception as e:
            self.hologram = None
            logger.warning(f'[HoloGram] 初始化失败: {e}')

        # Capability 统一层 — 把现有 Bridge 包装为 Capability + MCP 自动发现
        from capability.bridge_adapter import BridgeCapabilityAdapter
        from capability.mcp_discovery import MCPDiscovery

        # 1. 把 HologramBridge 的高层方法包装为 Capability（向后兼容，享受进化机制）
        if self.hologram and self.hologram.is_connected():
            hologram_methods = [
                'preflight', 'impact', 'explore', 'graph_summary',
                'fragile_modules', 'blindspots', 'search', 'analyze_project',
            ]
            for method in hologram_methods:
                if hasattr(self.hologram, method):
                    cap = BridgeCapabilityAdapter(
                        id=f'bridge.hologram.{method}',
                        name=f'HoloGram {method}',
                        bridge=self.hologram,
                        method_name=method,
                        category='code_graph',
                        tags=['hologram']
                    )
                    self.capability_registry.register(cap)
            logger.info(f'[能力注册] HologramBridge {len(hologram_methods)} 个方法已包装为Capability')

        # 2. 把 QidiBridge 的方法包装为 Capability
        if self.qidi_bridge and self.qidi_bridge.is_connected():
            qidi_methods = [
                'analyze_code', 'evaluate_emergence', 'get_capability_tree',
                'chat', 'run_task', 'get_tools',
            ]
            for method in qidi_methods:
                if hasattr(self.qidi_bridge, method):
                    cap = BridgeCapabilityAdapter(
                        id=f'bridge.qidi.{method}',
                        name=f'Qidi {method}',
                        bridge=self.qidi_bridge,
                        method_name=method,
                        category='qidi',
                        tags=['qidi']
                    )
                    self.capability_registry.register(cap)
            logger.info(f'[能力注册] QidiBridge {len(qidi_methods)} 个方法已包装为Capability')

        # 3. MCP 自动发现 — 从 config/mcp_services.json 加载新 MCP 服务
        self.mcp_discovery = MCPDiscovery(self.capability_registry)
        mcp_stats = self.mcp_discovery.discover_and_register()
        if mcp_stats['services'] > 0 or mcp_stats['failed']:
            logger.info(f'[MCP发现] 服务:{mcp_stats["services"]} 工具:{mcp_stats["tools"]}'
                        + (f' 失败:{mcp_stats["failed"]}' if mcp_stats["failed"] else ''))

        # 4. 云端模型 Provider — 从 config/cloud_models.json 加载云端模型
        try:
            from models.cloud_provider import CloudProvider, CloudCapability, CloudEmbeddingCapability
            self.cloud_provider = CloudProvider()
            if self.cloud_provider.providers:
                cloud_chat = CloudCapability(self.cloud_provider)
                cloud_embed = CloudEmbeddingCapability(self.cloud_provider)
                self.capability_registry.register(cloud_chat)
                self.capability_registry.register(cloud_embed)
                available_models = self.cloud_provider.get_available_models()
                logger.info(f'[云端模型] Provider已加载: {len(self.cloud_provider.providers)} 个')
                if available_models:
                    logger.info(f'[云端模型] 可用模型: {", ".join(available_models)}')
                else:
                    logger.info(f'[云端模型] 暂无启用的Provider，使用环境变量配置API Key后启用')
            else:
                self.cloud_provider = None
                logger.info('[云端模型] 未配置Provider')
        except Exception as e:
            self.cloud_provider = None
            logger.warning(f'[云端模型] 初始化失败: {e}')

        # 能力统计
        total_caps = len(self.capability_registry.list_all())
        logger.info(f'[能力体系] 共 {total_caps} 个能力已注册（Skill+MCP+Bridge+Cloud）')

        # API服务器（可选）
        try:
            from server.api_server import APIServer
            self.api_server = APIServer(system=self)
            logger.info('[API服务] Flask服务器就绪')
        except Exception as e:
            self.api_server = None
            logger.warning(f'[API服务] 初始化失败: {e}')

    def start_api(self, port=5000):
        """启动API服务"""
        if self.api_server:
            self.api_server.port = port
            self.api_server.start()
            logger.info(f'[API服务] 已启动: {self.api_server.get_url()}')
            return self.api_server.get_url()
        return None

    def analyze_code(self, project_path=None):
        """分析代码结构 — HoloGram 引擎扫描项目"""
        if not self.hologram:
            return {'error': 'HoloGram 引擎未连接'}
        path = project_path or str(PROJECT_ROOT)
        result = self.hologram.analyze_project(path, wait=True)
        if result:
            self.hologram.learn_code_structure(self.knowledge_tree)
        return result

    def explore_code(self, query):
        """自然语言查询代码"""
        if not self.hologram:
            return {'error': 'HoloGram 引擎未连接'}
        return self.hologram.explore(query=query)

    def perceive(self, text_or_url, source='manual'):
        """感知入口：文本或URL → 向量化 → 存入记忆"""
        logger.info(f'[感知] 输入: {text_or_url[:50]}...')

        # 判断是URL还是纯文本
        if text_or_url.startswith('http://') or text_or_url.startswith('https://'):
            content = self._fetch_url(text_or_url)
        else:
            content = text_or_url

        if not content:
            logger.warning('[感知] 未获取到内容')
            return None

        # 向量化
        embedding = self.baize_embed(content[:1000])
        pools = self.baize_embed_with_pools(content[:200])

        # 存入工作记忆 L1
        self.memory.store(
            key=f'percept_{int(time.time())}',
            content={
                'text': content[:5000],
                'embedding': embedding,
                'source': source,
            },
            level=self.MemoryLevel.L1_WORKING,
            tags=['perception', source],
        )

        # 知识树学习
        topic = content[:50].replace('\n', ' ').strip()
        if len(topic) > 5:
            self.knowledge_tree.learn(topic, content[:2000], source=source)

        return {
            'content': content[:500],
            'embedding_dim': len(embedding),
            'memory_stored': True,
            'knowledge_learned': bool(topic),
        }

    def _fetch_url(self, url):
        """获取URL内容：浏览器优先，降级走搜索"""
        if self.browser and self.page_extractor:
            try:
                page = self.browser.fetch(url)
                if page:
                    return self.page_extractor.extract(page)
            except Exception as e:
                logger.debug(f'浏览器抓取失败，降级搜索: {e}')

        # 降级：联网搜索获取摘要
        results = self.web_learner.search(url, top_k=3)
        if results:
            return '\n'.join(f'{r["title"]}: {r["snippet"]}' for r in results)
        return None

    def decide(self, percepts=None, **kwargs):
        """决策入口：感知 → worm大脑 → 决策"""
        if self.decision:
            return self.decision.decide(percepts, **kwargs)
        else:
            return self.brain.think(percepts, **kwargs)

    def act(self, decision):
        """执行决策"""
        action = decision.get('decision', {}).get('action', '休息')
        logger.info(f'[行动] 执行: {action}')

        if action == '爬取':
            return self._action_crawl()
        elif action == '分析':
            return self._action_analyze()
        elif action == '学习':
            return self._action_learn()
        elif action == '调度':
            return self._action_schedule()
        elif action == '整理记忆':
            return self._action_organize_memory()
        elif action == '求助':
            return self._action_ask()
        else:
            return {'action': action, 'result': '执行默认行为'}

    def _action_crawl(self):
        """爬取行动：搜索热点话题"""
        topics = ['人工智能', '深度学习', '自进化智能体']
        learned = 0
        for topic in topics:
            count = self.web_learner.digest(topic, self.knowledge_tree)
            learned += count
        return {'action': '爬取', 'topics': topics, 'learned': learned}

    def _action_analyze(self):
        """分析行动：检查记忆和知识树状态"""
        mem_stats = self.memory.get_statistics()
        kt_stats = self.knowledge_tree.get_stats()
        brain_status = self.brain.get_status()
        return {
            'action': '分析',
            'memory': mem_stats,
            'knowledge_tree': kt_stats,
            'brain': brain_status,
        }

    def _action_learn(self):
        """学习行动：联网搜索补充知识"""
        # 从知识树找低命中率节点
        results = self.knowledge_tree.recall('', top_k=10, min_score=0.0)
        learned = 0
        for r in results:
            if r['hit_count'] < 3:
                count = self.web_learner.digest(r['topic'], self.knowledge_tree)
                learned += count
        return {'action': '学习', 'topics_learned': learned}

    def _action_schedule(self):
        """调度行动：检查源池状态"""
        activity = self.source_pool.activity()
        saturated = self.source_pool.is_saturated()
        return {'action': '调度', 'activity': activity, 'saturated': saturated}

    def _action_organize_memory(self):
        """整理记忆：清理过期、晋升高置信记忆"""
        result = self.memory.run_maintenance()
        return {
            'action': '整理记忆',
            'cleaned': result['maintenance']['cleaned'],
            'promoted': result['maintenance']['promoted'],
        }

    def _action_ask(self):
        """求助行动：通过Qidi Bridge调用云端LLM"""
        if hasattr(self, 'qidi_bridge') and self.qidi_bridge:
            try:
                return self.qidi_bridge.call('analyze', {'query': '分析当前系统状态'})
            except Exception as e:
                return {'action': '求助', 'error': str(e)}
        return {'action': '求助', 'result': 'Qidi Bridge未连接'}

    def evolve(self):
        """进化循环：诊断→修改→测试→采纳/回滚"""
        if self.self_evolve:
            results = self.self_evolve.evolve()
            return results
        return {'result': 'SelfEvolve未初始化'}

    def get_status(self):
        """获取系统整体状态"""
        return {
            'role': self.role.name,
            'memory': self.memory.get_statistics(),
            'knowledge_tree': self.knowledge_tree.get_stats(),
            'brain': self.brain.get_status(),
            'source_pool': self.source_pool.to_dict(),
            'health': self.monitor.check_health(),
            'evolution': self.evolution.get_statistics(),
        }

    def run(self, iterations=5):
        """运行统合体主循环（向后兼容，内部调用autonomous_loop）"""
        return self.autonomous_loop(max_iterations=iterations, interval=1)

    def detect_knowledge_gaps(self, top_k=5):
        """
        检测知识盲区 — 基于知识树召回质量识别未探索领域

        原理: 对一组"种子话题"做recall,召回分数低的就是盲区
        """
        seed_topics = [
            '人工智能', '机器学习', '深度学习', '神经网络', '自然语言处理',
            '代码生成', '自进化系统', '知识图谱', '强化学习', 'Transformer',
            '大语言模型', '智能体', '多模态', '推理', '记忆系统',
            '浏览器自动化', '向量数据库', '涌现', '进化算法', '元学习',
        ]
        gaps = []
        for topic in seed_topics:
            results = self.knowledge_tree.recall(topic, top_k=1, min_score=0.1)
            if not results:
                gaps.append({'topic': topic, 'score': 0.0, 'reason': '完全未探索'})
            else:
                score = results[0].get('score', 0) if isinstance(results[0], dict) else 0
                if score < 0.3:
                    gaps.append({'topic': topic, 'score': score, 'reason': f'召回分数低({score:.2f})'})

        gaps.sort(key=lambda x: x['score'])
        return gaps[:top_k]

    def autonomous_learn(self, topic):
        """
        自主学习一个话题 — 学习+反思+记忆整合

        流程:
        1. 联网搜索学习
        2. 云端模型反思(如可用)
        3. 存入知识树+记忆系统
        4. 蠕虫大脑reward
        """
        logger.info(f'[自主学习] 目标: {topic}')

        # 1. 联网学习
        learned = self.web_learner.learn(topic, max_results=3)
        if not learned:
            logger.info(f'[自主学习] 未找到关于"{topic}"的内容')
            return {'topic': topic, 'learned': 0, 'reason': '无搜索结果'}

        # 2. 整合到知识树+记忆
        new_count = 0
        for item in learned:
            content = item.get('content', '') or item.get('summary', '')
            if not content or len(content) < 20:
                continue

            # 存入知识树
            self.knowledge_tree.learn(topic, content, source='autonomous')

            # 存入L1记忆
            mem_key = f'auto_learn_{topic}_{int(time.time())}_{new_count}'
            self.memory.store(mem_key, {
                'topic': topic,
                'content': content[:500],
                'source': 'autonomous',
                'url': item.get('url', ''),
            }, level='L1_WORKING', tags=['autonomous', 'learned'])

            new_count += 1

        # 3. 云端模型反思(如可用)
        reflection = None
        if self.cloud_provider and self.cloud_provider.get_available_models():
            try:
                sample_content = learned[0].get('content', '')[:300] if learned else ''
                prompt = f"我刚学到了关于'{topic}'的知识。请用一句话总结核心要点:\n\n{sample_content}"
                reflection = self.cloud_provider.chat([
                    {'role': 'system', 'content': '你是白泽的反思模块,用简洁中文总结知识要点。'},
                    {'role': 'user', 'content': prompt}
                ], max_tokens=100)
                logger.info(f'[反思] {reflection[:80]}...')

                # 反思结果存入L2经验
                self.memory.store(f'reflection_{topic}_{int(time.time())}', {
                    'topic': topic,
                    'reflection': reflection,
                    'source': 'cloud_reflection',
                }, level='L2_EXPERIENCE', tags=['reflection', topic])
            except Exception as e:
                logger.warning(f'[反思] 失败(继续运行): {e}')

        # 4. 蠕虫大脑reward
        self.brain.reward(f'learn_{topic}', score=0.8 if new_count > 0 else 0.3)

        logger.info(f'[自主学习] 完成: {topic}, 学到{new_count}条, 反思={"✓" if reflection else "✗"}')
        return {
            'topic': topic,
            'learned': new_count,
            'reflection': reflection,
            'sources': len(learned),
        }

    def autonomous_loop(self, max_iterations=None, interval=2):
        """
        自主进化循环 — 系统自主运行,无需人工干预

        循环流程:
        1. 感知: 检测知识盲区,选择学习目标
        2. 学习: 联网学习+云端反思
        3. 记忆: 整合到知识树+记忆系统
        4. 进化: 定期能力评估+代码自生长
        5. 反思: 蠕虫大脑reward+经验沉淀
        """
        logger.info(f'[自主循环] 开始 (max={max_iterations or "∞"}, interval={interval}s)')

        i = 0
        while max_iterations is None or i < max_iterations:
            self.cycle_count += 1
            i += 1
            logger.info(f'\n{"="*50}')
            logger.info(f'[自主循环] 第 {self.cycle_count} 轮 (本次第 {i} 轮)')
            logger.info(f'{"="*50}')

            try:
                # ===== 1. 感知: 检测知识盲区 =====
                gaps = self.detect_knowledge_gaps(top_k=3)
                if not gaps:
                    logger.info('[感知] 知识树覆盖良好,无盲区')
                    gaps = [{'topic': '前沿AI技术', 'score': 0.5, 'reason': '探索新领域'}]

                target_topic = gaps[0]['topic']
                logger.info(f'[感知] 检测到 {len(gaps)} 个盲区,选择学习: {target_topic}')
                logger.info(f'         原因: {gaps[0]["reason"]}')

                # ===== 2. 蠕虫大脑决策 =====
                brain_result = self.brain.think(seeds=[target_topic], rounds=3)
                logger.info(f'[大脑] 蠕虫决策完成,激活扩散 {len(brain_result.get("activated", []))} 个节点')

                # ===== 3. 自主学习 =====
                learn_result = self.autonomous_learn(target_topic)
                logger.info(f'[学习] 学到 {learn_result.get("learned", 0)} 条知识')

                # ===== 4. 进化(每5轮) =====
                if i % 5 == 0:
                    logger.info('[进化] 触发能力评估+代码自生长')
                    evo_result = self.evolve()
                    logger.info(f'[进化] {evo_result.get("status", "完成")}')

                # ===== 5. 记忆维护(每10轮) =====
                if i % 10 == 0:
                    maintenance = self.memory.run_maintenance()
                    cleaned = maintenance.get('maintenance', {}).get('cleaned', 0)
                    promoted = maintenance.get('maintenance', {}).get('promoted', 0)
                    logger.info(f'[维护] 清理 {cleaned} 条, 晋升 {promoted} 条')

                # ===== 6. 能力统计(每15轮) =====
                if i % 15 == 0:
                    active = self.capability_registry.get_active_skills(min_usage=1)
                    inactive = self.capability_registry.get_inactive_skills(inactive_days=7)
                    logger.info(f'[能力] 活跃 {len(active)} 个, 沉寂 {len(inactive)} 个')

                # ===== 7. 知识树持久化(每20轮) =====
                if i % 20 == 0:
                    self.knowledge_tree.save(force=True)
                    logger.info('[持久化] 知识树已保存')

                # ===== 8. 记录历史 =====
                self.history.append({
                    'cycle': self.cycle_count,
                    'topic': target_topic,
                    'action': f'autonomous_learn',
                    'outcome': 0.8 if learn_result.get('learned', 0) > 0 else 0.3,
                    'learned': learn_result.get('learned', 0),
                    'reflection': bool(learn_result.get('reflection')),
                    'phase': 'autonomous',
                })

            except KeyboardInterrupt:
                logger.info('[自主循环] 用户中断,停止运行')
                break
            except Exception as e:
                logger.error(f'[自主循环] 第 {i} 轮异常: {e}', exc_info=True)
                self.history.append({
                    'cycle': self.cycle_count,
                    'error': str(e),
                    'phase': 'autonomous_error',
                })

            if max_iterations is None or i < max_iterations:
                time.sleep(interval)

        # 更新成功率
        if self.history:
            recent = self.history[-10:]
            self._last_success_rate = sum(1 for h in recent if h.get('outcome', 0) > 0.5) / len(recent)

        logger.info(f'[自主循环] 完成,共 {i} 轮,成功率 {self._last_success_rate*100:.0f}%')
        return self.get_status()


async def _open_browser_url(browser_sensor, url):
    """打开浏览器访问指定URL"""
    await browser_sensor.start()
    await browser_sensor.new_context()
    await browser_sensor._page.goto(url, wait_until='networkidle')
    print(f'✓ 浏览器已打开: {url}')


def _run_repl(system):
    """
    交互式命令行界面（REPL）—— 默认启动模式

    支持命令：
      status    - 查看系统状态
      evolve    - 执行一次进化
      perceive  - 感知输入（文本或URL）
      learn     - 联网学习
      analyze   - 分析代码
      memory    - 记忆管理
      skills    - 能力列表
      mcp       - MCP服务状态
      run       - 运行主循环
      help/h    - 显示帮助
      exit/quit - 退出
    """
    import json
    print('\n' + '=' * 60)
    print('  🎯 启迪·白泽 交互式界面')
    print('=' * 60)
    print('  输入命令开始交互，输入 help 查看命令列表')
    print('=' * 60)

    while True:
        try:
            cmd_input = input('\n白泽> ').strip()
            if not cmd_input:
                continue

            parts = cmd_input.split(' ', 1)
            cmd = parts[0].lower()
            args = parts[1] if len(parts) > 1 else ''

            if cmd in ('exit', 'quit', 'q'):
                print('👋 再见！')
                break

            elif cmd in ('help', 'h'):
                print('''
📖 命令列表：
  status          - 查看系统状态（记忆/知识树/大脑/健康）
  evolve          - 执行一次代码自进化
  perceive <内容> - 感知输入（文本或URL），存入记忆
  learn <话题>    - 联网搜索学习指定话题
  analyze         - 分析代码结构（HoloGram）
  memory          - 记忆系统统计
  skills          - 能力列表（Skill+MCP+Bridge+Cloud）
  cloud           - 云端模型配置管理（启用/禁用/设置API Key/测试）
  introduce/自我介绍 - 查看系统简介
  chat <内容>     - 与云端大模型对话
  auto/自主进化 [次数] - 🤖 自主进化模式(系统自己学习+反思+进化)
  browser/打开浏览器 - 打开浏览器访问平台（doubao/qianwen/kimi等）
  mcp             - MCP服务状态
  run [次数]      - 运行主循环（默认5次）
  capability <ID> - 调用指定能力
  clear           - 清屏
  exit/quit       - 退出
''')

            elif cmd == 'status':
                status = system.get_status()
                print('\n📊 系统状态：')
                print(f"  角色: {status['role']}")
                memory_by_level = status['memory'].get('by_level', {})
                print(f"  记忆: {status['memory']['total_entries']} 条（L1:{memory_by_level.get('L1_WORKING',0)} L2:{memory_by_level.get('L2_EXPERIENCE',0)} L3:{memory_by_level.get('L3_KNOWLEDGE',0)} L4:{memory_by_level.get('L4_META',0)}）")
                print(f"  知识树: {status['knowledge_tree']['total_nodes']} 节点")
                brain = status['brain']
                if isinstance(brain, dict) and 'swarm' in brain:
                    print(f"  大脑: {brain['swarm']['total_worms']} 蠕虫, {brain['swarm']['total_links']} 连接")
                else:
                    print(f"  大脑: {brain.get('total_worms', '?')} 蠕虫")
                health = status['health']
                print(f"  健康: 异常={health.get('total_anomalies', 0)} 严重={health.get('critical', 0)} 警告={health.get('warning', 0)}")
                print(f"  进化: {status['evolution']['total_evolution']} 次, 成功率 {status['evolution']['success_rate']:.1%}")

            elif cmd == 'evolve':
                print('🔄 执行进化...')
                result = system.evolve()
                if result:
                    print(json.dumps(result, ensure_ascii=False, indent=2))
                else:
                    print('SelfEvolve未初始化')

            elif cmd == 'perceive':
                if not args:
                    print('用法: perceive <文本或URL>')
                    continue
                print(f'👁️ 感知: {args[:50]}...')
                result = system.perceive(args)
                if result:
                    print(f"  ✓ 已存入记忆, 向量维度: {result['embedding_dim']}")
                else:
                    print('  ✗ 未获取到内容')

            elif cmd == 'learn':
                topic = args or '人工智能'
                print(f'📚 学习: {topic}')
                count = system.web_learner.digest(topic, system.knowledge_tree)
                print(f'  ✓ 学到 {count} 条知识')

            elif cmd == 'analyze':
                if not system.hologram:
                    print('⚠️ HoloGram引擎未连接')
                    continue
                print('🔍 分析代码结构...')
                result = system.analyze_code()
                if result:
                    print(f"  ✓ 图谱节点: {len(result.get('nodes', []))}")
                    print(f"  ✓ 图谱边: {len(result.get('edges', []))}")
                else:
                    print('  ✗ 分析失败')

            elif cmd == 'memory':
                stats = system.memory.get_statistics()
                print('\n🧠 记忆系统：')
                print(f"  总条目: {stats['total_entries']}")
                by_level = stats.get('by_level', {})
                print(f"  各层级: L1={by_level.get('L1_WORKING',0)} L2={by_level.get('L2_EXPERIENCE',0)} L3={by_level.get('L3_KNOWLEDGE',0)} L4={by_level.get('L4_META',0)}")
                print(f"  平均置信: {stats['avg_confidence']:.2f}")
                print(f"  冲突解决: {stats.get('total_conflicts', 0)}")
                print(f"  晋升次数: {stats.get('total_promotions', 0)}")
                print('\n  运行维护? (y/n): ', end='')
                if input().lower() == 'y':
                    result = system.memory.run_maintenance()
                    print(f"  ✓ 清理: {result['maintenance']['cleaned']} 条")
                    print(f"  ✓ 晋升: {result['maintenance']['promoted']} 条")

            elif cmd == 'skills':
                caps = system.capability_registry.list_all()
                print(f'\n⚡ 能力列表（共 {len(caps)} 个）：')
                categories = {}
                for cap in caps:
                    cat = cap.category
                    if cat not in categories:
                        categories[cat] = []
                    categories[cat].append(cap)
                for cat, caps_in_cat in categories.items():
                    print(f"\n  [{cat}]")
                    for cap in caps_in_cat[:5]:
                        status = '🟢' if cap.usage_count > 0 else '⚪'
                        print(f"    {status} {cap.id[:40]}... 调用:{cap.usage_count} 成功率:{cap.success_rate:.0%}")
                    if len(caps_in_cat) > 5:
                        print(f"    ... 还有 {len(caps_in_cat) - 5} 个")

            elif cmd == 'mcp':
                stats = system.mcp_discovery.get_stats()
                print(f'\n🔗 MCP服务：')
                print(f"  活跃服务: {stats['transports']}")
                print(f"  连接状态: {stats['connected']}")
                caps = system.capability_registry.list_by_category('code_graph')
                print(f"  code_graph能力: {len(caps)} 个")

            elif cmd == 'cloud':
                if not system.cloud_provider:
                    print('⚠️ 云端模型Provider未加载')
                    continue
                
                while True:
                    providers = system.cloud_provider.list_providers()
                    print(f'\n☁️ 云端模型配置管理：')
                    print(f"  默认Provider: {system.cloud_provider.default_provider_id}")
                    print(f"  \n  Provider列表（共 {len(providers)} 个）：")
                    for p in providers:
                        status = '🟢 启用' if p['available'] else '🔴 未启用'
                        base_url = p['models'][0].get('base_url', '') if p['models'] else ''
                        config_base_url = p.get('base_url', '')
                        url_display = config_base_url or base_url
                        print(f"    [{p['id']}] {p['name']} — {status}")
                        if url_display:
                            print(f"        网址: {url_display}")
                    
                    models = system.cloud_provider.get_available_models()
                    if models:
                        print(f"\n  ✅ 可用模型: {', '.join(models)}")
                    
                    print('\n  操作菜单：')
                    print('    1. 启用Provider')
                    print('    2. 禁用Provider')
                    print('    3. 设置API Key')
                    print('    4. 设置连接网址')
                    print('    5. 设置默认Provider')
                    print('    6. 测试Provider')
                    print('    7. 保存配置')
                    print('    0. 返回')
                    
                    choice = input('\n  请选择操作 [0-7]: ').strip()
                    
                    if choice == '0':
                        break
                    elif choice == '1':
                        pid = input('    输入Provider ID（如 openai/deepseek）: ').strip()
                        if system.cloud_provider.enable_provider(pid):
                            print(f"    ✅ {pid} 已启用")
                        else:
                            print(f"    ❌ {pid} 不存在")
                    elif choice == '2':
                        pid = input('    输入Provider ID: ').strip()
                        if system.cloud_provider.disable_provider(pid):
                            print(f"    ✅ {pid} 已禁用")
                        else:
                            print(f"    ❌ {pid} 不存在")
                    elif choice == '3':
                        pid = input('    输入Provider ID: ').strip()
                        api_key = input('    输入API Key（输入时隐藏）: ')
                        if system.cloud_provider.set_api_key(pid, api_key):
                            print(f"    ✅ {pid} 的API Key已设置（内存中，需保存）")
                            system.cloud_provider.enable_provider(pid)
                            print(f"    ✅ {pid} 已自动启用")
                        else:
                            print(f"    ❌ {pid} 不存在")
                    elif choice == '4':
                        pid = input('    输入Provider ID: ').strip()
                        base_url = input('    输入连接网址（如 https://api.deepseek.com/v1）: ').strip()
                        if system.cloud_provider.set_base_url(pid, base_url):
                            print(f"    ✅ {pid} 的连接网址已设为: {base_url}")
                        else:
                            print(f"    ❌ {pid} 不存在")
                    elif choice == '5':
                        pid = input('    输入默认Provider ID: ').strip()
                        if system.cloud_provider.set_default_provider(pid):
                            print(f"    ✅ 默认Provider已设为 {pid}")
                        else:
                            print(f"    ❌ {pid} 不存在")
                    elif choice == '6':
                        pid = input('    输入Provider ID: ').strip()
                        result = system.cloud_provider.test_provider(pid)
                        if result['success']:
                            print(f"    ✅ 测试成功! 响应: {result['response']}")
                        else:
                            print(f"    ❌ 测试失败: {result['error']}")
                    elif choice == '7':
                        if system.cloud_provider.save_config():
                            print("    ✅ 配置已保存")
                        else:
                            print("    ❌ 保存失败")
                    else:
                        print('    ❌ 无效选项')

            elif cmd == 'chat':
                if not args:
                    print('用法: chat <对话内容>')
                    print('示例: chat 你好，白泽！')
                    continue
                if not system.cloud_provider:
                    print('⚠️ 云端模型Provider未加载')
                    continue
                available = system.cloud_provider.get_available_models()
                if not available:
                    print('⚠️ 暂无启用的云端模型Provider')
                    print('请在 config/cloud_models.json 中启用Provider并设置API Key环境变量')
                    continue
                print(f'🤖 对话（模型: {system.cloud_provider.default_provider_id}）...')
                try:
                    result = system.cloud_provider.chat([{'role': 'user', 'content': args}])
                    print(f'\n白泽> {result}')
                except Exception as e:
                    print(f'❌ 对话失败: {e}')

            elif cmd == 'run':
                iterations = int(args) if args.isdigit() else 5
                print(f'🚀 运行主循环（{iterations}次）...')
                result = system.run(iterations=iterations)
                print(f"\n✓ 完成，成功率: {result['health']['overall']}/100")

            elif cmd == 'auto' or cmd == '自主进化':
                if not args:
                    print('🤖 自主进化模式 — 系统自主运行,无需干预')
                    print('')
                    print('用法:')
                    print('  auto          - 无限自主进化(Ctrl+C停止)')
                    print('  auto 10       - 自主进化10轮')
                    print('  auto 10 5     - 自主进化10轮,每轮间隔5秒')
                    print('  auto gaps     - 仅检测知识盲区')
                    print('')
                    print('自主循环流程:')
                    print('  1. 检测知识盲区 → 选择学习目标')
                    print('  2. 联网学习 → 云端反思')
                    print('  3. 存入知识树+记忆系统')
                    print('  4. 定期进化(每5轮)+记忆维护(每10轮)')
                    continue

                if args == 'gaps':
                    print('🔍 检测知识盲区...')
                    gaps = system.detect_knowledge_gaps(top_k=10)
                    if not gaps:
                        print('✅ 知识树覆盖良好,无盲区')
                    else:
                        print(f'\n发现 {len(gaps)} 个盲区:')
                        for i, g in enumerate(gaps, 1):
                            print(f"  {i}. {g['topic']} (分数:{g['score']:.2f}) - {g['reason']}")
                    continue

                parts = args.split()
                iterations = None
                interval = 2
                if parts and parts[0].isdigit():
                    iterations = int(parts[0])
                    if len(parts) > 1 and parts[1].isdigit():
                        interval = int(parts[1])

                print(f'🤖 启动自主进化{"("+str(iterations)+"轮)" if iterations else "(无限)"}')
                print(f'   间隔: {interval}秒/轮, 按 Ctrl+C 中断')
                print('=' * 60)
                try:
                    result = system.autonomous_loop(max_iterations=iterations, interval=interval)
                    print('\n' + '=' * 60)
                    print(f'✓ 自主进化完成')
                    print(f"  总轮数: {system.cycle_count}")
                    print(f"  成功率: {system._last_success_rate*100:.0f}%")
                except KeyboardInterrupt:
                    print('\n⏸️  自主进化已暂停')

            elif cmd == 'browser' or cmd == '打开浏览器':
                if not system.browser:
                    print('⚠️ 浏览器未加载（Playwright未安装）')
                    print('请执行: pip install playwright && playwright install msedge')
                    continue
                
                if not args:
                    print('用法: browser <平台名> 或 browser open <URL>')
                    print('快捷平台: doubao(豆包) qianwen(千问) kimi chatgpt claude')
                    print('示例: browser doubao 或 browser open https://www.doubao.com')
                    continue
                
                import asyncio
                
                platform_map = {
                    'doubao': 'https://www.doubao.com',
                    'qianwen': 'https://qianwen.alibaba.com',
                    'kimi': 'https://kimi.moonshot.cn',
                    'chatgpt': 'https://chat.openai.com',
                    'claude': 'https://claude.ai',
                    'deepseek': 'https://chat.deepseek.com',
                    'longcat': 'https://longcat.chat',
                    'baidu': 'https://www.baidu.com',
                }
                
                if args.startswith('open '):
                    url = args[5:].strip()
                elif args in platform_map:
                    url = platform_map[args]
                else:
                    url = args
                
                print(f'🌐 打开浏览器: {url}')
                try:
                    asyncio.run(_open_browser_url(system.browser, url))
                except Exception as e:
                    print(f'❌ 打开失败: {e}')

            elif cmd == 'capability':
                if not args:
                    print('用法: capability <能力ID> [参数JSON]')
                    continue
                cap_id = args.split()[0]
                cap_args = ' '.join(args.split()[1:]) if len(args.split()) > 1 else '{}'
                try:
                    args_dict = json.loads(cap_args) if cap_args else {}
                except json.JSONDecodeError:
                    print('参数必须是JSON格式')
                    continue
                try:
                    result = system.capability_registry.invoke(cap_id, args_dict)
                    print(f"\n结果:")
                    print(json.dumps(result, ensure_ascii=False, indent=2)[:500])
                except KeyError:
                    print(f"能力不存在: {cap_id}")
                except Exception as e:
                    print(f"调用失败: {e}")

            elif cmd == 'introduce' or cmd == '自我介绍':
                print("""
  🐉 启迪·白泽 统合体 — 自进化智能体

  我是白泽，一个具有自我进化能力的AI系统。

  🧠 核心能力：
    • 四层记忆架构（感官/短期/长期/永久）
    • 蠕虫大脑群体思维系统
    • 知识图谱自动构建
    • 联网学习与浏览
    • 代码自生长与进化

  ⚡ 能力体系（46+）：
    • Skill 内部能力：搜索、记忆、分析、执行...
    • MCP 外部服务：全息观测站、启迪Agent...
    • Cloud 云端模型：OpenAI、DeepSeek、美团龙猫...

  🌱 进化机制：
    • 共现分析 + 涌现度量
    • 规则匹配 + 评估 + 回滚
    • 代码自生长 + Teacher注入

  💡 输入命令开始交互，输入 help 查看完整命令列表
                """)

            elif cmd == 'clear':
                import os
                os.system('cls' if os.name == 'nt' else 'clear')
                print('=' * 60)
                print('  🎯 启迪·白泽 交互式界面')
                print('=' * 60)

            else:
                print(f"❓ 未知命令: {cmd}，输入 help 查看命令列表")

        except KeyboardInterrupt:
            print('\n👋 再见！')
            break
        except Exception as e:
            print(f"\n❌ 错误: {e}")


def main():
    """命令行入口"""
    import argparse
    parser = argparse.ArgumentParser(description='启迪·白泽 统合体')
    parser.add_argument('--iterations', type=int, default=5, help='迭代次数')
    parser.add_argument('--mode', type=str, default='repl', choices=['run', 'status', 'evolve', 'api', 'repl'], help='运行模式')
    parser.add_argument('--perceive', type=str, default=None, help='感知输入')
    parser.add_argument('--port', type=int, default=5000, help='API端口')
    args = parser.parse_args()

    logger.info('=' * 60)
    logger.info('  启迪·白泽 统合体 — 自进化智能体')
    logger.info('=' * 60)

    system = BaizeSystem()

    if args.perceive:
        result = system.perceive(args.perceive)
        print('\n感知结果:')
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.mode == 'status':
        status = system.get_status()
        print('\n系统状态:')
        import json
        print(json.dumps(status, ensure_ascii=False, indent=2))
    elif args.mode == 'api':
        url = system.start_api(port=args.port)
        print(f'\nAPI服务已启动: {url}')
        print('按 Ctrl+C 停止服务')
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print('\nAPI服务已停止')
    elif args.mode == 'evolve':
        result = system.evolve()
        print('\n进化结果:')
        import json
        print(json.dumps(result, ensure_ascii=False, indent=2))
    elif args.mode == 'run':
        final_status = system.run(iterations=args.iterations)
        print('\n最终状态:')
        import json
        print(json.dumps(final_status, ensure_ascii=False, indent=2))
    else:
        _run_repl(system)


if __name__ == '__main__':
    main()
