"""
HoloGram Bridge — Python↔Rust MCP JSON-RPC 桥接

通过 stdio 调用 hologram-engine.exe，提供代码图谱分析能力:
  - analyze: 扫描项目生成代码图谱
  - explore: 自然语言查询代码
  - impact: BFS影响分析
  - preflight: 变更前预检
  - fragile: 脆弱模块排名
  - blindspots: 盲点检测
  - search: 模糊搜索节点
  - graph_summary: 图概览

引擎位置: C:\\Program Files\\全息观测站\\_up\\engine\\target\\release\\hologram-engine.exe
协议: MCP JSON-RPC 2.0 over stdio (持久会话)
"""
import subprocess
import json
import logging
import time
import threading
import os
from typing import Dict, Any, Optional, List

logger = logging.getLogger('HologramBridge')


class HologramBridge:
    """HoloGram Engine 跨语言桥接 — 持久 stdio 会话"""

    ENGINE_PATH = r'C:\Program Files\全息观测站\_up_\engine\target\release\hologram-engine.exe'
    TIMEOUT = 60
    ANALYZE_POLL_INTERVAL = 2
    ANALYZE_MAX_WAIT = 120

    def __init__(self, engine_path=None):
        self.engine_path = engine_path or self.ENGINE_PATH
        self._proc = None
        self._lock = threading.Lock()
        self._connected = False
        self._message_id = 0
        self._initialized = False
        self._current_project = None

    def connect(self) -> bool:
        """连接 HoloGram Engine"""
        with self._lock:
            if self._connected:
                return True

            if not os.path.exists(self.engine_path):
                logger.error(f'[HoloGram] 引擎不存在: {self.engine_path}')
                return False

            try:
                self._proc = subprocess.Popen(
                    [self.engine_path, 'serve'],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    encoding='utf-8',
                    bufsize=1,
                    universal_newlines=True,
                )

                time.sleep(0.5)

                if self._proc.poll() is not None:
                    stderr = self._proc.stderr.read()
                    logger.error(f'[HoloGram] 进程启动失败: {stderr[:500]}')
                    return False

                # MCP 初始化握手
                if not self._initialize():
                    return False

                self._connected = True
                logger.info('[HoloGram] 桥接已建立')
                return True

            except Exception as e:
                logger.error(f'[HoloGram] 连接失败: {e}')
                return False

    def _initialize(self) -> bool:
        """MCP initialize 握手"""
        resp = self._send_request('initialize', {
            'protocolVersion': '2024-11-05',
            'capabilities': {},
            'clientInfo': {'name': 'baize', 'version': '1.0'},
        })
        if resp and 'result' in resp:
            info = resp['result'].get('serverInfo', {})
            logger.info(f'[HoloGram] 引擎: {info.get("name", "?")} v{info.get("version", "?")}')
            self._initialized = True
            return True
        logger.error(f'[HoloGram] 初始化握手失败: {resp}')
        return False

    def _send_request(self, method: str, params: Dict = None) -> Optional[Dict]:
        """发送 JSON-RPC 请求"""
        if not self._proc or self._proc.poll() is not None:
            logger.warning('[HoloGram] 进程未运行')
            return None

        self._message_id += 1
        req = {
            'jsonrpc': '2.0',
            'id': self._message_id,
            'method': method,
            'params': params or {},
        }

        try:
            self._proc.stdin.write(json.dumps(req) + '\n')
            self._proc.stdin.flush()
            line = self._proc.stdout.readline()
            if not line:
                logger.warning('[HoloGram] 无响应')
                return None
            return json.loads(line)
        except Exception as e:
            logger.error(f'[HoloGram] 请求失败: {e}')
            self._connected = False
            return None

    def call_tool(self, name: str, args: Dict = None) -> Optional[Dict]:
        """调用 MCP 工具"""
        if not self._connected and not self.connect():
            return None

        resp = self._send_request('tools/call', {
            'name': name,
            'arguments': args or {},
        })

        if not resp or 'result' not in resp:
            err = resp.get('error') if resp else None
            logger.error(f'[HoloGram] 工具调用失败 {name}: {err}')
            return None

        content = resp['result'].get('content', [])
        if not content:
            return None

        text = content[0].get('text', '')
        try:
            return json.loads(text)
        except (json.JSONDecodeError, TypeError):
            return {'raw_text': text}

    # ============ 高层 API ============

    def analyze_project(self, project_path: str, wait: bool = True) -> Optional[Dict]:
        """分析项目目录"""
        logger.info(f'[HoloGram] 分析项目: {project_path}')
        result = self.call_tool('hologram_analyze', {'path': project_path})
        if not result:
            return None

        self._current_project = project_path

        if wait and result.get('status') == 'started':
            result = self._wait_for_ready()

        return result

    def _wait_for_ready(self) -> Optional[Dict]:
        """轮询等待分析完成"""
        deadline = time.time() + self.ANALYZE_MAX_WAIT
        while time.time() < deadline:
            time.sleep(self.ANALYZE_POLL_INTERVAL)
            status = self.get_status()
            if status and status.get('phase') == 'ready':
                return status
            if status and status.get('phase') == 'empty':
                logger.warning('[HoloGram] 分析未启动 (phase=empty)')
                return status
        logger.warning('[HoloGram] 分析超时')
        return self.get_status()

    def get_status(self) -> Optional[Dict]:
        """获取引擎状态"""
        return self.call_tool('hologram_status')

    def graph_summary(self) -> Optional[Dict]:
        """获取图概览"""
        return self.call_tool('hologram_graph_summary')

    def search(self, query: str, limit: int = 20) -> Optional[Dict]:
        """模糊搜索节点"""
        return self.call_tool('hologram_search', {'query': query, 'limit': limit})

    def explore(self, query: str = None, symbols: List[str] = None,
                include_source: bool = True) -> Optional[Dict]:
        """统一查询: 自然语言或符号 → 完整信息"""
        args = {'includeSource': include_source}
        if query:
            args['query'] = query
        if symbols:
            args['symbols'] = symbols
        return self.call_tool('hologram_explore', args)

    def impact(self, node_id: str, depth: int = 3) -> Optional[Dict]:
        """BFS 影响分析"""
        return self.call_tool('hologram_impact', {'node_id': node_id, 'depth': depth})

    def preflight(self, files: List[str]) -> Optional[Dict]:
        """变更前预检: 分析文件改动会发生什么"""
        return self.call_tool('hologram_preflight', {'files': files})

    def fragile_modules(self, limit: int = 5) -> Optional[Dict]:
        """脆弱模块排名 (L4封装违规密度)"""
        return self.call_tool('hologram_fragile', {'limit': limit})

    def blindspots(self, filter: str = 'all') -> Optional[Dict]:
        """盲点检测 (L4违规/未锁并发/LLM反馈环)"""
        return self.call_tool('hologram_blindspots', {'filter': filter})

    def coupling_report(self, module_name: str) -> Optional[Dict]:
        """耦合深度报告 (L1-L4)"""
        return self.call_tool('hologram_coupling_report', {'module_name': module_name})

    def community_report(self, min_size: int = 3, max_nodes: int = 20) -> Optional[Dict]:
        """社区聚类报告"""
        return self.call_tool('hologram_community_report',
                              {'min_size': min_size, 'max_nodes': max_nodes})

    def unused_symbols(self, kind_filter: str = 'function,class',
                       limit: int = 20) -> Optional[Dict]:
        """未使用符号检测"""
        return self.call_tool('hologram_unused',
                              {'kind_filter': kind_filter, 'limit': limit})

    def node_info(self, node_id: str) -> Optional[Dict]:
        """单节点完整信息"""
        return self.call_tool('hologram_node', {'node_id': node_id})

    def neighbors(self, node_id: str) -> Optional[Dict]:
        """节点邻居 (按边类型分组)"""
        return self.call_tool('hologram_neighbors', {'node_id': node_id})

    def find_path(self, from_id: str, to_id: str, depth: int = 20) -> Optional[Dict]:
        """两节点间所有路径"""
        return self.call_tool('hologram_path',
                              {'from_id': from_id, 'to_id': to_id, 'depth': depth})

    def delayed_edges(self) -> Optional[Dict]:
        """所有时序边 (非空延迟)"""
        return self.call_tool('hologram_delayed', {})

    def cycles(self, mode: str = 'all') -> Optional[Dict]:
        """数据流循环检测"""
        return self.call_tool('hologram_cycle', {'mode': mode})

    def timeline(self, limit: int = 100, since: str = None) -> Optional[Dict]:
        """因果审计时间线"""
        args = {'limit': limit}
        if since:
            args['since'] = since
        return self.call_tool('hologram_timeline', args)

    def rename_symbol(self, old_name: str, new_name: str,
                      dry_run: bool = False) -> Optional[Dict]:
        """安全重命名 (原子回滚)"""
        return self.call_tool('hologram_rename', {
            'oldName': old_name, 'newName': new_name, 'dryRun': dry_run,
        })

    def health(self, path: str, days: int = 30) -> Optional[Dict]:
        """项目健康快照"""
        return self.call_tool('hologram_run_health', {'path': path, 'days': days})

    def policy_check(self, rules: List[Dict] = None) -> Optional[Dict]:
        """架构边界规则检查"""
        args = {}
        if rules:
            args['rules'] = rules
        return self.call_tool('hologram_policy_check', args)

    # ============ 白泽集成专用 ============

    def learn_code_structure(self, knowledge_tree) -> Dict:
        """将代码图谱摘要学习到知识树"""
        summary = self.graph_summary()
        if not summary:
            return {'learned': 0, 'error': '无法获取图概览'}

        edge_types = summary.get('edge_types', {})
        content = f"""代码结构概览:
节点总数: {summary.get('nodes_total', 0)}
边总数: {summary.get('edges_total', 0)}
符号数: {summary.get('symbols', 0)}
媒体数: {summary.get('media', 0)}
边类型分布: {json.dumps(edge_types, ensure_ascii=False)}
"""
        knowledge_tree.learn(
            f'代码图谱_{self._current_project or "project"}',
            content,
            source='hologram',
        )

        # 学习脆弱模块
        fragile = self.fragile_modules(limit=5)
        if fragile and fragile.get('fragile_modules'):
            frag_content = '\n'.join(
                f"- {m['node_id']}: 脆弱度={m['fragility_score']}"
                for m in fragile['fragile_modules']
            )
            knowledge_tree.learn(
                '脆弱模块排名',
                f'项目最脆弱的模块:\n{frag_content}',
                source='hologram',
            )

        # 学习盲点
        blindspots = self.blindspots()
        if blindspots and blindspots.get('boundaries'):
            bs_content = '\n'.join(
                f"- [{b['severity']}] {b['type']}: {b['desc']}"
                for b in blindspots['boundaries']
            )
            knowledge_tree.learn(
                '代码盲点检测',
                f'检测到的架构问题:\n{bs_content}',
                source='hologram',
            )

        return {
            'learned': 3,
            'nodes': summary.get('nodes_total', 0),
            'edges': summary.get('edges_total', 0),
        }

    def preflight_for_self_evolve(self, files: List[str]) -> Dict:
        """SelfEvolve 修改代码前的预检"""
        result = self.preflight(files)
        if not result:
            return {'safe': True, 'reason': '预检不可用，允许修改'}

        # 解析预检结果
        impacts = result.get('impacts', [])
        risky = [i for i in impacts if i.get('severity') in ('high', 'critical')]

        return {
            'safe': len(risky) == 0,
            'total_impacts': len(impacts),
            'risky_impacts': len(risky),
            'details': risky[:5],
            'raw': result,
        }

    # ============ 生命周期 ============

    def disconnect(self):
        """断开连接"""
        with self._lock:
            if self._proc:
                try:
                    self._proc.stdin.close()
                    self._proc.terminate()
                    self._proc.wait(timeout=5)
                except Exception:
                    pass
                self._proc = None
            self._connected = False
            self._initialized = False
            logger.info('[HoloGram] 桥接已断开')

    def is_connected(self) -> bool:
        """检查连接状态"""
        return self._connected and self._proc and self._proc.poll() is None

    def get_status_report(self) -> Dict:
        """获取桥接状态报告"""
        return {
            'connected': self.is_connected(),
            'engine_path': self.engine_path,
            'initialized': self._initialized,
            'current_project': self._current_project,
            'message_id': self._message_id,
        }
