"""
Qidi Bridge — Python↔Node.js JSON-RPC桥接

设计:
  - subprocess + stdin/stdout JSON-RPC
  - 调用 Qidi Agent 的 SynchronyMeter/EmergenceEvaluator/CapabilityTree/13适配器
  - 不搬码，保持原目录
  - 超时保护 + 重连机制

Qidi Agent 位置: C:\\Users\\ASUS\\Documents\\trae_projects\\ai-orchestrator\\
"""
import subprocess
import json
import logging
import time
import threading
from typing import Dict, Any, Optional

logger = logging.getLogger('QidiBridge')


class QidiBridge:
    """Qidi Agent 跨语言桥接"""

    QIDI_PATH = r'C:\Users\ASUS\Documents\trae_projects\ai-orchestrator'
    RPC_SCRIPT = 'qidi_rpc.js'
    TIMEOUT = 30
    RETRY_COUNT = 3
    RETRY_DELAY = 2

    def __init__(self, qidi_path=None, rpc_script=None):
        self.qidi_path = qidi_path or self.QIDI_PATH
        self.rpc_script = rpc_script or self.RPC_SCRIPT
        self._proc = None
        self._lock = threading.Lock()
        self._connected = False
        self._message_id = 0

    def connect(self) -> bool:
        """连接 Qidi Agent"""
        with self._lock:
            if self._connected:
                return True

            try:
                self._proc = subprocess.Popen(
                    ['node', self.rpc_script],
                    cwd=self.qidi_path,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    encoding='utf-8',
                    bufsize=1,
                    universal_newlines=True,
                )

                time.sleep(1)

                if self._proc.poll() is not None:
                    stderr = self._proc.stderr.read()
                    logger.error(f'[Qidi] 进程启动失败: {stderr}')
                    return False

                self._connected = True
                logger.info('[Qidi] 桥接已建立')
                return True

            except Exception as e:
                logger.error(f'[Qidi] 连接失败: {e}')
                return False

    def disconnect(self):
        """断开连接"""
        with self._lock:
            if self._proc:
                try:
                    self._proc.stdin.close()
                    self._proc.terminate()
                    self._proc.wait(timeout=5)
                except Exception:
                    pass
                self._proc = None
            self._connected = False
            logger.info('[Qidi] 桥接已断开')

    def call(self, method: str, params: Dict[str, Any] = None) -> Optional[Dict[str, Any]]:
        """
        调用 Qidi Agent 方法

        Args:
            method: RPC方法名
            params: 参数字典

        Returns:
            RPC响应结果
        """
        if not self._connected and not self.connect():
            logger.error('[Qidi] 未连接，无法调用')
            return None

        params = params or {}
        self._message_id += 1

        request = {
            'jsonrpc': '2.0',
            'id': self._message_id,
            'method': method,
            'params': params,
        }

        for attempt in range(self.RETRY_COUNT):
            try:
                with self._lock:
                    if not self._proc or self._proc.poll() is not None:
                        if not self.connect():
                            return None

                    self._proc.stdin.write(json.dumps(request) + '\n')
                    self._proc.stdin.flush()

                    line = self._proc.stdout.readline()
                    if not line:
                        logger.warning('[Qidi] 无响应，尝试重连')
                        self._connected = False
                        self.connect()
                        continue

                response = json.loads(line)

                if 'error' in response:
                    logger.error(f'[Qidi] RPC错误: {response["error"]}')
                    return None

                return response.get('result')

            except json.JSONDecodeError as e:
                logger.error(f'[Qidi] JSON解析失败: {e}')
            except Exception as e:
                logger.error(f'[Qidi] 调用失败 (尝试{attempt+1}/{self.RETRY_COUNT}): {e}')
                if attempt < self.RETRY_COUNT - 1:
                    time.sleep(self.RETRY_DELAY)
                    self._connected = False

        return None

    def analyze_code(self, code: str, language: str = 'python') -> Optional[Dict[str, Any]]:
        """分析代码"""
        return self.call('analyze_code', {'code': code, 'language': language})

    def evaluate_emergence(self, metrics: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """评估涌现度"""
        return self.call('evaluate_emergence', {'metrics': metrics})

    def get_capability_tree(self) -> Optional[Dict[str, Any]]:
        """获取能力树"""
        return self.call('get_capability_tree')

    def run_task(self, task: str, mode: str = 'quality') -> Optional[Dict[str, Any]]:
        """运行任务"""
        return self.call('run_task', {'task': task, 'mode': mode})

    def chat(self, message: str, provider: str = None) -> Optional[Dict[str, Any]]:
        """聊天接口"""
        params = {'message': message}
        if provider:
            params['provider'] = provider
        return self.call('chat', params)

    def get_tools(self) -> Optional[Dict[str, Any]]:
        """获取工具列表"""
        return self.call('get_tools')

    def is_connected(self) -> bool:
        """检查连接状态"""
        return self._connected and self._proc and self._proc.poll() is None

    def get_status(self) -> Dict[str, Any]:
        """获取桥接状态"""
        return {
            'connected': self.is_connected(),
            'qidi_path': self.qidi_path,
            'rpc_script': self.rpc_script,
            'message_id': self._message_id,
        }
