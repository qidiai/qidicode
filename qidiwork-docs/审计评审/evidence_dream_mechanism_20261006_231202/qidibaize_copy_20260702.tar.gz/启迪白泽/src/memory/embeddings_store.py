"""
向量存储 — V10向量的存储与检索

设计:
  - 优先使用 numpy 矩阵加速检索
  - 支持 StorageBackend 持久化（SQLite），降级到 JSON
  - 支持增量更新
  - 相似度搜索（余弦相似度）
"""
import json
import math
import time
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional

logger = logging.getLogger('EmbeddingsStore')


class EmbeddingsStore:
    """向量存储与检索"""

    def __init__(self, dim=1024, store_path=None, storage_backend=None):
        self.dim = dim
        self.store_path = Path(store_path) if store_path else Path('data/memory/embeddings.json')
        self.store_path.parent.mkdir(parents=True, exist_ok=True)
        self.backend = storage_backend

        self._vectors: Dict[str, List[float]] = {}
        self._metadata: Dict[str, Dict[str, Any]] = {}
        self._index_built = False
        # numpy 矩阵缓存（启动时构建，add/delete 后失效）
        self._matrix = None
        self._keys = []
        self._key_to_idx = {}

        self._load()

    def _load(self):
        """从存储加载 — 优先 backend，降级 JSON"""
        if self.backend is not None:
            self._load_from_backend()
        elif self.store_path.exists():
            try:
                data = json.loads(self.store_path.read_text('utf-8'))
                self._vectors = data.get('vectors', {})
                self._metadata = data.get('metadata', {})
                logger.info(f'[向量存储] 已加载 {len(self._vectors)} 个向量')
            except Exception as e:
                logger.error(f'[向量存储] 加载失败: {e}')

    def _load_from_backend(self):
        """从 SQLite 加载 — 复用 knowledge_nodes 表的 embedding 列"""
        # 向量存储在 knowledge_nodes 表的 embedding 字段中
        # 这里只做缓存用，不重复存储
        rows = self.backend.query('knowledge_nodes')
        count = 0
        for row in rows:
            emb = row.get('embedding')
            if emb:
                try:
                    vec = json.loads(emb) if isinstance(emb, str) else emb
                    if vec and len(vec) == self.dim:
                        self._vectors[row['id']] = vec
                        self._metadata[row['id']] = {
                            'topic': row.get('topic', ''),
                            'source': row.get('source', ''),
                        }
                        count += 1
                except Exception:
                    pass
        if count:
            logger.info(f'[向量存储] 从 SQLite 加载 {count} 个向量')

    def _build_matrix(self):
        """构建 numpy 矩阵 — 启动时或缓存失效后调用"""
        try:
            import numpy as _np
            if not self._vectors:
                self._matrix = None
                self._index_built = True
                return
            self._keys = list(self._vectors.keys())
            self._key_to_idx = {k: i for i, k in enumerate(self._keys)}
            self._matrix = _np.array([self._vectors[k] for k in self._keys])
            # 预归一化
            norms = _np.linalg.norm(self._matrix, axis=1, keepdims=True)
            norms[norms < 1e-9] = 1.0
            self._matrix = self._matrix / norms
            self._index_built = True
        except ImportError:
            self._index_built = True  # 无 numpy 也标记为已构建，走纯 Python

    def save(self):
        """持久化 — backend 模式下向量已存在 knowledge_nodes 表，无需单独保存"""
        if self.backend is not None:
            return  # 向量随 KnowledgeTree 一起保存
        data = {
            'dim': self.dim,
            'vectors': self._vectors,
            'metadata': self._metadata,
            'updated_at': time.time(),
        }
        self.store_path.write_text(json.dumps(data, ensure_ascii=False), 'utf-8')
        logger.debug(f'[向量存储] 已保存 {len(self._vectors)} 个向量')

    def add(self, key: str, vector: List[float], metadata: Dict[str, Any] = None):
        """添加向量"""
        if len(vector) != self.dim:
            if len(vector) > self.dim:
                vector = vector[:self.dim]
            else:
                vector = vector + [0.0] * (self.dim - len(vector))

        self._vectors[key] = vector
        if metadata:
            self._metadata[key] = metadata
        self._index_built = False

    def get(self, key: str) -> Optional[List[float]]:
        """获取向量"""
        return self._vectors.get(key)

    def get_metadata(self, key: str) -> Optional[Dict[str, Any]]:
        """获取元数据"""
        return self._metadata.get(key)

    def delete(self, key: str):
        """删除向量"""
        self._vectors.pop(key, None)
        self._metadata.pop(key, None)
        self._index_built = False

    def search(self, query: List[float], top_k=5, min_score=0.1) -> List[Dict[str, Any]]:
        """相似度搜索 — 优先 numpy 矩阵乘法，降级纯 Python"""
        if len(self._vectors) == 0:
            return []

        # 优先用 numpy 矩阵
        if not self._index_built:
            self._build_matrix()

        if self._matrix is not None:
            return self._search_numpy(query, top_k, min_score)
        return self._search_python(query, top_k, min_score)

    def _search_numpy(self, query: List[float], top_k: int, min_score: float) -> List[Dict[str, Any]]:
        """numpy 批量余弦相似度 — 矩阵乘法"""
        import numpy as _np
        q = _np.array(query[:self.dim])
        q_norm = _np.linalg.norm(q)
        if q_norm < 1e-9:
            return []
        q_unit = q / q_norm
        # 矩阵已预归一化，直接点积
        sims = self._matrix @ q_unit
        # 取 top_k
        indices = _np.argsort(sims)[::-1][:top_k]
        results = []
        for idx in indices:
            score = float(sims[idx])
            if score < min_score:
                break
            key = self._keys[idx]
            results.append({
                'key': key,
                'score': round(score, 4),
                'metadata': self._metadata.get(key, {}),
            })
        return results

    def _search_python(self, query: List[float], top_k: int, min_score: float) -> List[Dict[str, Any]]:
        """纯 Python 余弦相似度（降级）"""
        results = []
        for key, vector in self._vectors.items():
            score = self._cosine_similarity(query, vector)
            if score >= min_score:
                results.append({
                    'key': key,
                    'score': round(score, 4),
                    'metadata': self._metadata.get(key, {}),
                })
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:top_k]

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """余弦相似度"""
        try:
            import numpy as _np
            va, vb = _np.array(a), _np.array(b)
            d = _np.dot(va, vb)
            na, nb = _np.linalg.norm(va), _np.linalg.norm(vb)
            if na < 1e-9 or nb < 1e-9:
                return 0.0
            return float(d / (na * nb))
        except ImportError:
            dot = sum(x * y for x, y in zip(a, b))
            norm_a = math.sqrt(sum(x * x for x in a))
            norm_b = math.sqrt(sum(x * x for x in b))
            if norm_a < 1e-9 or norm_b < 1e-9:
                return 0.0
            return dot / (norm_a * norm_b)

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'total_vectors': len(self._vectors),
            'dimension': self.dim,
            'total_metadata': len(self._metadata),
            'matrix_built': self._index_built and self._matrix is not None,
        }

    def batch_add(self, items: List[Dict[str, Any]]):
        """批量添加"""
        for item in items:
            self.add(item['key'], item['vector'], item.get('metadata'))

    def batch_search(self, queries: List[List[float]], top_k=5) -> List[List[Dict[str, Any]]]:
        """批量搜索"""
        return [self.search(q, top_k) for q in queries]
