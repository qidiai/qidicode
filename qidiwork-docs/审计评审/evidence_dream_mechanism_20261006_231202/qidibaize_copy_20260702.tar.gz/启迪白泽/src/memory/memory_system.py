"""
记忆系统 — 四层分层架构 + 置信分算法 + 矛盾消解

设计灵感：
- 元系统 meta_agent_v3.py 的 SourcePool（源池）→ 短期记忆
- 元系统的 Knowledge（知识分叉）→ 长期记忆
- 涌现理论 L1-L10 → 记忆分层的理论依据
- 知识树（磁场.py / master_scout.py）→ 矛盾消解机制
"""

import time
import math
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum, auto
from collections import defaultdict


class MemoryLevel(Enum):
    """四层记忆分层"""
    L1_WORKING = auto()     # 短期工作记忆（任务上下文，TTL 1小时）
    L2_EXPERIENCE = auto()  # 中期经验记忆（Skill调用模式，TTL 7天）
    L3_KNOWLEDGE = auto()   # 长期知识记忆（沉淀为可复用Skill，永久）
    L4_META = auto()        # 元认知记忆（进化规则、策略，永久）


@dataclass
class MemoryEntry:
    """记忆条目"""
    key: str                        # 唯一键
    content: Any                    # 内容
    level: MemoryLevel              # 层级
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    access_count: int = 0           # 访问次数
    success_count: int = 0          # 成功次数
    fail_count: int = 0             # 失败次数
    ttl_seconds: float = 3600.0     # TTL（秒）
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def is_expired(self) -> bool:
        return (time.time() - self.updated_at) > self.ttl_seconds
    
    @property
    def confidence_score(self) -> float:
        """记忆置信分算法"""
        if self.access_count == 0:
            return 0.0
        
        # 置信分 = 使用频率×0.3 + 成功率×0.3 + 时间衰减×0.2 + 人工验证×0.2
        freq_score = min(self.access_count / 100.0, 1.0)  # 归一化到 0-1
        success_rate = self.success_count / (self.success_count + self.fail_count) if (self.success_count + self.fail_count) > 0 else 0.5
        
        # 时间衰减：越新的记忆衰减越少
        age_hours = (time.time() - self.updated_at) / 3600.0
        recency_decay = max(0.0, 1.0 - age_hours / 168.0)  # 7天后衰减到0
        
        expert_validation = self.metadata.get('expert_validated', 0.0)  # 0.0 或 1.0
        
        score = (
            freq_score * 0.3 +
            success_rate * 0.3 +
            recency_decay * 0.2 +
            expert_validation * 0.2
        )
        return min(score, 1.0)
    
    def record_access(self, success: bool = True):
        """记录一次访问"""
        self.access_count += 1
        self.updated_at = time.time()
        if success:
            self.success_count += 1
        else:
            self.fail_count += 1


class ConflictResolver:
    """矛盾消解器 — 当新知识与旧知识冲突时裁决"""
    
    def resolve(self, old_entry: MemoryEntry, new_entry: MemoryEntry) -> Tuple[MemoryEntry, str]:
        """
        消解两个冲突的记忆条目
        
        Returns:
            (winner, reason) — 获胜条目和消解原因
        """
        old_score = old_entry.confidence_score
        new_score = new_entry.confidence_score
        
        # 策略1：置信分高者胜
        if abs(old_score - new_score) > 0.05:  # 5% 阈值
            winner = new_entry if new_score > old_score else old_entry
            reason = f"置信分更高 ({new_score:.3f} vs {old_score:.3f})"
            return winner, reason
        
        # 策略2：人工验证优先
        if new_entry.metadata.get('expert_validated', False) and not old_entry.metadata.get('expert_validated', False):
            return new_entry, "新条目经人工验证"
        if old_entry.metadata.get('expert_validated', False) and not new_entry.metadata.get('expert_validated', False):
            return old_entry, "旧条目经人工验证"
        
        # 策略3：使用频率优先
        if new_entry.access_count > old_entry.access_count * 1.5:
            return new_entry, "新条目使用频率显著更高"
        if old_entry.access_count > new_entry.access_count * 1.5:
            return old_entry, "旧条目使用频率显著更高"
        
        # 策略4：默认保留旧的（保守策略）
        return old_entry, "置信分相近且无验证，保留旧条目（保守策略）"


class MemorySystem:
    """
    记忆系统 — 核心枢纽
    
    功能：
    1. 四层记忆分层存储
    2. 动态分层调整（高频任务提升优先级）
    3. 记忆置信分评估
    4. 矛盾消解
    5. 过期清理
    """
    
    def __init__(self, storage_backend=None):
        self.storage: Dict[str, MemoryEntry] = {}  # key -> MemoryEntry
        self.index_by_level: Dict[MemoryLevel, List[str]] = defaultdict(list)
        self.index_by_tag: Dict[str, List[str]] = defaultdict(list)  # tag -> [keys]
        self.conflict_resolver = ConflictResolver()
        self.evolution_log: List[Dict] = []  # 记录每次进化操作
        self.backend = storage_backend  # StorageBackend 实例，None 时纯内存
        if self.backend is not None:
            self._load_from_backend()
        
    def store(self, key: str, content: Any, level: MemoryLevel,
              ttl_seconds: float = None, tags: List[str] = None,
              metadata: Dict = None) -> MemoryEntry:
        """存入记忆"""
        existing = self.storage.get(key)

        if existing and not existing.is_expired:
            # 已有条目：检查是否需要更新（矛盾消解）
            if existing.content != content:
                winner, reason = self.conflict_resolver.resolve(existing,
                    MemoryEntry(key=key, content=content, level=level, metadata=metadata or {}))
                if winner is existing:
                    existing.updated_at = time.time()
                    existing.metadata.update(metadata or {})
                    self._log_evolution("conflict_resolved", key, reason, level)
                    self._save_entry(key, existing)
                else:
                    self._replace_entry(key, content, level, ttl_seconds, tags, metadata)
                    self._log_evolution("conflict_overwritten", key, reason, level)
            else:
                existing.updated_at = time.time()
                existing.metadata.update(metadata or {})
                self._save_entry(key, existing)
            return existing

        # 新条目
        ttl = ttl_seconds or self._default_ttl(level)
        entry = MemoryEntry(
            key=key,
            content=content,
            level=level,
            ttl_seconds=ttl,
            metadata=metadata or {}
        )
        self._add_entry(entry, tags)
        self._save_entry(key, entry)
        self._log_evolution("stored", key, f"level={level.name}", level)
        return entry
    
    def retrieve(self, key: str) -> Optional[MemoryEntry]:
        """检索记忆"""
        entry = self.storage.get(key)
        if entry and not entry.is_expired:
            entry.record_access(success=True)
            self._save_entry(key, entry)
            return entry
        elif entry and entry.is_expired:
            self._remove_entry(key)
            self._log_evolution("expired", key, "TTL到期", entry.level)
        return None
    
    def query_by_level(self, level: MemoryLevel, limit: int = 20) -> List[MemoryEntry]:
        """按层级查询"""
        keys = self.index_by_level.get(level, [])
        entries = []
        for key in keys:
            entry = self.storage.get(key)
            if entry and not entry.is_expired:
                entries.append(entry)
        # 按置信分降序
        entries.sort(key=lambda e: e.confidence_score, reverse=True)
        return entries[:limit]
    
    def query_by_tag(self, tag: str, limit: int = 20) -> List[MemoryEntry]:
        """按标签查询"""
        keys = self.index_by_tag.get(tag, [])
        entries = []
        for key in keys:
            entry = self.storage.get(key)
            if entry and not entry.is_expired:
                entries.append(entry)
        entries.sort(key=lambda e: e.confidence_score, reverse=True)
        return entries[:limit]
    
    def promote_to_higher_level(self, key: str, target_level: MemoryLevel) -> bool:
        """
        动态分层：将记忆提升到更高层级
        触发条件：高频访问 + 高成功率
        """
        entry = self.storage.get(key)
        if not entry or entry.is_expired:
            return False
        
        if entry.level.value >= target_level.value:
            return False  # 已经是更高层级或同级
        
        # 检查是否满足晋升条件
        if entry.access_count < 10:
            return False  # 访问太少
        
        success_rate = entry.success_count / (entry.success_count + entry.fail_count) if (entry.success_count + entry.fail_count) > 0 else 0
        if success_rate < 0.7:
            return False  # 成功率太低
        
        old_level = entry.level
        entry.level = target_level
        entry.ttl_seconds = self._default_ttl(target_level)
        self._save_entry(key, entry)
        self._log_evolution("promoted", key, f"{old_level.name} → {target_level.name}", target_level)
        return True
    
    def demote_to_lower_level(self, key: str, target_level: MemoryLevel) -> bool:
        """降级到更低层级（淘汰低效记忆）"""
        entry = self.storage.get(key)
        if not entry or entry.is_expired:
            return False
        
        if entry.level.value <= target_level.value:
            return False
        
        old_level = entry.level
        entry.level = target_level
        entry.ttl_seconds = self._default_ttl(target_level)
        self._log_evolution("demoted", key, f"{old_level.name} → {target_level.name}", target_level)
        return True
    
    def cleanup_expired(self) -> int:
        """清理过期记忆 + 分级遗忘策略"""
        now = time.time()
        expired_keys = []
        forget_keys = []

        for key, entry in list(self.storage.items()):
            if entry.is_expired:
                expired_keys.append((key, entry.level))
                continue
            conf = entry.confidence_score
            age_seconds = now - entry.updated_at
            # 分级遗忘
            if entry.level == MemoryLevel.L1_WORKING:
                if conf < 0.1 and age_seconds > 7 * 86400:
                    forget_keys.append((key, entry.level))
            elif entry.level == MemoryLevel.L2_EXPERIENCE:
                if conf < 0.05 and age_seconds > 30 * 86400:
                    forget_keys.append((key, entry.level))
            elif entry.level in (MemoryLevel.L3_KNOWLEDGE, MemoryLevel.L4_META):
                if conf < 0.01:
                    entry.metadata['pending_review'] = True
                    self._save_entry(key, entry)

        for key, level in expired_keys + forget_keys:
            reason = "TTL过期" if (key, level) in expired_keys else "低置信遗忘"
            self._remove_entry(key)
            self._log_evolution("cleaned", key, reason, level)

        return len(expired_keys) + len(forget_keys)
    
    def get_statistics(self) -> Dict:
        """获取记忆系统统计"""
        stats = {
            'total_entries': len(self.storage),
            'by_level': {},
            'avg_confidence': 0.0,
            'total_conflicts': 0,
            'total_promotions': 0,
        }
        
        confidences = []
        for entry in self.storage.values():
            if not entry.is_expired:
                confidences.append(entry.confidence_score)
                level_name = entry.level.name
                stats['by_level'][level_name] = stats['by_level'].get(level_name, 0) + 1
        
        stats['avg_confidence'] = sum(confidences) / len(confidences) if confidences else 0.0
        
        # 从进化日志中统计
        for log in self.evolution_log:
            if log['action'] == 'conflict_resolved':
                stats['total_conflicts'] += 1
            elif log['action'] == 'promoted':
                stats['total_promotions'] += 1
        
        return stats
    
    def _add_entry(self, entry: MemoryEntry, tags: List[str] = None):
        """内部：添加条目到存储和索引"""
        self.storage[entry.key] = entry
        self.index_by_level[entry.level].append(entry.key)
        if tags:
            for tag in tags:
                self.index_by_tag[tag].append(entry.key)
    
    def _replace_entry(self, key: str, content: Any, level: MemoryLevel, 
                       ttl: float = None, tags: List[str] = None, metadata: Dict = None):
        """内部：替换条目"""
        if key in self.storage:
            self._remove_entry(key)
        self.store(key, content, level, ttl, tags, metadata)
    
    def _remove_entry(self, key: str):
        """内部：移除条目"""
        entry = self.storage.pop(key, None)
        if entry:
            if key in self.index_by_level.get(entry.level, []):
                self.index_by_level[entry.level].remove(key)
            for tag_keys in self.index_by_tag.values():
                if key in tag_keys:
                    tag_keys.remove(key)
            if self.backend is not None:
                try:
                    self.backend.delete('memory_entries', key)
                except Exception:
                    pass
    
    def _default_ttl(self, level: MemoryLevel) -> float:
        """默认TTL"""
        ttls = {
            MemoryLevel.L1_WORKING: 3600.0,       # 1小时
            MemoryLevel.L2_EXPERIENCE: 604800.0,   # 7天
            MemoryLevel.L3_KNOWLEDGE: float('inf'), # 永久
            MemoryLevel.L4_META: float('inf'),      # 永久
        }
        return ttls[level]
    
    def _log_evolution(self, action: str, key: str, detail: str, level: MemoryLevel):
        """记录进化操作"""
        self.evolution_log.append({
            'timestamp': time.time(),
            'action': action,
            'key': key,
            'detail': detail,
            'level': level.name,
        })
        # 只保留最近 1000 条
        if len(self.evolution_log) > 1000:
            self.evolution_log = self.evolution_log[-1000:]

    # ===== 持久化 + 进化维护 =====

    def auto_promote(self) -> int:
        """自动晋升检查 — 扫描所有记忆，满足条件则晋升"""
        promoted = 0
        now = time.time()
        for key, entry in list(self.storage.items()):
            if entry.is_expired:
                continue
            age_seconds = now - entry.created_at
            total = entry.success_count + entry.fail_count
            success_rate = entry.success_count / total if total > 0 else 0

            target = None
            if entry.level == MemoryLevel.L1_WORKING:
                if entry.access_count >= 10 and success_rate >= 0.7 and age_seconds > 3600:
                    target = MemoryLevel.L2_EXPERIENCE
            elif entry.level == MemoryLevel.L2_EXPERIENCE:
                if entry.access_count >= 50 and success_rate >= 0.8 and age_seconds > 7 * 86400:
                    target = MemoryLevel.L3_KNOWLEDGE
            elif entry.level == MemoryLevel.L3_KNOWLEDGE:
                if entry.access_count >= 200 and success_rate >= 0.9:
                    target = MemoryLevel.L4_META

            if target and self.promote_to_higher_level(key, target):
                promoted += 1
        return promoted

    def run_maintenance(self) -> Dict:
        """周期性维护 — 遗忘 + 晋升 + 统计"""
        cleaned = self.cleanup_expired()
        promoted = self.auto_promote()
        stats = self.get_statistics()
        stats['maintenance'] = {
            'cleaned': cleaned,
            'promoted': promoted,
            'timestamp': time.time(),
        }
        return stats

    def _save_entry(self, key: str, entry: MemoryEntry):
        """增量保存单条记忆到 backend"""
        if self.backend is None:
            return
        try:
            data = {
                'key': key,
                'content': json.dumps(entry.content, ensure_ascii=False),
                'level': entry.level.name,
                'created_at': entry.created_at,
                'updated_at': entry.updated_at,
                'access_count': entry.access_count,
                'success_count': entry.success_count,
                'fail_count': entry.fail_count,
                'ttl_seconds': entry.ttl_seconds,
                'metadata': json.dumps(entry.metadata, ensure_ascii=False),
                'tags': '',
            }
            self.backend.upsert('memory_entries', key, data)
        except Exception as e:
            print(f"[MemorySystem] 保存记忆失败 {key}: {e}")

    def _load_from_backend(self):
        """从 SQLite 加载所有记忆"""
        rows = self.backend.load_table('memory_entries')
        loaded = 0
        for row in rows:
            try:
                level = MemoryLevel[row['level']]
                content = json.loads(row['content']) if row.get('content') else None
                metadata = json.loads(row['metadata']) if row.get('metadata') else {}
                entry = MemoryEntry(
                    key=row['key'],
                    content=content,
                    level=level,
                    created_at=row.get('created_at', time.time()),
                    updated_at=row.get('updated_at', time.time()),
                    access_count=row.get('access_count', 0),
                    success_count=row.get('success_count', 0),
                    fail_count=row.get('fail_count', 0),
                    ttl_seconds=row.get('ttl_seconds', 3600.0),
                    metadata=metadata,
                )
                # 直接写入 storage 和索引，不触发 _save_entry
                self.storage[entry.key] = entry
                self.index_by_level[entry.level].append(entry.key)
                loaded += 1
            except Exception as e:
                print(f"[MemorySystem] 加载记忆失败 {row.get('key')}: {e}")
        if loaded:
            print(f"[MemorySystem] 从 SQLite 加载 {loaded} 条记忆")
