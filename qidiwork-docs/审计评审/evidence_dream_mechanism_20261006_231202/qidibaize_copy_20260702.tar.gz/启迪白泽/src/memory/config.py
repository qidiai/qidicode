EMBED_DIM = 1024
EMBED_CACHE_SIZE = 100

JUNK_KEYWORDS = [
    'def ', 'import ', 'class ', 'function ', 'var ', 'let ', 'const ',
    '<html', '<body', '<div', '<script', '</script', '<style', '</style',
    '&nbsp;', 'undefined', 'null', 'true', 'false',
]

SCIENCE_PROTECT_KEYWORDS = [
    '物理', '化学', '生物', '数学', '天文', '遗传', '细胞',
    '免疫', '药理', '分子', '量子', '相对论', '统计', '粒子',
    '算法', '编程', '开发', '数据库', '网络', '深度学习', '机器学习',
]
