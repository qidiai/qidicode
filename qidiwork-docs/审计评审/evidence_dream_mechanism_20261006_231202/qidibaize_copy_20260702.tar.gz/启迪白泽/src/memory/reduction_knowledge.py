# reduction_knowledge_tree.py — 归约知识树（整合冲突检测+假设生成）
"""
归约知识树：不是简单存储，而是自动归约分布式结果。
流程：ingest_result → 归约到主干 / 冲突聚合 → hypothesize → verify
"""
import json
import os
import time
from typing import List, Dict, Optional
from dataclasses import dataclass, field


@dataclass
class Hypothesis:
    """知识冲突假设"""
    domain: str
    description: str
    status: str = "pending"  # pending / verified / rejected
    evidence: Dict = field(default_factory=dict)

    def to_dict(self):
        return {"domain": self.domain, "description": self.description, "status": self.status, "evidence": self.evidence}


@dataclass
class KnowledgeNode:
    """知识树节点"""
    name: str
    description: str
    parent: Optional[str] = None
    children: List[str] = field(default_factory=list)
    metadata: Dict = field(default_factory=dict)

    def to_dict(self):
        return {"name": self.name, "description": self.description, "parent": self.parent, "children": self.children, "metadata": self.metadata}

    @classmethod
    def from_dict(cls, d):
        return cls(name=d["name"], description=d["description"], parent=d.get("parent"), children=d.get("children", []), metadata=d.get("metadata", {}))


class ReductionKnowledgeTree:
    """归约知识树：自动归约分布式结果，检测冲突，生成假设"""

    def __init__(self, data_dir: str = "data", storage_backend=None):
        self.data_dir = data_dir
        self.save_path = os.path.join(data_dir, "reduction_knowledge_tree.json")
        self.backend = storage_backend  # StorageBackend 实例，None 时降级 JSON
        self.nodes: Dict[str, KnowledgeNode] = {}
        self.root_id = "root"
        self.conflict_groups: Dict[str, Dict] = {}  # domain -> {"count", "values", "nodes"}
        self.hypotheses: List[Hypothesis] = []
        self._init_root()
        self.load()

    def _init_root(self):
        """初始化根节点"""
        self.nodes[self.root_id] = KnowledgeNode(
            name="分布式计算主干",
            description="所有分布式计算结果的归约根节点",
            parent=None,
        )
        # 预定义主干分类
        for name, desc in [
            ("训练结果", "模型训练准确率/损失值"),
            ("推理结果", "模型推理速度/正确率"),
            ("爬虫结果", "网页采集成功率/数据质量"),
            ("代码分析", "代码审查/bug检测结果"),
            ("资源监控", "CPU/GPU/内存/温度状态"),
            ("异常事件", "节点故障/网络异常/超时"),
        ]:
            self._add_child(self.root_id, name, desc)

    def _add_child(self, parent_id: str, name: str, description: str, metadata: Dict = None) -> str:
        node_id = f"{name}_{len(self.nodes)}"
        node = KnowledgeNode(name=name, description=description, parent=parent_id, metadata=metadata or {})
        self.nodes[node_id] = node
        self.nodes[parent_id].children.append(node_id)
        return node_id

    def _find_trunk(self, domain: str) -> Optional[str]:
        """根据 domain 找到对应的主干节点"""
        trunk_map = {
            "train": "训练结果", "training": "训练结果", "acc": "训练结果",
            "inference": "推理结果", "predict": "推理结果", "ocr": "推理结果",
            "crawl": "爬虫结果", "spider": "爬虫结果", "fetch": "爬虫结果",
            "code": "代码分析", "lint": "代码分析", "review": "代码分析",
            "monitor": "资源监控", "cpu": "资源监控", "gpu": "资源监控", "memory": "资源监控",
            "error": "异常事件", "timeout": "异常事件", "fail": "异常事件",
        }
        trunk_name = trunk_map.get(domain.lower().split("_")[0], None)
        if trunk_name:
            for node_id, node in self.nodes.items():
                if node.name == trunk_name and node.parent == self.root_id:
                    return node_id
        return None

    def _matches_trunk(self, trunk_id: str, value: float) -> bool:
        """检查值是否匹配主干的预期范围"""
        trunk = self.nodes[trunk_id]
        # 不同主干有不同的归约规则
        if trunk.name == "训练结果":
            return 0.0 <= value <= 1.0  # 准确率
        elif trunk.name == "推理结果":
            return 0.0 <= value <= 10.0  # 推理速度(s)或准确率
        elif trunk.name == "爬虫结果":
            return 0.0 <= value <= 1.0  # 成功率
        elif trunk.name == "资源监控":
            return 0.0 <= value <= 100.0  # 百分比
        elif trunk.name == "异常事件":
            return value > 0  # 异常计数
        return True

    def ingest_result(self, result: Dict) -> str:
        """
        归约分布式结果到知识树
        返回: "归约(主干名)" / "冲突(已聚合)"
        """
        domain = result.get("domain", "unknown")
        value = result.get("value", 0.0)
        node_id = result.get("node_id", "unknown")

        trunk_id = self._find_trunk(domain)
        if trunk_id and self._matches_trunk(trunk_id, value):
            # 可以归约到主干
            trunk = self.nodes[trunk_id]
            leaf_id = self._add_child(
                trunk_id,
                f"{domain}_{node_id}",
                f"{value} (from {node_id})",
                metadata={"domain": domain, "value": value, "node_id": node_id}
            )
            return f"归约({trunk.name})"

        # 无法归约 → 冲突聚合
        if domain not in self.conflict_groups:
            self.conflict_groups[domain] = {"count": 0, "values": [], "nodes": []}
        self.conflict_groups[domain]["count"] += 1
        self.conflict_groups[domain]["values"].append(value)
        self.conflict_groups[domain]["nodes"].append(node_id)
        return "冲突(已聚合)"

    def hypothesize(self) -> List[Hypothesis]:
        """针对冲突生成假设"""
        new_hypotheses = []
        for domain, info in self.conflict_groups.items():
            if info["count"] >= 3:
                # 冲突多次出现，生成假设
                avg_v = sum(info["values"]) / len(info["values"]) if info["values"] else 0
                already = any(h.domain == domain for h in self.hypotheses)
                if not already:
                    hypo = Hypothesis(
                        domain=domain,
                        description=f"{domain} 存在异常模式，平均值={avg_v:.3f}，可能需调整配置或检查节点 {info['nodes']}",
                        status="pending",
                        evidence={"values": info["values"], "nodes": info["nodes"], "avg": avg_v}
                    )
                    self.hypotheses.append(hypo)
                    new_hypotheses.append(hypo)
                    print(f"  💡 假设：{domain} 存在异常模式")
        return new_hypotheses

    def verify_with_agnes(self, hypothesis: Hypothesis, agnes_teacher) -> bool:
        """用 Agnes 验证假设"""
        if agnes_teacher is None:
            return False
        evidence = hypothesis.evidence
        prompt = f"""分析以下分布式计算冲突：
Domain: {hypothesis.domain}
描述: {hypothesis.description}
证据: {json.dumps(evidence, ensure_ascii=False)}

请判断这是否是真实异常，并给出简短分析。"""
        try:
            response = agnes_teacher.chat(prompt)
            hypothesis.status = "verified" if "异常" in response or "问题" in response else "rejected"
            return hypothesis.status == "verified"
        except Exception as e:
            print(f"  Agnes验证失败: {e}")
            return False

    def finalize_conflicts(self):
        """将未解决的冲突挂上知识树"""
        for domain, info in self.conflict_groups.items():
            avg_v = sum(info["values"]) / len(info["values"]) if info["values"] else 0
            desc = f"{domain}: 平均值={avg_v:.3f}, 冲突次数={info['count']}, 节点={info['nodes']}"
            self._add_child("root", f"冲突_{domain}", desc)
        self.conflict_groups.clear()

    def save(self):
        """持久化 — 优先 backend，降级 JSON"""
        if self.backend is not None:
            return self._save_to_backend()
        return self._save_to_json()

    def _save_to_backend(self):
        """保存到 SQLite — 复用 evolution_log 表，单行 JSON blob"""
        data = {
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "root_id": self.root_id,
            "conflict_groups": self.conflict_groups,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
        }
        blob = json.dumps(data, ensure_ascii=False)
        # 先删除旧快照，再插入新快照（保持单行）
        self.backend.execute(
            "DELETE FROM evolution_log WHERE evolution_type = ?",
            ('reduction_snapshot',)
        )
        self.backend.execute(
            "INSERT INTO evolution_log (timestamp, evolution_type, rule_id, description, action) "
            "VALUES (?, ?, ?, ?, ?)",
            (time.time(), 'reduction_snapshot', 'reduction_knowledge', blob, 'snapshot')
        )

    def _save_to_json(self):
        """保存到 JSON（降级）"""
        os.makedirs(self.data_dir, exist_ok=True)
        data = {
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "root_id": self.root_id,
            "conflict_groups": self.conflict_groups,
            "hypotheses": [h.to_dict() for h in self.hypotheses],
        }
        with open(self.save_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def load(self):
        """从存储恢复 — 优先 backend，降级 JSON"""
        if self.backend is not None:
            return self._load_from_backend()
        return self._load_from_json()

    def _load_from_backend(self):
        """从 SQLite 恢复"""
        rows = self.backend.query('evolution_log', {'evolution_type': 'reduction_snapshot'}, limit=1)
        if not rows:
            # backend 无数据 — 尝试从 JSON 迁移一次
            if os.path.exists(self.save_path):
                self._load_from_json()
                self._save_to_backend()
            return
        try:
            data = json.loads(rows[0]['description'])
            self.nodes = {k: KnowledgeNode.from_dict(v) for k, v in data.get("nodes", {}).items()}
            self.root_id = data.get("root_id", "root")
            self.conflict_groups = data.get("conflict_groups", {})
            self.hypotheses = [Hypothesis(**h) for h in data.get("hypotheses", [])]
        except Exception as e:
            print(f"[ReductionKnowledgeTree] backend 加载失败: {e}")

    def _load_from_json(self):
        """从 JSON 恢复（降级/迁移用）"""
        if not os.path.exists(self.save_path):
            return
        try:
            with open(self.save_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.nodes = {k: KnowledgeNode.from_dict(v) for k, v in data.get("nodes", {}).items()}
            self.root_id = data.get("root_id", "root")
            self.conflict_groups = data.get("conflict_groups", {})
            self.hypotheses = [Hypothesis(**h) for h in data.get("hypotheses", [])]
        except Exception as e:
            print(f"[ReductionKnowledgeTree] JSON 加载失败: {e}")

    def get_status(self) -> dict:
        return {
            "total_nodes": len(self.nodes),
            "conflict_groups": len(self.conflict_groups),
            "hypotheses": len(self.hypotheses),
            "pending_hypotheses": sum(1 for h in self.hypotheses if h.status == "pending"),
            "verified_hypotheses": sum(1 for h in self.hypotheses if h.status == "verified"),
        }

    def __repr__(self):
        return f"ReductionKnowledgeTree(nodes={len(self.nodes)}, conflicts={len(self.conflict_groups)}, hypotheses={len(self.hypotheses)})"
