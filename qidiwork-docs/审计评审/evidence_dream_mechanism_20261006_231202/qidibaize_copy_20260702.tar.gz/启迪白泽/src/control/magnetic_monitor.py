# magnetic_monitor.py — 磁场监控（CPU/GPU/温度/异常检测）
"""
磁场监控：每个节点运行，检测自身异常，广播到知识树。
整合自：元系统的 磁场.py + 磁场工程化.py
"""
import time
from typing import List, Dict, Optional
from dataclasses import dataclass

# psutil 可选，未安装时使用模拟
try:
    import psutil
    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False


@dataclass
class Anomaly:
    """异常事件"""
    node_id: str
    type: str       # 'cpu_high', 'gpu_overheat', 'memory_leak', 'disk_full', 'network_timeout'
    severity: str   # 'info', 'warning', 'critical'
    value: float
    threshold: float
    timestamp: float
    description: str

    def to_dict(self):
        return {
            "node_id": self.node_id, "type": self.type, "severity": self.severity,
            "value": self.value, "threshold": self.threshold,
            "timestamp": self.timestamp, "description": self.description,
        }


class MagneticMonitor:
    """磁场监控：分布式节点的健康监控"""

    def __init__(self, check_interval: float = 5.0):
        self.check_interval = check_interval
        self.anomalies: List[Anomaly] = []
        self.history: Dict[str, List[Dict]] = {}  # node_id -> 历史监控数据

    def monitor(self, node) -> List[Anomaly]:
        """监控单个节点，返回检测到的异常列表"""
        found = []
        node_id = node.node_id if hasattr(node, "node_id") else str(node)
        cpu = 50.0
        mem_percent = 60.0
        gpu_temp = self._get_gpu_temp()

        if HAS_PSUTIL:
            # CPU
            try:
                cpu = psutil.cpu_percent(interval=None)
                if cpu > 90:
                    found.append(Anomaly(node_id, "cpu_high", "critical", cpu, 90, time.time(), f"CPU使用率 {cpu:.1f}%"))
                elif cpu > 70:
                    found.append(Anomaly(node_id, "cpu_high", "warning", cpu, 70, time.time(), f"CPU使用率 {cpu:.1f}%"))
            except Exception:
                pass

            # 内存
            try:
                mem = psutil.virtual_memory()
                mem_percent = mem.percent
                if mem.percent > 95:
                    found.append(Anomaly(node_id, "memory_full", "critical", mem.percent, 95, time.time(), f"内存使用率 {mem.percent:.1f}%"))
                elif mem.percent > 85:
                    found.append(Anomaly(node_id, "memory_high", "warning", mem.percent, 85, time.time(), f"内存使用率 {mem.percent:.1f}%"))
            except Exception:
                pass

            # 磁盘
            try:
                disk = psutil.disk_usage("/")
                if disk.percent > 95:
                    found.append(Anomaly(node_id, "disk_full", "critical", disk.percent, 95, time.time(), f"磁盘使用率 {disk.percent:.1f}%"))
                elif disk.percent > 85:
                    found.append(Anomaly(node_id, "disk_high", "warning", disk.percent, 85, time.time(), f"磁盘使用率 {disk.percent:.1f}%"))
            except Exception:
                pass

        # GPU 温度
        if gpu_temp and gpu_temp > 85:
            found.append(Anomaly(node_id, "gpu_overheat", "critical", gpu_temp, 85, time.time(), f"GPU温度 {gpu_temp:.1f}C"))
        elif gpu_temp and gpu_temp > 75:
            found.append(Anomaly(node_id, "gpu_hot", "warning", gpu_temp, 75, time.time(), f"GPU温度 {gpu_temp:.1f}C"))

        # 记录历史
        self._record_history(node_id, {"cpu": cpu, "memory": mem_percent, "gpu_temp": gpu_temp})

        # 趋势检测：缓慢持续上升
        trend_anomaly = self._detect_trend(node_id, "memory")
        if trend_anomaly:
            found.append(trend_anomaly)

        self.anomalies.extend(found)
        return found

    def _get_gpu_temp(self) -> Optional[float]:
        """获取GPU温度（模拟，实际调用 nvidia-smi）"""
        try:
            import subprocess
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=2
            )
            if result.returncode == 0:
                return float(result.stdout.strip().split("\n")[0])
        except Exception:
            pass
        return None

    def _record_history(self, node_id: str, metrics: Dict):
        if node_id not in self.history:
            self.history[node_id] = []
        self.history[node_id].append({"timestamp": time.time(), **metrics})
        if len(self.history[node_id]) > 1000:
            self.history[node_id] = self.history[node_id][-500:]

    def _detect_trend(self, node_id: str, metric: str) -> Optional[Anomaly]:
        """检测缓慢持续上升（内存泄漏等）"""
        hist = self.history.get(node_id, [])
        if len(hist) < 20:
            return None
        recent = hist[-20:]
        first_half = sum(h.get(metric, 0) for h in recent[:10]) / 10
        second_half = sum(h.get(metric, 0) for h in recent[10:]) / 10
        if second_half - first_half > 10.0:
            return Anomaly(
                node_id, "memory_leak", "warning",
                second_half, first_half + 10, time.time(),
                f"{metric} 缓慢持续上升: {first_half:.1f} → {second_half:.1f}"
            )
        return None

    def check_health(self) -> Dict:
        """整体健康检查报告"""
        return {
            "total_anomalies": len(self.anomalies),
            "critical": sum(1 for a in self.anomalies if a.severity == "critical"),
            "warning": sum(1 for a in self.anomalies if a.severity == "warning"),
            "monitored_nodes": len(self.history),
        }

    def get_recent_anomalies(self, node_id: str = None, limit: int = 10) -> List[Dict]:
        """获取最近异常"""
        filtered = [a for a in self.anomalies if node_id is None or a.node_id == node_id]
        return [a.to_dict() for a in filtered[-limit:]]

    def __repr__(self):
        return f"MagneticMonitor(anomalies={len(self.anomalies)}, nodes={len(self.history)})"
