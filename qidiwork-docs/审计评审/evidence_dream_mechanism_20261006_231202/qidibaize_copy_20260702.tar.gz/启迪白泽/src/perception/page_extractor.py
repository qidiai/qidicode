"""
页面提取器 — DOM→{title,url,text,links,forms}结构化

设计:
  - 过滤导航/广告/脚本/样式
  - 提取正文内容
  - 支持多种页面结构（文章、列表、表单）
"""
import re
import logging
from typing import Dict, List, Any

logger = logging.getLogger('PageExtractor')


class PageExtractor:
    """页面结构化提取器"""

    # 需要过滤的标签（这些标签通常不包含有用内容）
    SKIP_TAGS = {'script', 'style', 'nav', 'footer', 'aside', 'form', 'header', 'iframe', 'svg'}

    # 需要过滤的类名/ID模式
    AD_PATTERNS = [
        r'ad|banner|sidebar|widget|promo|sponsor|advertisement|推荐|广告|赞助',
        r'logo|copyright|footer|header|navigation|menu|nav',
        r'comment|reply|discuss|评论|回复',
        r'login|register|signin|signup|登录|注册',
        r'share|social|weibo|wechat|qq|分享',
    ]

    # 文章内容的常见标签
    CONTENT_TAGS = {'article', 'main', 'section', 'div', 'p', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'}

    def extract(self, page_data: Dict[str, Any]) -> str:
        """
        从页面数据中提取结构化内容

        Args:
            page_data: {'url', 'title', 'html', 'text'} 或 Playwright页面对象

        Returns:
            提取的正文文本
        """
        if isinstance(page_data, dict):
            html = page_data.get('html', '')
            text = page_data.get('text', '')
        else:
            html = ''
            text = ''

        if not html and text:
            return self._clean_text(text)

        return self._extract_from_html(html)

    def extract_structure(self, page_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        提取完整的结构化信息

        Returns:
            {'title', 'url', 'text', 'links', 'forms', 'images', 'clean_text'}
        """
        result = {
            'title': page_data.get('title', ''),
            'url': page_data.get('url', ''),
            'text': page_data.get('text', ''),
            'links': page_data.get('links', []),
            'forms': page_data.get('forms', []),
            'images': page_data.get('images', []),
        }

        result['clean_text'] = self.extract(page_data)

        return result

    def _extract_from_html(self, html: str) -> str:
        """从HTML提取正文"""
        # 去除不需要的标签
        for tag in self.SKIP_TAGS:
            html = re.sub(
                rf'<{tag}[^>]*>.*?</{tag}>', '', html,
                flags=re.DOTALL | re.IGNORECASE
            )

        # 去除HTML注释
        html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)

        # 去除广告块（通过class/id）
        for pattern in self.AD_PATTERNS:
            html = re.sub(
                rf'<[^>]*class=["\'].*?{pattern}.*?["\'][^>]*>.*?</[^>]+>', '', html,
                flags=re.DOTALL | re.IGNORECASE
            )
            html = re.sub(
                rf'<[^>]*id=["\'].*?{pattern}.*?["\'][^>]*>.*?</[^>]+>', '', html,
                flags=re.DOTALL | re.IGNORECASE
            )

        # 块级标签转换为换行
        html = re.sub(r'<(p|div|br|h[1-6]|li|tr|td|article|section)[^>]*>', '\n', html, flags=re.IGNORECASE)

        # 去除所有标签
        html = re.sub(r'<[^>]+>', '', html)

        # 还原HTML实体
        html = self._unescape_html(html)

        # 清理文本
        return self._clean_text(html)

    def _clean_text(self, text: str) -> str:
        """清理文本：去乱码、去短行、去废物"""
        lines = []
        for line in text.split('\n'):
            line = line.strip()

            if not line:
                continue

            if len(line) < 5:
                continue

            if self._is_junk_line(line):
                continue

            if self._is_noise_line(line):
                continue

            lines.append(line)

        return '\n'.join(lines)

    def _is_junk_line(self, line: str) -> bool:
        """判断是否是废物行"""
        junk_patterns = [
            r'cookie[s]? ?政策', r'我们使用.*?cookie', r'隐私政策', r'用户协议',
            r'版权所有.*?\d{4}', r'copyright.*?\d{4}', r'all rights reserved',
            r'订阅.*? newsletter', r'关注.*?公众号', r'扫码.*?下载',
            r'登录|注册|忘记密码', r'首页|上一页|下一页|返回顶部',
            r'分享到.*?微博|分享到.*?微信', r'本文链接|永久链接',
            r'Powered by|技术支持|网站地图',
        ]
        for pattern in junk_patterns:
            if re.search(pattern, line, re.IGNORECASE):
                return True
        return False

    def _is_noise_line(self, line: str) -> bool:
        """判断是否是噪音行（JS代码、乱码等）"""
        # JS代码残留
        js_patterns = ['function(', 'var ', '={', '();', 'document.', 'window.', 'undefined', 'null']
        if any(pattern in line for pattern in js_patterns):
            return True

        # 乱码检测：有用字符占比太低
        chars = len(line)
        useful = sum(1 for c in line if c.isalnum() or '\u4e00' <= c <= '\u9fff' or c in '，。、？！；：""''')
        if chars > 0 and useful / chars < 0.5:
            return True

        # 纯数字或纯符号
        if re.match(r'^[\d\s.,;:?!]+$', line):
            return True

        return False

    def _unescape_html(self, text: str) -> str:
        """还原HTML实体"""
        entities = {
            '&amp;': '&',
            '&lt;': '<',
            '&gt;': '>',
            '&quot;': '"',
            '&#x27;': "'",
            '&#39;': "'",
            '&nbsp;': ' ',
            '&ensp;': ' ',
            '&emsp;': ' ',
            '&#0183;': '·',
            '&middot;': '·',
        }
        for entity, char in entities.items():
            text = text.replace(entity, char)
        return text

    def extract_links(self, page_data: Dict[str, Any]) -> List[Dict[str, str]]:
        """提取链接列表"""
        links = page_data.get('links', [])
        if not links:
            return []

        clean_links = []
        seen_urls = set()

        for link in links:
            url = link.get('href', '')
            text = link.get('text', '').strip()

            if not url or not text:
                continue

            if len(text) < 2 or len(text) > 200:
                continue

            if url in seen_urls:
                continue

            # 过滤常见垃圾链接
            if any(p in url for p in ['javascript:', '#', 'mailto:', 'tel:']):
                continue

            if any(p in text for p in ['广告', '赞助', '登录', '注册', '首页', '导航']):
                continue

            seen_urls.add(url)
            clean_links.append({
                'text': text[:100],
                'url': url,
            })

        return clean_links[:50]

    def extract_images(self, page_data: Dict[str, Any]) -> List[Dict[str, str]]:
        """提取图片列表"""
        images = page_data.get('images', [])
        if not images:
            return []

        clean_images = []
        seen_src = set()

        for img in images:
            src = img.get('src', '')
            alt = img.get('alt', '').strip()

            if not src:
                continue

            if src in seen_src:
                continue

            seen_src.add(src)
            clean_images.append({
                'src': src,
                'alt': alt[:100],
            })

        return clean_images[:30]
