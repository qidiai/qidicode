"""
浏览器传感器 — Playwright驱动Edge，持久登录多平台，自己上网学习

设计:
  - channel="msedge" 用本机已装Edge，零额外安装
  - 持久登录态: storage_state 存 data/browser_profiles/{platform}.json
  - 自动处理Cookie/Storage持久化
  - 支持多平台登录管理
"""
import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Dict, Optional, Any

logger = logging.getLogger('BrowserSensor')


class BrowserSensor:
    """浏览器传感器 — Playwright Edge浏览器感知"""

    def __init__(self, profiles_dir=None, headless=False):
        self.profiles_dir = Path(profiles_dir) if profiles_dir else Path('data/browser_profiles')
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        self.headless = headless
        self._browser = None
        self._contexts = {}
        self._page = None
        self._playwright = None

    async def start(self):
        """启动浏览器"""
        if self._browser:
            return True

        try:
            from playwright.async_api import async_playwright
            self._playwright = await async_playwright().start()
            self._browser = await self._playwright.chromium.launch(
                channel="msedge",
                headless=self.headless,
                args=[
                    '--disable-gpu',
                    '--disable-dev-shm-usage',
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-features=IsolateOrigins,site-per-process',
                ],
            )
            logger.info('[浏览器] Edge已启动')
            return True
        except Exception as e:
            logger.error(f'[浏览器] 启动失败: {e}')
            return False

    async def stop(self):
        """停止浏览器"""
        if self._page:
            await self._page.close()
        for ctx in self._contexts.values():
            await ctx.close()
        if self._browser:
            await self._browser.close()
        if self._playwright:
            await self._playwright.stop()
        logger.info('[浏览器] 已停止')

    async def new_context(self, platform_name=None):
        """创建新上下文（带持久登录态）"""
        storage_path = None
        if platform_name:
            storage_path = self.profiles_dir / f'{platform_name}.json'
            if storage_path.exists():
                logger.info(f'[浏览器] 加载登录态: {platform_name}')

        context = await self._browser.new_context(
            storage_state=str(storage_path) if storage_path and storage_path.exists() else None,
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            viewport={'width': 1920, 'height': 1080},
        )

        if platform_name:
            self._contexts[platform_name] = context

        self._page = await context.new_page()
        return context

    async def login_platform(self, platform_name, url, login_func=None):
        """
        登录平台并保存登录态

        Args:
            platform_name: 平台名称（用于保存登录态）
            url: 登录页面URL
            login_func: 登录函数，接收page参数，执行登录操作
        """
        if not self._browser:
            await self.start()

        await self.new_context(platform_name)
        await self._page.goto(url, wait_until='networkidle')

        if login_func:
            await login_func(self._page)
            await asyncio.sleep(3)

        # 保存登录态
        storage_path = self.profiles_dir / f'{platform_name}.json'
        await self._page.context.storage_state(path=str(storage_path))
        logger.info(f'[浏览器] 登录态已保存: {platform_name}')

        return True

    async def restore_session(self, platform_name):
        """恢复已保存的登录会话"""
        if not self._browser:
            await self.start()

        storage_path = self.profiles_dir / f'{platform_name}.json'
        if not storage_path.exists():
            logger.warning(f'[浏览器] 未找到登录态: {platform_name}')
            return False

        await self.new_context(platform_name)
        logger.info(f'[浏览器] 会话已恢复: {platform_name}')
        return True

    async def fetch(self, url, wait_selector=None, timeout=30000):
        """
        抓取页面内容

        Args:
            url: 目标URL
            wait_selector: 等待元素出现
            timeout: 超时时间(毫秒)
        """
        if not self._page:
            await self.new_context()

        try:
            await self._page.goto(url, wait_until='networkidle', timeout=timeout)

            if wait_selector:
                await self._page.wait_for_selector(wait_selector, timeout=timeout)

            await asyncio.sleep(1)

            page_data = {
                'url': self._page.url,
                'title': await self._page.title(),
                'html': await self._page.content(),
                'text': await self._page.text_content('body'),
            }

            logger.info(f'[浏览器] 抓取成功: {url}')
            return page_data

        except Exception as e:
            logger.error(f'[浏览器] 抓取失败 {url}: {e}')
            return None

    async def extract_structure(self, url=None):
        """
        提取页面结构化信息

        Returns:
            {'title', 'url', 'text', 'links', 'forms', 'images'}
        """
        if url:
            page_data = await self.fetch(url)
            if not page_data:
                return None
        elif self._page:
            page_data = {
                'url': self._page.url,
                'title': await self._page.title(),
                'html': await self._page.content(),
                'text': await self._page.text_content('body'),
            }
        else:
            return None

        # 提取链接
        links = await self._page.evaluate("""() => {
            return Array.from(document.querySelectorAll('a[href]')).map(a => ({
                text: a.textContent.trim(),
                href: a.href,
            })).filter(l => l.text && l.href);
        }""")

        # 提取表单
        forms = await self._page.evaluate("""() => {
            return Array.from(document.querySelectorAll('form')).map(form => ({
                action: form.action,
                method: form.method || 'GET',
                fields: Array.from(form.querySelectorAll('input, select, textarea')).map(f => ({
                    name: f.name,
                    type: f.type,
                    value: f.value,
                })),
            }));
        }""")

        # 提取图片
        images = await self._page.evaluate("""() => {
            return Array.from(document.querySelectorAll('img[src]')).map(img => ({
                src: img.src,
                alt: img.alt,
            })).filter(i => i.src);
        }""")

        return {
            'title': page_data['title'],
            'url': page_data['url'],
            'text': page_data['text'],
            'links': links[:50],
            'forms': forms,
            'images': images[:30],
        }

    async def screenshot(self, path=None):
        """截取当前页面"""
        if not self._page:
            return None

        path = path or f'screenshot_{int(time.time())}.png'
        await self._page.screenshot(path=path, full_page=True)
        return path

    async def execute_script(self, script):
        """执行JavaScript"""
        if not self._page:
            return None
        return await self._page.evaluate(script)

    def get_platforms(self):
        """获取已保存的平台登录态列表"""
        platforms = []
        if self.profiles_dir.exists():
            for f in self.profiles_dir.glob('*.json'):
                platforms.append(f.stem)
        return platforms

    def is_logged_in(self, platform_name):
        """检查平台是否已登录"""
        return (self.profiles_dir / f'{platform_name}.json').exists()

    # ---- 同步包装 ----

    def fetch_sync(self, url, **kwargs):
        """同步版本的fetch"""
        return asyncio.get_event_loop().run_until_complete(self.fetch(url, **kwargs))

    def extract_structure_sync(self, url=None):
        """同步版本的extract_structure"""
        return asyncio.get_event_loop().run_until_complete(self.extract_structure(url))

    def start_sync(self):
        """同步版本的start"""
        return asyncio.get_event_loop().run_until_complete(self.start())

    def stop_sync(self):
        """同步版本的stop"""
        return asyncio.get_event_loop().run_until_complete(self.stop())

    def login_platform_sync(self, platform_name, url, login_func=None):
        """同步版本的login_platform"""
        return asyncio.get_event_loop().run_until_complete(
            self.login_platform(platform_name, url, login_func)
        )

    def restore_session_sync(self, platform_name):
        """同步版本的restore_session"""
        return asyncio.get_event_loop().run_until_complete(self.restore_session(platform_name))
