"""
联网学习器 — 生物体饿了时联网搜索补充知识

设计:
  - Bing 搜索优先 (国内通, 中文结果质量高), DDG Instant Answer API 兜底
  - 只读搜索结果摘要, 不爬深页, 超时5秒, 失败不影响循环
  - 搜出来的内容灌进知识树 (只增不改)
  - 嵌入走 V10 (body.learn 内部), 不碰 ollama
  - 触发权在生物体自己 (本地知识不够/命中率低时), 前端无按钮
"""
import urllib.request
import urllib.parse
import json as _json
import re
import logging
import threading
import time

logger = logging.getLogger('WebLearner')

# 搜索端点
BING_URL = 'https://www.bing.com/search'
DDG_API_URL = 'https://api.duckduckgo.com/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'


class WebLearner:
    """联网搜索学习器 — 把搜索结果摘要灌进知识树"""

    def __init__(self):
        self._lock = threading.Lock()
        self._learned_count = 0
        self._last_query = None
        self._last_results = []
        self._bing_ok = True     # Bing 可用标记
        self._ddg_ok = True      # DDG 可用标记
        # 指数退避: 连续失败时逐步增大冷却, 防止 IP 封禁
        self._fail_streak = 0
        self._backoff_until = 0.0

    def available(self):
        return True  # 始终可用, 搜索内部自行处理失败

    def search(self, query, top_k=5):
        """
        搜一个关键词 → 返回 [{title, snippet, url}] 列表
        策略: Bing 优先 (国内通, 中文质量高), DDG API 兜底
        """
        results = []

        # 1. Bing 搜索 (国内通, 中文结果质量最好)
        if self._bing_ok:
            # 检查退避冷却
            if time.time() < self._backoff_until:
                pass  # 正在退避中, 跳过 Bing
            else:
                try:
                    results = self._search_bing(query, top_k)
                    if results:
                        self._bing_ok = True  # 有网, 下次再试 Bing
                        self._fail_streak = 0  # 成功, 重置失败计数
                        return results
                except Exception as e:
                    logger.debug(f'Bing搜索失败 [{query}]: {e}')
                    self._fail_streak += 1
                    self._bing_ok = False
                    # 指数退避: 1s, 2s, 4s, 8s, ... 最大 60s
                    backoff = min(60, 2 ** self._fail_streak)
                    self._backoff_until = time.time() + backoff
                    logger.warning(f'Bing 连续失败 {self._fail_streak} 次, 退避 {backoff}s')

        # 2. DDG Instant Answer API 兜底 (免 key, JSON)
        if self._ddg_ok:
            try:
                results = self._search_ddg_api(query, top_k)
                if results:
                    self._bing_ok = True  # 有网, 下次再试 Bing
                    self._ddg_ok = True   # 恢复
                    self._fail_streak = 0
                    return results
            except Exception as e:
                logger.debug(f'DDG API失败 [{query}]: {e}')
                self._fail_streak += 1
                self._ddg_ok = False
                backoff = min(60, 2 ** self._fail_streak)
                self._backoff_until = time.time() + backoff

        # 都没结果, 但下次还要重试 (网络可能恢复)
        # 退避冷却结束后再重试
        self._bing_ok = True
        self._ddg_ok = True
        self._fail_streak = 0
        return results

    # ---- Bing 搜索 (主引擎) ----

    def _search_bing(self, query, top_k):
        """Bing 搜索 — 国内通, 中文结果质量高, DOM解析(非正则)"""
        url = f'{BING_URL}?{urllib.parse.urlencode({"q": query, "count": top_k * 2})}'
        req = urllib.request.Request(url, headers={
            'User-Agent': USER_AGENT,
            'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        })
        with urllib.request.urlopen(req, timeout=6) as r:
            html = r.read().decode('utf-8', errors='ignore')

        results = []
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(html, 'html.parser')
            for li in soup.select('li.b_algo'):
                a = li.select_one('h2 a')
                if not a:
                    continue
                title = a.get_text(strip=True)
                href = a.get('href', '')
                # 摘要: <p> 或 .b_caption p
                snip_el = li.select_one('.b_caption p') or li.select_one('p')
                snippet = snip_el.get_text(strip=True) if snip_el else ''
                url_clean = self._clean_bing_url(href)
                if title and len(title) > 2:
                    results.append({'title': title[:120], 'snippet': snippet[:400], 'url': url_clean})
                if len(results) >= top_k:
                    break
        except ImportError:
            # bs4没装, 降级用正则(脆弱但能用)
            results = self._parse_bing_fallback(html, top_k)
        return results

    def _parse_bing_fallback(self, html, top_k):
        """Bing HTML 正则降级解析 — bs4没装时用, Bing改版可能挂"""
        blocks = re.findall(r'<li[^>]*class="[^"]*b_algo[^"]*"[^>]*>(.*?)</li>', html, re.DOTALL)
        results = []
        for b in blocks[:top_k * 2]:
            title_m = re.search(r'<h2[^>]*>\s*<a[^>]*href="([^"]+)"[^>]*>(.*?)</a>', b, re.DOTALL)
            if not title_m:
                continue
            url_raw = title_m.group(1)
            title = self._strip_html(title_m.group(2)).strip()
            snip_m = re.search(r'<p[^>]*>(.*?)</p>', b, re.DOTALL)
            snippet = self._strip_html(snip_m.group(1)).strip() if snip_m else ''
            url_clean = self._clean_bing_url(url_raw)
            if title and len(title) > 2:
                results.append({'title': title[:120], 'snippet': snippet[:400], 'url': url_clean})
            if len(results) >= top_k:
                break
        return results

    def _clean_bing_url(self, url):
        """清理 Bing 跳转 URL → 还原真实 URL"""
        # Bing 有两种跳转: /search?q=... 或 /click?u=...
        if url.startswith('/'):
            # 相对路径, 补全
            url = 'https://www.bing.com' + url
        # 去掉 Bing 的搜索跳转包装
        m = re.search(r'[?&]u=([^&]+)', url)
        if m:
            try:
                import base64
                decoded = base64.b64decode(m.group(1) + '==').decode('utf-8', errors='ignore')
                if decoded.startswith('http'):
                    return decoded
            except Exception:
                pass
        return url

    # ---- DDG Instant Answer API (兜底) ----

    def _search_ddg_api(self, query, top_k):
        """DuckDuckGo Instant Answer API — JSON, 免 key, 兜底用"""
        params = urllib.parse.urlencode({
            'q': query, 'format': 'json', 'no_html': 1, 't': 'worm_engine'
        })
        url = f'{DDG_API_URL}?{params}'
        req = urllib.request.Request(url, headers={'User-Agent': USER_AGENT})
        with urllib.request.urlopen(req, timeout=5) as r:
            data = _json.loads(r.read().decode('utf-8'))

        results = []
        if data.get('AbstractText'):
            results.append({
                'title': data.get('Heading', query)[:120],
                'snippet': data['AbstractText'][:400],
                'url': data.get('AbstractURL', ''),
            })
        for topic in (data.get('RelatedTopics') or [])[:top_k * 2]:
            if isinstance(topic, dict) and topic.get('Text'):
                results.append({
                    'title': (topic.get('Text', '')[:60] or query)[:120],
                    'snippet': topic['Text'][:400],
                    'url': topic.get('FirstURL', ''),
                })
            if len(results) >= top_k:
                break
        return results[:top_k]

    # ---- HTML 工具 ----

    def _strip_html(self, s):
        """去 HTML 标签 + 转义"""
        s = re.sub(r'<[^>]+>', '', s)
        s = s.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
        s = s.replace('&quot;', '"').replace('&#x27;', "'").replace('&#39;', "'")
        # Bing 常见实体: &ensp; &emsp; &nbsp; &#0183;(中点) &middot;
        s = re.sub(r'&ensp;|&emsp;|&nbsp;', ' ', s)
        s = re.sub(r'&#0183;|&middot;', '·', s)
        s = re.sub(r'\s{2,}', ' ', s)  # 压缩连续空白
        return s

    # ---- 知识消化 ----

    def digest(self, query, knowledge_tree):
        """
        搜一个关键词 → 过滤+提取正文 → 只吸收有用的进知识树

        质量过滤:
          1. 删广告/导航/乱码/超短/重复
          2. 抓正文 (去 HTML/脚本/样式), 不只摘要
          3. 和查询词语义相关 (V10 余弦相似度 > 0.15), 无用丢弃
          4. 每次最多抓 3 个最相关 URL 正文, 避免拖慢
        只增不改不删. 返回灌进去的节点数, 失败返回0.
        """
        with self._lock:
            results = self.search(query, top_k=5)
            if not results:
                return 0
            # 查询词嵌入 (用于有用性判断)
            try:
                from .knowledge_tree import smart_embedding, _cosine_similarity
                query_emb = smart_embedding(query)
            except Exception:
                query_emb = None
            learned = []
            seen_titles = set()
            fetched = 0
            # 质量门: 必须抓到真实正文, 摘要太短不算知识
            all_snippets = []
            for r in results:
                title = r['title'].strip()
                if title in seen_titles or len(title) < 4:
                    continue
                if any(w in title for w in ['广告', '赞助', '登录', '注册', '首页', '导航', '©', 'Copyright', '下载', 'App']):
                    continue
                seen_titles.add(title)
                # 正文优先: 必须抓真实网页正文, 抓不到就跳过
                content = ''
                if r['url'] and fetched < 3:
                    full = self._fetch_content(r['url'])
                    if full and len(full) > 200:
                        content = full
                        fetched += 1
                if not content:
                    # 摘要足够长也可以用 (Bing snippet 通常 150-300 字, 有一定价值)
                    snippet = r.get('snippet', '')
                    if len(snippet) > 100:
                        content = snippet
                    else:
                        continue
                content = self._clean_content(content)
                if len(content) < 100:
                    continue
                if query_emb:
                    try:
                        c_emb = smart_embedding(title + ' ' + content[:300])
                        sim = _cosine_similarity(query_emb, c_emb)
                        if sim < 0.10:  # 相关度门槛 (词袋哈希降级时 0.15 太严, 0.10 更宽容)
                            continue
                    except Exception:
                        pass
                all_snippets.append({'title': title, 'content': content, 'url': r['url']})
            # 聚合成有实质正文的知识条目
            if all_snippets:
                top = all_snippets[0]
                main_content = top['content'][:2000]  # 主体正文加长到2000
                if len(all_snippets) > 1:
                    points = ['\n\n【其他要点】']
                    for s in all_snippets[1:4]:
                        points.append(f'· {s["title"]}: {s["content"][:300]}')
                    main_content += '\n'.join(points)
                try:
                    node, action = knowledge_tree.merge_knowledge(
                        query,
                        f'[联网搜索: {query}]\n{main_content}\n来源: {top["url"]}',
                        source='web'
                    )
                    if action in ('created', 'merged'):
                        learned.append({'topic': query, 'snippet': main_content[:60], 'action': action})
                        self._learned_count += 1
                except Exception as e:
                    logger.warning(f'灌入搜索结果失败: {e}')
            self._last_query = query
            self._last_results = learned
            logger.info(f'[联网] 搜"{query}" → 过滤后学{len(learned)}/{len(results)}条')
            return len(learned)

    def _fetch_content(self, url):
        """抓网页正文 — 去 HTML 标签/脚本/样式, 只留可见文本"""
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': USER_AGENT,
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Accept': 'text/html,application/xhtml+xml',
            })
            with urllib.request.urlopen(req, timeout=6) as r:
                # 处理重定向和编码
                charset = 'utf-8'
                ct = r.headers.get('Content-Type', '')
                m = re.search(r'charset=([\w-]+)', ct)
                if m:
                    charset = m.group(1)
                html = r.read().decode(charset, errors='ignore')
            return self._extract_text(html)
        except Exception as e:
            logger.debug(f'抓正文失败 {url[:60]}: {e}')
            return ''

    def _extract_text(self, html):
        """从 HTML 提取正文 — 严格去废物, 只留主体内容"""
        # 去脚本/样式/head/nav/footer/aside/form/header/iframe/svg
        html = re.sub(r'<(script|style|head|nav|footer|aside|form|header|iframe|svg)[^>]*>.*?</\1>', '', html, flags=re.DOTALL|re.IGNORECASE)
        # 去 HTML 注释
        html = re.sub(r'<!--.*?-->', '', html, flags=re.DOTALL)
        # 块级标签转换行
        html = re.sub(r'<(p|div|br|h[1-6]|li|tr|td|article|section)[^>]*>', '\n', html, flags=re.IGNORECASE)
        # 去所有标签
        html = re.sub(r'<[^>]+>', '', html)
        # 转义还原
        html = html.replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>')
        html = html.replace('&quot;', '"').replace('&#x27;', "'").replace('&#39;', "'").replace('&nbsp;', ' ')
        # 压缩空白
        lines = [l.strip() for l in html.split('\n') if l.strip()]
        text = '\n'.join(lines)
        # 去常见废物段落
        waste_patterns = [
            r'cookie[s]? ?政策', r'我们使用.*?cookie', r'隐私政策', r'用户协议',
            r'版权所有.*?\d{4}', r'copyright.*?\d{4}', r'all rights reserved',
            r'订阅.*? newsletter', r'关注.*?公众号', r'扫码.*?下载',
            r'登录|注册|忘记密码', r'首页|上一页|下一页|返回顶部',
            r'分享到.*?微博|分享到.*?微信', r'本文链接|永久链接',
        ]
        for w in waste_patterns:
            text = re.sub(w, '', text, flags=re.IGNORECASE)
        return text

    def _clean_content(self, content):
        """严格清洗 — 去JS/乱码/超短行/废物行, 只留实质内容"""
        lines = []
        for l in content.split('\n'):
            l = l.strip()
            if not l or len(l) < 5:
                continue
            # 去 JS 残留
            if any(w in l for w in ['function(', 'var ', '={', '();', 'document.', 'window.', 'undefined', 'null']):
                continue
            # 去乱码行 (中英文字符占比太低)
            chars = len(l)
            useful = sum(1 for c in l if c.isalnum() or '\u4e00' <= c <= '\u9fff' or c in '，。、？！；：""''')
            if useful / max(chars, 1) < 0.5:
                continue
            # 去废物行
            if any(w in l for w in ['cookie', '隐私政策', '版权所有', 'Copyright', '关注公众号', '扫码下载', '登录注册', '分享到']):
                continue
            lines.append(l)
        return '\n'.join(lines)

    def get_stats(self):
        return {
            'available': True,
            'learned': self._learned_count,
            'last_query': self._last_query,
            'last_count': len(self._last_results),
            'engine': 'Bing优先+DDG兜底',
        }
