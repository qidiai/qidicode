# source_pool.py — 32维源池（来自元系统）
"""源池：共享基准 + 门控，记录智能体在各类型任务上的能力分布。"""
from typing import List


class SourcePool:
    """源池：记录智能体在各类型任务上的能力分布，不是容量数字。"""

    TYPE_MAP = {
        "compute": 0, "render": 1, "train": 2, "code": 3,
        "spider": 4, "debug": 5, "write": 6, "design": 7,
        "analyze": 8, "ocr": 9, "inference": 10, "embedding": 11,
        "monitor": 12, "cleanup": 13, "sync": 14, "backup": 15,
        "test": 16, "deploy": 17, "query": 18, "index": 19,
        "compress": 20, "encrypt": 21, "decode": 22, "encode": 23,
        "parse": 24, "validate": 25, "merge": 26, "split": 27,
        "route": 28, "filter": 29, "sort": 30, "transform": 31,
    }

    def __init__(self, dim: int = 32):
        self.dim = dim
        self.baseline = [0.0] * dim
        self.gate_threshold = 0.8

    def update(self, delta: List[float]):
        """更新源池，带衰减"""
        for i in range(min(self.dim, len(delta))):
            self.baseline[i] += delta[i]
            self.baseline[i] *= 0.99  # 衰减防止无限增长

    def is_saturated(self) -> bool:
        """门控饱和：稳定且活跃"""
        max_val = max(abs(x) for x in self.baseline)
        return max_val > self.gate_threshold

    def activity(self) -> float:
        """源池整体活跃度"""
        return sum(abs(x) for x in self.baseline) / self.dim

    def dimension_activity(self, task_type: str) -> float:
        """指定任务类型的活跃度"""
        dim = self.TYPE_MAP.get(task_type, 9) % self.dim
        return abs(self.baseline[dim])

    def merge(self, other: "SourcePool") -> "SourcePool":
        """归源融合：不是叠加，是平均"""
        merged = SourcePool(self.dim)
        for i in range(self.dim):
            merged.baseline[i] = (self.baseline[i] + other.baseline[i]) / 2
        return merged

    def branch(self) -> "SourcePool":
        """分化：继承但衰减"""
        branched = SourcePool(self.dim)
        for i in range(self.dim):
            branched.baseline[i] = self.baseline[i] * 0.9
        return branched

    def to_dict(self) -> dict:
        return {"baseline": self.baseline, "dim": self.dim}

    @classmethod
    def from_dict(cls, d: dict) -> "SourcePool":
        pool = cls(d.get("dim", 32))
        pool.baseline = d.get("baseline", [0.0] * pool.dim)
        return pool

    def __repr__(self):
        active = sum(1 for x in self.baseline if abs(x) > 0.01)
        max_v = max(abs(x) for x in self.baseline) if self.baseline else 0.0
        return f"SourcePool(dim={self.dim}, active={active}, max={max_v:.3f}, saturated={self.is_saturated()})"
