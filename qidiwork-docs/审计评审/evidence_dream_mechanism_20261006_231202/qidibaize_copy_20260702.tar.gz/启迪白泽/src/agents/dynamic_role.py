# dynamic_role.py — 动态身份枚举（来自元系统）
"""动态身份：ROOT / ROUTER / COMPUTE / IMMUNE，身份由状态决定。"""
from enum import Enum, auto


class Role(Enum):
    """动态身份"""
    ROOT = auto()      # 根节点，可分裂
    ROUTER = auto()   # 有子节点，负责调度
    COMPUTE = auto()   # 叶子节点，负责执行
    IMMUNE = auto()    # 异常检测，隔离审计

    def __repr__(self):
        return f"Role.{self.name}"
