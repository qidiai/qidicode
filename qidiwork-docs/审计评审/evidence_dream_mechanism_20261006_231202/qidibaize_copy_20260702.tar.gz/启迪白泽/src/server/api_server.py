"""
交互式Web服务 — Flask API端口

提供REST API接口，支持:
  - 感知输入
  - 决策查询
  - 行动执行
  - 系统状态
  - 进化触发
  - 记忆管理
  - 知识树操作
"""
import json
import logging
from threading import Thread
from flask import Flask, request, jsonify

logger = logging.getLogger('APIServer')


class APIServer:
    """交互式Web服务"""

    def __init__(self, system, host='0.0.0.0', port=5000):
        self.system = system
        self.host = host
        self.port = port
        self.app = Flask('BaizeAPI')
        self._setup_routes()
        self._thread = None
        self._running = False

    def _setup_routes(self):
        """设置API路由"""

        @self.app.route('/api/health', methods=['GET'])
        def health():
            return jsonify({'status': 'ok', 'service': 'baize-api'})

        @self.app.route('/api/status', methods=['GET'])
        def status():
            return jsonify(self.system.get_status())

        @self.app.route('/api/perceive', methods=['POST'])
        def perceive():
            data = request.get_json()
            if not data or 'input' not in data:
                return jsonify({'error': '缺少input参数'}), 400

            text_or_url = data['input']
            source = data.get('source', 'api')
            result = self.system.perceive(text_or_url, source=source)
            return jsonify(result)

        @self.app.route('/api/decide', methods=['POST'])
        def decide():
            data = request.get_json() or {}
            percepts = data.get('percepts', ['default'])
            kwargs = data.get('kwargs', {})
            result = self.system.decide(percepts=percepts, **kwargs)
            return jsonify(result)

        @self.app.route('/api/act', methods=['POST'])
        def act():
            data = request.get_json()
            if not data or 'decision' not in data:
                return jsonify({'error': '缺少decision参数'}), 400

            decision = data['decision']
            result = self.system.act(decision)
            return jsonify(result)

        @self.app.route('/api/think', methods=['POST'])
        def think():
            data = request.get_json()
            if not data or 'input' not in data:
                return jsonify({'error': '缺少input参数'}), 400

            text_or_url = data['input']
            source = data.get('source', 'api')

            result = self.system.perceive(text_or_url, source=source)
            if not result:
                return jsonify({'error': '感知失败'}), 500

            decision = self.system.decide(percepts=['api_request'])
            action = decision.get('decision', {}).get('action', '休息')

            act_result = self.system.act(decision)

            return jsonify({
                'perception': result,
                'decision': decision,
                'action': action,
                'result': act_result,
            })

        @self.app.route('/api/evolve', methods=['POST'])
        def evolve():
            result = self.system.evolve()
            return jsonify(result)

        @self.app.route('/api/memory', methods=['GET'])
        def get_memory():
            level = request.args.get('level')
            if level:
                return jsonify({
                    'level': level,
                    'entries': [e.to_dict() for e in self.system.memory.query_by_level(level)],
                })
            return jsonify(self.system.memory.get_statistics())

        @self.app.route('/api/memory/<key>', methods=['GET', 'DELETE'])
        def memory_key(key):
            if request.method == 'GET':
                entry = self.system.memory.retrieve(key)
                return jsonify(entry.to_dict() if entry else {'error': '未找到'})
            else:
                self.system.memory.delete(key)
                return jsonify({'success': True})

        @self.app.route('/api/knowledge', methods=['GET'])
        def get_knowledge():
            return jsonify(self.system.knowledge_tree.get_stats())

        @self.app.route('/api/knowledge/search', methods=['POST'])
        def search_knowledge():
            data = request.get_json()
            if not data or 'query' not in data:
                return jsonify({'error': '缺少query参数'}), 400

            query = data['query']
            top_k = data.get('top_k', 5)
            min_score = data.get('min_score', 0.3)
            results = self.system.knowledge_tree.recall(query, top_k=top_k, min_score=min_score)
            return jsonify(results)

        @self.app.route('/api/knowledge/learn', methods=['POST'])
        def learn_knowledge():
            data = request.get_json()
            if not data or 'topic' not in data or 'content' not in data:
                return jsonify({'error': '缺少topic或content参数'}), 400

            result = self.system.knowledge_tree.learn(
                data['topic'],
                data['content'],
                source=data.get('source', 'api')
            )
            return jsonify({'success': result is not None})

        @self.app.route('/api/brain', methods=['GET'])
        def get_brain():
            return jsonify(self.system.brain.get_status())

        @self.app.route('/api/brain/reward', methods=['POST'])
        def reward_brain():
            data = request.get_json()
            if not data or 'action' not in data:
                return jsonify({'error': '缺少action参数'}), 400

            score = data.get('score', 0.5)
            self.system.brain.reward(data['action'], score=score)
            return jsonify({'success': True})

        @self.app.route('/api/run', methods=['POST'])
        def run():
            data = request.get_json() or {}
            iterations = data.get('iterations', 3)
            final_status = self.system.run(iterations=iterations)
            return jsonify(final_status)

        @self.app.route('/api/history', methods=['GET'])
        def get_history():
            limit = int(request.args.get('limit', 20))
            return jsonify(self.system.history[-limit:])

        @self.app.route('/api/qidi', methods=['GET'])
        def qidi_status():
            if hasattr(self.system, 'qidi_bridge') and self.system.qidi_bridge:
                return jsonify(self.system.qidi_bridge.get_status())
            return jsonify({'connected': False, 'message': 'Qidi Bridge未连接'})

        @self.app.route('/api/qidi/connect', methods=['POST'])
        def qidi_connect():
            if hasattr(self.system, 'qidi_bridge') and self.system.qidi_bridge:
                success = self.system.qidi_bridge.connect()
                return jsonify({'connected': success})
            return jsonify({'error': 'Qidi Bridge未初始化'}), 500

        @self.app.route('/api/qidi/chat', methods=['POST'])
        def qidi_chat():
            data = request.get_json()
            if not data or 'message' not in data:
                return jsonify({'error': '缺少message参数'}), 400

            if hasattr(self.system, 'qidi_bridge') and self.system.qidi_bridge:
                result = self.system.qidi_bridge.chat(data['message'], data.get('provider'))
                return jsonify(result)
            return jsonify({'error': 'Qidi Bridge未连接'}), 500

        @self.app.route('/api/tools', methods=['GET'])
        def get_tools():
            if hasattr(self.system, 'qidi_bridge') and self.system.qidi_bridge:
                tools = self.system.qidi_bridge.get_tools()
                return jsonify(tools)
            return jsonify({'error': 'Qidi Bridge未连接'}), 500

        @self.app.route('/api/emergence', methods=['POST'])
        def evaluate_emergence():
            data = request.get_json()
            if not data or 'metrics' not in data:
                return jsonify({'error': '缺少metrics参数'}), 400

            if hasattr(self.system, 'qidi_bridge') and self.system.qidi_bridge:
                result = self.system.qidi_bridge.evaluate_emergence(data['metrics'])
                return jsonify(result)
            return jsonify({'error': 'Qidi Bridge未连接'}), 500

        @self.app.route('/api/embedding', methods=['POST'])
        def embedding():
            data = request.get_json()
            if not data or 'text' not in data:
                return jsonify({'error': '缺少text参数'}), 400

            embedding = self.system.baize_embed(data['text'][:1000])
            return jsonify({
                'dim': len(embedding),
                'embedding': embedding[:20],
                'truncated': len(data['text']) > 1000,
            })

        # ============ HoloGram 代码图谱 ============

        @self.app.route('/api/code/status', methods=['GET'])
        def hologram_status():
            if hasattr(self.system, 'hologram') and self.system.hologram:
                return jsonify(self.system.hologram.get_status())
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/analyze', methods=['POST'])
        def hologram_analyze():
            data = request.get_json() or {}
            path = data.get('path')
            result = self.system.analyze_code(path)
            return jsonify(result)

        @self.app.route('/api/code/explore', methods=['POST'])
        def hologram_explore():
            data = request.get_json()
            if not data or 'query' not in data:
                return jsonify({'error': '缺少query参数'}), 400
            result = self.system.explore_code(data['query'])
            return jsonify(result)

        @self.app.route('/api/code/fragile', methods=['GET'])
        def hologram_fragile():
            if hasattr(self.system, 'hologram') and self.system.hologram:
                limit = int(request.args.get('limit', 5))
                return jsonify(self.system.hologram.fragile_modules(limit=limit))
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/blindspots', methods=['GET'])
        def hologram_blindspots():
            if hasattr(self.system, 'hologram') and self.system.hologram:
                filter_type = request.args.get('filter', 'all')
                return jsonify(self.system.hologram.blindspots(filter=filter_type))
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/search', methods=['POST'])
        def hologram_search():
            data = request.get_json()
            if not data or 'query' not in data:
                return jsonify({'error': '缺少query参数'}), 400
            if hasattr(self.system, 'hologram') and self.system.hologram:
                limit = data.get('limit', 20)
                return jsonify(self.system.hologram.search(data['query'], limit=limit))
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/summary', methods=['GET'])
        def hologram_summary():
            if hasattr(self.system, 'hologram') and self.system.hologram:
                return jsonify(self.system.hologram.graph_summary())
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/impact', methods=['POST'])
        def hologram_impact():
            data = request.get_json()
            if not data or 'node_id' not in data:
                return jsonify({'error': '缺少node_id参数'}), 400
            if hasattr(self.system, 'hologram') and self.system.hologram:
                depth = data.get('depth', 3)
                return jsonify(self.system.hologram.impact(data['node_id'], depth=depth))
            return jsonify({'error': 'HoloGram未连接'}), 500

        @self.app.route('/api/code/preflight', methods=['POST'])
        def hologram_preflight():
            data = request.get_json()
            if not data or 'files' not in data:
                return jsonify({'error': '缺少files参数'}), 400
            if hasattr(self.system, 'hologram') and self.system.hologram:
                return jsonify(self.system.hologram.preflight_for_self_evolve(data['files']))
            return jsonify({'error': 'HoloGram未连接'}), 500

    def start(self):
        """启动服务（后台线程）"""
        if self._running:
            logger.warning('[API] 服务已在运行')
            return

        self._running = True
        self._thread = Thread(target=self._run_server, daemon=True)
        self._thread.start()
        logger.info(f'[API] 服务已启动: http://{self.host}:{self.port}')

    def _run_server(self):
        """运行Flask服务器"""
        try:
            self.app.run(host=self.host, port=self.port, debug=False)
        except Exception as e:
            logger.error(f'[API] 服务运行失败: {e}')
            self._running = False

    def stop(self):
        """停止服务"""
        self._running = False
        logger.info('[API] 服务已停止')

    def is_running(self):
        """检查服务状态"""
        return self._running and self._thread and self._thread.is_alive()

    def get_url(self):
        """获取服务URL"""
        return f'http://{self.host}:{self.port}'
