"""
CloudProvider — 云端模型统一调用接口

支持的Provider类型:
  - openai: OpenAI API
  - anthropic: Anthropic Claude API
  - azure_openai: Azure OpenAI Service
  - openai_compatible: 兼容OpenAI协议的服务（如DeepSeek、豆包、通义千问）
  - custom: 自定义HTTP API

统一接口:
  - chat(messages, model=None, stream=False) → 对话响应
  - completions(prompt, model=None) → 文本补全
  - embeddings(texts) → 向量嵌入

自动注册为Capability，参与共现分析和进化机制
"""
import os
import json
import time
import logging
import requests
from typing import Any, Dict, List, Optional, Union, Iterator
from pathlib import Path

from capability.base import Capability

logger = logging.getLogger('CloudProvider')

PROJECT_ROOT = Path(__file__).parent.parent.parent
CONFIG_PATH = PROJECT_ROOT / 'config' / 'cloud_models.json'


class CloudProviderError(Exception):
    pass


class BaseProvider:
    def __init__(self, config: Dict):
        self.config = config
        self.id = config['id']
        self.name = config['name']
        self.enabled = config.get('enabled', False)
        self.models = config.get('models', [])
        self.default_model = config.get('default_model')
        self.api_key = os.getenv(config.get('api_key_env'))
        if self.enabled and not self.api_key:
            logger.warning(f"[{self.name}] 已启用但未设置 API Key 环境变量: {config.get('api_key_env')}")

    def is_available(self) -> bool:
        return self.enabled and self.api_key is not None

    def chat(self, messages: List[Dict], model: str = None, stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        raise NotImplementedError

    def completions(self, prompt: str, model: str = None, **kwargs) -> str:
        raise NotImplementedError

    def embeddings(self, texts: Union[str, List[str]]) -> List[List[float]]:
        raise NotImplementedError

    def list_models(self) -> List[Dict]:
        return self.models


class OpenAIProvider(BaseProvider):
    def __init__(self, config: Dict):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.openai.com/v1')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

    def chat(self, messages: List[Dict], model: str = None, stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        model = model or self.default_model
        url = f"{self.base_url}/chat/completions"
        payload = {
            'model': model,
            'messages': messages,
            'stream': stream,
            **kwargs
        }

        response = requests.post(url, headers=self.headers, json=payload, stream=stream, timeout=60)
        response.raise_for_status()

        if stream:
            return self._stream_chat(response)
        return response.json()['choices'][0]['message']['content']

    def _stream_chat(self, response) -> Iterator[str]:
        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        break
                    try:
                        chunk = json.loads(data)
                        content = chunk['choices'][0]['delta'].get('content', '')
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue

    def completions(self, prompt: str, model: str = None, **kwargs) -> str:
        model = model or self.default_model
        url = f"{self.base_url}/completions"
        payload = {
            'model': model,
            'prompt': prompt,
            **kwargs
        }
        response = requests.post(url, headers=self.headers, json=payload, timeout=60)
        response.raise_for_status()
        return response.json()['choices'][0]['text']

    def embeddings(self, texts: Union[str, List[str]]) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        url = f"{self.base_url}/embeddings"
        results = []
        for text in texts:
            payload = {'model': self._get_embedding_model(), 'input': text}
            response = requests.post(url, headers=self.headers, json=payload, timeout=60)
            response.raise_for_status()
            results.append(response.json()['data'][0]['embedding'])
        return results

    def _get_embedding_model(self) -> str:
        for m in self.models:
            if m.get('type') == 'embedding':
                return m['name']
        return 'text-embedding-3-large'


class AnthropicProvider(BaseProvider):
    def __init__(self, config: Dict):
        super().__init__(config)
        self.base_url = config.get('base_url', 'https://api.anthropic.com/v1')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
            'anthropic-version': '2023-06-01'
        }

    def chat(self, messages: List[Dict], model: str = None, stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        model = model or self.default_model
        url = f"{self.base_url}/messages"

        system = ""
        user_messages = []
        for msg in messages:
            if msg['role'] == 'system':
                system += msg['content'] + "\n"
            else:
                user_messages.append(msg)

        payload = {
            'model': model,
            'system': system.strip(),
            'messages': user_messages,
            'stream': stream,
            'max_tokens': kwargs.get('max_tokens', 4096),
            **{k: v for k, v in kwargs.items() if k != 'max_tokens'}
        }

        response = requests.post(url, headers=self.headers, json=payload, stream=stream, timeout=60)
        response.raise_for_status()

        if stream:
            return self._stream_chat(response)
        return response.json()['content'][0]['text']

    def _stream_chat(self, response) -> Iterator[str]:
        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8').strip()
                if line.startswith('event: '):
                    event = line[7:]
                    continue
                if line.startswith('data: '):
                    data = line[6:]
                    try:
                        chunk = json.loads(data)
                        if chunk.get('type') == 'content_block_delta':
                            yield chunk['delta'].get('text', '')
                    except json.JSONDecodeError:
                        continue

    def completions(self, prompt: str, model: str = None, **kwargs) -> str:
        return self.chat([{'role': 'user', 'content': prompt}], model, **kwargs)

    def embeddings(self, texts: Union[str, List[str]]) -> List[List[float]]:
        raise CloudProviderError("Anthropic 不支持 embeddings API")


class AzureOpenAIProvider(BaseProvider):
    def __init__(self, config: Dict):
        super().__init__(config)
        self.endpoint = config.get('azure_endpoint', '')
        self.api_version = config.get('api_version', '2024-02-15-preview')
        self.headers = {
            'api-key': self.api_key,
            'Content-Type': 'application/json'
        }

    def _get_deployment_name(self, model: str) -> str:
        for m in self.models:
            if m['name'] == model:
                return m.get('deployment_name', model)
        return model

    def chat(self, messages: List[Dict], model: str = None, stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        model = model or self.default_model
        deployment = self._get_deployment_name(model)
        url = f"{self.endpoint}openai/deployments/{deployment}/chat/completions?api-version={self.api_version}"
        payload = {
            'messages': messages,
            'stream': stream,
            **kwargs
        }

        response = requests.post(url, headers=self.headers, json=payload, stream=stream, timeout=60)
        response.raise_for_status()

        if stream:
            return self._stream_chat(response)
        return response.json()['choices'][0]['message']['content']

    def _stream_chat(self, response) -> Iterator[str]:
        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        break
                    try:
                        chunk = json.loads(data)
                        content = chunk['choices'][0]['delta'].get('content', '')
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue

    def completions(self, prompt: str, model: str = None, **kwargs) -> str:
        model = model or self.default_model
        deployment = self._get_deployment_name(model)
        url = f"{self.endpoint}openai/deployments/{deployment}/completions?api-version={self.api_version}"
        payload = {'prompt': prompt, **kwargs}
        response = requests.post(url, headers=self.headers, json=payload, timeout=60)
        response.raise_for_status()
        return response.json()['choices'][0]['text']

    def embeddings(self, texts: Union[str, List[str]]) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        model = self._get_embedding_model()
        deployment = self._get_deployment_name(model)
        url = f"{self.endpoint}openai/deployments/{deployment}/embeddings?api-version={self.api_version}"
        results = []
        for text in texts:
            payload = {'input': text}
            response = requests.post(url, headers=self.headers, json=payload, timeout=60)
            response.raise_for_status()
            results.append(response.json()['data'][0]['embedding'])
        return results

    def _get_embedding_model(self) -> str:
        for m in self.models:
            if m.get('type') == 'embedding':
                return m['name']
        return 'text-embedding-3-large'


class CustomProvider(BaseProvider):
    def __init__(self, config: Dict):
        super().__init__(config)
        self.base_url = config.get('base_url', '')
        self.chat_endpoint = config.get('chat_endpoint', '/chat/completions')
        self.embed_endpoint = config.get('embed_endpoint', '/embeddings')
        self.headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }

    def chat(self, messages: List[Dict], model: str = None, stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        model = model or self.default_model
        url = f"{self.base_url}{self.chat_endpoint}"
        payload = {'model': model, 'messages': messages, 'stream': stream, **kwargs}

        response = requests.post(url, headers=self.headers, json=payload, stream=stream, timeout=60)
        response.raise_for_status()

        if stream:
            return self._stream_chat(response)
        return response.json()['choices'][0]['message']['content']

    def _stream_chat(self, response) -> Iterator[str]:
        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data = line[6:]
                    if data == '[DONE]':
                        break
                    try:
                        chunk = json.loads(data)
                        content = chunk['choices'][0]['delta'].get('content', '')
                        if content:
                            yield content
                    except json.JSONDecodeError:
                        continue

    def completions(self, prompt: str, model: str = None, **kwargs) -> str:
        return self.chat([{'role': 'user', 'content': prompt}], model, **kwargs)

    def embeddings(self, texts: Union[str, List[str]]) -> List[List[float]]:
        if isinstance(texts, str):
            texts = [texts]
        url = f"{self.base_url}{self.embed_endpoint}"
        results = []
        for text in texts:
            payload = {'input': text}
            response = requests.post(url, headers=self.headers, json=payload, timeout=60)
            response.raise_for_status()
            results.append(response.json()['data'][0]['embedding'])
        return results


_PROVIDER_REGISTRY = {
    'openai': OpenAIProvider,
    'anthropic': AnthropicProvider,
    'azure_openai': AzureOpenAIProvider,
    'openai_compatible': OpenAIProvider,
    'custom': CustomProvider,
}


class CloudProvider:
    def __init__(self):
        self.providers: Dict[str, BaseProvider] = {}
        self.default_provider_id: str = None
        self._load_config()

    def _load_config(self):
        if not CONFIG_PATH.exists():
            logger.warning(f"未找到云端模型配置: {CONFIG_PATH}")
            return

        try:
            with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
                config = json.load(f)

            for provider_config in config.get('providers', []):
                provider_type = provider_config.get('type', 'openai')
                provider_cls = _PROVIDER_REGISTRY.get(provider_type, OpenAIProvider)
                provider = provider_cls(provider_config)
                self.providers[provider.id] = provider
                if provider.is_available():
                    logger.info(f"[{provider.name}] 已配置并启用")

            self.default_provider_id = config.get('default_provider', 'openai')
            logger.info(f"云端模型Provider已加载: {len(self.providers)} 个")

        except Exception as e:
            logger.error(f"加载云端模型配置失败: {e}")

    def get_provider(self, provider_id: str = None) -> Optional[BaseProvider]:
        provider_id = provider_id or self.default_provider_id
        provider = self.providers.get(provider_id)
        if provider and provider.is_available():
            return provider
        return None

    def list_providers(self) -> List[Dict]:
        return [{
            'id': p.id,
            'name': p.name,
            'enabled': p.enabled,
            'available': p.is_available(),
            'base_url': getattr(p, 'base_url', p.config.get('base_url', '')),
            'models': p.list_models()
        } for p in self.providers.values()]

    def chat(self, messages: List[Dict], provider_id: str = None, model: str = None,
             stream: bool = False, **kwargs) -> Union[str, Iterator[str]]:
        provider = self.get_provider(provider_id)
        if not provider:
            raise CloudProviderError(f"Provider {provider_id} 不可用，请检查配置")
        return provider.chat(messages, model, stream, **kwargs)

    def completions(self, prompt: str, provider_id: str = None, model: str = None, **kwargs) -> str:
        provider = self.get_provider(provider_id)
        if not provider:
            raise CloudProviderError(f"Provider {provider_id} 不可用，请检查配置")
        return provider.completions(prompt, model, **kwargs)

    def embeddings(self, texts: Union[str, List[str]], provider_id: str = None) -> List[List[float]]:
        provider = self.get_provider(provider_id)
        if not provider:
            raise CloudProviderError(f"Provider {provider_id} 不可用，请检查配置")
        return provider.embeddings(texts)

    def get_available_models(self) -> List[str]:
        models = []
        for provider in self.providers.values():
            if provider.is_available():
                for m in provider.models:
                    if m.get('type') != 'embedding':
                        models.append(f"{provider.id}:{m['name']}")
        return models

    def save_config(self) -> bool:
        """保存当前配置到文件"""
        try:
            config = {
                'providers': [],
                'default_provider': self.default_provider_id
            }
            for provider_id, provider in self.providers.items():
                provider_config = provider.config.copy()
                config['providers'].append(provider_config)
            
            with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
                json.dump(config, f, ensure_ascii=False, indent=2)
            logger.info(f"云端模型配置已保存: {CONFIG_PATH}")
            return True
        except Exception as e:
            logger.error(f"保存配置失败: {e}")
            return False

    def enable_provider(self, provider_id: str) -> bool:
        """启用指定Provider"""
        if provider_id not in self.providers:
            return False
        self.providers[provider_id].enabled = True
        self.providers[provider_id].config['enabled'] = True
        return True

    def disable_provider(self, provider_id: str) -> bool:
        """禁用指定Provider"""
        if provider_id not in self.providers:
            return False
        self.providers[provider_id].enabled = False
        self.providers[provider_id].config['enabled'] = False
        return True

    def set_api_key(self, provider_id: str, api_key: str) -> bool:
        """设置Provider的API Key（内存中，需要save_config持久化）"""
        if provider_id not in self.providers:
            return False
        provider = self.providers[provider_id]
        provider.api_key = api_key
        provider.config['api_key'] = api_key
        if 'api_key_env' in provider.config:
            del provider.config['api_key_env']
        if hasattr(provider, 'headers'):
            if isinstance(provider, AzureOpenAIProvider):
                provider.headers['api-key'] = api_key
            else:
                provider.headers['Authorization'] = f'Bearer {api_key}'
        return True

    def set_default_provider(self, provider_id: str) -> bool:
        """设置默认Provider"""
        if provider_id not in self.providers:
            return False
        self.default_provider_id = provider_id
        return True

    def set_base_url(self, provider_id: str, base_url: str) -> bool:
        """设置Provider的连接网址"""
        if provider_id not in self.providers:
            return False
        provider = self.providers[provider_id]
        provider.base_url = base_url
        provider.config['base_url'] = base_url
        provider.headers['Authorization'] = f'Bearer {provider.api_key}' if provider.api_key else ''
        return True

    def test_provider(self, provider_id: str) -> Dict:
        """测试Provider连接"""
        if provider_id not in self.providers:
            return {'success': False, 'error': 'Provider不存在'}
        provider = self.providers[provider_id]
        if not provider.is_available():
            return {'success': False, 'error': 'Provider未启用或API Key未设置'}
        
        try:
            result = provider.chat([{'role': 'user', 'content': 'Hello'}], max_tokens=10)
            return {'success': True, 'response': result[:50]}
        except Exception as e:
            return {'success': False, 'error': str(e)}


class CloudCapability(Capability):
    def __init__(self, provider: CloudProvider):
        super().__init__(
            id='cloud.chat',
            name='云端对话',
            category='llm',
            tags=['cloud', 'ai', 'chat', 'api'],
            description='调用云端大语言模型进行对话'
        )
        self.provider = provider

    def invoke(self, args: Dict[str, Any], context: Dict = None) -> Any:
        t0 = time.time()
        ok = True
        try:
            messages = args.get('messages', [])
            provider_id = args.get('provider')
            model = args.get('model')
            stream = args.get('stream', False)

            if isinstance(messages, str):
                messages = [{'role': 'user', 'content': messages}]

            result = self.provider.chat(messages, provider_id, model, stream)
            if stream:
                full_response = ''
                for chunk in result:
                    full_response += chunk
                return full_response
            return result
        except Exception as e:
            ok = False
            logger.error(f"云端模型调用失败: {e}")
            raise
        finally:
            duration_ms = (time.time() - t0) * 1000
            self.record_call(ok, duration_ms)


class CloudEmbeddingCapability(Capability):
    def __init__(self, provider: CloudProvider):
        super().__init__(
            id='cloud.embeddings',
            name='云端嵌入',
            category='embedding',
            tags=['cloud', 'ai', 'embedding', 'vector'],
            description='调用云端模型生成文本嵌入向量'
        )
        self.provider = provider

    def invoke(self, args: Dict[str, Any], context: Dict = None) -> Any:
        t0 = time.time()
        ok = True
        try:
            texts = args.get('texts', args.get('text', ''))
            provider_id = args.get('provider')
            return self.provider.embeddings(texts, provider_id)
        except Exception as e:
            ok = False
            logger.error(f"云端嵌入调用失败: {e}")
            raise
        finally:
            duration_ms = (time.time() - t0) * 1000
            self.record_call(ok, duration_ms)


if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    cp = CloudProvider()
    print(f"可用Provider: {[p['id'] for p in cp.list_providers()]}")
    print(f"可用模型: {cp.get_available_models()}")