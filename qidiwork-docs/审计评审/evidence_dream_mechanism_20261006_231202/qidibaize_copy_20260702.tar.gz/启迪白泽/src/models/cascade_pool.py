"""
CascadePool — 级联扫描池生成架构
零 Transformer 组件，无 pairwise token 交互

核心:
  - 因果扫描池: pool[t] = decay·pool[t-1] + (1-decay)·write[t-1]
  - 三速并行: fast(0.85), medium(0.95), slow(0.995)
  - 逐 token 独立读池 + 融合门控
  - FFN 逐 token 非线性的
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math


# ─── 配置 ─────────────────────────────────────────────
class Config:
    vocab_size: int = 4096
    embed_dim: int = 256
    num_layers: int = 6
    max_seq_len: int = 256
    sp_dim: int = 24            # 每速池维度
    fast_decay: float = 0.85
    medium_decay: float = 0.95
    slow_decay: float = 0.995
    ff_hidden: int = 512        # FFN 中间层维度

    def __init__(self, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)


# ─── 因果扫描（向量化实现） ──────────────────────────
def causal_scan(write: torch.Tensor, decay: float) -> torch.Tensor:
    """
    因果前缀和扫描（指数衰减）
    write: [B, T, sp_dim]
    return: [B, T, sp_dim] — pool[t] = Σ_{k=0}^{t-1} decay^(t-1-k) · write[k]
    
    向量化实现: 三角矩阵乘 (T≤256 时 OK)
    """
    B, T, sp = write.shape
    device = write.device
    
    # 构造衰减三角矩阵 [T, T]
    # decay_mat[i][j] = decay^(i-j)  if i >= j else 0
    i_idx = torch.arange(T, device=device).unsqueeze(1)  # [T, 1]
    j_idx = torch.arange(T, device=device).unsqueeze(0)  # [1, T]
    diff = i_idx - j_idx                  # [T, T]
    mask = (diff >= 0).float()            # 下三角掩码
    decay_mat = mask * (decay ** diff)    # [T, T], decay^(i-j) for i>=j
    
    # pool[t] = Σ_j decay_mat[t][j] · write[j]  其中 decay_mat[t][t]=1
    # 但我们的定义: pool[t] = Σ_{k=0}^{t-1} decay^(t-1-k)·write[k]
    # → pool[t] = Σ_j decay_mat[t-1][j] · write[j]   (其中 decay_mat[t][t]=1)
    # → 等价于 pool = decay_mat[:-1] @ write 然后补0
    # 更简单: pool[t] = decay_mat[t][:t] @ write[:t] 乘 (1-decay) 再调适

    # 标准定义:
    # pool[t] = (1-decay) * Σ_{k=0}^{t-1} decay^(t-1-k) * write[k]
    # 用 decay_mat 实现:
    # 令 weights[t][k] = decay^(t-1-k) for t>k, else 0
    # pool[t] = (1-decay) * Σ_k weights[t][k] * write[k]
    
    # 构造: weights[t][k] = decay^(t-1-k) if k < t else 0
    # = decay^(t-k-1) * mask(k < t)
    # = decay_diff^(diff-1) for diff >= 1
    K = torch.arange(T, device=device).unsqueeze(0)  # [1, T]
    T_ = torch.arange(T, device=device).unsqueeze(1)  # [T, 1]
    diff = T_ - K                                    # [T, T]: i - j
    mask_kt = (diff >= 1).float()                    # k < t 的位置
    # weights: decay^(diff-1) for diff >= 1
    weights = mask_kt * (decay ** (diff - 1).clamp(min=0))  # [T, T]
    
    # pool[t] = (1-decay) * Σ_k weights[t][k] * write[k]
    pool = (1 - decay) * torch.einsum('tk,bks->bts', weights, write)
    return pool  # [B, T, sp_dim]


# ─── CascadePool 单层 ────────────────────────────────
class CascadePoolLayer(nn.Module):
    """
    单层: 写池 → 三速因果扫描 → 三速独立读 → softmax融合 → FFN
    """
    def __init__(self, config: Config):
        super().__init__()
        d = config.embed_dim
        sp = config.sp_dim
        
        # 写入门控
        self.write_gate = nn.Linear(d, sp, bias=True)
        
        # 三速读取投影（各自独立）
        self.fast_read = nn.Linear(sp, d, bias=True)
        self.medium_read = nn.Linear(sp, d, bias=True)
        self.slow_read = nn.Linear(sp, d, bias=True)
        
        # 融合门控: 拼接三路读出的 d 维 → 3 维 softmax
        self.fusion_gate = nn.Linear(d * 3, 3, bias=False)
        
        # FFN
        self.ln1 = nn.LayerNorm(d)
        self.ff_in = nn.Linear(d, config.ff_hidden, bias=True)
        self.ff_out = nn.Linear(config.ff_hidden, d, bias=True)
        self.ln2 = nn.LayerNorm(d)
        
        self.decay = {
            'fast': config.fast_decay,
            'medium': config.medium_decay,
            'slow': config.slow_decay,
        }
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        x: [B, T, embed_dim]
        return: [B, T, embed_dim]  — 调制后的序列
        """
        B, T, D = x.shape
        device = x.device
        
        # 1. 写入门控
        write_vals = torch.tanh(self.write_gate(x))  # [B, T, sp]
        
        # 2. 三速因果扫描
        fast_pool = causal_scan(write_vals, self.decay['fast'])    # [B, T, sp]
        med_pool  = causal_scan(write_vals, self.decay['medium'])
        slow_pool = causal_scan(write_vals, self.decay['slow'])
        
        # 3. 三速独立读取
        fast_r = self.fast_read(fast_pool)    # [B, T, D]
        med_r  = self.medium_read(med_pool)
        slow_r = self.slow_read(slow_pool)
        
        # 4. softmax 融合门控
        concat = torch.cat([fast_r, med_r, slow_r], dim=-1)  # [B, T, 3D]
        gate_logits = self.fusion_gate(concat)               # [B, T, 3]
        gate = F.softmax(gate_logits, dim=-1)                # [B, T, 3]
        
        modulation = (gate[..., 0:1] * fast_r +
                      gate[..., 1:2] * med_r   +
                      gate[..., 2:3] * slow_r)   # [B, T, D]
        
        # 5. 残差 + FFN
        h = x + modulation
        h = h + self.ff_out(F.relu(self.ff_in(self.ln1(h))))
        
        return h


# ─── CascadePool 堆叠 ────────────────────────────────
class CascadePoolStack(nn.Module):
    """N 层级联池堆叠"""
    def __init__(self, config: Config):
        super().__init__()
        self.layers = nn.ModuleList([
            CascadePoolLayer(config) for _ in range(config.num_layers)
        ])
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        for layer in self.layers:
            x = layer(x)
        return x


# ─── 完整生成模型 ────────────────────────────────────
class CascadePoolModel(nn.Module):
    """
    CascadePool 生成模型
    
    数据流:
        tokens → Embed(无位置) → CascadePoolStack × N → LN → VocabHead → logits
    """
    def __init__(self, config: Config):
        super().__init__()
        self.config = config
        
        # 字符嵌入（无位置编码）
        self.token_embedding = nn.Embedding(
            config.vocab_size, config.embed_dim, padding_idx=0
        )
        
        # 核心堆叠
        self.pool_stack = CascadePoolStack(config)
        
        # 输出头
        self.ln_final = nn.LayerNorm(config.embed_dim)
        self.vocab_head = nn.Linear(config.embed_dim, config.vocab_size, bias=True)
        
        self._init_weights()
    
    def _init_weights(self, scale: float = 0.02):
        """初始化权重（防止初始输出爆炸）"""
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.normal_(p, mean=0.0, std=scale)
        # vocab_head 用更小初始化
        nn.init.normal_(self.vocab_head.weight, mean=0.0, std=0.01)
        nn.init.zeros_(self.vocab_head.bias)
    
    def forward(self, tokens: torch.Tensor) -> torch.Tensor:
        """
        tokens: [B, T] — token IDs
        return: [B, T, vocab_size] — logits
        """
        # 1. 嵌入（无位置编码）
        h = self.token_embedding(tokens)  # [B, T, D]
        
        # 2. CascadePool 堆叠
        h = self.pool_stack(h)  # [B, T, D]
        
        # 3. 输出
        h = self.ln_final(h)
        logits = self.vocab_head(h)  # [B, T, V]
        
        return logits
    
    def get_loss(self, tokens: torch.Tensor) -> tuple:
        """
        计算 next-token prediction loss
        tokens: [B, T]
        return: (loss, perplexity)
        """
        logits = self.forward(tokens)  # [B, T, V]
        B, T, V = logits.shape
        
        shift_logits = logits[:, :-1, :].contiguous()
        shift_labels = tokens[:, 1:].contiguous()
        
        loss = F.cross_entropy(
            shift_logits.view(-1, V),
            shift_labels.view(-1),
            ignore_index=0,
            reduction='mean'
        )
        
        perplexity = math.exp(min(loss.item(), 20))
        return loss, perplexity
    
    @torch.no_grad()
    def generate(
        self,
        input_ids: torch.Tensor,
        max_new_tokens: int = 50,
        temperature: float = 0.8,
        top_k: int = 20,
        eos_id: int = None,
        repetition_penalty: float = 1.2,
        no_repeat_ngram_size: int = 3,
    ) -> torch.Tensor:
        """
        自回归生成，遇到 eos_id 提前停止
        
        方案 A 防重复:
          - repetition_penalty: 对已出现 token 的 logit 除以 penalty（>1 降权）
          - no_repeat_ngram_size: 禁止生成与已生成文本重复的 n-gram
        """
        self.eval()
        device = input_ids.device
        max_len = self.config.max_seq_len
        
        for _ in range(max_new_tokens):
            if input_ids.size(1) > max_len:
                input_ids = input_ids[:, -max_len:]
            
            logits = self.forward(input_ids)
            next_logits = logits[:, -1, :] / temperature
            
            # ── 重复惩罚：已出现 token 的 logit 除以 penalty ──
            if repetition_penalty > 1.0:
                for b in range(input_ids.size(0)):
                    seen = set(input_ids[b].tolist())
                    for tid in seen:
                        if next_logits[b, tid] > 0:
                            next_logits[b, tid] /= repetition_penalty
                        else:
                            next_logits[b, tid] *= repetition_penalty
            
            # ── n-gram 重复禁止：禁止与历史重复的 no_repeat_ngram_size-gram ──
            if no_repeat_ngram_size > 0 and input_ids.size(1) >= no_repeat_ngram_size:
                for b in range(input_ids.size(0)):
                    seq = input_ids[b].tolist()
                    ngram = no_repeat_ngram_size
                    if len(seq) >= ngram:
                        # 当前前缀 (最后 ngram-1 个 token)
                        prefix = tuple(seq[-(ngram-1):]) if ngram > 1 else ()
                        # 找出历史中所有跟在 prefix 后的 token，禁止它们
                        banned = set()
                        for i in range(len(seq) - ngram + 1):
                            window = tuple(seq[i:i+ngram-1])
                            if window == prefix and i + ngram - 1 < len(seq):
                                banned.add(seq[i + ngram - 1])
                        for tid in banned:
                            next_logits[b, tid] = float('-inf')
            
            if top_k > 0:
                top_vals, _ = torch.topk(next_logits, top_k, dim=-1)
                threshold = top_vals[:, -1].unsqueeze(-1)
                next_logits = next_logits.masked_fill(
                    next_logits < threshold, float('-inf')
                )
            
            probs = F.softmax(next_logits, dim=-1)
            next_token = torch.multinomial(probs, num_samples=1)
            input_ids = torch.cat([input_ids, next_token], dim=1)
            
            # 遇到 EOS 提前停止（batch 内任一序列停止则全停）
            if eos_id is not None and (next_token == eos_id).any():
                break
        
        return input_ids
    
    def count_params(self) -> int:
        return sum(p.numel() for p in self.parameters())


# ─── 验证运行 ─────────────────────────────────────────
if __name__ == "__main__":
    cfg = Config()
    model = CascadePoolModel(cfg)
    n = model.count_params()
    print(f"CascadePoolModel 参数量: {n:,} ({n/1e6:.2f}M)")
    
    # 前向测试
    x = torch.randint(1, 100, (2, 32))
    logits = model(x)
    print(f"输入: {x.shape} → 输出: {logits.shape}")
    
    loss, ppl = model.get_loss(x)
    print(f"Loss: {loss.item():.4f}, PPL: {ppl:.2f}")
    
    # 生成测试
    out = model.generate(x[:, :4], max_new_tokens=10)
    print(f"生成: {x[:, :4].shape} → {out.shape}")
