"""
V10 嵌入引擎 — 接入训练好的 V10 纯源池模型
替代 v9v3 + 词袋哈希, 提供 1024 维语义向量 + 三速池状态
"""
import json, os, sys, time, logging
import numpy as np

logger = logging.getLogger('V10Embed')

# ─── 模型加载 (懒加载, 首次调用时初始化) ────────
_MODEL = None
_CFG = None

def _load_model():
    global _MODEL, _CFG
    if _MODEL is not None:
        return _MODEL, _CFG

    import torch
    pyroot = "c:/Users/ASUS/CodeBuddy/Claw/Claw-Assistant/python"
    sys.path.insert(0, pyroot)
    from train_pure_pool import BaizeEmbeddingV10, Config

    # 搜索权重路径
    search_dirs = [
        "F:/代码/v10原始版/_backup",
        "F:/代码/v10原始版/建筑行业微调",
        "c:/Users/ASUS/CodeBuddy/Claw/Claw-Assistant/.qoder/experiments/v10_purepool",
    ]

    for base in search_dirs:
        cfg_p = os.path.join(base, "embedding_model.json")
        pt_p = os.path.join(base, "best_model.pt")
        if os.path.exists(cfg_p):
            cfg = Config()
            with open(cfg_p) as f:
                for k, v in json.load(f)["config"].items():
                    setattr(cfg, k, v)
            m = BaizeEmbeddingV10(cfg)
            m.load_state_dict(torch.load(pt_p, map_location="cpu", weights_only=True), strict=False)
            m = m.eval()
            _MODEL = m
            _CFG = cfg
            logger.info(f"V10加载: {base}")
            return m, cfg

    logger.warning("V10权重未找到, 使用降级嵌入")
    return None, None


def embed(text):
    """输入文本 → 1024维向量 (降级到词袋哈希)"""
    m, cfg = _load_model()
    if m is None:
        return _bag_hash(text, 1024)

    import torch
    ids = [ord(c) % 4096 for c in text[:96]]
    if len(ids) < 96:
        ids += [0] * (96 - len(ids))
    t = torch.tensor([ids])
    with torch.no_grad():
        vec = m(t)[0].numpy().tolist()
    return vec


def embed_with_pools(text):
    """输入文本 → {embedding, fast_pool, medium_pool, slow_pool}"""
    m, cfg = _load_model()
    if m is None:
        e = _bag_hash(text, 1024)
        return {"embedding": e, "fast_pool": e[:24], "medium_pool": e[:24], "slow_pool": e[:24]}

    import torch
    ids = [ord(c) % 4096 for c in text[:96]]
    if len(ids) < 96:
        ids += [0] * (96 - len(ids))
    t = torch.tensor([ids])
    with torch.no_grad():
        vec = m(t)[0].numpy().tolist()

    # 从池栈获取三速状态 (近似, 实际需从V10内部暴露)
    return {"embedding": vec, "fast_pool": vec[:24], "medium_pool": vec[24:48], "slow_pool": vec[48:72]}


def _bag_hash(text, dim=1024):
    """词袋哈希降级"""
    vec = [0.0] * dim
    for i, c in enumerate(text):
        h = hash(f"{c}_{i}") % dim
        vec[h] += 1.0
    norm = sum(x*x for x in vec)**0.5
    if norm > 0:
        vec = [x/norm for x in vec]
    return vec


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    for t in ["建筑工程施工总承包一级", "土方开挖", "hello world"]:
        v = embed(t)
        print(f"\"{t}\" -> 1024维向量, 前5={v[:5]}, 范数={sum(x*x for x in v)**0.5:.4f}")
