# v22_arch.py
# V22 共享场生成架构 — 共享反应-扩散场 + 逐token生成
#
# 核心创新（与V10生成模型的区别）:
#   V10: 每层独立的 write/read 参数, 三速独立
#   V22: 所有层共享 write/read 参数（场动力学是通用的）
#        共享参数 = 梯度跨层累计 = 更深的信息混合
#
# 架构: Embed → N×[共享场层] → Norm → VocabHead
# 每层: Linear → write(共享)→ 前缀池 → read(共享)→ 调制 → activation

import torch
import torch.nn as nn
import torch.nn.functional as F


class PrefixPool(nn.Module):
    """矩阵化前缀池：一次性计算所有位置的EMA池状态"""
    def __init__(self, sp_dim, d_embed, decay):
        super().__init__()
        self.sp_dim = sp_dim
        self.register_buffer('decay', torch.tensor(decay))
        self.write = nn.Linear(d_embed, sp_dim)
        self.read = nn.Linear(sp_dim, d_embed)

    def forward(self, x_seq):
        """
        x_seq: [B, T, d_embed]
        返回: [B, T, d_embed] 每个位置从池读出的调制信号
        """
        B, T, D = x_seq.shape
        device = x_seq.device

        # 写入：所有位置同时写入
        w = torch.tanh(self.write(x_seq))  # [B, T, sp_dim]

        # 前缀池矩阵: weights[t][k] = decay^(t-k) * (1-decay) for k≤t
        idx = torch.arange(T, device=device)
        dist = idx.unsqueeze(1) - idx.unsqueeze(0)  # [T, T]
        mask = (dist >= 0).float()
        weights = mask * (self.decay ** dist) * (1 - self.decay)
        pool = torch.einsum('tk,bks->bts', weights, w)  # [B, T, sp_dim]

        # 读取
        return self.read(pool)  # [B, T, d_embed]


class SharedFieldLayer(nn.Module):
    """单层共享场：所有层共享同一个 write/fast_read/slow_read"""
    def __init__(self, d_embed, shared_fast, shared_slow):
        """
        shared_fast, shared_slow: PrefixPool 实例（跨层共享）
        """
        super().__init__()
        self.fast_pool = shared_fast    # 共享！
        self.slow_pool = shared_slow    # 共享！
        self.linear = nn.Linear(d_embed, d_embed)
        self.fusion_gate = nn.Linear(d_embed, 1)
        self.skip_gate = nn.Parameter(torch.ones(1))

    def forward(self, x_seq):
        """
        x_seq: [B, T, d_embed]
        返回: [B, T, d_embed]
        """
        pre_act = self.linear(x_seq)

        # 从共享场读取
        fast_mod = self.fast_pool(pre_act)   # 共享 read
        slow_mod = self.slow_pool(pre_act)   # 共享 read

        # 融合 fast/slow
        alpha = torch.sigmoid(self.fusion_gate(pre_act))  # [B, T, 1]
        modulation = alpha * fast_mod + (1 - alpha) * slow_mod

        # 调制后激活 + 残差
        y = F.silu(pre_act + modulation)
        skip = x_seq.mean(dim=1, keepdim=True) * torch.sigmoid(self.skip_gate)
        return y + skip


class V22SharedFieldGen(nn.Module):
    """
    V22 共享场生成模型

    所有层共享 fast/slow pool 的 write/read 参数（场动力学=通用物理定律）
    Embed → N×共享场层 → Norm → VocabHead → logits

    参数量估算:
       Embedding:      vocab × 384 = ~4M (vocab=10633)
       共享fast pool:  384×72 + 72×384 = ~55K
       共享slow pool:  384×72 + 72×384 = ~55K
       每层:          linear(384×384) + fusion_gate(384) + skip_gate(0) = ~148K
       6层:            ~888K
       Norm + head:    ~4M
       总计:           ~9M
    """
    def __init__(self, vocab_size=10633, d_embed=384, sp_dim=72,
                 num_layers=6, fast_decay=0.9, slow_decay=0.99):
        super().__init__()
        self.d_embed = d_embed
        self.sp_dim = sp_dim
        self.num_layers = num_layers

        self.embedding = nn.Embedding(vocab_size, d_embed)

        # 共享场参数（跨所有层！）
        self.shared_fast = PrefixPool(sp_dim, d_embed, fast_decay)
        self.shared_slow = PrefixPool(sp_dim, d_embed, slow_decay)

        # 分层参数（每层独立）
        self.layers = nn.ModuleList([
            SharedFieldLayer(d_embed, self.shared_fast, self.shared_slow)
            for _ in range(num_layers)
        ])

        # 生成头
        self.out_norm = nn.LayerNorm(d_embed)
        self.vocab_head = nn.Linear(d_embed, vocab_size)

        # 初始化
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight, gain=0.5)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward(self, tokens):
        """
        tokens: [B, T] token ids
        返回: logits [B, T, vocab_size]
        """
        x = self.embedding(tokens)

        for layer in self.layers:
            x = layer(x)

        x = self.out_norm(x)
        return self.vocab_head(x)

    def compute_loss(self, tokens):
        """
        tokens: [B, T] 包含完整的 input + target
        loss: next-token prediction cross-entropy
        """
        logits = self.forward(tokens[:, :-1])
        targets = tokens[:, 1:]
        return F.cross_entropy(
            logits.reshape(-1, logits.size(-1)),
            targets.reshape(-1)
        )

    @torch.no_grad()
    def generate(self, prompt, max_new=128, temperature=0.5, top_p=0.9, repetition_penalty=1.2):
        """自回归生成（CPU采样，避免CUDA multinomial崩溃）"""
        self.eval()
        generated = prompt.clone()
        for _ in range(max_new):
            if generated.shape[1] > 256:
                inp = generated[:, -256:]
            else:
                inp = generated
            logits = self.forward(inp)
            next_logits = logits[:, -1, :].cpu() / temperature

            # 重复惩罚：对已生成的token降权
            if repetition_penalty != 1.0:
                for token_id in generated[0].tolist():
                    next_logits[0, token_id] /= repetition_penalty

            # 清理NaN/Inf防止CUDA静默崩溃
            next_logits = torch.nan_to_num(next_logits, nan=0.0, posinf=1e9, neginf=-1e9)

            # top-p 采样（CPU安全）
            probs = F.softmax(next_logits, dim=-1)
            sorted_probs, sorted_idx = torch.sort(probs, descending=True)
            cumsum = torch.cumsum(sorted_probs, dim=-1)
            mask = cumsum - sorted_probs > top_p
            sorted_probs[mask] = 0
            if sorted_probs.sum() == 0:
                # 所有token被过滤时回退均匀分布
                sorted_probs = torch.ones_like(sorted_probs) / sorted_probs.size(-1)
            else:
                sorted_probs /= sorted_probs.sum(dim=-1, keepdim=True)
            next_token = torch.multinomial(sorted_probs, num_samples=1)
            next_token = sorted_idx.gather(1, next_token).to(prompt.device)

            generated = torch.cat([generated, next_token], dim=1)
            if next_token.item() == 2 or next_token.item() == 0:  # <EOS> or <PAD>
                break
        return generated


def count_params(model):
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    shared = sum(p.numel() for p in model.shared_fast.parameters()) \
           + sum(p.numel() for p in model.shared_slow.parameters())
    return total, trainable, shared


# ===== 验证 =====
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"设备: {device}")

    model = V22SharedFieldGen(vocab_size=10633).to(device)
    total, trainable, shared = count_params(model)
    print(f"\n[参数量]")
    print(f"  总计:     {total:,} ({total/1e6:.1f}M)")
    print(f"  可训练:   {trainable:,}")
    print(f"  共享场:   {shared:,} ({shared/1e6:.2f}M)")
    print(f"  每层独立: {(total-shared):,}")

    # 验证共享参数
    for i in range(1, model.num_layers):
        assert model.layers[0].fast_pool.write is model.layers[i].fast_pool.write
        assert model.layers[0].fast_pool.read is model.layers[i].fast_pool.read
        assert model.layers[0].slow_pool.write is model.layers[i].slow_pool.write
        assert model.layers[0].slow_pool.read is model.layers[i].slow_pool.read
    print("  参数共享验证: ✅ 所有层共享 write/read")

    # 前向 + loss 测试
    B, T = 4, 32
    tokens = torch.randint(1, 10633, (B, T), device=device)
    logits = model(tokens)
    loss = model.compute_loss(tokens)
    print(f"\n[前向测试] B={B}, T={T}")
    print(f"  logits: {logits.shape} (期望 [4, 32, 10633])")
    print(f"  loss: {loss.item():.4f}")

    # 生成测试
    prompt = torch.tensor([[1, 2526]], device=device)
    gen = model.generate(prompt, max_new=16)
    print(f"  生成: {gen.shape} (prompt + {gen.shape[1]-2} new tokens)")

    print("\n✅ V22 共享场生成架构验证通过")
