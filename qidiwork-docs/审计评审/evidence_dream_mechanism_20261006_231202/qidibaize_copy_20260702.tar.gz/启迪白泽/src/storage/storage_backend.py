"""存储后端抽象 — 统一 JSON/SQLite 的持久化接口

所有持久化操作（知识树、记忆系统、技能调用、进化日志）都通过此接口，
实现层可替换（SQLite/JSON/未来可扩展FAISS）。
"""
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional


class StorageBackend(ABC):
    """存储后端基类 — 所有持久化操作的统一接口"""

    @abstractmethod
    def load_table(self, table: str) -> List[Dict[str, Any]]:
        """加载整张表，返回行字典列表"""

    @abstractmethod
    def upsert(self, table: str, key: str, data: Dict[str, Any]) -> bool:
        """插入或更新一行（按主键 key）"""

    @abstractmethod
    def delete(self, table: str, key: str) -> bool:
        """删除一行"""

    @abstractmethod
    def query(self, table: str, filters: Dict[str, Any] = None,
              limit: int = 0) -> List[Dict[str, Any]]:
        """条件查询（等值过滤）"""

    @abstractmethod
    def count(self, table: str) -> int:
        """计数"""

    def execute(self, sql: str, params: tuple = None):
        """直接执行 SQL（供复杂查询用，JSON 后端可不支持）"""
        raise NotImplementedError('此后端不支持直接 SQL 执行')

    def close(self):
        """关闭连接（可选实现）"""
        pass
