"""SQLite 存储后端 — 替代 JSON 全量读写

设计:
  - sqlite3 内置，无需额外安装
  - 向量以 JSON 文本存储（启动时全量加载到 numpy 矩阵做检索）
  - FTS5 全文检索知识内容（可选，sqlite3 编译时带 FTS5 就行）
  - WAL 模式提升并发读写
"""
import json
import sqlite3
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
from .storage_backend import StorageBackend

logger = logging.getLogger('SQLiteBackend')


# 全局表结构定义 — 所有模块共用
TABLE_SCHEMAS = {
    'knowledge_nodes': '''
        CREATE TABLE IF NOT EXISTS knowledge_nodes (
            id TEXT PRIMARY KEY,
            parent_id TEXT,
            children_ids TEXT DEFAULT '[]',
            topic TEXT,
            content TEXT DEFAULT '',
            depth INTEGER DEFAULT 0,
            hit_count INTEGER DEFAULT 0,
            is_dying INTEGER DEFAULT 0,
            created_at REAL,
            last_accessed REAL,
            source TEXT DEFAULT '',
            embedding TEXT,
            fast_pool TEXT,
            medium_pool TEXT,
            slow_pool TEXT
        )
    ''',
    'memory_entries': '''
        CREATE TABLE IF NOT EXISTS memory_entries (
            key TEXT PRIMARY KEY,
            content TEXT,
            level TEXT,
            created_at REAL,
            updated_at REAL,
            access_count INTEGER DEFAULT 0,
            success_count INTEGER DEFAULT 0,
            fail_count INTEGER DEFAULT 0,
            ttl_seconds REAL,
            metadata TEXT DEFAULT '{}',
            tags TEXT DEFAULT ''
        )
    ''',
    'skill_calls': '''
        CREATE TABLE IF NOT EXISTS skill_calls (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            skill_id TEXT,
            skill_name TEXT,
            timestamp REAL,
            success INTEGER,
            duration_ms REAL,
            context TEXT DEFAULT '{}'
        )
    ''',
    'evolution_log': '''
        CREATE TABLE IF NOT EXISTS evolution_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp REAL,
            evolution_type TEXT,
            rule_id TEXT,
            description TEXT,
            action TEXT,
            scores TEXT,
            file_path TEXT,
            trigger TEXT
        )
    ''',
}


class SQLiteBackend(StorageBackend):
    """SQLite 存储后端实现"""

    def __init__(self, db_path: str = 'data/baize.db'):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,
        )
        self._conn.row_factory = sqlite3.Row
        # WAL 模式：读写不互斥
        try:
            self._conn.execute('PRAGMA journal_mode=WAL')
            self._conn.execute('PRAGMA synchronous=NORMAL')
        except Exception:
            pass
        self._init_tables()
        logger.info(f'[SQLiteBackend] 已连接: {self.db_path}')

    def _init_tables(self):
        """初始化所有表"""
        for table, ddl in TABLE_SCHEMAS.items():
            self._conn.execute(ddl)
        # 索引
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS idx_kn_parent ON knowledge_nodes(parent_id)')
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS idx_kn_depth ON knowledge_nodes(depth)')
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS idx_me_level ON memory_entries(level)')
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS idx_sc_skill ON skill_calls(skill_id)')
        self._conn.execute(
            'CREATE INDEX IF NOT EXISTS idx_el_type ON evolution_log(evolution_type)')
        # 可选：FTS5 全文索引
        try:
            self._conn.execute(
                'CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts '
                'USING fts5(topic, content, content=\'knowledge_nodes\')'
            )
        except Exception:
            logger.debug('[SQLiteBackend] FTS5 不可用，跳过全文索引')
        self._conn.commit()

    def load_table(self, table: str) -> List[Dict[str, Any]]:
        """加载整张表"""
        if table not in TABLE_SCHEMAS:
            raise ValueError(f'未知表: {table}')
        rows = self._conn.execute(f'SELECT * FROM {table}').fetchall()
        return [dict(r) for r in rows]

    def upsert(self, table: str, key: str, data: Dict[str, Any]) -> bool:
        """插入或更新一行（INSERT OR REPLACE）"""
        if table not in TABLE_SCHEMAS:
            raise ValueError(f'未知表: {table}')
        # 获取表的列名
        cursor = self._conn.execute(f'PRAGMA table_info({table})')
        columns = [row[1] for row in cursor.fetchall()]
        # 只保留表中存在的列
        filtered = {k: v for k, v in data.items() if k in columns}
        # 确保 key 字段存在
        if columns and columns[0] not in filtered:
            filtered[columns[0]] = key
        # 构造 SQL
        col_names = list(filtered.keys())
        placeholders = ', '.join(['?'] * len(col_names))
        col_str = ', '.join(col_names)
        sql = f'INSERT OR REPLACE INTO {table} ({col_str}) VALUES ({placeholders})'
        values = []
        for col in col_names:
            v = filtered[col]
            if isinstance(v, (list, dict)):
                v = json.dumps(v, ensure_ascii=False)
            elif isinstance(v, bool):
                v = 1 if v else 0
            values.append(v)
        try:
            self._conn.execute(sql, values)
            self._conn.commit()
            return True
        except Exception as e:
            logger.error(f'[SQLiteBackend] upsert 失败: {e}')
            return False

    def delete(self, table: str, key: str) -> bool:
        """删除一行"""
        if table not in TABLE_SCHEMAS:
            raise ValueError(f'未知表: {table}')
        # 获取主键列名（第一个列）
        cursor = self._conn.execute(f'PRAGMA table_info({table})')
        pk_col = cursor.fetchone()[1]
        try:
            self._conn.execute(f'DELETE FROM {table} WHERE {pk_col}=?', (key,))
            self._conn.commit()
            return True
        except Exception as e:
            logger.error(f'[SQLiteBackend] delete 失败: {e}')
            return False

    def query(self, table: str, filters: Dict[str, Any] = None,
              limit: int = 0) -> List[Dict[str, Any]]:
        """条件查询（等值过滤）"""
        if table not in TABLE_SCHEMAS:
            raise ValueError(f'未知表: {table}')
        sql = f'SELECT * FROM {table}'
        params = []
        if filters:
            where_clauses = []
            for k, v in filters.items():
                where_clauses.append(f'{k}=?')
                params.append(v)
            sql += ' WHERE ' + ' AND '.join(where_clauses)
        if limit > 0:
            sql += f' LIMIT {limit}'
        rows = self._conn.execute(sql, params).fetchall()
        return [dict(r) for r in rows]

    def count(self, table: str) -> int:
        """计数"""
        if table not in TABLE_SCHEMAS:
            raise ValueError(f'未知表: {table}')
        row = self._conn.execute(f'SELECT COUNT(*) as cnt FROM {table}').fetchone()
        return row['cnt'] if row else 0

    def execute(self, sql: str, params: tuple = None):
        """直接执行 SQL（供复杂查询用）"""
        cursor = self._conn.execute(sql, params or ())
        self._conn.commit()
        return cursor

    def close(self):
        """关闭连接"""
        try:
            self._conn.close()
            logger.info('[SQLiteBackend] 连接已关闭')
        except Exception:
            pass
