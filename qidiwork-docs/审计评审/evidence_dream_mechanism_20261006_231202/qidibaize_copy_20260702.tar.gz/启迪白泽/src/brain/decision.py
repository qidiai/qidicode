"""
大脑路由器 — 决策路由策略

设计:
  1. 蠕虫大脑先试（秒级，不需LLM）→ confidence > 0.7 直接决策
  2. 需要生成/推理 → 云端（通过Qidi Bridge）
  3. 需要向量化 → 本地V10
  4. 未知领域 → 知识树检索 + 假设生成

不要把大脑硬绑V22 — V22重训好之前，生成/推理走云端。
"""
import logging
from typing import Dict, Any, Optional

logger = logging.getLogger('BrainRouter')


class BrainRouter:
    """大脑路由器 — 多源决策路由"""

    CONFIDENCE_THRESHOLD = 0.7
    KNOWLEDGE_HIT_THRESHOLD = 0.5

    def __init__(self, worm_brain=None, baize_embed=None, knowledge_tree=None,
                 qidi_bridge=None, hologram=None):
        self.worm_brain = worm_brain
        self.baize_embed = baize_embed
        self.knowledge_tree = knowledge_tree
        self.qidi_bridge = qidi_bridge
        self.hologram = hologram
        self._last_decision = None
        self._routing_history = []

    def decide(self, percepts=None, **kwargs) -> Dict[str, Any]:
        """
        决策路由主入口

        Returns:
            {
                'decision': {action, score, activation, valence},
                'source': 'worm' | 'knowledge' | 'cloud' | 'v10',
                'confidence': float,
                'chain': 思维链,
                'candidates': 候选列表,
            }
        """
        # 1. 蠕虫大脑快速反应
        worm_result = self._try_worm_brain(percepts, **kwargs)
        confidence = worm_result.get('decision', {}).get('score', 0)

        # 蠕虫有把握，直接返回
        if confidence > self.CONFIDENCE_THRESHOLD:
            logger.info(f'[路由] 蠕虫大脑决策: {worm_result["decision"]["action"]} (置信度: {confidence})')
            return {
                **worm_result,
                'source': 'worm',
                'confidence': confidence,
            }

        # 2. 知识树检索
        if self.knowledge_tree:
            knowledge_result = self._try_knowledge(percepts)
            if knowledge_result:
                logger.info(f'[路由] 知识树命中: {knowledge_result["topic"]}')
                return {
                    **worm_result,
                    'source': 'knowledge',
                    'confidence': min(confidence + 0.2, 0.9),
                    'knowledge': knowledge_result,
                }

        # 3. 需要生成/推理 → 云端LLM
        if self.qidi_bridge and self._needs_generation(worm_result):
            cloud_result = self._try_cloud_llm(worm_result, percepts)
            if cloud_result:
                logger.info(f'[路由] 云端LLM决策: {cloud_result.get("action")}')
                return {
                    **worm_result,
                    'source': 'cloud',
                    'confidence': 0.85,
                    'cloud_response': cloud_result,
                }

        # 4. 降级：使用蠕虫的最佳猜测
        logger.info(f'[路由] 降级决策: {worm_result.get("decision", {}).get("action", "休息")}')
        return {
            **worm_result,
            'source': 'worm',
            'confidence': confidence,
        }

    def _try_worm_brain(self, percepts=None, **kwargs) -> Dict[str, Any]:
        """尝试蠕虫大脑决策"""
        if not self.worm_brain:
            return {'decision': None, 'chain': [], 'candidates': [], 'hunger': 0.5}

        return self.worm_brain.think(percepts=percepts, **kwargs)

    def _try_knowledge(self, percepts=None) -> Optional[Dict[str, Any]]:
        """尝试知识树检索"""
        if not self.knowledge_tree or not percepts:
            return None

        query = ' '.join(percepts) if isinstance(percepts, list) else str(percepts)
        results = self.knowledge_tree.recall(query, top_k=3, min_score=self.KNOWLEDGE_HIT_THRESHOLD)

        if results:
            return {
                'topic': results[0]['topic'],
                'content': results[0]['content'],
                'similarity': results[0]['similarity'],
                'score': results[0]['score'],
                'hit_count': results[0]['hit_count'],
            }
        return None

    def _try_cloud_llm(self, worm_result: Dict, percepts=None) -> Optional[Dict[str, Any]]:
        """尝试云端LLM决策"""
        if not self.qidi_bridge:
            return None

        decision = worm_result.get('decision', {})
        action = decision.get('action', '分析')
        candidates = worm_result.get('candidates', [])

        prompt = f"""
基于以下感知信息做出决策：
感知: {percepts}
蠕虫建议: {action}
候选行动: {candidates}

请给出最终决策（一个词）和简短理由。
"""

        try:
            response = self.qidi_bridge.call('chat', {'message': prompt})
            if response and response.get('content'):
                content = response['content'].strip()
                return {
                    'action': content.split('\n')[0].strip(),
                    'reason': content,
                    'raw_response': response,
                }
        except Exception as e:
            logger.error(f'[路由] 云端LLM调用失败: {e}')

        return None

    def _needs_generation(self, worm_result: Dict) -> bool:
        """判断是否需要生成/推理"""
        decision = worm_result.get('decision', {})
        score = decision.get('score', 0)

        if score < 0.5:
            return True

        action = decision.get('action', '')
        generation_actions = {'分析', '学习', '写代码', '生成', '推理', '创作'}
        if any(a in action for a in generation_actions):
            return True

        return False

    def embed(self, text: str) -> Optional[list]:
        """向量化 — 使用V10嵌入引擎"""
        if not self.baize_embed:
            return None
        try:
            return self.baize_embed(text)
        except Exception as e:
            logger.error(f'[路由] V10嵌入失败: {e}')
            return None

    def explore_code(self, query: str) -> Optional[Dict[str, Any]]:
        """代码查询 — 通过 HoloGram 引擎理解代码结构"""
        if not self.hologram:
            return None
        try:
            return self.hologram.explore(query=query)
        except Exception as e:
            logger.error(f'[路由] 代码查询失败: {e}')
            return None

    def learn(self, topic: str, content: str, source='decision'):
        """学习新知识到知识树"""
        if self.knowledge_tree:
            self.knowledge_tree.learn(topic, content, source=source)

    def reward(self, action: str, score: float):
        """行动后反馈 — 调整蠕虫大脑连接"""
        if self.worm_brain:
            self.worm_brain.reward(action, score)

    def get_status(self) -> Dict[str, Any]:
        """获取路由器状态"""
        return {
            'worm_available': self.worm_brain is not None,
            'embed_available': self.baize_embed is not None,
            'knowledge_available': self.knowledge_tree is not None,
            'cloud_available': self.qidi_bridge is not None,
            'hologram_available': self.hologram is not None,
            'last_decision': self._last_decision,
            'routing_history_count': len(self._routing_history),
        }
