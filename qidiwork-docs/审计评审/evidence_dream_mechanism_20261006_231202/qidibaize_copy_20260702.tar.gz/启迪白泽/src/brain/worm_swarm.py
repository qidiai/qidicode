"""
蠕虫群 = 大脑

蠕虫 = 概念节点
蠕虫聚在一起 = 大脑
激活扩散 = 群体思维
合体/分裂 = 生命周期
"""
import numpy as np
import time
import copy
import logging
from collections import defaultdict

logger = logging.getLogger('WormSwarm')


class Worm:
    """一条蠕虫 = 一个概念"""

    def __init__(self, wid, name, category='general'):
        self.id = wid
        self.name = name
        self.category = category
        self.activation = 0.0
        self.baseline = 0.0
        self.valence = 0.0
        self.links = {}
        self.last_activated = 0.0
        self.activation_count = 0

    def activate(self, energy):
        remaining = 1.0 - self.activation
        self.activation = min(1.0, self.activation + energy * remaining)
        self.last_activated = time.time()
        self.activation_count += 1

    def decay(self, rate=0.85):
        self.activation *= rate
        if self.activation < 0.01:
            self.activation = 0.0

    def reinforce(self, delta):
        self.baseline = min(1.0, self.baseline + delta * 0.01)

    def link_to(self, other_id, strength=0.5):
        self.links[other_id] = min(1.0, self.links.get(other_id, 0) + strength)

    def weaken_link(self, other_id, amount=0.1):
        if other_id in self.links:
            self.links[other_id] = max(0.0, self.links[other_id] - amount)
            if self.links[other_id] < 0.01:
                del self.links[other_id]


class WormSwarm:
    """蠕虫群 = 大脑"""

    def __init__(self):
        self.worms = {}
        self._id_counter = 0
        self._name_index = {}
        self.mode = 'fused'
        self.thought_log = []

    def spawn(self, name, category='general', valence=0.0):
        if name in self._name_index:
            return self.worms[self._name_index[name]]
        self._id_counter += 1
        wid = f'w_{self._id_counter}'
        w = Worm(wid, name, category)
        w.valence = valence
        self.worms[wid] = w
        self._name_index[name] = wid
        return w

    def get(self, name):
        wid = self._name_index.get(name)
        return self.worms.get(wid) if wid else None

    def link(self, name_a, name_b, strength=0.5):
        a, b = self.get(name_a), self.get(name_b)
        if a and b:
            a.link_to(b.id, strength)
            b.link_to(a.id, strength)

    # ---- 群体思维 ----

    def spread(self, decay=0.7, threshold=0.05):
        """扩散一轮 = 群体"想了一下" """
        incoming = defaultdict(float)
        for w in self.worms.values():
            if w.activation < threshold:
                continue
            for nid, strength in w.links.items():
                energy = w.activation * strength * decay
                if energy > 0.01:
                    incoming[nid] += energy
        for wid, energy in incoming.items():
            w = self.worms.get(wid)
            if w:
                w.activate(energy)
        for w in self.worms.values():
            w.decay(rate=0.9)
            if w.baseline > 0.1 and w.activation < w.baseline * 0.3:
                w.activation = max(w.activation, w.baseline * 0.1)

    def think(self, seeds, rounds=5, decay=0.7):
        """群体思考 — seeds: {蠕虫名: 能量}"""
        for name, energy in seeds.items():
            w = self.get(name)
            if w:
                w.activate(energy)
            else:
                w = self.spawn(name)
                w.activate(energy)
        chain = []
        for i in range(rounds):
            self.spread(decay=decay)
            snap = self._snapshot()
            chain.append(snap)
            if not snap or max(snap.values(), default=0) < 0.02:
                break
        self.thought_log.append({
            'seeds': seeds, 'rounds': len(chain),
            'result': chain[-1] if chain else {}, 'time': time.time()
        })
        return chain

    def _snapshot(self, top_k=20):
        active = {}
        for w in self.worms.values():
            if w.activation > 0.02:
                active[w.name] = round(w.activation, 4)
        return dict(sorted(active.items(), key=lambda x: x[1], reverse=True)[:top_k])

    def read_decision(self, action_names=None):
        """读出决策 — 最亮的行动蠕虫"""
        if action_names is None:
            action_names = [w.name for w in self.worms.values() if w.category == 'action']
        candidates = []
        for name in action_names:
            w = self.get(name)
            if w and w.activation > 0.02:
                score = w.activation * (1.0 + w.valence)
                candidates.append((name, score, w.activation, w.valence))
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates

    # ---- 反思 ----

    def reflect(self, action_name, outcome, chain=None):
        w = self.get(action_name)
        if not w:
            return
        if outcome == 'success':
            w.valence = min(1.0, w.valence + 0.1)
            w.reinforce(0.5)
            if chain and len(chain) >= 2:
                for prev_name in chain[-2]:
                    prev = self.get(prev_name)
                    if prev and prev.id in w.links:
                        s = min(1.0, w.links[prev.id] + 0.05)
                        w.links[prev.id] = s
                        prev.links[w.id] = s
        elif outcome == 'failure':
            w.valence = max(-1.0, w.valence - 0.15)
            if chain and len(chain) >= 2:
                for prev_name in chain[-2]:
                    prev = self.get(prev_name)
                    if prev and prev.id in w.links:
                        w.weaken_link(prev.id, 0.05)
                        prev.weaken_link(w.id, 0.05)

    # ---- 规划 ----

    def plan(self, goal_name, candidates, sim_rounds=3):
        goal = self.get(goal_name)
        if not goal:
            return [(c, 0.5) for c in candidates]
        scores = {}
        for cand_name in candidates:
            saved = {wid: w.activation for wid, w in self.worms.items()}
            goal.activate(0.8)
            cw = self.get(cand_name)
            if cw:
                cw.activate(0.6)
            for _ in range(sim_rounds):
                self.spread(decay=0.6)
            if cw:
                score = cw.activation * (1.0 + cw.valence)
                related = sum(
                    self.worms[nid].activation * s
                    for nid, s in cw.links.items() if nid in self.worms
                )
                scores[cand_name] = score + related * 0.3
            else:
                scores[cand_name] = 0.0
            for wid, act in saved.items():
                if wid in self.worms:
                    self.worms[wid].activation = act
        return sorted(scores.items(), key=lambda x: x[1], reverse=True)

    # ---- 合体 / 分裂 ----

    def should_fission(self, success_rate=0.5, task_count=1, worm_count=1):
        avg_bl = np.mean([w.baseline for w in self.worms.values()]) if self.worms else 0
        return avg_bl > 0.3 and success_rate > 0.6 and task_count > worm_count

    def should_fuse(self, failure_streak=0, novelty=0.0):
        return failure_streak >= 3 or novelty > 0.7

    def fission(self, n=2, noise=0.05):
        """分裂 — 大脑复制n份，差异化"""
        swarms = []
        for i in range(n):
            ns = WormSwarm()
            for w in self.worms.values():
                nw = copy.deepcopy(w)
                for nid in nw.links:
                    nw.links[nid] += np.random.uniform(-noise, noise)
                    nw.links[nid] = max(0.0, min(1.0, nw.links[nid]))
                nw.activation = 0.0
                ns.worms[nw.id] = nw
                ns._name_index[nw.name] = nw.id
                ns._id_counter = max(ns._id_counter, int(nw.id.split('_')[1]))
            ns.mode = 'dispersed'
            swarms.append(ns)
        self.mode = 'dispersed'
        logger.info(f'分裂: 1群体 -> {n}个独立蠕虫群')
        return swarms

    def fuse_with(self, other):
        """合体 — 另一个群体的能量汇入"""
        for w in other.worms.values():
            existing = self.get(w.name)
            if existing:
                existing.activation = max(existing.activation, w.activation)
                existing.baseline = max(existing.baseline, w.baseline)
                for nid, s in w.links.items():
                    existing.links[nid] = max(existing.links.get(nid, 0), s)
            else:
                nw = self.spawn(w.name, w.category, w.valence)
                nw.activation = w.activation
                nw.baseline = w.baseline
                nw.links = dict(w.links)
        self.mode = 'fused'
        logger.info(f'合体: 吸入{len(other.worms)}条蠕虫')

    # ---- 状态 ----

    def get_active(self, threshold=0.05):
        active = []
        for w in self.worms.values():
            if w.activation > threshold:
                active.append((w.name, w.activation, w.valence, w.category))
        active.sort(key=lambda x: x[1], reverse=True)
        return active

    def get_stats(self):
        actions = [w for w in self.worms.values() if w.category == 'action']
        return {
            'total_worms': len(self.worms),
            'total_links': sum(len(w.links) for w in self.worms.values()) // 2,
            'active_now': len(self.get_active()),
            'mode': self.mode,
            'avg_baseline': float(np.mean([w.baseline for w in self.worms.values()])) if self.worms else 0,
            'action_worms': len(actions),
            'thought_count': len(self.thought_log),
        }
