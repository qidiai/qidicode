"""
蠕虫大脑 v2 — 群体思维

单个蠕虫 = 概念，激活太弱想不了
蠕虫群 = 大脑，能量叠加扩散，思维涌现

生命周期:
  弱小期: 合体群体思考
  成熟期: 分裂独立并行
  危机时: 重新合体
"""
import numpy as np
import time
import logging

from .worm_swarm import WormSwarm, Worm

logger = logging.getLogger('WormBrain')


class WormBrain:
    """
    蠕虫大脑 v2

    思考: 感知 → 激活蠕虫 → 群体扩散 → 读出最亮行动 → 决策
    反思: 行动后调整连接，下次想得不一样
    生命周期: 合体(弱小) → 分裂(成熟) → 合体(危机)
    """

    PERCEPT_MAP = {
        'high_load':     {'负载高': 0.7, '压力大': 0.5, '需要减负': 0.4},
        'low_load':      {'空闲': 0.6, '可以多做事': 0.5, '饥饿': 0.3},
        'task_success':  {'成功': 0.8, '继续': 0.5, '加强': 0.4},
        'task_failure':  {'失败': 0.7, '换策略': 0.5, '降并发': 0.4, '检查代理': 0.3},
        'high_hunger':   {'饥饿': 0.8, '找任务': 0.6, '主动出击': 0.4},
        'low_hunger':    {'满足': 0.5, '可以休息': 0.4, '整理记忆': 0.3},
        'network_slow':  {'网络慢': 0.7, '增加延迟': 0.5, '减少并发': 0.4},
        'knowledge_hit': {'有经验': 0.6, '参考历史': 0.5, '走老路': 0.3},
        'knowledge_miss':{'没经验': 0.5, '探索': 0.4, '试错': 0.3, '小心': 0.2},
    }

    ACTIONS = ['爬取', '分析', '学习', '调度', '休息', '换目标', '降速', '加速', '求助', '整理记忆']

    def __init__(self, knowledge_tree=None):
        self.swarm = WormSwarm()
        self.knowledge_tree = knowledge_tree
        self.hunger = 0.0
        self.last_chain = []
        self.last_decision = None
        self.success_count = 0
        self.failure_count = 0
        self.failure_streak = 0
        self._sub_brains = []

        self._build_innate_knowledge()

    def _build_innate_knowledge(self):
        """先天知识 — 蠕虫生下来就知道的"""

        # 概念 + 类别 + 好感度
        concepts = {
            # 行动
            '爬取': ('action', 0.3), '分析': ('action', 0.3),
            '学习': ('action', 0.3), '调度': ('action', 0.3),
            '休息': ('action', 0.1), '换目标': ('action', 0.2),
            '降速': ('action', 0.2), '加速': ('action', 0.2),
            '求助': ('action', 0.1), '整理记忆': ('action', 0.2),
            # 结果
            '成功': ('outcome', 0.8), '失败': ('outcome', -0.5),
            # 驱动
            '饥饿': ('drive', -0.3), '满足': ('drive', 0.3),
            # 感知
            '负载高': ('percept', 0.0), '空闲': ('percept', 0.0),
            '网络慢': ('percept', 0.0), '有经验': ('percept', 0.1),
            '没经验': ('percept', -0.1),
            # 感受
            '压力大': ('feeling', -0.2), '可以多做事': ('feeling', 0.2),
            '小心': ('feeling', -0.1),
            # 策略
            '继续': ('strategy', 0.3), '加强': ('strategy', 0.3),
            '换策略': ('strategy', 0.2), '降并发': ('strategy', 0.2),
            '增加延迟': ('strategy', 0.1), '减少并发': ('strategy', 0.1),
            '检查代理': ('strategy', 0.1), '找任务': ('strategy', 0.2),
            '主动出击': ('strategy', 0.2), '可以休息': ('strategy', 0.1),
            '整理记忆': ('strategy', 0.1), '需要减负': ('strategy', 0.1),
            '参考历史': ('strategy', 0.2), '走老路': ('strategy', 0.1),
            '探索': ('strategy', 0.2), '试错': ('strategy', 0.0),
        }

        for name, (cat, val) in concepts.items():
            self.swarm.spawn(name, cat, val)

        # 关联 — 概念之间的联系
        links = [
            # 失败 → 各种应对
            ('失败', '换策略', 0.8), ('失败', '降并发', 0.7),
            ('失败', '检查代理', 0.5), ('失败', '换目标', 0.4),
            # 成功 → 继续加强
            ('成功', '继续', 0.8), ('成功', '加强', 0.7),
            ('成功', '加速', 0.5), ('成功', '爬取', 0.3),
            # 负载 → 减负
            ('负载高', '需要减负', 0.8), ('负载高', '降速', 0.6),
            ('负载高', '降并发', 0.5),
            # 空闲 → 多做事
            ('空闲', '可以多做事', 0.7), ('空闲', '找任务', 0.6),
            ('空闲', '加速', 0.4),
            # 饥饿 → 找活
            ('饥饿', '找任务', 0.9), ('饥饿', '主动出击', 0.7),
            ('饥饿', '爬取', 0.5),
            # 满足 → 休息整理
            ('满足', '可以休息', 0.6), ('满足', '整理记忆', 0.5),
            ('满足', '分析', 0.4),
            # 网络慢 → 降速
            ('网络慢', '增加延迟', 0.8), ('网络慢', '减少并发', 0.7),
            ('网络慢', '降速', 0.5),
            # 经验 → 策略
            ('有经验', '参考历史', 0.7), ('有经验', '走老路', 0.5),
            ('没经验', '探索', 0.7), ('没经验', '试错', 0.5),
            ('没经验', '小心', 0.6),
            # 策略 → 行动
            ('找任务', '爬取', 0.7), ('主动出击', '爬取', 0.6),
            ('继续', '爬取', 0.6), ('加强', '加速', 0.5),
            ('换策略', '换目标', 0.5), ('换策略', '学习', 0.4),
            ('需要减负', '降速', 0.6), ('需要减负', '休息', 0.3),
            ('可以多做事', '爬取', 0.5), ('可以多做事', '分析', 0.4),
            ('参考历史', '爬取', 0.4), ('探索', '学习', 0.5),
            ('整理记忆', '分析', 0.5), ('整理记忆', '学习', 0.4),
            # 行动之间
            ('爬取', '分析', 0.3), ('分析', '学习', 0.4),
            ('调度', '爬取', 0.3), ('加速', '爬取', 0.3),
            ('降速', '休息', 0.2), ('求助', '调度', 0.4),
        ]

        for a, b, s in links:
            self.swarm.link(a, b, s)

    # ---- 感知 ----

    def perceive(self, percepts=None, **kwargs):
        """
        感知环境 → 返回应该激活的蠕虫

        percepts: ['high_load', 'task_failure', ...]
        kwargs: load, hunger, success_rate 等数值 → 自动转percepts
        """
        if percepts is None:
            percepts = []

        # 数值 → 自动判断
        load = kwargs.get('load', 0.5)
        self.hunger = kwargs.get('hunger', self.hunger)
        success_rate = kwargs.get('success_rate', 0.5)

        if load > 0.7:
            percepts.append('high_load')
        elif load < 0.3:
            percepts.append('low_load')

        if self.hunger > 0.6:
            percepts.append('high_hunger')
        elif self.hunger < 0.3:
            percepts.append('low_hunger')

        # 合并激活
        seeds = {}
        for p in percepts:
            if p in self.PERCEPT_MAP:
                for name, energy in self.PERCEPT_MAP[p].items():
                    seeds[name] = max(seeds.get(name, 0), energy)

        return seeds

    # ---- 思考 ----

    def think(self, seeds=None, rounds=5, percepts=None, **kwargs):
        """
        思考 = 感知 + 激活 + 扩散 + 读出

        返回: {
            'decision': 最亮行动,
            'chain': 思维链,
            'candidates': 所有候选行动及分数,
            'hunger': 饥饿度,
        }
        """
        # 感知
        if seeds is None:
            seeds = {}
        percept_seeds = self.perceive(percepts, **kwargs)
        for name, energy in percept_seeds.items():
            seeds[name] = max(seeds.get(name, 0), energy)

        # 饥饿自然增长
        self.hunger = min(1.0, self.hunger + 0.01)

        # 群体扩散
        chain = self.swarm.think(seeds, rounds=rounds)
        self.last_chain = chain

        # 读出决策
        candidates = self.swarm.read_decision(self.ACTIONS)

        # 构造结果
        decision = None
        if candidates:
            best = candidates[0]
            decision = {
                'action': best[0],
                'score': round(best[1], 4),
                'activation': round(best[2], 4),
                'valence': round(best[3], 4),
            }

        result = {
            'decision': decision,
            'chain': chain,
            'candidates': [(c[0], round(c[1], 4)) for c in candidates[:5]],
            'hunger': round(self.hunger, 4),
        }
        self.last_decision = result

        # 知识树记录
        if self.knowledge_tree and decision:
            self.knowledge_tree.learn(
                topic=f'决策: {decision["action"]}',
                content=f'感知={list(seeds.keys())} 决策={decision["action"]} 分数={decision["score"]}',
                source='decision'
            )

        return result

    # ---- 反思 ----

    def reward(self, action, score):
        """行动后反馈 — 调整连接"""
        outcome = 'success' if score > 0.5 else 'failure'

        if outcome == 'success':
            self.success_count += 1
            self.failure_streak = 0
            self.hunger = max(0.0, self.hunger - 0.1)
        else:
            self.failure_count += 1
            self.failure_streak += 1
            self.hunger = min(1.0, self.hunger + 0.05)

        self.swarm.reflect(action, outcome, self.last_chain)

    # ---- 生命周期 ----

    def try_fission(self, task_count=1):
        """尝试分裂"""
        total = self.success_count + self.failure_count
        rate = self.success_count / total if total > 0 else 0
        if self.swarm.should_fission(rate, task_count, 1):
            subs = self.swarm.fission(n=2)
            self._sub_brains = subs
            return subs
        return None

    def try_fuse(self, sub_swarm):
        """重新合体"""
        if self.swarm.should_fuse(self.failure_streak):
            self.swarm.fuse_with(sub_swarm)
            self._sub_brains = []
            return True
        return False

    # ---- 兼容旧接口 ----

    def decide(self):
        """兼容旧接口 — 返回简化的决策"""
        result = self.think()
        d = result.get('decision') or {}
        return {
            'expert': d.get('action', '休息'),
            'delay': (1.0 - d.get('activation', 0.5)) * 5.0,
            'concurrency': int(d.get('activation', 0.5) * 10) + 1,
            'backoff': (1.0 - d.get('activation', 0.5)) * 3.0,
            'hunger': self.hunger,
        }

    # ---- 状态 ----

    def get_status(self):
        stats = self.swarm.get_stats()
        total = self.success_count + self.failure_count
        return {
            'hunger': round(self.hunger, 4),
            'success_rate': round(self.success_count / total, 4) if total > 0 else 0,
            'failure_streak': self.failure_streak,
            'mode': stats['mode'],
            'swarm': stats,
            'sub_brains': len(self._sub_brains),
        }
