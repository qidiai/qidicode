"""
自我进化 — 生物体修改自己的代码

发现不足 → 分析代码 → 生成修改 → 测试 → 采纳或回滚

安全机制:
  1. 只改自己目录下的代码
  2. 每次修改前自动备份
  3. 修改后必须跑测试
  4. 测试不过自动回滚
  5. 所有修改记录可追溯

进化触发:
  - 概念图发现自身结构不够(连接太稀疏)
  - 反复失败且反思无法解决
  - 老师建议修改
  - 做梦时灵感 → 具体代码改进
"""
import os
import sys
import ast
import json
import time
import shutil
import copy
import logging
import traceback
import importlib
from pathlib import Path
from datetime import datetime

logger = logging.getLogger('SelfEvolve')


class CodeChange:
    """一次代码修改"""

    def __init__(self, file_path, old_code, new_code, reason, trigger):
        self.file_path = file_path
        self.old_code = old_code
        self.new_code = new_code
        self.reason = reason
        self.trigger = trigger  # reflect / dream / teacher / self
        self.timestamp = time.time()
        self.test_passed = None
        self.adopted = None
        self.rollback_id = None

    def to_dict(self):
        return {
            'file': self.file_path,
            'reason': self.reason,
            'trigger': self.trigger,
            'timestamp': self.timestamp,
            'test_passed': self.test_passed,
            'adopted': self.adopted,
            'old_lines': len(self.old_code.splitlines()),
            'new_lines': len(self.new_code.splitlines()),
        }


class SelfEvolve:
    """
    自我进化 — 生物体修改自己的代码

    流程:
      1. 诊断: 发现什么不够好
      2. 定位: 找到对应代码
      3. 方案: 生成修改(大模型或规则)
      4. 测试: 跑测试验证
      5. 采纳/回滚
    """

    # 模块 → 职责映射（启迪白泽实际文件路径，相对于 src/）
    MODULE_MAP = {
        'brain/worm_brain.py': {
            'concepts': ['决策', '感知', '反思', '饥饿', '行动', '思考', '蠕虫'],
            'description': '大脑 — 感知→思考→决策→反思',
            'can_modify': True,
        },
        'memory/knowledge_tree.py': {
            'concepts': ['记忆', '知识', '检索', '学习', '三速池', '知识树'],
            'description': '知识树 — 三速池记忆 + 语义检索',
            'can_modify': True,
        },
        'memory/memory_system.py': {
            'concepts': ['记忆', '遗忘', '晋升', '置信分', '四层'],
            'description': '记忆系统 — 四层分层 + 持久化',
            'can_modify': True,
        },
        'skills/skill_registry.py': {
            'concepts': ['Skill', '技能', '组合', '共现', '能力'],
            'description': 'Skill系统 — 注册 + 共现 + 组合',
            'can_modify': True,
        },
        'evolution/evolution_engine.py': {
            'concepts': ['进化', '规则', '回滚', '快照'],
            'description': '进化引擎 — 规则匹配 + 评估 + 回滚',
            'can_modify': True,
        },
        'bridge/qidi_bridge.py': {
            'concepts': ['Qidi', 'Bridge', '远程', 'RPC', '涌现'],
            'description': 'Qidi Bridge — 远程 RPC 桥接',
            'can_modify': False,  # 外部接口，不自己改
        },
        'growth/self_evolve.py': {
            'concepts': ['进化', '自我修改', '代码', '回滚'],
            'description': '自我进化 — 修改自己的代码',
            'can_modify': False,  # 不改自己，防止递归
        },
        'main.py': {
            'concepts': ['统合体', '主循环', '系统入口', '组件'],
            'description': '系统入口 — 统合所有组件',
            'can_modify': True,
        },
    }

    # 内置优化规则 — 不需要大模型就能做的简单修改
    OPTIMIZATION_RULES = [
        {
            'name': '稀疏连接补强',
            'condition': lambda org: hasattr(org, 'brain') and hasattr(org.brain, 'swarm') and
                len(org.brain.swarm.worms) > 50 and
                sum(len(w.links) for w in org.brain.swarm.worms.values()) / len(org.brain.swarm.worms) < 2.0,
            'action': 'add_links',
            'description': '蠕虫平均连接数<2，太稀疏，自动补充关联',
        },
        {
            'name': '扩散效率提升',
            'condition': lambda org: org._last_success_rate < 0.3 and org.cycle_count > 10,
            'action': 'tune_spread',
            'description': '成功率太低，调整扩散参数',
        },
        {
            'name': '睡眠周期调整',
            'condition': lambda org: org.cycle_count > 30 and
                len([h for h in org.history if h.get('phase') == 'dream']) < 2,
            'action': 'tune_sleep',
            'description': '很久没睡觉，缩短睡眠周期',
        },
        {
            'name': '概念图膨胀检测',
            'condition': lambda org: hasattr(org, 'brain') and hasattr(org.brain, 'swarm') and
                len(org.brain.swarm.worms) > 500 and
                sum(1 for w in org.brain.swarm.worms.values() if w.baseline < 0.01 and w.activation_count < 3) > len(org.brain.swarm.worms) * 0.3,
            'action': 'prune_concepts',
            'description': '30%以上概念几乎没用过，需要修剪',
        },
        {
            'name': '记忆膨胀检测',
            'condition': lambda org: hasattr(org, 'memory') and len(org.memory.storage) > 10000,
            'action': 'trigger_forgetting',
            'description': '记忆条目超过10000，触发激进遗忘',
        },
        {
            'name': 'Skill成功率低',
            'condition': lambda org: hasattr(org, 'skill_registry') and any(
                s.usage_count > 10 and s.success_rate < 0.5
                for s in org.skill_registry.list_all()
            ),
            'action': 'skill_demote',
            'description': '部分Skill成功率低于50%，建议降级或优化',
        },
        {
            'name': '高共现未组合',
            'condition': lambda org: hasattr(org, 'cooccurrence') and
                org.cooccurrence.get_stats()['total_calls'] > 100,
            'action': 'trigger_combine',
            'description': '共现分析数据充足，检查是否有高共现Skill对需要组合',
        },
    ]

    def __init__(self, organism, teacher=None, code_dir=None):
        self.organism = organism
        self.teacher = teacher
        # code_dir 默认指向 src/ 目录（self_evolve.py 在 src/growth/ 下）
        self.code_dir = code_dir or os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.changes = []         # 所有修改记录
        self.backup_dir = os.path.join(self.code_dir, '..', 'evolution_backups')
        self.max_backups = 20
        self.hologram = None  # HoloGram 引擎（可选，用于预检）

    # ---- 诊断 ----

    def diagnose(self):
        """诊断: 发现什么不够好"""
        issues = []

        # 1. 检查内置规则
        for rule in self.OPTIMIZATION_RULES:
            try:
                if rule['condition'](self.organism):
                    issues.append({
                        'type': 'rule',
                        'name': rule['name'],
                        'action': rule['action'],
                        'description': rule['description'],
                    })
            except Exception:
                pass

        # 2. 检查概念图结构
        swarm = self.organism.brain.swarm
        stats = swarm.get_stats()

        if stats['total_worms'] > 0 and stats['total_links'] / stats['total_worms'] < 1.5:
            issues.append({
                'type': 'structural',
                'name': '连接太稀疏',
                'description': f'平均连接数={stats["total_links"]/max(stats["total_worms"],1):.1f}，建议>2',
            })

        # 3. 检查成功率趋势
        if len(self.organism.history) >= 10:
            recent = self.organism.history[-10:]
            recent_rate = sum(1 for h in recent if h.get('outcome', 0) > 0.5) / len(recent)
            if recent_rate < 0.3:
                issues.append({
                    'type': 'performance',
                    'name': '最近成功率低',
                    'description': f'最近10轮成功率={recent_rate:.0%}',
                })

        # 4. 检查是否有模块需要修改
        for filename, info in self.MODULE_MAP.items():
            if not info['can_modify']:
                continue
            filepath = os.path.join(self.code_dir, filename)
            if not os.path.exists(filepath):
                continue
            # 检查文件大小 — 如果太大可能需要拆分
            size = os.path.getsize(filepath)
            if size > 20000:  # >20KB
                issues.append({
                    'type': 'code_size',
                    'name': f'{filename}较大',
                    'description': f'{filename}有{size}字节，考虑拆分',
                })

        return issues

    # ---- 定位 ----

    def locate_code(self, concept_name):
        """根据概念名定位代码文件"""
        for filename, info in self.MODULE_MAP.items():
            if concept_name in info['concepts']:
                return filename
        # 模糊匹配
        for filename, info in self.MODULE_MAP.items():
            for c in info['concepts']:
                if c in concept_name or concept_name in c:
                    return filename
        return None

    # ---- 执行修改 ----

    def _validate_code(self, filepath, new_code):
        """
        写文件前的守卫 — 防止把源文件写成 JSON / 片段 / 空

        规则:
          1. 新代码必须能 ast.parse (比 compile 更严, 能挡语义错误)
          2. 新代码的顶层 class/def 符号集合 必须 ⊇ 原代码的顶层符号
             (大模型不能把 WormSwarm/Worm 这种关键类搞丢)
          3. 每个类的方法集合 不能减少 (大模型重写某函数时顺手删 think/get_stats)
          4. 新代码非空且长度不能骤缩 (<原代码 30% 视为片段)
        返回 (ok, reason). ok=False 时绝不写文件.
        """
        if not new_code or not new_code.strip():
            return False, '新代码为空'
        try:
            new_tree = ast.parse(new_code)
        except SyntaxError as e:
            return False, f'语法错误: {e}'

        # 收集 class 的方法集合 (类体内嵌套的 FunctionDef)
        def _collect_class_methods(tree):
            methods = {}  # {class_name: {method_name}}
            for n in tree.body:
                if isinstance(n, ast.ClassDef):
                    ms = {m.name for m in n.body
                          if isinstance(m, (ast.FunctionDef, ast.AsyncFunctionDef))}
                    methods[n.name] = ms
            return methods

        # 提取新代码顶层符号
        new_symbols = {n.name for n in new_tree.body
                       if isinstance(n, (ast.ClassDef, ast.FunctionDef))}
        new_methods = _collect_class_methods(new_tree)

        # 提取原代码顶层符号 + 类方法
        try:
            old_code = open(filepath, 'r', encoding='utf-8').read()
            old_tree = ast.parse(old_code)
            old_symbols = {n.name for n in old_tree.body
                           if isinstance(n, (ast.ClassDef, ast.FunctionDef))}
            old_methods = _collect_class_methods(old_tree)
        except Exception:
            old_symbols = set()  # 原文件本身就坏就不校验符号
            old_methods = {}

        # 关键顶层符号丢失 → 拒绝
        missing = old_symbols - new_symbols
        if missing:
            return False, f'顶层符号丢失: {missing}'

        # 关键方法丢失 → 拒绝 (本次 think 被删的真凶)
        # 检查每个类的方法集合不能减少 (新增方法允许, 删除不允许)
        for cls_name, old_ms in old_methods.items():
            new_ms = new_methods.get(cls_name, set())
            missing_methods = old_ms - new_ms
            if missing_methods:
                return False, f'类 {cls_name} 方法丢失: {missing_methods}'

        # 长度骤缩 → 视为大模型只返回了片段
        if old_code and len(new_code) < len(old_code) * 0.3:
            return False, f'新代码过短 ({len(new_code)} < 原 {len(old_code)} 的30%)'
        return True, 'ok'

    def _backup(self, file_path):
        """备份文件"""
        os.makedirs(self.backup_dir, exist_ok=True)
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        basename = os.path.basename(file_path)
        backup_path = os.path.join(self.backup_dir, f'{basename}.{ts}.bak')
        shutil.copy2(file_path, backup_path)

        # 清理旧备份
        backups = sorted(Path(self.backup_dir).glob(f'{basename}.*.bak'))
        while len(backups) > self.max_backups:
            os.remove(backups[0])
            backups.pop(0)

        return backup_path

    def _rollback(self, backup_path, target_path):
        """从备份回滚"""
        shutil.copy2(backup_path, target_path)
        logger.info(f'已回滚: {target_path}')

    def apply_rule_change(self, issue):
        """应用规则型修改 — 不改代码，调参数"""
        action = issue.get('action')
        result = {'issue': issue['name'], 'action': action, 'success': False}

        if action == 'add_links':
            # 稀疏连接补强 — 自动在同类概念间建弱连接
            swarm = self.organism.brain.swarm
            categories = {}
            for w in swarm.worms.values():
                cat = w.category
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append(w)

            added = 0
            for cat, worms in categories.items():
                if len(worms) < 2:
                    continue
                for i in range(len(worms)):
                    for j in range(i + 1, min(i + 3, len(worms))):
                        if worms[j].id not in worms[i].links:
                            strength = 0.15  # 弱连接
                            worms[i].link_to(worms[j].id, strength)
                            worms[j].link_to(worms[i].id, strength)
                            added += 1
            result['success'] = True
            result['added_links'] = added
            logger.info(f'稀疏连接补强: +{added}条弱连接')

        elif action == 'tune_spread':
            # 调整扩散参数 — 降低decay让扩散更远
            result['success'] = True
            result['note'] = '建议降低spread的decay参数(0.7→0.75)，让思维传更远'
            # 实际修改代码
            self._tune_spread_decay(0.75)
            logger.info('扩散参数已调整')

        elif action == 'tune_sleep':
            # 缩短睡眠周期
            old = self.organism.sleep_after_cycles
            new = max(5, old - 5)
            self.organism.sleep_after_cycles = new
            result['success'] = True
            result['old_cycle'] = old
            result['new_cycle'] = new
            logger.info(f'睡眠周期: {old}→{new}')

        elif action == 'prune_concepts':
            # 修剪无用概念
            swarm = self.organism.brain.swarm
            pruned = 0
            to_remove = []
            for wid, w in swarm.worms.items():
                if w.baseline < 0.01 and w.activation_count < 3 and w.category == 'taught':
                    to_remove.append(wid)
            for wid in to_remove:
                w = swarm.worms[wid]
                # 先断开所有连接
                for other_id in list(w.links.keys()):
                    other = swarm.worms.get(other_id)
                    if other and wid in other.links:
                        del other.links[wid]
                # 从名字索引删除
                if w.name in swarm._name_index:
                    del swarm._name_index[w.name]
                del swarm.worms[wid]
                pruned += 1
            result['success'] = True
            result['pruned'] = pruned
            logger.info(f'修剪概念: -{pruned}条')

        return result

    def _tune_spread_decay(self, new_decay):
        """修改 worm_swarm.py 的 spread decay 默认值"""
        filepath = os.path.join(self.code_dir, 'worm_swarm.py')
        if not os.path.exists(filepath):
            return False

        old_code = open(filepath, 'r', encoding='utf-8').read()
        backup = self._backup(filepath)

        # 简单文本替换: 找到 spread 方法的 decay 默认值
        import re
        new_code = re.sub(
            r'def spread\(self,\s*decay\s*=\s*[\d.]+',
            f'def spread(self, decay={new_decay}',
            old_code
        )

        if new_code != old_code:
            change = CodeChange(filepath, old_code, new_code,
                              f'调整扩散decay→{new_decay}', 'self')
            # 写前守卫 — 先验证再写, 不允许先写后验证
            ok, reason = self._validate_code(filepath, new_code)
            if not ok:
                self._rollback(backup, filepath)
                change.test_passed = False
                change.adopted = False
                self.changes.append(change)
                logger.warning(f'spread decay修改被守卫拒绝: {reason}')
                return False
            try:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(new_code)
                change.test_passed = True
                change.adopted = True
                self.changes.append(change)
                logger.info(f'代码已修改: spread decay→{new_decay}')
                return True
            except Exception as e:
                self._rollback(backup, filepath)
                change.test_passed = False
                change.adopted = False
                self.changes.append(change)
                logger.warning(f'写入失败已回滚: {e}')
                return False
        return False

    def propose_code_change(self, issue, code_snippet=None):
        """
        用大模型提出代码修改方案 — 补丁模式

        策略: 不让大模型重写整个文件(它总会丢类/函数),
        而是让它输出一个函数级补丁: 要改哪个函数, 新代码是什么.
        守卫只检查补丁本身, 不需要检查整个文件的顶层符号.
        """
        if not self.teacher or not self.teacher.backend:
            logger.warning('无大模型，无法提出代码修改')
            return None

        filename = self.locate_code(issue.get('name', ''))
        if not filename:
            filename = 'worm_brain.py'

        filepath = os.path.join(self.code_dir, filename)
        if not os.path.exists(filepath):
            return None

        current_code = open(filepath, 'r', encoding='utf-8').read()

        # 提取函数/方法签名列表, 给大模型看(不超过3000字)
        import ast as _ast
        try:
            tree = _ast.parse(current_code)
            sigs = []
            for node in _ast.walk(tree):
                if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                    args = ', '.join(a.arg for a in node.args.args if a.arg != 'self')
                    sigs.append(f'  def {node.name}({args})  # line {node.lineno}')
            sig_text = '\n'.join(sigs[:50])
        except Exception:
            sig_text = '(解析失败)'

        messages = [
            {'role': 'system', 'content': f'''你是代码优化专家。你需要修改 {filename} 中的一个函数来解决指定问题。

输出格式(严格遵守):
1. 第一行写要修改的函数名
2. 后面写完整的新函数代码(包含def行)

示例输出:
think
def think(self, percepts, rounds=3):
    # 修改后的函数代码
    ...

不要输出整个文件, 只输出要改的那一个函数!'''},
            {'role': 'user', 'content': f'问题: {issue["description"]}\n\n文件中的函数:\n{sig_text}\n\n当前文件前3000字:\n```python\n{current_code[:3000]}\n```'},
        ]

        response = self.teacher.backend.chat(messages, temperature=0.3, max_tokens=2000)
        if not response:
            return None

        # 解析补丁: 提取函数名和新函数代码
        import re
        lines = response.strip().split('\n')
        # 去掉 ```python ``` 包裹
        clean_lines = []
        for l in lines:
            if l.strip().startswith('```'):
                continue
            clean_lines.append(l)
        clean_text = '\n'.join(clean_lines)

        # 找 def 行
        def_match = re.search(r'(def\s+(\w+)\s*\([^)]*\).*?(?=\ndef\s|\Z))', clean_text, re.DOTALL)
        if not def_match:
            logger.warning(f'大模型输出无法解析为函数补丁: {clean_text[:200]}')
            return {'file': filename, 'reason': '大模型输出无法解析为函数补丁', 'rejected': True,
                    'description': issue['description']}
        func_name = def_match.group(2)
        new_func_code = def_match.group(1)

        # 验证补丁本身
        try:
            _ast.parse(new_func_code)
        except SyntaxError as e:
            return {'file': filename, 'reason': f'补丁语法错误: {e}', 'rejected': True,
                    'description': issue['description']}

        # 在原文件中找到并替换该函数
        backup = self._backup(filepath)
        old_code = current_code

        # 用 ast 找原函数的行范围
        try:
            tree = _ast.parse(old_code)
            target_node = None
            for node in _ast.walk(tree):
                if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and node.name == func_name:
                    target_node = node
                    break
            if not target_node:
                self._rollback(backup, filepath)
                return {'file': filename, 'reason': f'原文件找不到函数 {func_name}', 'rejected': True,
                        'description': issue['description']}
            # 替换: 按行号定位
            old_lines = old_code.split('\n')
            start_line = target_node.lineno - 1  # 0-based
            end_line = target_node.end_lineno  # 1-based exclusive
            new_lines = new_func_code.split('\n')
            replaced_lines = old_lines[:start_line] + new_lines + old_lines[end_line:]
            new_code = '\n'.join(replaced_lines)
        except Exception as e:
            self._rollback(backup, filepath)
            return {'file': filename, 'reason': f'补丁应用失败: {e}', 'rejected': True,
                    'description': issue['description']}

        # 守卫: 验证合并后的完整文件
        ok, reason = self._validate_code(filepath, new_code)
        if not ok:
            logger.warning(f'补丁合并后守卫拒绝: {reason}')
            self._rollback(backup, filepath)
            return {'file': filename, 'reason': reason, 'rejected': True,
                    'description': issue['description']}

        # 写入
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_code)

        change = CodeChange(filepath, old_code, new_code,
                          f'{issue["description"]} (改{func_name})', 'teacher')
        change.rollback_id = backup

        # 测试
        change.test_passed = self._run_self_test()
        if change.test_passed:
            change.adopted = True
            logger.info(f'代码修改已采纳: {issue["name"]} (改{func_name})')
        else:
            self._rollback(backup, filepath)
            change.adopted = False
            logger.info(f'代码修改测试失败，已回滚: {issue["name"]}')

        self.changes.append(change)
        return change

    def _run_self_test(self):
        """运行自检 — 尝试import并基本功能测试"""
        try:
            # 重新加载模块 — reload 已坏文件会抛 SyntaxError, 要捕获
            # 否则自检本身把进程搞崩, 连回滚的机会都没有
            import worm_knowledge_engine
            try:
                importlib.reload(worm_knowledge_engine.worm_swarm)
                importlib.reload(worm_knowledge_engine.worm_brain)
            except SyntaxError as e:
                logger.error(f'reload 失败 (源文件已损坏): {e}')
                return False

            # 基本功能测试
            from worm_knowledge_engine.worm_swarm import WormSwarm
            sw = WormSwarm()
            sw.spawn('test', 'test')
            sw.think({'test': 0.5}, rounds=2)
            sw.get_stats()

            from worm_knowledge_engine.worm_brain import WormBrain
            brain = WormBrain()
            brain.think(percepts=['task_failure'], rounds=3)

            # 测试生物体集成 — 确保整体链路正常
            from worm_knowledge_engine.organism import Organism
            import tempfile, shutil
            tmpdir = tempfile.mkdtemp()
            try:
                org = Organism(data_dir=tmpdir)
                org.brain.swarm.spawn('test_integ', 'test')
                org.brain.think(percepts=['low_hunger'], rounds=2)
                assert org.body is not None
            except Exception as e:
                logger.error(f'集成测试失败: {e}')
                return False
            finally:
                shutil.rmtree(tmpdir, ignore_errors=True)

            return True
        except Exception as e:
            logger.error(f'自检失败: {e}')
            return False

    # ---- 主动进化 ----

    def evolve(self):
        """
        一次完整的进化循环: 诊断→修改→测试→采纳/回滚

        策略:
          - 有真大模型(非MockBackend): 规则调整 + 代码补丁
          - 无大模型(MockBackend): 只走规则调整, 不碰代码
        """
        issues = self.diagnose()
        if not issues:
            logger.info('诊断完成: 无问题')
            return []

        # 检查是否有真大模型 (MockBackend 不是真模型, 不能生成代码)
        has_real_llm = (self.teacher and self.teacher.backend
                        and not isinstance(self.teacher.backend, type)  # 不是类本身
                        and self.teacher.backend.__class__.__name__ != 'MockBackend')

        results = []
        for issue in issues:
            if issue['type'] == 'rule':
                r = self.apply_rule_change(issue)
                results.append(r)
            elif issue['type'] in ('structural', 'performance') and has_real_llm:
                # HoloGram 预检：修改代码前先看影响范围
                preflight_ok = True
                if self.hologram and 'filename' in issue:
                    filepath = os.path.join(self.code_dir, issue['filename'])
                    preflight = self.hologram.preflight_for_self_evolve([filepath])
                    if not preflight.get('safe'):
                        results.append({
                            'issue': issue['name'],
                            'action': 'blocked_by_preflight',
                            'risky_impacts': preflight.get('risky_impacts', 0),
                            'details': preflight.get('details', []),
                        })
                        preflight_ok = False
                        logger.info(f'[SelfEvolve] 预检拦截: {issue["name"]} '
                                    f'({preflight.get("risky_impacts", 0)} 个风险)')

                if preflight_ok:
                    r = self.propose_code_change(issue)
                    if r:
                        if isinstance(r, dict):
                            results.append(r)
                        else:
                            results.append(r.to_dict())
            elif issue['type'] in ('structural', 'performance') and not has_real_llm:
                # 无真大模型: 把代码修改类问题降级为规则调整
                logger.info(f'无真大模型, 跳过代码修改: {issue["name"]}')
                results.append({'issue': issue['name'], 'action': 'skipped',
                                'reason': '无真大模型(MockBackend), 只能规则调整不能改代码'})

        return results

    # ---- 状态 ----

    def get_stats(self):
        adopted = sum(1 for c in self.changes if c.adopted)
        rejected = sum(1 for c in self.changes if c.adopted is False)
        code_changes = sum(1 for c in self.changes if c.old_code != c.new_code)
        return {
            'total_changes': len(self.changes),
            'adopted': adopted,
            'rejected': rejected,
            'code_changes': code_changes,
            'backups': len(list(Path(self.backup_dir).glob('*.bak'))) if os.path.exists(self.backup_dir) else 0,
            'latest_change': self.changes[-1].to_dict() if self.changes else None,
        }
