"""
Qidi Teacher 适配器 — 包装 QidiBridge 暴露 Teacher 接口

SelfEvolve 通过 teacher.backend.chat(messages, temperature, max_tokens) 调用。
本适配器将 QidiBridge 的 RPC 接口适配为 Teacher 接口。

降级策略：QidiBridge 未连接时返回空字符串，SelfEvolve 会降级到本地规则。
"""
import logging
from typing import List, Dict, Optional

logger = logging.getLogger('QidiTeacher')


class QidiTeacherAdapter:
    """Qidi Teacher 适配器 — 暴露 backend.chat 接口"""

    def __init__(self, qidi_bridge=None):
        self.bridge = qidi_bridge
        # SelfEvolve 访问 teacher.backend.chat，所以 backend 指向自己
        self.backend = self

    def chat(self, messages: List[Dict[str, str]],
             temperature: float = 0.7, max_tokens: int = 2000) -> str:
        """
        Teacher 对话接口

        Args:
            messages: [{'role': 'system', 'content': '...'}, {'role': 'user', 'content': '...'}]
            temperature: 温度参数
            max_tokens: 最大 token 数

        Returns:
            模型响应文本，失败时返回空字符串
        """
        if not self.bridge or not getattr(self.bridge, 'connected', False):
            logger.debug('QidiBridge 未连接，Teacher 降级')
            return ''

        prompt = self._messages_to_prompt(messages)
        if not prompt:
            return ''

        try:
            result = self.bridge.call('chat', {
                'prompt': prompt,
                'temperature': temperature,
                'max_tokens': max_tokens,
            })
            if isinstance(result, str):
                return result
            if isinstance(result, dict):
                return result.get('response', result.get('content', ''))
            return str(result) if result else ''
        except Exception as e:
            logger.warning(f'Teacher chat 失败: {e}')
            return ''

    def _messages_to_prompt(self, messages: List[Dict[str, str]]) -> str:
        """将 messages 列表转为 QidiBridge 的 prompt 字符串"""
        parts = []
        for msg in messages:
            role = msg.get('role', 'user')
            content = msg.get('content', '')
            if not content:
                continue
            if role == 'system':
                parts.append(f'[系统] {content}')
            elif role == 'user':
                parts.append(f'[用户] {content}')
            elif role == 'assistant':
                parts.append(f'[助手] {content}')
            else:
                parts.append(content)
        return '\n\n'.join(parts)

    def is_available(self) -> bool:
        """检查 Teacher 是否可用"""
        return bool(self.bridge and getattr(self.bridge, 'connected', False))
