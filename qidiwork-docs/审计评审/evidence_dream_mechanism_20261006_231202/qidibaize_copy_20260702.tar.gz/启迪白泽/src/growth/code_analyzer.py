"""
代码自生长层 — AST 分析 + 缓存优化 + 重复代码提取

融合：
- 元系统 mycelium_sim.py 的信息素自适应 → 代码优化优先级
- 涌现理论 L4 空间认知 → 代码空间结构优化
- 知识树（磁场.py）→ 新代码归约到知识树
"""

import ast
import time
import inspect
import textwrap
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
from collections import defaultdict


@dataclass
class CodeIssue:
    """代码问题"""
    file_path: str
    line_number: int
    issue_type: str           # 'duplicate' | 'too_long' | 'unused_param' | 'high_complexity'
    severity: str             # 'high' | 'medium' | 'low'
    description: str
    suggested_fix: str
    affected_lines: int = 1


@dataclass
class CodeAction:
    """代码重构动作"""
    issue: CodeIssue
    action_type: str          # 'extract_method' | 'add_cache' | 'split_function' | 'remove_param'
    status: str = "pending"   # pending | applied | rolled_back
    applied_at: float = 0.0
    before_metrics: Dict = field(default_factory=dict)
    after_metrics: Dict = field(default_factory=dict)


class CodeAnalyzer:
    """代码分析器 — AST 分析 + 静态检查"""
    
    def __init__(self):
        self.issues: List[CodeIssue] = []
        self.functions_cache: Dict[str, Dict] = {}
    
    def analyze_file(self, file_path: str, source_code: str) -> List[CodeIssue]:
        """分析单个文件"""
        issues = []
        
        try:
            tree = ast.parse(source_code, filename=file_path)
        except SyntaxError:
            return [CodeIssue(
                file_path=file_path, line_number=0,
                issue_type='syntax_error', severity='high',
                description='语法错误，无法分析',
                suggested_fix='修复语法错误'
            )]
        
        # 检查过长函数
        issues.extend(self._check_long_functions(tree, file_path))
        
        # 检查重复代码
        issues.extend(self._check_duplicate_code(tree, file_path))
        
        # 检查未使用参数
        issues.extend(self._check_unused_params(tree, file_path))
        
        # 检查圈复杂度
        issues.extend(self._check_complexity(tree, file_path))
        
        self.issues.extend(issues)
        return issues
    
    def _check_long_functions(self, tree: ast.AST, file_path: str) -> List[CodeIssue]:
        """检查过长函数（>100行）"""
        issues = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                line_count = node.end_lineno - node.lineno + 1 if hasattr(node, 'end_lineno') and node.end_lineno else 0
                if line_count > 100:
                    issues.append(CodeIssue(
                        file_path=file_path,
                        line_number=node.lineno,
                        issue_type='too_long',
                        severity='medium',
                        description=f"函数 '{node.name}' 过长 ({line_count} 行)",
                        suggested_fix=f"拆分函数 '{node.name}'"
                    ))
        return issues
    
    def _check_duplicate_code(self, tree: ast.AST, file_path: str) -> List[CodeIssue]:
        """检查重复代码块"""
        issues = []
        # 简化的重复检测：找重复的语句块
        func_bodies = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.body:
                body_str = ast.dump(node.body[:5])  # 只看前5个语句
                if body_str in func_bodies:
                    issues.append(CodeIssue(
                        file_path=file_path,
                        line_number=node.lineno,
                        issue_type='duplicate',
                        severity='high',
                        description=f"函数 '{node.name}' 与 '{func_bodies[body_str]}' 代码重复",
                        suggested_fix=f"提取公共方法"
                    ))
                else:
                    func_bodies[body_str] = node.name
        return issues
    
    def _check_unused_params(self, tree: ast.AST, file_path: str) -> List[CodeIssue]:
        """检查未使用的函数参数"""
        issues = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                args = node.args
                all_args = [a.arg for a in args.args if a.arg != 'self']
                if not all_args:
                    continue
                
                # 收集函数体内所有使用的变量名
                used_names = set()
                for child in ast.walk(node):
                    if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Load):
                        used_names.add(child.id)
                
                for arg in all_args:
                    if arg not in used_names:
                        issues.append(CodeIssue(
                            file_path=file_path,
                            line_number=node.lineno,
                            issue_type='unused_param',
                            severity='high',
                            description=f"函数 '{node.name}' 参数 '{arg}' 未使用",
                            suggested_fix=f"移除参数 '{arg}'"
                        ))
        return issues
    
    def _check_complexity(self, tree: ast.AST, file_path: str) -> List[CodeIssue]:
        """检查圈复杂度"""
        issues = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                complexity = self._calc_cyclomatic_complexity(node)
                if complexity > 10:
                    issues.append(CodeIssue(
                        file_path=file_path,
                        line_number=node.lineno,
                        issue_type='high_complexity',
                        severity='low',
                        description=f"函数 '{node.name}' 圈复杂度过高 ({complexity})",
                        suggested_fix=f"简化函数 '{node.name}' 的逻辑"
                    ))
        return issues
    
    def _calc_cyclomatic_complexity(self, node: ast.AST) -> int:
        """计算圈复杂度"""
        complexity = 1
        for child in ast.walk(node):
            if isinstance(child, (ast.If, ast.While, ast.For, ast.ExceptHandler)):
                complexity += 1
            elif isinstance(child, ast.BoolOp):
                complexity += len(child.values) - 1
        return complexity


class CodeGrowthExecutor:
    """代码生长执行器 — 自动应用低风险重构"""
    
    def __init__(self):
        self.actions: List[CodeAction] = []
        self.growth_log: List[Dict] = []
    
    def prioritize_actions(self, issues: List[CodeIssue]) -> List[CodeAction]:
        """按优先级排序重构动作"""
        priority_map = {
            'high': 1,
            'medium': 2,
            'low': 3,
        }
        
        actions = []
        for issue in issues:
            action_type = self._map_issue_to_action(issue)
            if action_type:
                action = CodeAction(
                    issue=issue,
                    action_type=action_type,
                )
                actions.append(action)
        
        # 按优先级排序
        actions.sort(key=lambda a: priority_map.get(a.issue.severity, 99))
        self.actions.extend(actions)
        return actions
    
    def _map_issue_to_action(self, issue: CodeIssue) -> Optional[str]:
        """将问题映射到重构动作"""
        mapping = {
            'duplicate': 'extract_method',
            'too_long': 'split_function',
            'unused_param': 'remove_param',
            'high_complexity': 'simplify_logic',
        }
        return mapping.get(issue.issue_type)
    
    def execute_action(self, action: CodeAction, before_metrics: Dict, 
                       after_metrics: Dict) -> Dict:
        """执行重构动作并记录结果"""
        action.status = "applied"
        action.applied_at = time.time()
        action.before_metrics = before_metrics
        action.after_metrics = after_metrics
        
        log_entry = {
            'timestamp': time.time(),
            'action_type': action.action_type,
            'file': action.issue.file_path,
            'line': action.issue.line_number,
            'before': before_metrics,
            'after': after_metrics,
        }
        self.growth_log.append(log_entry)
        
        return log_entry
    
    def get_growth_statistics(self) -> Dict:
        return {
            'total_actions': len(self.actions),
            'applied': len([a for a in self.actions if a.status == 'applied']),
            'pending': len([a for a in self.actions if a.status == 'pending']),
            'growth_log_entries': len(self.growth_log),
        }
