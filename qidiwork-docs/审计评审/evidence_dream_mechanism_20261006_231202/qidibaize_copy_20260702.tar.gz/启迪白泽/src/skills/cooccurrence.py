"""
真共现分析 — 时序滑动窗口

设计:
  - 时间窗口内的技能调用序列分析
  - 滑动窗口大小可配置
  - 支持时间衰减（近期权重更高）
  - 输出共现矩阵和关联规则
  - 重写 agent 项目的造假版（静态相似度）

与 agent 项目的区别:
  - 假共现: 计算技能 embedding 之间的静态相似度
  - 真共现: 计算时间窗口内技能调用的真实同时出现频率
"""
import time
import logging
from collections import defaultdict, deque
from typing import Dict, List, Any, Tuple

logger = logging.getLogger('Cooccurrence')


class CooccurrenceAnalyzer:
    """真共现分析器"""

    def __init__(self, window_size=60, decay_factor=0.95):
        """
        Args:
            window_size: 滑动窗口大小（秒）
            decay_factor: 时间衰减因子（0-1，越接近1衰减越慢）
        """
        self.window_size = window_size
        self.decay_factor = decay_factor
        self._call_history = deque()
        self._cooccurrence_matrix = defaultdict(lambda: defaultdict(float))
        self._call_count = defaultdict(int)
        self._last_cleanup = time.time()

    def record_call(self, skill_name: str, context: Dict[str, Any] = None):
        """
        记录一次技能调用

        Args:
            skill_name: 技能名称
            context: 上下文信息（可选）
        """
        entry = {
            'skill': skill_name,
            'timestamp': time.time(),
            'context': context or {},
        }
        self._call_history.append(entry)
        self._call_count[skill_name] += 1

        self._update_cooccurrence(entry)
        self._cleanup_old_entries()

    def _update_cooccurrence(self, new_entry: Dict[str, Any]):
        """更新共现矩阵"""
        new_skill = new_entry['skill']
        new_time = new_entry['timestamp']

        for entry in self._call_history:
            if entry['skill'] == new_skill:
                continue

            time_diff = new_time - entry['timestamp']
            if time_diff > self.window_size:
                continue

            weight = self.decay_factor ** (time_diff / self.window_size)

            self._cooccurrence_matrix[new_skill][entry['skill']] += weight
            self._cooccurrence_matrix[entry['skill']][new_skill] += weight

    def _cleanup_old_entries(self):
        """清理过期记录"""
        now = time.time()
        if now - self._last_cleanup < self.window_size:
            return

        while self._call_history and now - self._call_history[0]['timestamp'] > self.window_size:
            self._call_history.popleft()

        self._last_cleanup = now

    def get_cooccurrence_matrix(self) -> Dict[str, Dict[str, float]]:
        """获取共现矩阵"""
        return dict(self._cooccurrence_matrix)

    def get_cooccurrence(self, skill_a: str, skill_b: str) -> float:
        """获取两个技能的共现强度"""
        return self._cooccurrence_matrix[skill_a].get(skill_b, 0.0)

    def get_top_cooccurrences(self, skill_name: str, top_k=5) -> List[Tuple[str, float]]:
        """获取与指定技能共现最强的技能"""
        cooccurrences = self._cooccurrence_matrix.get(skill_name, {})
        sorted_list = sorted(cooccurrences.items(), key=lambda x: x[1], reverse=True)
        return sorted_list[:top_k]

    def discover_rules(self, min_support=0.1, min_confidence=0.5) -> List[Dict[str, Any]]:
        """
        发现关联规则

        Args:
            min_support: 最小支持度
            min_confidence: 最小置信度

        Returns:
            [{'antecedent', 'consequent', 'support', 'confidence', 'lift'}, ...]
        """
        rules = []
        total_calls = sum(self._call_count.values())

        for skill_a in self._call_count:
            count_a = self._call_count[skill_a]
            support_a = count_a / total_calls

            if support_a < min_support:
                continue

            for skill_b in self._call_count:
                if skill_a == skill_b:
                    continue

                count_b = self._call_count[skill_b]
                cooccur_count = self._cooccurrence_matrix[skill_a].get(skill_b, 0.0)

                support_ab = cooccur_count / total_calls
                if support_ab < min_support:
                    continue

                confidence = cooccur_count / count_a
                if confidence < min_confidence:
                    continue

                support_b = count_b / total_calls
                lift = confidence / support_b if support_b > 0 else 0

                rules.append({
                    'antecedent': skill_a,
                    'consequent': skill_b,
                    'support': round(support_ab, 4),
                    'confidence': round(confidence, 4),
                    'lift': round(lift, 4),
                })

        rules.sort(key=lambda x: x['lift'], reverse=True)
        return rules

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        skills = list(self._call_count.keys())
        return {
            'total_calls': sum(self._call_count.values()),
            'total_skills': len(skills),
            'window_size': self.window_size,
            'decay_factor': self.decay_factor,
            'history_size': len(self._call_history),
            'call_count': dict(self._call_count),
        }

    def reset(self):
        """重置分析器"""
        self._call_history.clear()
        self._cooccurrence_matrix.clear()
        self._call_count.clear()


class SkillSequenceAnalyzer:
    """技能序列分析器"""

    def __init__(self, n_gram_sizes=(2, 3)):
        """
        Args:
            n_gram_sizes: N-gram大小列表
        """
        self.n_gram_sizes = n_gram_sizes
        self._sequences = defaultdict(int)
        self._current_sequence = []

    def record_call(self, skill_name: str):
        """记录技能调用"""
        self._current_sequence.append(skill_name)

        for n in self.n_gram_sizes:
            if len(self._current_sequence) >= n:
                n_gram = tuple(self._current_sequence[-n:])
                self._sequences[n_gram] += 1

    def get_top_sequences(self, n: int, top_k=10) -> List[Tuple[Tuple[str, ...], int]]:
        """获取最频繁的N-gram序列"""
        filtered = [(seq, count) for seq, count in self._sequences.items() if len(seq) == n]
        filtered.sort(key=lambda x: x[1], reverse=True)
        return filtered[:top_k]

    def predict_next(self, prefix: List[str], top_k=3) -> List[Tuple[str, float]]:
        """
        根据前缀预测下一个技能

        Args:
            prefix: 技能序列前缀
            top_k: 返回前k个预测结果

        Returns:
            [{'skill', 'probability'}, ...]
        """
        predictions = defaultdict(int)
        total = 0

        for n in self.n_gram_sizes:
            if len(prefix) >= n - 1:
                target_prefix = tuple(prefix[-(n - 1):])
                for seq, count in self._sequences.items():
                    if len(seq) == n and seq[:-1] == target_prefix:
                        predictions[seq[-1]] += count
                        total += count

        if total == 0:
            return []

        sorted_predictions = sorted(
            predictions.items(),
            key=lambda x: x[1],
            reverse=True
        )

        return [
            {'skill': skill, 'probability': round(count / total, 4)}
            for skill, count in sorted_predictions[:top_k]
        ]

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'n_gram_sizes': self.n_gram_sizes,
            'total_sequences': len(self._sequences),
            'total_counts': sum(self._sequences.values()),
        }

    def reset(self):
        """重置分析器"""
        self._sequences.clear()
        self._current_sequence.clear()
