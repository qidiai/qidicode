"""
Skill 系统 — 注册、调用追踪、组合生成

融合：
- 元系统 mycelium_sim.py 的信息素路由 → Skill 调用路径优化
- 涌现理论 L7 社会智能 → Skill 组合生成
- 涌现理论 L8 文化智能 → Skill 知识传承
"""

import time
import math
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from collections import defaultdict


@dataclass
class Skill:
    """Skill 定义"""
    id: str
    name: str
    description: str
    category: str                     # 技能类别
    implementation: Callable          # 实现函数
    parameters: Dict[str, Any] = field(default_factory=dict)
    dependencies: List[str] = field(default_factory=list)  # 依赖的其他 Skill
    created_at: float = field(default_factory=time.time)
    last_used: float = 0.0
    usage_count: int = 0
    success_count: int = 0
    fail_count: int = 0
    avg_duration_ms: float = 0.0
    total_duration_ms: float = 0.0
    tags: List[str] = field(default_factory=list)
    composite: bool = False           # 是否是组合 Skill
    parent_skills: List[str] = field(default_factory=list)  # 如果是组合 Skill，父 Skill 列表
    
    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 0.0
    
    @property
    def avg_response_time(self) -> float:
        return self.total_duration_ms / self.usage_count if self.usage_count > 0 else 0.0
    
    def record_call(self, success: bool, duration_ms: float):
        self.usage_count += 1
        self.last_used = time.time()
        self.total_duration_ms += duration_ms
        if success:
            self.success_count += 1
        else:
            self.fail_count += 1
    
    def __repr__(self):
        status = "🟢" if self.usage_count > 0 else "⚪"
        return (f"{status} {self.id}({self.name}) "
                f"calls={self.usage_count} success={self.success_rate:.1%} "
                f"avg={self.avg_response_time:.1f}ms composite={self.composite}")


class SkillRegistry:
    """Skill 注册中心"""

    def __init__(self, storage_backend=None, cooccurrence_analyzer=None):
        self.skills: Dict[str, Skill] = {}
        self.category_index: Dict[str, List[str]] = defaultdict(list)
        self.tag_index: Dict[str, List[str]] = defaultdict(list)
        self.backend = storage_backend
        self.cooccurrence = cooccurrence_analyzer

    def register(self, skill: Skill):
        """注册 Skill"""
        self.skills[skill.id] = skill
        self.category_index[skill.category].append(skill.id)
        for tag in skill.tags:
            self.tag_index[tag].append(skill.id)

    def record_call(self, skill_id: str, success: bool, duration_ms: float, context: Dict = None):
        """记录 Skill 调用 — 同步到内存 + backend + 共现分析"""
        skill = self.skills.get(skill_id)
        if not skill:
            return
        skill.record_call(success, duration_ms)
        # 共现分析
        if self.cooccurrence:
            self.cooccurrence.record_call(skill_id, context)
        # 持久化到 skill_calls 表
        if self.backend:
            try:
                self.backend.execute(
                    "INSERT INTO skill_calls (skill_id, skill_name, timestamp, success, duration_ms, context) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (skill_id, skill.name, time.time(), 1 if success else 0, duration_ms,
                     json.dumps(context or {}, ensure_ascii=False))
                )
            except Exception:
                pass
    
    def get(self, skill_id: str) -> Optional[Skill]:
        return self.skills.get(skill_id)
    
    def list_by_category(self, category: str) -> List[Skill]:
        ids = self.category_index.get(category, [])
        return [self.skills[id] for id in ids if id in self.skills]
    
    def list_by_tag(self, tag: str) -> List[Skill]:
        ids = self.tag_index.get(tag, [])
        return [self.skills[id] for id in ids if id in self.skills]
    
    def list_all(self) -> List[Skill]:
        return list(self.skills.values())
    
    def get_active_skills(self, min_usage: int = 1) -> List[Skill]:
        """获取活跃 Skill（使用次数 >= min_usage）"""
        return [s for s in self.skills.values() if s.usage_count >= min_usage]
    
    def get_inactive_skills(self, inactive_days: int = 30) -> List[Skill]:
        """获取不活跃 Skill（超过 inactive_days 天未使用）"""
        cutoff = time.time() - inactive_days * 86400
        return [s for s in self.skills.values() if s.last_used < cutoff]


class SkillCombiner:
    """Skill 组合器 — 基于真共现分析生成复合 Skill"""

    CO_OCCURRENCE_THRESHOLD = 0.7  # 共现阈值
    MIN_USAGE = 50  # 最少使用次数

    def __init__(self, cooccurrence_analyzer=None):
        self.analyzer = cooccurrence_analyzer

    def detect_composite_opportunities(self, registry: SkillRegistry) -> List[Dict]:
        """
        检测可以组合的 Skill 对

        基于真共现分析：
        如果两个 Skill 经常被一起调用（共现率高），
        则建议组合成一个复合 Skill
        """
        active_skills = registry.get_active_skills(min_usage=self.MIN_USAGE)
        combinations = []

        for i, skill_a in enumerate(active_skills):
            for skill_b in active_skills[i + 1:]:
                co_occurrence = self._get_cooccurrence(skill_a, skill_b)

                if co_occurrence >= self.CO_OCCURRENCE_THRESHOLD:
                    combinations.append({
                        'skill_a': skill_a.id,
                        'skill_b': skill_b.id,
                        'cooccurrence': co_occurrence,
                        'suggested_name': f"{skill_a.name}+{skill_b.name}",
                    })

        return sorted(combinations, key=lambda c: c['cooccurrence'], reverse=True)

    def _get_cooccurrence(self, skill_a: Skill, skill_b: Skill) -> float:
        """获取两个 Skill 的真实共现率（时序滑动窗口）"""
        if self.analyzer is not None:
            return self.analyzer.get_cooccurrence(skill_a.id, skill_b.id)
        return 0.0  # 无分析器时降级为 0


class SkillEvolutionMonitor:
    """Skill 进化监控器"""

    def __init__(self, registry: SkillRegistry, capability_tree=None):
        self.registry = registry
        self.combiner = SkillCombiner(cooccurrence_analyzer=registry.cooccurrence)
        self.capability_tree = capability_tree
        self.evolution_log: List[Dict] = []
    
    def analyze(self) -> Dict:
        """全面分析 Skill 进化机会"""
        return {
            'active_skills': len(self.registry.get_active_skills()),
            'inactive_skills': len(self.registry.get_inactive_skills()),
            'composite_opportunities': self.combiner.detect_composite_opportunities(self.registry),
            'low_performers': self._find_low_performers(),
            'high_demand': self._find_high_demand_skills(),
        }
    
    def _find_low_performers(self, max_success_rate: float = 0.5) -> List[Skill]:
        """找出低效 Skill（成功率低）"""
        return [
            s for s in self.registry.list_all()
            if s.usage_count > 10 and s.success_rate < max_success_rate
        ]
    
    def _find_high_demand_skills(self, min_usage: int = 100) -> List[Skill]:
        """找出高需求 Skill"""
        return [
            s for s in self.registry.list_all()
            if s.usage_count >= min_usage
        ]
    
    def recommend_evolution(self) -> List[Dict]:
        """推荐进化操作"""
        analysis = self.analyze()
        recommendations = []
        
        # 1. 组合建议
        for combo in analysis['composite_opportunities']:
            recommendations.append({
                'type': 'combine',
                'priority': 'high',
                'details': combo,
            })
        
        # 2. 淘汰建议
        for skill in analysis['low_performers']:
            recommendations.append({
                'type': 'deprecate',
                'priority': 'medium',
                'skill_id': skill.id,
                'reason': f"成功率低 ({skill.success_rate:.1%})",
            })
        
        # 3. 归档建议
        for skill in analysis['inactive_skills']:
            recommendations.append({
                'type': 'archive',
                'priority': 'low',
                'skill_id': skill.id,
                'reason': "长时间未使用",
            })
        
        return recommendations
