"""
进化引擎 — 规则匹配 + 效果评估 + 回滚

融合：
- 元系统 meta_agent_v3.py 的分裂/合并机制
- 涌现理论 L1-L10 的分级判定
- 菌丝网络 mycelium_sim.py 的探索/利用平衡
"""

import time
import json
import hashlib
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Callable
from enum import Enum, auto
from collections import defaultdict


class RiskLevel(Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


@dataclass
class EvolutionRule:
    """进化规则"""
    id: str
    name: str
    trigger: str                    # 'agent' | 'code' | 'skill'
    condition: Dict[str, Any]       # {metric, field, op, threshold}
    action: Dict[str, Any]          # {type, params}
    risk_level: RiskLevel
    requires_approval: bool
    expected_improvement: str = ""
    skill_affected: Optional[str] = None


@dataclass
class EvolutionSuggestion:
    """进化建议"""
    rule_id: str
    rule_name: str
    action: Dict[str, Any]
    risk_level: RiskLevel
    requires_approval: bool
    estimated_improvement: str
    affected_files: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)


@dataclass
class Snapshot:
    """快照（用于回滚）"""
    id: str
    timestamp: float
    state: Dict[str, Any]
    
    @staticmethod
    def serialize(state: Dict) -> str:
        return json.dumps(state, default=str, ensure_ascii=False)
    
    @staticmethod
    def deserialize(data: str) -> Dict:
        return json.loads(data)


class EvolutionEvaluator:
    """进化效果评估器"""
    
    def evaluate(self, before: Dict[str, Any], after: Dict[str, Any]) -> Dict[str, float]:
        """
        多维度评估进化效果
        
        Returns:
            {performance: float, reliability: float, complexity: float, overall: float}
        """
        scores = {}
        
        # 性能评分
        before_perf = before.get('avg_duration_ms', 0)
        after_perf = after.get('avg_duration_ms', 0)
        if before_perf > 0:
            scores['performance'] = (before_perf - after_perf) / before_perf
        else:
            scores['performance'] = 0.0
        
        # 可靠性评分
        before_rel = before.get('success_rate', 0)
        after_rel = after.get('success_rate', 0)
        scores['reliability'] = after_rel - before_rel
        
        # 复杂度评分（越低越好）
        before_comp = before.get('cyclomatic_complexity', 0)
        after_comp = after.get('cyclomatic_complexity', 0)
        if before_comp > 0:
            scores['complexity'] = (before_comp - after_comp) / before_comp
        else:
            scores['complexity'] = 0.0
        
        # 综合评分
        scores['overall'] = (
            scores['performance'] * 0.4 +
            scores['reliability'] * 0.4 +
            scores['complexity'] * 0.2
        )
        
        return scores


class EvolutionEngine:
    """
    进化引擎 — 核心控制器
    
    工作流程：
    1. 监控数据 → 匹配进化规则
    2. 生成进化建议（按风险排序）
    3. 执行进化（低风险自动，高风险人工审批）
    4. 评估效果（不佳则回滚）
    """
    
    # 默认进化规则库
    DEFAULT_RULES = [
        EvolutionRule(
            id="R001", name="高频工具添加缓存",
            trigger="agent",
            condition={"metric": "tool_stats", "field": "call_count", "op": ">", "threshold": 100},
            action={"type": "add_lru_cache", "maxsize": 256},
            risk_level=RiskLevel.LOW,
            requires_approval=False,
            expected_improvement="80% latency reduction"
        ),
        EvolutionRule(
            id="R002", name="长函数拆分",
            trigger="code",
            condition={"metric": "code_metrics", "field": "line_count", "op": ">", "threshold": 100},
            action={"type": "split_function", "strategy": "by_logic_block"},
            risk_level=RiskLevel.MEDIUM,
            requires_approval=True,
            expected_improvement="40% readability"
        ),
        EvolutionRule(
            id="R003", name="重复代码提取",
            trigger="code",
            condition={"metric": "code_metrics", "field": "duplicate_lines", "op": ">", "threshold": 20},
            action={"type": "extract_common_method"},
            risk_level=RiskLevel.MEDIUM,
            requires_approval=True,
            expected_improvement="30% code reduction"
        ),
        EvolutionRule(
            id="R004", name="Skill组合生成",
            trigger="skill",
            condition={"metric": "skill_usage", "field": "cooccurrence", "op": ">", "threshold": 0.8},
            action={"type": "create_composite_skill"},
            risk_level=RiskLevel.HIGH,
            requires_approval=True,
            expected_improvement="50% call overhead reduction"
        ),
    ]
    
    def __init__(self, rules: List[EvolutionRule] = None, emergence_meter=None):
        self.rules = rules or self.DEFAULT_RULES
        self.evaluator = EvolutionEvaluator()
        self.emergence_meter = emergence_meter
        self.snapshots: Dict[str, Snapshot] = {}
        self.evolution_log: List[Dict] = []
        self.evolution_count = 0
        self.success_count = 0
        self.failed_count = 0
    
    def analyze(self, metrics: Dict[str, Any]) -> List[EvolutionSuggestion]:
        """分析当前指标，生成进化建议"""
        suggestions = []
        
        for rule in self.rules:
            if self._matches_rule(metrics, rule):
                suggestion = EvolutionSuggestion(
                    rule_id=rule.id,
                    rule_name=rule.name,
                    action=rule.action,
                    risk_level=rule.risk_level,
                    requires_approval=rule.requires_approval,
                    estimated_improvement=rule.expected_improvement,
                )
                suggestions.append(suggestion)
        
        # 按风险排序
        priority = {RiskLevel.LOW: 1, RiskLevel.MEDIUM: 2, RiskLevel.HIGH: 3}
        suggestions.sort(key=lambda s: priority[s.risk_level])
        
        return suggestions
    
    def execute(self, suggestion: EvolutionSuggestion, 
                before_metrics: Dict, after_metrics: Dict,
                state_before: Dict = None) -> Dict[str, Any]:
        """
        执行进化建议
        
        Returns:
            {'success': bool, 'scores': Dict, 'action': str}
        """
        # 创建快照
        snapshot_id = self._create_snapshot(state_before or {})
        
        # 评估效果
        scores = self.evaluator.evaluate(before_metrics, after_metrics)
        
        self.evolution_count += 1
        
        if scores['overall'] > 0:
            self.success_count += 1
            action = "applied"
        else:
            # 效果不佳，回滚
            self._rollback(snapshot_id)
            self.failed_count += 1
            action = "rolled_back"
        
        log_entry = {
            'timestamp': time.time(),
            'rule_id': suggestion.rule_id,
            'suggestion_name': suggestion.rule_name,
            'scores': scores,
            'action': action,
            'snapshot_id': snapshot_id,
        }
        self.evolution_log.append(log_entry)
        
        return {
            'success': action == "applied",
            'scores': scores,
            'action': action,
            'log': log_entry,
        }
    
    def get_statistics(self) -> Dict:
        total = self.evolution_count
        return {
            'total_evolution': total,
            'success_count': self.success_count,
            'failed_count': self.failed_count,
            'success_rate': self.success_count / total if total > 0 else 0.0,
            'log_entries': len(self.evolution_log),
        }
    
    def _matches_rule(self, metrics: Dict, rule: EvolutionRule) -> bool:
        """检查监控数据是否匹配规则条件"""
        condition = rule.condition
        # 组合 metric + field 路径，如 "tool_stats.call_count"
        field_path = f"{condition['metric']}.{condition['field']}"
        metric_data = self._get_nested_field(metrics, field_path)
        
        if metric_data is None:
            return False
        
        threshold = condition['threshold']
        ops = {
            '>': lambda a, b: a > b,
            '<': lambda a, b: a < b,
            '>=': lambda a, b: a >= b,
            '<=': lambda a, b: a <= b,
            '==': lambda a, b: a == b,
        }
        
        op_func = ops.get(condition['op'], lambda a, b: False)
        return op_func(metric_data, threshold)
    
    def _get_nested_field(self, data: Dict, field_path: str) -> Optional[Any]:
        """获取嵌套字段值（支持点号分隔）"""
        keys = field_path.split('.')
        current = data
        for key in keys:
            if isinstance(current, dict):
                current = current.get(key)
            else:
                return None
            if current is None:
                return None
        return current
    
    def _create_snapshot(self, state: Dict) -> str:
        """创建快照"""
        snapshot_id = hashlib.md5(str(state).encode()).hexdigest()[:8]
        self.snapshots[snapshot_id] = Snapshot(
            id=snapshot_id,
            timestamp=time.time(),
            state=state
        )
        return snapshot_id
    
    def _rollback(self, snapshot_id: str):
        """回滚到快照状态 — 恢复文件备份"""
        if snapshot_id not in self.snapshots:
            return
        snapshot = self.snapshots[snapshot_id]
        state = snapshot.state
        # 如果 state 中包含文件备份信息，恢复文件
        import os
        import shutil
        import logging
        file_backups = state.get('file_backups', {})
        restored = 0
        for file_path, backup_path in file_backups.items():
            try:
                if os.path.exists(backup_path):
                    shutil.copy2(backup_path, file_path)
                    restored += 1
            except Exception as e:
                logging.getLogger('EvolutionEngine').warning(f'回滚文件失败 {file_path}: {e}')
        if restored:
            logging.getLogger('EvolutionEngine').info(f'已回滚 {restored} 个文件')
