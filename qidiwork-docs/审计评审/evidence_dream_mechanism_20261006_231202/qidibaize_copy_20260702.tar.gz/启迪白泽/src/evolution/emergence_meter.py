"""
涌现测量计 — F/G/M 三模态同步性测量

设计:
  - F (Fast): 快速模态 — 短期信号同步性（毫秒级响应）
  - G (Global): 全局模态 — 群体信号同步性（多组件协同）
  - M (Meta): 元模态 — 元认知信号同步性（自我反思）
  - 优先调用 QidiBridge 远程评估，降级本地统计
  - 本地缓存避免重复远程调用
"""
import time
import math
import logging
from typing import Dict, List, Any, Optional

logger = logging.getLogger('EmergenceMeter')


class EmergenceMeter:
    """涌现测量计 — 三模态同步性"""

    def __init__(self, qidi_bridge=None):
        self.bridge = qidi_bridge
        self._cache: Dict[str, Dict] = {}  # 本地缓存
        self._cache_ttl = 60.0  # 缓存 60 秒
        self._history: List[Dict[str, Any]] = []  # 测量历史

    def measure(self, signals: Dict[str, Any]) -> Dict[str, float]:
        """
        测量 F/G/M 三模态同步性

        Args:
            signals: 包含各模态信号的字典
                - 'fast': 快速模态信号列表
                - 'global': 全局模态信号列表
                - 'meta': 元模态信号列表

        Returns:
            {'F': float, 'G': float, 'M': float, 'emergent': bool, 'gain': float}
        """
        cache_key = self._make_cache_key(signals)
        cached = self._cache.get(cache_key)
        if cached and (time.time() - cached['timestamp'] < self._cache_ttl):
            return cached['metrics']

        # 优先远程
        if self.bridge and getattr(self.bridge, 'connected', False):
            try:
                result = self.bridge.evaluate_emergence(signals)
                if result and isinstance(result, dict):
                    result.setdefault('emergent', False)
                    result.setdefault('gain', 0.0)
                    self._cache_result(cache_key, result)
                    self._record_history(result)
                    return result
            except Exception as e:
                logger.debug(f'远程涌现评估失败，降级本地: {e}')

        # 降级本地
        result = self._fallback_measure(signals)
        self._cache_result(cache_key, result)
        self._record_history(result)
        return result

    def _fallback_measure(self, signals: Dict[str, Any]) -> Dict[str, float]:
        """本地降级测量 — 基于信号方差和互相关"""
        fast = signals.get('fast', [])
        global_sig = signals.get('global', [])
        meta = signals.get('meta', [])

        F = self._synchrony_score(fast)
        G = self._synchrony_score(global_sig)
        M = self._synchrony_score(meta)

        # 涌现增益 = 三模态协同 > 单模态之和
        combined = F * G * M
        individual = (F + G + M) / 3.0
        gain = combined - individual
        emergent = gain > 0.05

        return {
            'F': round(F, 4),
            'G': round(G, 4),
            'M': round(M, 4),
            'emergent': emergent,
            'gain': round(gain, 4),
        }

    def _synchrony_score(self, signal: List[float]) -> float:
        """计算信号同步性 — 基于变异系数的倒数"""
        if not signal or len(signal) < 2:
            return 0.0
        mean = sum(signal) / len(signal)
        if abs(mean) < 1e-9:
            return 0.0
        variance = sum((x - mean) ** 2 for x in signal) / len(signal)
        std = math.sqrt(variance)
        cv = std / abs(mean)  # 变异系数
        # 同步性 = 1 / (1 + cv)，cv 越小同步性越高
        return 1.0 / (1.0 + cv)

    def _make_cache_key(self, signals: Dict[str, Any]) -> str:
        """生成缓存键"""
        fast = signals.get('fast', [])
        global_sig = signals.get('global', [])
        meta = signals.get('meta', [])
        return f'{len(fast)}_{len(global_sig)}_{len(meta)}_{hash(tuple(fast[:10]))}'

    def _cache_result(self, key: str, metrics: Dict):
        """缓存结果"""
        self._cache[key] = {'timestamp': time.time(), 'metrics': metrics}
        if len(self._cache) > 100:
            oldest = min(self._cache, key=lambda k: self._cache[k]['timestamp'])
            del self._cache[oldest]

    def _record_history(self, metrics: Dict):
        """记录测量历史"""
        self._history.append({'timestamp': time.time(), 'metrics': metrics})
        if len(self._history) > 1000:
            self._history = self._history[-1000:]

    def get_trend(self, window: int = 10) -> Dict[str, float]:
        """获取最近 N 次测量的趋势"""
        if not self._history:
            return {'F': 0.0, 'G': 0.0, 'M': 0.0, 'gain': 0.0}
        recent = self._history[-window:]
        avg_f = sum(h['metrics'].get('F', 0) for h in recent) / len(recent)
        avg_g = sum(h['metrics'].get('G', 0) for h in recent) / len(recent)
        avg_m = sum(h['metrics'].get('M', 0) for h in recent) / len(recent)
        avg_gain = sum(h['metrics'].get('gain', 0) for h in recent) / len(recent)
        return {'F': round(avg_f, 4), 'G': round(avg_g, 4), 'M': round(avg_m, 4), 'gain': round(avg_gain, 4)}

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        return {
            'total_measurements': len(self._history),
            'cache_size': len(self._cache),
            'bridge_connected': bool(self.bridge and getattr(self.bridge, 'connected', False)),
            'trend': self.get_trend(),
        }
