"""
能力树 — L1-L10 能力层级评估与进化路径

设计:
  - L1-L10 能力层级（基于智能涌现理论）
  - 本地评估 + 远程同步（QidiBridge）
  - 持久化到 SQLite
  - 每个 Skill 有独立的能力层级
"""
import time
import json
import logging
from typing import Dict, List, Optional, Any

logger = logging.getLogger('CapabilityTree')

# L1-L10 能力层级定义
CAPABILITY_LEVELS = {
    1: '基础感知',      # 能接收信号
    2: '模式识别',      # 能识别重复模式
    3: '记忆形成',      # 能存储和检索
    4: '推理决策',      # 能做简单推理
    5: '工具使用',      # 能调用外部工具
    6: '抽象建模',      # 能构建抽象模型
    7: '社会智能',      # 能与其他 Skill 协同
    8: '文化智能',      # 能传承知识
    9: '元智能',        # 能反思自身
    10: '创造性智能',   # 能生成新知识
}


class CapabilityTree:
    """能力树 — Skill 能力层级评估"""

    def __init__(self, qidi_bridge=None, storage_backend=None):
        self.bridge = qidi_bridge
        self.backend = storage_backend
        # skill_id -> {'level': int, 'history': [...], 'last_assessed': float}
        self._capabilities: Dict[str, Dict[str, Any]] = {}
        self._load_from_backend()

    def assess(self, skill_id: str, performance_data: Dict[str, Any]) -> int:
        """
        评估 Skill 当前能力层级

        Args:
            skill_id: Skill ID
            performance_data: {
                'success_rate': float,
                'usage_count': int,
                'avg_duration_ms': float,
                'complexity_handled': float,  # 处理的任务复杂度
                'collaboration_count': int,   # 协同次数
            }

        Returns:
            能力层级 1-10
        """
        success_rate = performance_data.get('success_rate', 0.0)
        usage_count = performance_data.get('usage_count', 0)
        complexity = performance_data.get('complexity_handled', 0.0)
        collaboration = performance_data.get('collaboration_count', 0)

        # 优先远程评估
        if self.bridge and getattr(self.bridge, 'connected', False):
            try:
                result = self.bridge.get_capability_tree()
                if result and isinstance(result, dict) and skill_id in result:
                    level = result[skill_id].get('level', 1)
                    self._set_capability(skill_id, level, performance_data)
                    return level
            except Exception as e:
                logger.debug(f'远程能力评估失败，降级本地: {e}')

        # 本地评估 — 基于性能指标分级
        level = self._local_assess(success_rate, usage_count, complexity, collaboration)
        self._set_capability(skill_id, level, performance_data)
        return level

    def _local_assess(self, success_rate: float, usage_count: int,
                      complexity: float, collaboration: int) -> int:
        """本地能力评估 — 多维度加权"""
        score = 0

        # 成功率维度 (0-3 分)
        if success_rate >= 0.9:
            score += 3
        elif success_rate >= 0.7:
            score += 2
        elif success_rate >= 0.5:
            score += 1

        # 使用次数维度 (0-2 分)
        if usage_count >= 200:
            score += 2
        elif usage_count >= 50:
            score += 1

        # 复杂度维度 (0-3 分)
        if complexity >= 0.8:
            score += 3
        elif complexity >= 0.5:
            score += 2
        elif complexity >= 0.3:
            score += 1

        # 协同维度 (0-2 分)
        if collaboration >= 20:
            score += 2
        elif collaboration >= 5:
            score += 1

        # score 范围 0-10，映射到 L1-L10
        return max(1, min(10, score + 1))

    def _set_capability(self, skill_id: str, level: int, performance_data: Dict):
        """设置能力层级并持久化"""
        entry = self._capabilities.get(skill_id, {
            'level': 1,
            'history': [],
            'last_assessed': 0,
        })
        old_level = entry['level']
        entry['level'] = level
        entry['last_assessed'] = time.time()
        entry['history'].append({
            'timestamp': time.time(),
            'level': level,
            'performance': performance_data,
        })
        # 只保留最近 50 条历史
        if len(entry['history']) > 50:
            entry['history'] = entry['history'][-50:]
        self._capabilities[skill_id] = entry

        # 持久化
        if self.backend:
            try:
                self.backend.upsert('evolution_log', f'cap_{skill_id}', {
                    'timestamp': time.time(),
                    'evolution_type': 'capability_assess',
                    'rule_id': skill_id,
                    'description': json.dumps({
                        'level': level,
                        'old_level': old_level,
                        'performance': performance_data,
                    }, ensure_ascii=False),
                    'action': f'L{old_level}->L{level}',
                })
            except Exception as e:
                logger.debug(f'能力评估持久化失败: {e}')

        if level != old_level:
            logger.info(f'[能力树] {skill_id}: L{old_level} → L{level}')

    def get_level(self, skill_id: str) -> int:
        """获取 Skill 当前能力层级"""
        return self._capabilities.get(skill_id, {}).get('level', 1)

    def get_level_name(self, level: int) -> str:
        """获取层级名称"""
        return CAPABILITY_LEVELS.get(level, '未知')

    def sync_remote(self) -> bool:
        """从 Qidi 同步能力树"""
        if not self.bridge or not getattr(self.bridge, 'connected', False):
            return False
        try:
            result = self.bridge.get_capability_tree()
            if result and isinstance(result, dict):
                for skill_id, info in result.items():
                    level = info.get('level', 1)
                    self._set_capability(skill_id, level, info)
                logger.info(f'[能力树] 从 Qidi 同步 {len(result)} 个 Skill 能力')
                return True
        except Exception as e:
            logger.warning(f'能力树远程同步失败: {e}')
        return False

    def _load_from_backend(self):
        """从 SQLite 加载能力评估历史"""
        if not self.backend:
            return
        try:
            rows = self.backend.query('evolution_log', {'evolution_type': 'capability_assess'})
            for row in rows:
                skill_id = row.get('rule_id', '')
                if not skill_id:
                    continue
                try:
                    data = json.loads(row.get('description', '{}'))
                    level = data.get('level', 1)
                    entry = self._capabilities.get(skill_id, {
                        'level': 1, 'history': [], 'last_assessed': 0,
                    })
                    entry['level'] = level
                    entry['last_assessed'] = row.get('timestamp', time.time())
                    self._capabilities[skill_id] = entry
                except Exception:
                    pass
            if self._capabilities:
                logger.info(f'[能力树] 从 SQLite 加载 {len(self._capabilities)} 个 Skill 能力')
        except Exception as e:
            logger.debug(f'能力树加载失败: {e}')

    def get_stats(self) -> Dict[str, Any]:
        """获取统计信息"""
        level_dist = {}
        for cap in self._capabilities.values():
            level = cap['level']
            level_dist[f'L{level}'] = level_dist.get(f'L{level}', 0) + 1
        return {
            'total_skills': len(self._capabilities),
            'level_distribution': level_dist,
            'bridge_connected': bool(self.bridge and getattr(self.bridge, 'connected', False)),
        }
