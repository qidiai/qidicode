"""
MCPCapability — MCP 工具能力

一个 MCP 工具 = 一个 MCPCapability
invoke() 通过 transport.call_tool() 调用远程工具，自动记录统计
"""
import time
from typing import Any, Dict, List, Optional
from .base import Capability


class MCPCapability(Capability):
    """MCP 工具能力 — 外部 MCP 服务的工具封装为 Capability"""

    def __init__(self, id: str, name: str, tool_name: str, transport,
                 category: str = 'mcp', tags: List[str] = None,
                 description: str = ''):
        """
        Args:
            id: 能力ID（如 'mcp.hologram.explore'）
            name: 能力名称（人类可读）
            tool_name: MCP tools/call 的 name 参数（如 'hologram_explore'）
            transport: StdioMCPTransport 实例
            category: 能力类别
            tags: 标签列表
            description: 描述
        """
        super().__init__(id=id, name=name, category=category,
                         tags=tags, description=description)
        self.tool_name = tool_name
        self.transport = transport

    def invoke(self, args: Dict[str, Any], context: Dict = None) -> Any:
        """
        调用 MCP 工具 — 自动记录统计

        Args:
            args: 工具参数（传给 transport.call_tool 的 args）
            context: 上下文（用于共现分析，不传给工具）

        Returns:
            工具调用结果
        """
        t0 = time.time()
        ok = True
        try:
            result = self.transport.call_tool(self.tool_name, args)
            if result is None:
                ok = False
            return result
        except Exception:
            ok = False
            raise
        finally:
            duration_ms = (time.time() - t0) * 1000
            self.record_call(ok, duration_ms)
