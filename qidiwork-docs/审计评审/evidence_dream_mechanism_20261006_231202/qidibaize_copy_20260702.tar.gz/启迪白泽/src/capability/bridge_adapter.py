"""
BridgeCapabilityAdapter — 把现有 Bridge 的高层方法包装为 Capability

向后兼容设计:
  - HologramBridge/QidiBridge 的 20+ 高层方法（preflight/impact/evaluate_emergence 等）
  - 每个方法包装为一个 BridgeCapabilityAdapter
  - 享受统一的 record_call + 共现分析 + 能力树评估
  - 现有 Bridge 实例和注入链不改动
"""
import time
from typing import Any, Dict, List, Optional
from .base import Capability


class BridgeCapabilityAdapter(Capability):
    """Bridge 方法适配器 — 把现有 Bridge 方法包装为 Capability"""

    def __init__(self, id: str, name: str, bridge, method_name: str,
                 category: str = 'bridge', tags: List[str] = None,
                 description: str = ''):
        """
        Args:
            id: 能力ID（如 'bridge.hologram.preflight'）
            name: 能力名称
            bridge: Bridge 实例（HologramBridge/QidiBridge）
            method_name: Bridge 方法名（如 'preflight'）
            category: 能力类别
            tags: 标签
            description: 描述
        """
        super().__init__(id=id, name=name, category=category,
                         tags=tags, description=description)
        self.bridge = bridge
        self.method_name = method_name

    def invoke(self, args: Dict[str, Any], context: Dict = None) -> Any:
        """
        调用 Bridge 方法 — 自动记录统计

        Args:
            args: 方法参数（dict 解包为 kwargs，或直接传位置参数）
            context: 上下文（用于共现分析，不传给 Bridge）

        Returns:
            Bridge 方法返回值
        """
        method = getattr(self.bridge, self.method_name)
        t0 = time.time()
        ok = True
        try:
            if isinstance(args, dict):
                return method(**args)
            elif args is None:
                return method()
            else:
                return method(args)
        except Exception:
            ok = False
            raise
        finally:
            duration_ms = (time.time() - t0) * 1000
            self.record_call(ok, duration_ms)
