"""
MCPDiscovery — MCP 服务自动发现

从 config/mcp_services.json 加载服务清单:
  - 启动 StdioMCPTransport 连接每个服务
  - MCP 协议: tools/list 自动发现工具
  - 非标准协议: 从配置读取 tools 列表
  - 每个工具注册为一个 MCPCapability

新增 MCP 服务只需在配置文件加一条，无需改代码
"""
import os
import json
import logging
from typing import Dict, List, Optional
from .mcp_transport import StdioMCPTransport
from .mcp_capability import MCPCapability

logger = logging.getLogger('MCPDiscovery')


class MCPDiscovery:
    """MCP 服务自动发现 — 读配置、连接、注册工具为 Capability"""

    def __init__(self, registry, config_path: str = None):
        """
        Args:
            registry: CapabilityRegistry 实例
            config_path: 配置文件路径（默认 config/mcp_services.json）
        """
        self.registry = registry
        self.config_path = config_path or self._default_config_path()
        self.transports: Dict[str, StdioMCPTransport] = {}  # service_id -> transport

    def _default_config_path(self) -> str:
        """默认配置路径 — 项目根目录下的 config/mcp_services.json"""
        # 从当前文件位置推断项目根目录
        current = os.path.dirname(os.path.abspath(__file__))
        project_root = os.path.dirname(os.path.dirname(current))
        return os.path.join(project_root, 'config', 'mcp_services.json')

    def discover_and_register(self) -> Dict:
        """
        加载配置，连接服务，注册工具为 Capability

        Returns:
            {'services': int, 'tools': int, 'failed': [service_id, ...]}
        """
        config = self._load_config()
        if not config:
            return {'services': 0, 'tools': 0, 'failed': []}

        stats = {'services': 0, 'tools': 0, 'failed': []}

        for svc in config.get('services', []):
            svc_id = svc.get('id', 'unknown')
            try:
                transport = StdioMCPTransport(
                    command=svc['command'],
                    args=svc.get('args', []),
                    cwd=svc.get('cwd'),
                    protocol=svc.get('protocol', 'mcp'),
                )

                if not transport.connect():
                    stats['failed'].append(svc_id)
                    logger.warning(f'[MCPDiscovery] 连接失败: {svc_id}')
                    continue

                self.transports[svc_id] = transport
                stats['services'] += 1

                # 工具发现
                tools = self._discover_tools(svc, transport)
                svc_category = svc.get('category', 'mcp')
                svc_tags = svc.get('tags', [])

                for tool in tools:
                    tool_name = tool.get('name', '')
                    if not tool_name:
                        continue
                    cap_id = f"mcp.{svc_id}.{tool_name}"
                    cap = MCPCapability(
                        id=cap_id,
                        name=tool.get('description', tool_name),
                        tool_name=tool_name,
                        transport=transport,
                        category=tool.get('category', svc_category),
                        tags=svc_tags,
                        description=tool.get('description', ''),
                    )
                    self.registry.register(cap)
                    stats['tools'] += 1

                logger.info(f'[MCPDiscovery] {svc_id}: 发现 {len(tools)} 个工具')

            except Exception as e:
                stats['failed'].append(svc_id)
                logger.error(f'[MCPDiscovery] 服务 {svc_id} 异常: {e}')

        return stats

    def _load_config(self) -> Optional[Dict]:
        """加载配置文件"""
        if not os.path.exists(self.config_path):
            logger.warning(f'[MCPDiscovery] 配置文件不存在: {self.config_path}')
            return None
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f'[MCPDiscovery] 配置加载失败: {e}')
            return None

    def _discover_tools(self, svc: Dict, transport: StdioMCPTransport) -> List[Dict]:
        """发现工具 — MCP 用 tools/list，其他用配置声明"""
        if svc.get('auto_discover') and svc.get('protocol') == 'mcp':
            try:
                tools = transport.list_tools()
                if tools:
                    return tools
            except Exception as e:
                logger.warning(f'[MCPDiscovery] tools/list 失败: {e}')
        # 非自动发现或失败，用配置声明的工具列表
        return svc.get('tools', [])

    def disconnect_all(self):
        """断开所有 transport"""
        for svc_id, transport in self.transports.items():
            try:
                transport.disconnect()
            except Exception:
                pass
        self.transports.clear()

    def get_stats(self) -> Dict:
        """获取发现状态"""
        return {
            'transports': len(self.transports),
            'connected': [sid for sid, t in self.transports.items() if t.is_connected()],
        }
