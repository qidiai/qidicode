"""
StdioMCPTransport — 通用 stdio MCP 传输层

从 HologramBridge 抽取通用逻辑:
  - subprocess.Popen 启动子进程
  - JSON-RPC 2.0 over stdio 通信
  - MCP initialize 握手（protocol='mcp' 时）
  - tools/call 调用工具
  - tools/list 自动发现工具（仅 MCP 协议）

支持两种协议:
  - 'mcp': 标准 MCP（HoloGram Engine），有 initialize 握手 + tools/list
  - 'qidi_rpc': 非标准 RPC（Qidi Agent），无握手，靠配置声明工具
"""
import subprocess
import json
import logging
import time
import threading
import os
from typing import Dict, Any, Optional, List

logger = logging.getLogger('MCPTransport')


class StdioMCPTransport:
    """通用 stdio MCP 传输 — 支持标准 MCP 和非标准 RPC"""

    TIMEOUT = 60

    def __init__(self, command: str, args: List[str] = None, cwd: str = None,
                 protocol: str = 'mcp'):
        """
        Args:
            command: 可执行命令（如 'hologram-engine.exe' 或 'node'）
            args: 命令参数列表（如 ['serve'] 或 ['qidi_rpc.js']）
            cwd: 工作目录
            protocol: 'mcp' 或 'qidi_rpc'
        """
        self.command = command
        self.args = args or []
        self.cwd = cwd
        self.protocol = protocol
        self._proc = None
        self._lock = threading.Lock()
        self._connected = False
        self._message_id = 0
        self._initialized = False

    def connect(self) -> bool:
        """连接服务 — 启动子进程并完成握手（MCP 协议时）"""
        with self._lock:
            if self._connected:
                return True

            # 检查可执行文件存在性（command 是完整路径时）
            if os.path.isabs(self.command) and not os.path.exists(self.command):
                logger.error(f'[MCPTransport] 命令不存在: {self.command}')
                return False

            try:
                cmd_list = [self.command] + self.args
                self._proc = subprocess.Popen(
                    cmd_list,
                    cwd=self.cwd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    encoding='utf-8',
                    bufsize=1,
                    universal_newlines=True,
                )

                time.sleep(0.5)

                if self._proc.poll() is not None:
                    stderr = self._proc.stderr.read()
                    logger.error(f'[MCPTransport] 进程启动失败: {stderr[:500]}')
                    return False

                # MCP 协议需要 initialize 握手
                if self.protocol == 'mcp':
                    if not self._initialize():
                        return False
                else:
                    # qidi_rpc 等非标准协议，直接标记已连接
                    time.sleep(0.5)
                    if self._proc.poll() is not None:
                        stderr = self._proc.stderr.read()
                        logger.error(f'[MCPTransport] 非MCP进程退出: {stderr[:500]}')
                        return False

                self._connected = True
                logger.info(f'[MCPTransport] {self.protocol} 桥接已建立: {self.command}')
                return True

            except Exception as e:
                logger.error(f'[MCPTransport] 连接失败: {e}')
                return False

    def _initialize(self) -> bool:
        """MCP initialize 握手"""
        resp = self._send_request('initialize', {
            'protocolVersion': '2024-11-05',
            'capabilities': {},
            'clientInfo': {'name': 'baize', 'version': '1.0'},
        })
        if resp and 'result' in resp:
            info = resp['result'].get('serverInfo', {})
            logger.info(f'[MCPTransport] 引擎: {info.get("name", "?")} v{info.get("version", "?")}')
            self._initialized = True
            return True
        logger.error(f'[MCPTransport] initialize 握手失败: {resp}')
        return False

    def _send_request(self, method: str, params: Dict = None) -> Optional[Dict]:
        """发送 JSON-RPC 请求"""
        if not self._proc or self._proc.poll() is not None:
            logger.warning('[MCPTransport] 进程未运行')
            return None

        self._message_id += 1
        req = {
            'jsonrpc': '2.0',
            'id': self._message_id,
            'method': method,
            'params': params or {},
        }

        try:
            self._proc.stdin.write(json.dumps(req) + '\n')
            self._proc.stdin.flush()
            line = self._proc.stdout.readline()
            if not line:
                logger.warning('[MCPTransport] 无响应')
                return None
            return json.loads(line)
        except Exception as e:
            logger.error(f'[MCPTransport] 请求失败: {e}')
            self._connected = False
            return None

    def call_tool(self, name: str, args: Dict = None) -> Optional[Dict]:
        """
        调用工具 — 通用调用入口

        Args:
            name: 工具名（MCP）或方法名（qidi_rpc）
            args: 工具参数

        Returns:
            调用结果字典
        """
        if not self._connected and not self.connect():
            return None

        if self.protocol == 'mcp':
            # 标准 MCP: tools/call
            resp = self._send_request('tools/call', {
                'name': name,
                'arguments': args or {},
            })
            if not resp or 'result' not in resp:
                err = resp.get('error') if resp else None
                logger.error(f'[MCPTransport] 工具调用失败 {name}: {err}')
                return None
            content = resp['result'].get('content', [])
            if not content:
                return None
            text = content[0].get('text', '')
            try:
                return json.loads(text)
            except (json.JSONDecodeError, TypeError):
                return {'raw_text': text}
        else:
            # qidi_rpc: 直接用 method 字段调用
            resp = self._send_request(name, args or {})
            if not resp or 'result' not in resp:
                err = resp.get('error') if resp else None
                logger.error(f'[MCPTransport] RPC调用失败 {name}: {err}')
                return None
            return resp['result']

    def list_tools(self) -> List[Dict]:
        """MCP tools/list 自动发现（仅 protocol='mcp' 时可用）"""
        if self.protocol != 'mcp':
            return []
        resp = self._send_request('tools/list', {})
        if not resp or 'result' not in resp:
            return []
        return resp['result'].get('tools', [])

    def is_connected(self) -> bool:
        """检查连接状态"""
        return self._connected and self._proc and self._proc.poll() is None

    def disconnect(self):
        """断开连接"""
        with self._lock:
            if self._proc:
                try:
                    self._proc.stdin.close()
                    self._proc.terminate()
                    self._proc.wait(timeout=5)
                except Exception:
                    pass
                self._proc = None
            self._connected = False
            self._initialized = False
            logger.info(f'[MCPTransport] {self.protocol} 桥接已断开')
