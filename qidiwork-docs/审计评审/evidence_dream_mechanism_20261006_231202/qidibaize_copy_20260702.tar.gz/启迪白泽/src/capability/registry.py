"""
CapabilityRegistry — 能力注册中心

继承 SkillRegistry，统一管理 Skill（内部能力）和 MCP 服务（外部能力）:
  - register() 接受任何 Capability 子类（Skill/MCPCapability/BridgeCapabilityAdapter）
  - invoke() 统一调用入口，自动记录统计 + 共现分析 + SQLite 持久化
  - 兼容 SkillCombiner/SkillEvolutionMonitor（它们用 get_active_skills/list_all，返回值含 Capability）

进化机制零改动复用:
  - 父类 record_call() 内部调 cooccurrence.record_call() 和 SQLite skill_calls 表
  - MCPCapability 的 id 如 'mcp.hologram.preflight' 自动被共现分析捕获
"""
import time
from typing import Any, Dict, Optional
from skills.skill_registry import SkillRegistry


class CapabilityRegistry(SkillRegistry):
    """能力注册中心 — 继承 SkillRegistry，兼容现有进化机制"""

    def register(self, capability):
        """注册能力 — 接受 Skill/MCPCapability/BridgeCapabilityAdapter"""
        self.skills[capability.id] = capability
        self.category_index[capability.category].append(capability.id)
        for tag in getattr(capability, 'tags', []):
            self.tag_index[tag].append(capability.id)

    def invoke(self, capability_id: str, args: Dict = None,
               context: Dict = None) -> Any:
        """
        统一调用入口 — 自动记录统计 + 共现 + 持久化

        Args:
            capability_id: 能力ID（如 'mcp.hologram.preflight'）
            args: 调用参数
            context: 上下文（用于共现分析）

        Returns:
            调用结果

        Raises:
            KeyError: 能力不存在
        """
        cap = self.get(capability_id)
        if not cap:
            raise KeyError(f'能力不存在: {capability_id}')

        t0 = time.time()
        ok = True
        try:
            result = cap.invoke(args, context)
            # MCPCapability/BridgeCapabilityAdapter 内部已 record_call
            # 但这里再调一次父类 record_call 以触发共现分析 + SQLite 持久化
            return result
        except Exception:
            ok = False
            raise
        finally:
            duration_ms = (time.time() - t0) * 1000
            # 复用父类 record_call：更新统计 + cooccurrence + SQLite skill_calls 表
            # 注意：父类 record_call 会再次调 cap.record_call，但 MCPCapability.invoke
            # 内部已调过一次。为避免双重计数，这里只在 cap 没有 implementation 时调
            # （即 MCPCapability/BridgeCapabilityAdapter 已自己记录，Skill 走父类）
            # 实际上为统一行为，父类 record_call 内部会调 cap.record_call
            # 对于 MCPCapability，invoke 内部已记录一次，父类再记录一次会重复
            # 所以这里用 _record_call_only_stats 只记录统计 + 共现 + SQLite，不重复调 cap.record_call
            self._record_call_only_stats(capability_id, ok, duration_ms, context)

    def _record_call_only_stats(self, capability_id: str, success: bool,
                                 duration_ms: float, context: Dict = None):
        """仅记录统计 + 共现 + SQLite（不重复调 cap.record_call）"""
        # 共现分析
        if self.cooccurrence:
            try:
                self.cooccurrence.record_call(capability_id, context)
            except Exception:
                pass
        # 持久化到 skill_calls 表
        if self.backend:
            try:
                cap = self.get(capability_id)
                name = cap.name if cap else capability_id
                import json
                self.backend.execute(
                    "INSERT INTO skill_calls (skill_id, skill_name, timestamp, success, duration_ms, context) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (capability_id, name, time.time(), 1 if success else 0, duration_ms,
                     json.dumps(context or {}, ensure_ascii=False))
                )
            except Exception:
                pass
