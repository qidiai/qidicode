"""
Capability 抽象基类 — Skill 和 MCP 服务的统一接口

设计:
  - 与 Skill 同构的统计字段（usage_count/success_count/...）
  - 保证 SkillCombiner/SkillEvolutionMonitor 鸭子类型兼容
  - invoke() 由子类实现：Skill 用 implementation Callable，MCPCapability 用 transport.call_tool
"""
import time
from typing import Any, Dict, List, Optional


class Capability:
    """能力抽象基类 — 内部 Skill 和外部 MCP 服务都实现这个接口"""

    def __init__(self, id: str, name: str, category: str = 'general',
                 tags: List[str] = None, description: str = ''):
        self.id = id
        self.name = name
        self.category = category
        self.tags = tags or []
        self.description = description
        # 运行时统计（与 Skill 同构）
        self.created_at = time.time()
        self.last_used = 0.0
        self.usage_count = 0
        self.success_count = 0
        self.fail_count = 0
        self.total_duration_ms = 0.0

    @property
    def success_rate(self) -> float:
        """成功率"""
        total = self.success_count + self.fail_count
        return self.success_count / total if total > 0 else 0.0

    @property
    def avg_response_time(self) -> float:
        """平均响应时间（毫秒）"""
        return self.total_duration_ms / self.usage_count if self.usage_count > 0 else 0.0

    @property
    def avg_duration_ms(self) -> float:
        """avg_duration_ms 别名（兼容 CapabilityTree 评估维度）"""
        return self.avg_response_time

    def invoke(self, args: Dict[str, Any], context: Dict = None) -> Any:
        """
        调用能力 — 子类实现

        Args:
            args: 调用参数
            context: 上下文信息（用于共现分析等）

        Returns:
            调用结果
        """
        raise NotImplementedError

    def record_call(self, success: bool, duration_ms: float):
        """记录调用统计 — 与 Skill.record_call 同逻辑"""
        self.usage_count += 1
        self.last_used = time.time()
        self.total_duration_ms += duration_ms
        if success:
            self.success_count += 1
        else:
            self.fail_count += 1

    def __repr__(self):
        status = "🟢" if self.usage_count > 0 else "⚪"
        return (f"{status} {self.id}({self.name}) "
                f"calls={self.usage_count} success={self.success_rate:.1%} "
                f"avg={self.avg_response_time:.1f}ms category={self.category}")
