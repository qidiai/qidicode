"""
Capability 模块 — 统一 Skill 和 MCP 服务的能力抽象层

核心类:
  - Capability: 抽象基类（base.py）
  - CapabilityRegistry: 能力注册中心，继承 SkillRegistry（registry.py）
  - MCPCapability: MCP 工具能力（mcp_capability.py）
  - BridgeCapabilityAdapter: 现有 Bridge 方法适配器（bridge_adapter.py）
  - StdioMCPTransport: 通用 stdio MCP 传输（mcp_transport.py）
  - MCPDiscovery: MCP 服务自动发现（mcp_discovery.py）
"""
from .base import Capability
from .registry import CapabilityRegistry
from .mcp_capability import MCPCapability
from .bridge_adapter import BridgeCapabilityAdapter
from .mcp_transport import StdioMCPTransport
from .mcp_discovery import MCPDiscovery

__all__ = [
    'Capability',
    'CapabilityRegistry',
    'MCPCapability',
    'BridgeCapabilityAdapter',
    'StdioMCPTransport',
    'MCPDiscovery',
]
