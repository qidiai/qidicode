# 启迪·白泽 统合体

> 自进化智能体 — 浏览器自学习 × 白泽模型大脑 × 四自进化闭环
> 创建: 2026-07-02

## 这是什么

把分散在4个盘6个目录的资产，统合成一个有序的自进化智能体项目：

- **浏览器感知**：Playwright驱动Edge，持久登录多平台，自己上网学习
- **白泽大脑**：V10嵌入做感知向量化，V22生成架构做推理生成（需重训补数据）
- **蠕虫决策**：worm大脑激活扩散，群体思维涌现，合体/分裂生命周期
- **四自进化**：记忆系统自进化 + Skill自进化 + Agent自进化 + 代码自生长
- **真涌现度量**：调Qidi Agent的SynchronyMeter，三模态同步真测，L1-L10能力评级

## 快速开始

```bash
# 1. 安装依赖
pip install playwright torch numpy
playwright install msedge

# 2. 迁移资产（已完成，如需重跑）
python scripts/migrate_assets.py

# 3. 启动（阶段1完成后可用）
python src/main.py
```

## 目录结构

```
src/
├── perception/   感知层（浏览器+联网搜索）
├── models/       白泽模型（V10嵌入+V22生成大脑）
├── memory/       记忆系统（四层+知识树+向量存储）
├── brain/        蠕虫大脑（决策涌现）
├── skills/       Skill自进化（录制+共现+信息素路由）
├── agents/       Agent自进化（源池门控+分裂合并+动态身份）
├── growth/       代码自生长（SelfEvolve+AST分析+重构引擎）
├── evolution/    进化引擎（规则匹配+涌现度量+能力评级）
├── bridge/       跨语言桥接（Python↔Node.js Qidi）
├── control/      元控制层（安全护栏+磁场监控+免疫隔离）
└── compute/      闲置算力调度
```

## 资产来源

| 来源目录 | 搬了什么 |
|---------|---------|
| `F:\代码\导入数据\闲置算力系统` | worm大脑/知识树/联网学习/SelfEvolve/元集成（主骨架） |
| `F:\代码\白泽档案` | V22架构/CascadePool/V10嵌入权重路径 |
| `F:\代码\导入数据\元系统` | 源池门控/信息素路由/假设驱动（已合入闲置算力系统版本） |
| `F:\代码\导入数据\agent` | 四层记忆系统/AST分析/进化引擎骨架/Skill注册 |
| `trae_projects\ai-orchestrator` | 子进程调用不搬：SynchronyMeter/EmergenceEvaluator/13适配器 |

## 当前状态

- ✅ 目录规划完成
- ✅ 17个核心模块迁移就位
- ⬜ 阶段1：浏览器感知层（browser_sensor.py）
- ⬜ 阶段5：V22大脑重训（需扩数据到10万+条）

详见 `项目规划.md` 和 `docs/资产迁移清单.md`。
