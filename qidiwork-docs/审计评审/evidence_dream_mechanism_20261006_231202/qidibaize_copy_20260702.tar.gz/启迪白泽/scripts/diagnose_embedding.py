"""诊断嵌入向量问题"""
import sys
sys.path.insert(0, 'src')

print('测试V10嵌入引擎...')
from models.baize_embed import embed, embed_with_pools

text = '深度学习Transformer架构'

# 测试 embed
print('\n[1] 测试 embed():')
try:
    vec = embed(text)
    print(f'  成功, 维度: {len(vec)}')
    print(f'  前10个值: {vec[:10]}')
except Exception as e:
    print(f'  失败: {e}')

# 测试 embed_with_pools
print('\n[2] 测试 embed_with_pools():')
try:
    pools = embed_with_pools(text)
    print(f'  成功')
    print(f'  embedding维度: {len(pools.get("embedding", []))}')
    print(f'  fast_pool维度: {len(pools.get("fast_pool", []))}')
    print(f'  medium_pool维度: {len(pools.get("medium_pool", []))}')
    print(f'  slow_pool维度: {len(pools.get("slow_pool", []))}')
    if pools.get('embedding'):
        print(f'  embedding前5个值: {pools["embedding"][:5]}')
except Exception as e:
    print(f'  失败: {e}')

# 测试知识树的嵌入
print('\n[3] 测试知识树的 smart_embedding_with_pools():')
from memory.knowledge_tree import smart_embedding_with_pools, get_embed_status
print(f'  引擎状态: {get_embed_status()}')
try:
    result = smart_embedding_with_pools(text)
    print(f'  成功')
    print(f'  embedding维度: {len(result.get("embedding", []))}')
    if result.get('embedding'):
        print(f'  embedding前5个值: {result["embedding"][:5]}')
except Exception as e:
    print(f'  失败: {e}')
