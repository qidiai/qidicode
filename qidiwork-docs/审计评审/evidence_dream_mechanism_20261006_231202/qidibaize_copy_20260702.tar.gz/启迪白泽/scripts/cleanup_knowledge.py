"""知识树深度清理 — 删除死节点/零命中/损坏节点，保留高价值知识

清理策略:
  1. 先备份原文件 (knowledge_tree.json.bak.YYYYMMDD_HHMMSS)
  2. 删除 is_dying=True 的节点
  3. 删除零命中且 source 不在保护列表的节点
  4. 删除 topic 过短/内容过短的节点
  5. 删除重复 topic (保留命中数最高的)
  6. 修复孤儿节点 (parent_id 指向不存在的节点) → 重新挂到 root
  7. 保存并输出清理报告

保护列表 (不删除即使零命中):
  - manual: 手动添加的精华知识
  - teacher: 老师教的
  - 迁移: 从旧系统迁移的
"""
import json
import shutil
import time
from pathlib import Path
from collections import defaultdict

KT_PATH = Path(r'F:\代码\启迪白泽\data\knowledge_tree.json')
PROTECTED_SOURCES = {'manual', 'teacher', '迁移'}


def main():
    # 1. 备份
    ts = time.strftime('%Y%m%d_%H%M%S')
    backup_path = KT_PATH.with_suffix(f'.json.bak.{ts}')
    shutil.copy2(KT_PATH, backup_path)
    print(f'[备份] {backup_path.name}')

    # 2. 加载
    data = json.loads(KT_PATH.read_text(encoding='utf-8'))
    nodes = data.get('nodes', [])
    original_count = len(nodes)
    original_size = KT_PATH.stat().st_size
    print(f'[原状] {original_count} 节点, {original_size/1024:.1f} KB')

    # 索引
    by_id = {n['id']: n for n in nodes}
    reasons = defaultdict(list)  # reason -> [node_id, ...]

    # 3. 标记删除: is_dying
    for n in nodes:
        if n.get('is_dying', False):
            reasons['dying'].append(n['id'])

    # 4. 标记删除: 零命中且非保护
    for n in nodes:
        if n['id'] in {x for v in reasons.values() for x in v}:
            continue
        if n.get('hit_count', 0) == 0:
            src = n.get('source', '')
            if src not in PROTECTED_SOURCES:
                # 进一步检查: topic 太短或内容太空
                topic = (n.get('topic') or '').strip()
                content = (n.get('content') or '').strip()
                if len(topic) < 2 or len(content) < 20:
                    reasons['zero_hit_junk'].append(n['id'])
                elif topic.lower() in {'test', 'todo', 'tmp', 'temp', '未命名', '新建', '迁移知识', '测试'}:
                    reasons['placeholder'].append(n['id'])
                else:
                    # 零命中但内容还行 — 保留但标记观察
                    pass

    # 5. 标记删除: 重复 topic (保留命中最高)
    topic_groups = defaultdict(list)
    for n in nodes:
        if n['id'] in {x for v in reasons.values() for x in v}:
            continue
        if n['id'] == 'root':
            continue
        topic = (n.get('topic') or '').strip()
        if topic:
            topic_groups[topic].append(n)
    for topic, group in topic_groups.items():
        if len(group) > 1:
            # 按 hit_count 降序，保留第一个，删其余
            group.sort(key=lambda x: x.get('hit_count', 0), reverse=True)
            for n in group[1:]:
                reasons['duplicate_topic'].append(n['id'])

    # 6. 执行删除
    to_delete = set()
    for reason, ids in reasons.items():
        to_delete.update(ids)
        print(f'  [{reason}] 删除 {len(ids)} 个')

    # 同时清理 children_ids 中的引用 + 修复孤儿
    surviving = [n for n in nodes if n['id'] not in to_delete]
    surviving_ids = {n['id'] for n in surviving}

    for n in surviving:
        # 清理 children_ids
        n['children_ids'] = [cid for cid in n.get('children_ids', []) if cid in surviving_ids]
        # 修复孤儿: parent 不在了就挂 root
        pid = n.get('parent_id')
        if pid and pid not in surviving_ids:
            n['parent_id'] = 'root'
            if n['id'] not in by_id['root'].get('children_ids', []) if 'root' in by_id else []:
                pass  # 后面统一处理

    # 确保 root 存在
    root_node = next((n for n in surviving if n['id'] == 'root'), None)
    if not root_node:
        root_node = {
            'id': 'root', 'parent_id': None, 'children_ids': [],
            'topic': '知识根节点', 'depth': 0, 'hit_count': 0,
            'is_dying': False, 'source': 'root',
        }
        surviving.append(root_node)

    # 7. 保存
    data['nodes'] = surviving
    data['metadata'] = {
        'totalNodes': len(surviving),
        'totalHits': sum(n.get('hit_count', 0) for n in surviving),
        'cleanedAt': time.time(),
        'cleanedFrom': original_count,
    }
    KT_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

    new_size = KT_PATH.stat().st_size
    print(f'\n[结果] {len(surviving)} 节点 (删除 {original_count - len(surviving)})')
    print(f'[大小] {original_size/1024:.1f} KB → {new_size/1024:.1f} KB (节省 {(original_size-new_size)/1024:.1f} KB, {(original_size-new_size)*100/original_size:.1f}%)')

    # 8. 统计剩余
    hits = [n.get('hit_count', 0) for n in surviving]
    dying = sum(1 for n in surviving if n.get('is_dying', False))
    zero = sum(1 for h in hits if h == 0)
    print(f'[健康] 死亡 {dying}/{len(surviving)} ({dying*100/len(surviving):.1f}%), 零命中 {zero}/{len(surviving)} ({zero*100/len(surviving):.1f}%)')
    print(f'[命中] 总 {sum(hits)}, 平均 {sum(hits)/len(surviving):.1f}')

    # 来源分布
    from collections import Counter
    sources = Counter(n.get('source', 'unknown') for n in surviving)
    print(f'[来源] {dict(sources)}')

    # 深度分布
    depths = Counter(n.get('depth', 0) for n in surviving)
    print(f'[深度] {dict(sorted(depths.items()))}')


if __name__ == '__main__':
    main()
