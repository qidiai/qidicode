import sqlite3
conn = sqlite3.connect(r'C:\Users\ASUS\.openclaw\workspace\.hologram\hologram.db')
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
print('Tables:')
for r in cur.fetchall():
    print(' -', r[0])
    try:
        cur.execute(f"SELECT COUNT(*) FROM '{r[0]}'")
        cnt = cur.fetchone()[0]
        print(f'   rows: {cnt}')
        cur.execute(f"SELECT * FROM '{r[0]}' LIMIT 2")
        cols = [d[0] for d in cur.description]
        print(f'   cols: {cols}')
    except Exception as e:
        print(f'   err: {e}')
conn.close()
