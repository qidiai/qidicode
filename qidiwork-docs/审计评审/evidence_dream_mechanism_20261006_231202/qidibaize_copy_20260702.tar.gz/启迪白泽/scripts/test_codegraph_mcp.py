import sys
sys.path.insert(0, r'F:\代码\启迪白泽\src')

from main import BaizeSystem

baize = BaizeSystem()
caps = baize.capability_registry.list_all()

codegraph_caps = [c for c in caps if 'mcp.codegraph' in c.id]

print('=== CodeGraph MCP工具 ===')
print(f'数量: {len(codegraph_caps)}')
for c in codegraph_caps:
    print(f'  {c.id}: {c.name}')

print('\n=== 所有能力统计 ===')
from collections import defaultdict
cat_counts = defaultdict(int)
for c in caps:
    cat_counts[c.category] += 1
for cat, cnt in sorted(cat_counts.items()):
    print(f'  {cat}: {cnt}')
