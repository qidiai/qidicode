import sys
sys.path.insert(0, r'F:\代码\启迪白泽\src')

from main import BaizeSystem

print('=== 启动启迪白泽系统 ===')
baize = BaizeSystem()

print('\n=== 调用 CodeGraph 分析代码 ===')
print('正在分析启迪白泽项目代码库...')

result = baize.capability_registry.invoke('mcp.codegraph.analyze_codebase', {
    'project_root': r'F:\代码\启迪白泽\src',
    'quick': True
})

print('\n=== 分析结果 ===')
if result:
    if isinstance(result, dict):
        for key, value in result.items():
            print(f'  {key}: {value}')
    else:
        print(result)
else:
    print('分析失败')

print('\n=== 查找符号定义示例 ===')
result2 = baize.capability_registry.invoke('mcp.codegraph.find_definition', {
    'name': 'BaizeSystem',
    'project_root': r'F:\代码\启迪白泽\src'
})

print('\nBaizeSystem 定义位置:')
if result2:
    if isinstance(result2, dict):
        for key, value in result2.items():
            print(f'  {key}: {value}')
    else:
        print(result2)
else:
    print('未找到')

print('\n=== 项目统计 ===')
result3 = baize.capability_registry.invoke('mcp.codegraph.project_statistics', {
    'project_root': r'F:\代码\启迪白泽\src'
})

print('\n项目健康指标:')
if result3:
    if isinstance(result3, dict):
        for key, value in result3.items():
            print(f'  {key}: {value}')
    else:
        print(result3)
else:
    print('获取失败')
