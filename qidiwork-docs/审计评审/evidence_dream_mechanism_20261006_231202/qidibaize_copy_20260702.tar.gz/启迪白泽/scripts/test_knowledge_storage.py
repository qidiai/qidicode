"""测试知识树存储升级效果"""
import sys
sys.path.insert(0, 'src')

from memory.knowledge_tree import KnowledgeTree

print('=' * 60)
print('知识树存储升级验证')
print('=' * 60)

# 1. 加载知识树
print('\n[1] 加载知识树...')
kt = KnowledgeTree('data/knowledge_tree.json')
stats = kt.get_stats()
print(f'节点数: {stats["total_nodes"]}')
print(f'Dying节点: {stats["dying_nodes"]}')

# 2. 检查嵌入向量维度
print('\n[2] 检查嵌入向量维度...')
embedding_dims = []
for node in kt.nodes.values():
    if node.embedding:
        embedding_dims.append(len(node.embedding))

if embedding_dims:
    print(f'嵌入向量维度: min={min(embedding_dims)}, max={max(embedding_dims)}, avg={sum(embedding_dims)/len(embedding_dims):.0f}')
    if max(embedding_dims) >= 1024:
        print('✓ 嵌入向量已完整保存(1024维)')
    elif max(embedding_dims) >= 512:
        print('✓ 嵌入向量保存维度>=512')
    else:
        print('✗ 嵌入向量仍被截断')
else:
    print('无嵌入向量(将在下次学习时生成)')

# 3. 测试学习新知识
print('\n[3] 测试学习新知识...')
test_topic = '深度学习Transformer架构'
test_content = 'Transformer是一种基于自注意力机制的深度学习模型，由Vaswani等人在2017年提出。它使用多头注意力机制来捕捉序列中不同位置之间的依赖关系，避免了传统RNN的梯度消失问题。Transformer已成为NLP领域的主流架构，包括BERT、GPT等知名模型都基于Transformer构建。'
result = kt.learn(test_topic, test_content, source='test')
print(f'学习结果: {result is not None}')

# 4. 测试检索
print('\n[4] 测试检索...')
results = kt.recall('Transformer', top_k=3)
print(f'检索结果数: {len(results)}')
for r in results:
    print(f'  - {r["topic"]}: score={r["score"]:.4f}, similarity={r["similarity"]:.4f}')

# 5. 测试保存
print('\n[5] 测试保存...')
kt.save(force=True)
print('保存成功')

# 6. 重新加载验证
print('\n[6] 重新加载验证...')
kt2 = KnowledgeTree('data/knowledge_tree.json')
stats2 = kt2.get_stats()
print(f'重新加载后节点数: {stats2["total_nodes"]}')

# 检查新学习的节点
found = False
for node in kt2.nodes.values():
    if node.topic == test_topic:
        found = True
        dim = len(node.embedding) if node.embedding else 0
        print(f'找到测试节点: {test_topic}, 嵌入维度: {dim}')
        break
print(f'✓ 节点持久化成功' if found else '✗ 节点丢失')

# 7. 清理测试数据
print('\n[7] 清理测试数据...')
kt2.prune_junk(max_junk=10)
kt2.save(force=True)
print('清理完成')

print('\n' + '=' * 60)
print('所有验证通过!')
print('=' * 60)
