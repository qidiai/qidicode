import subprocess
import json
import time

print('=== 测试 MCP 协议 ===')

proc = subprocess.Popen(
    ['code-graph-mcp'],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    encoding='utf-8',
    bufsize=1,
    universal_newlines=True
)

time.sleep(1)

if proc.poll() is not None:
    stderr = proc.stderr.read()
    print(f'进程退出: {stderr}')
    exit(1)

print('发送 initialize...')
init_req = json.dumps({
    'jsonrpc': '2.0',
    'id': 1,
    'method': 'initialize',
    'params': {
        'protocolVersion': '2024-11-05',
        'capabilities': {},
        'clientInfo': {'name': 'test', 'version': '1.0'}
    }
}) + '\n'
proc.stdin.write(init_req)
proc.stdin.flush()

time.sleep(1)
line = proc.stdout.readline()
print(f'响应: {line}')

if line:
    resp = json.loads(line)
    print(f'引擎: {resp["result"].get("serverInfo", {})}')

print('\n发送 tools/list...')
list_req = json.dumps({
    'jsonrpc': '2.0',
    'id': 2,
    'method': 'tools/list',
    'params': {}
}) + '\n'
proc.stdin.write(list_req)
proc.stdin.flush()

time.sleep(1)
line = proc.stdout.readline()
print(f'响应: {line[:500]}')

if line:
    resp = json.loads(line)
    tools = resp['result'].get('tools', [])
    print(f'\n工具数量: {len(tools)}')
    for t in tools[:3]:
        print(f'  - {t.get("name")}')

proc.stdin.close()
proc.terminate()
print('\n测试完成')
