"""知识树存储健康分析 — 回答用户的5个问题"""
import json
import os
from pathlib import Path
from collections import Counter

KT_PATH = Path(r'F:\代码\启迪白泽\data\knowledge_tree.json')

data = json.loads(KT_PATH.read_text(encoding='utf-8'))
nodes = data.get('nodes', [])

# 基本信息
total = len(nodes)
file_size = KT_PATH.stat().st_size
print(f'=== 知识树存储分析 ===')
print(f'文件大小: {file_size:,} 字节 = {file_size/1024/1024:.2f} MB')
print(f'节点总数: {total}')
print(f'平均每节点: {file_size/total:.0f} 字节 = {file_size/total/1024:.1f} KB')

# 嵌入维度分布
emb_dims = Counter()
emb_total_bytes = 0
no_emb = 0
for n in nodes:
    emb = n.get('embedding')
    if emb is None:
        no_emb += 1
    else:
        emb_dims[len(emb)] += 1
        emb_total_bytes += len(json.dumps(emb, ensure_ascii=False))

print(f'\n=== 嵌入向量 ===')
print(f'维度分布: {dict(emb_dims)}')
print(f'无嵌入节点: {no_emb}')
print(f'嵌入总占用: {emb_total_bytes:,} 字节 = {emb_total_bytes/1024/1024:.2f} MB ({emb_total_bytes*100/file_size:.1f}%)')

# 内容字段
content_total = 0
empty_content = 0
for n in nodes:
    c = n.get('content', '')
    if not c:
        empty_content += 1
    content_total += len(c)
print(f'\n=== 内容字段 ===')
print(f'内容总字符: {content_total:,}')
print(f'空内容节点: {empty_content}')
print(f'内容占用约: {content_total*3:,} 字节 (UTF-8中文约3字节/字符) = {content_total*3/1024/1024:.2f} MB')

# 三速池
pools_bytes = 0
for n in nodes:
    for k in ('fast_pool', 'medium_pool', 'slow_pool'):
        v = n.get(k)
        if v:
            pools_bytes += len(json.dumps(v))
print(f'\n=== 三速池 ===')
print(f'三速池总占用: {pools_bytes:,} 字节 = {pools_bytes/1024:.1f} KB')

# 命中/死亡
hits = [n.get('hit_count', 0) for n in nodes]
dying = sum(1 for n in nodes if n.get('is_dying'))
zero_hit = sum(1 for h in hits if h == 0)
print(f'\n=== 健康度 ===')
print(f'死亡节点: {dying}/{total} ({dying*100/total:.1f}%)')
print(f'零命中节点: {zero_hit}/{total} ({zero_hit*100/total:.1f}%)')
print(f'总命中数: {sum(hits)}')
print(f'平均命中: {sum(hits)/total:.1f}')

# 深度分布
depths = Counter(n.get('depth', 0) for n in nodes)
print(f'\n=== 树结构 ===')
print(f'深度分布: {dict(sorted(depths.items()))}')

# 来源分布
sources = Counter(n.get('source', 'unknown') for n in nodes)
print(f'来源分布: {dict(sources)}')

# 增长预测
print(f'\n=== 增长预测 ===')
per_node = file_size / total
for n in [500, 1000, 5000, 10000, 50000]:
    predicted = per_node * n
    print(f'  {n:>6} 节点 → {predicted/1024/1024:>8.1f} MB ({predicted/1024/1024/1024:.2f} GB)')

# 检索复杂度
print(f'\n=== 检索性能预测 (numpy批量余弦, 1024维) ===')
import math
for n in [100, 500, 1000, 5000, 10000, 50000, 100000]:
    # 矩阵构建: n*1024 floats, matmul: n*1024 mul
    ops = n * 1024
    # numpy ~ 1e9 ops/sec
    ms = ops / 1e9 * 1000
    mem_mb = n * 1024 * 8 / 1024 / 1024  # float64
    print(f'  {n:>6} 节点 → {ms:>7.3f} ms/检索, 矩阵内存 {mem_mb:>7.1f} MB')

# SelfEvolve 触发条件
print(f'\n=== SelfEvolve 触发条件 ===')
print('1. 稀疏连接补强: worms>50 AND avg_links<2.0')
print('2. 扩散效率提升: cycle_count>10 AND success_rate<0.3')
print('3. 睡眠周期调整: cycle_count>30 AND dreams<2')
print('4. 概念图膨胀: worms>500 AND 30% unused')
print('注: 触发基于worm数量/成功率/周期, 非存储量')

# 当前蠕虫状态
print(f'\n=== 当前蠕虫大脑状态 (来自日志) ===')
print('worms: 37, links: 48, avg_links: 1.3')
print('触发条件1: worms>50? 否 (37<50)')
print('触发条件2: cycle>10 AND rate<0.3? 需10+轮且成功率<30%')
print('触发条件3: cycle>30 AND dreams<2? 需30+轮')
print('触发条件4: worms>500? 否 (37<500)')
