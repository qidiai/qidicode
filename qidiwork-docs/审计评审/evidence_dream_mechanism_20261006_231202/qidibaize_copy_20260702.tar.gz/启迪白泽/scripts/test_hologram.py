"""测试 HoloGram Engine MCP 接口"""
import subprocess
import json
import time
import sys

ENGINE = r"C:\Program Files\全息观测站\_up_\engine\target\release\hologram-engine.exe"

proc = subprocess.Popen(
    [ENGINE, "serve"],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    encoding='utf-8', bufsize=1, universal_newlines=True,
)

def call(method, params=None, id=1):
    req = {"jsonrpc": "2.0", "id": id, "method": method, "params": params or {}}
    proc.stdin.write(json.dumps(req) + "\n")
    proc.stdin.flush()
    line = proc.stdout.readline()
    return json.loads(line) if line else None

def tool(name, args=None, id=1):
    return call("tools/call", {"name": name, "arguments": args or {}}, id)

# 1. 初始化
r = call("initialize", {
    "protocolVersion": "2024-11-05",
    "capabilities": {},
    "clientInfo": {"name": "baize-test", "version": "1.0"},
}, 1)
print(f"[1] init: {r.get('result', {}).get('serverInfo', {})}")

# 2. 分析项目
PROJECT = r"F:\代码\启迪白泽"
r = tool("hologram_analyze", {"path": PROJECT}, 2)
print(f"[2] analyze: {r.get('result', {}).get('content', [{}])[0].get('text', '')[:200]}")

# 3. 轮询状态
for i in range(15):
    time.sleep(2)
    r = tool("hologram_status", {}, 3 + i)
    text = r.get('result', {}).get('content', [{}])[0].get('text', '')
    print(f"[3.{i}] status: {text[:200]}")
    if 'ready' in text or '"phase":"ready"' in text:
        break

# 4. 图概览
r = tool("hologram_graph_summary", {}, 100)
text = r.get('result', {}).get('content', [{}])[0].get('text', '')
print(f"\n[4] graph_summary:\n{text[:1000]}")

# 5. 搜索节点
r = tool("hologram_search", {"query": "BaizeSystem", "limit": 5}, 101)
text = r.get('result', {}).get('content', [{}])[0].get('text', '')
print(f"\n[5] search 'BaizeSystem':\n{text[:800]}")

# 6. 脆弱模块
r = tool("hologram_fragile", {"limit": 3}, 102)
text = r.get('result', {}).get('content', [{}])[0].get('text', '')
print(f"\n[6] fragile modules:\n{text[:800]}")

# 7. 盲点
r = tool("hologram_blindspots", {"filter": "all"}, 103)
text = r.get('result', {}).get('content', [{}])[0].get('text', '')
print(f"\n[7] blindspots:\n{text[:800]}")

proc.stdin.close()
proc.terminate()
print("\n[done]")
