# migrate_assets.py — 把6套旧资产复制到启迪白泽新结构
# 规则：只复制不剪切，旧目录保留不动
# 用法：python scripts/migrate_assets.py

import shutil, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # 启迪白泽/
SRC_MAP = {
    # (源文件绝对路径, 目标相对路径)
    # === 闲置算力系统 ===
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\worm_brain.py", "src/brain/worm_brain.py"),
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\worm_swarm.py", "src/brain/worm_swarm.py"),
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\knowledge_tree.py", "src/memory/knowledge_tree.py"),
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\web_learner.py", "src/perception/web_learner.py"),
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\self_evolve.py", "src/growth/self_evolve.py"),
    (r"F:\代码\导入数据\闲置算力系统\worm_knowledge_engine\v10_embed.py", "src/models/baize_embed.py"),
    (r"F:\代码\导入数据\闲置算力系统\meta_integration\source_pool.py", "src/agents/source_pool.py"),
    (r"F:\代码\导入数据\闲置算力系统\meta_integration\dynamic_role.py", "src/agents/dynamic_role.py"),
    (r"F:\代码\导入数据\闲置算力系统\meta_integration\magnetic_monitor.py", "src/control/magnetic_monitor.py"),
    (r"F:\代码\导入数据\闲置算力系统\meta_integration\reduction_knowledge_tree.py", "src/memory/reduction_knowledge.py"),
    (r"F:\代码\导入数据\闲置算力系统\data\knowledge_tree.json", "data/knowledge_tree.json"),
    # === 白泽档案 ===
    (r"F:\代码\白泽档案\v22_shared_field_gen\v22_arch.py", "src/models/v22_arch.py"),
    (r"F:\代码\白泽档案\CascadePool\cascade_pool.py", "src/models/cascade_pool.py"),
    (r"F:\代码\白泽档案\03-训练数据\handcraft_shortage_500.jsonl", "data/training/shortage_296.jsonl"),
    # === agent项目（记忆系统） ===
    (r"F:\代码\导入数据\agent\src\memory\system.py", "src/memory/memory_system.py"),
    (r"F:\代码\导入数据\agent\src\growth\executor.py", "src/growth/code_analyzer.py"),
    (r"F:\代码\导入数据\agent\src\evolution\engine.py", "src/evolution/evolution_engine.py"),
    (r"F:\代码\导入数据\agent\src\skills\manager.py", "src/skills/skill_registry.py"),
}

WEIGHT_LINKS = [
    # (源目录, 目标目录) — Windows不支持跨盘软链接，改用路径记录
    (r"F:\代码\白泽档案\02-模型权重\V10\原版", "data/models/v10_embed"),
]

def main():
    ok, fail, skip = 0, 0, 0
    for src, dst_rel in SRC_MAP:
        src_p = Path(src)
        dst_p = ROOT / dst_rel
        if not src_p.exists():
            print(f"  ⚠ 跳过(源不存在): {src}")
            skip += 1; continue
        dst_p.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(src_p, dst_p)
            print(f"  ✅ {Path(dst_rel).name}")
            ok += 1
        except Exception as e:
            print(f"  ❌ {dst_rel}: {e}")
            fail += 1
    # 权重路径记录（Windows不支持跨盘软链接）
    print("\n--- 模型权重 ---")
    for src, dst_rel in WEIGHT_LINKS:
        dst_p = ROOT / dst_rel
        dst_p.mkdir(parents=True, exist_ok=True)
        record = dst_p / "weights_path.txt"
        record.write_text(
            f"权重原位: {src}\n文件: best_model.pt, embedding_model.json\n"
            f"加载方式: baize_embed.py 从此路径读取，不复制避免占盘",
            encoding="utf-8")
        print(f"  📝 路径记录: {dst_rel}/weights_path.txt → {src}")
    # __init__.py
    for d in (ROOT/"src").rglob("*"):
        if d.is_dir() and not (d/"__init__.py").exists() and d != ROOT/"src":
            (d/"__init__.py").write_text("", encoding="utf-8")
    print(f"\n{'='*40}\n完成: ✅{ok} ❌{fail} ⚠{skip}")
    print(f"新项目根: {ROOT}")

if __name__ == "__main__":
    main()
