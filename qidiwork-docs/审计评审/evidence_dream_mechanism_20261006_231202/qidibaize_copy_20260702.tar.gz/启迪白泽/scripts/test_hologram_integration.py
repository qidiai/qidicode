"""端到端测试: HoloGram Bridge 集成"""
import sys
sys.path.insert(0, 'src')

from bridge.hologram_bridge import HologramBridge

print('=' * 60)
print('HoloGram Bridge 端到端测试')
print('=' * 60)

# 1. 连接
print('\n[1] 连接 HoloGram 引擎...')
bridge = HologramBridge()
ok = bridge.connect()
print(f'  连接结果: {ok}')
print(f'  状态: {bridge.get_status_report()}')

if not ok:
    print('连接失败，终止测试')
    sys.exit(1)

# 2. 分析项目
print('\n[2] 分析启迪白泽项目...')
import time
t0 = time.time()
result = bridge.analyze_project(r'F:\代码\启迪白泽', wait=True)
t1 = time.time()
print(f'  耗时: {t1-t0:.1f}s')
print(f'  结果: {result}')

# 3. 图概览
print('\n[3] 获取图概览...')
summary = bridge.graph_summary()
if summary:
    print(f'  节点数: {summary.get("nodes_total", 0)}')
    print(f'  边数: {summary.get("edges_total", 0)}')
    print(f'  边类型: {summary.get("edge_types", {})}')

# 4. 搜索 BaizeSystem
print('\n[4] 搜索 BaizeSystem...')
results = bridge.search('BaizeSystem', limit=3)
if results:
    print(f'  找到 {results.get("count", 0)} 个结果')
    for r in results.get('results', [])[:2]:
        print(f'  - {r.get("name")} ({r.get("kind")}) @ {r.get("location")}')

# 5. 脆弱模块
print('\n[5] 脆弱模块 TOP3...')
fragile = bridge.fragile_modules(limit=3)
if fragile:
    for m in fragile.get('fragile_modules', []):
        print(f'  - {m.get("node_id", "?")[:60]}: {m.get("fragility_score")}分')

# 6. 盲点检测
print('\n[6] 盲点检测...')
blindspots = bridge.blindspots()
if blindspots:
    print(f'  检测到 {blindspots.get("count", 0)} 类盲点')
    for b in blindspots.get('boundaries', []):
        print(f'  - [{b.get("severity")}] {b.get("type")}: {b.get("desc", "")[:60]}')

# 7. 代码探索（自然语言查询）
print('\n[7] 自然语言查询 "perceive 方法在哪里"...')
explore = bridge.explore(query='perceive')
if explore:
    text = str(explore)[:500]
    print(f'  结果(前500字符): {text}')

# 8. 断开
print('\n[8] 断开连接...')
bridge.disconnect()
print(f'  状态: {bridge.get_status_report()}')

print('\n' + '=' * 60)
print('所有测试通过!')
print('=' * 60)
