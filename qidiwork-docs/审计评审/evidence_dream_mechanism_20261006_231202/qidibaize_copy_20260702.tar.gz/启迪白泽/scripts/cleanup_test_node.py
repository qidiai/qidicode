"""删除残留的 test 节点 + 修复 depth=0 孤岛节点（重新分类到合适父节点）"""
import json
import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

KT_PATH = Path(r'F:\代码\启迪白泽\data\knowledge_tree.json')

# 加载
data = json.loads(KT_PATH.read_text(encoding='utf-8'))
nodes = data.get('nodes', [])

# 删除 test 节点
before = len(nodes)
nodes = [n for n in nodes if n.get('source', '') != 'test' and n.get('topic', '').lower() not in {'test', '测试'}]
print(f'[test节点] 删除 {before - len(nodes)} 个')

# 统计 depth=0 的非 root 节点（孤岛）
orphans = [n for n in nodes if n.get('depth', 0) == 0 and n['id'] != 'root']
print(f'[孤岛] depth=0 非root节点: {len(orphans)} 个')
for o in orphans:
    print(f'  - {o["topic"][:40]} (source={o.get("source","")}, hits={o.get("hit_count",0)})')

# 把孤岛挂到 root 下，depth=1
for o in orphans:
    o['depth'] = 1
    if o.get('parent_id') is None or o.get('parent_id') == '':
        o['parent_id'] = 'root'

# 确保 root 的 children_ids 包含所有 depth=1 节点
root = next((n for n in nodes if n['id'] == 'root'), None)
if root:
    depth1_ids = [n['id'] for n in nodes if n.get('depth') == 1 and n['id'] != 'root']
    root['children_ids'] = depth1_ids

# 保存
data['nodes'] = nodes
data['metadata'] = {
    'totalNodes': len(nodes),
    'totalHits': sum(n.get('hit_count', 0) for n in nodes),
}
KT_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

new_size = KT_PATH.stat().st_size
print(f'\n[结果] {len(nodes)} 节点, {new_size/1024:.1f} KB')

from collections import Counter
depths = Counter(n.get('depth', 0) for n in nodes)
sources = Counter(n.get('source', 'unknown') for n in nodes)
print(f'[深度] {dict(sorted(depths.items()))}')
print(f'[来源] {dict(sources)}')
