import ast
import os

ok = 0
fail = 0

for root, _, files in os.walk('src'):
    for f in files:
        if not f.endswith('.py'):
            continue
        
        filepath = os.path.join(root, f)
        try:
            content = open(filepath, 'r', encoding='utf-8').read()
            ast.parse(content)
            ok += 1
        except SyntaxError as e:
            print(f'FAIL: {filepath} - {e}')
            fail += 1
        except Exception as e:
            print(f'ERROR: {filepath} - {e}')
            fail += 1

print(f'\n语法检查完成: OK={ok} FAIL={fail}')
