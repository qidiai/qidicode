"""
4重进化架构 — 端到端集成验证

验证所有 4 个进化层次是否正确打通:
  Phase 1: 数据库进化 — SQLite 持久化
  Phase 2: 记忆系统进化 — 持久化 + 遗忘 + 晋升
  Phase 3: AI Skill 进化 — 共现 + 涌现 + 能力树
  Phase 4: 代码自生长 — Teacher + MODULE_MAP + EvolutionEngine
"""
import sys
import os
import time
import json
import tempfile

# 设置路径
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJECT_ROOT, 'src'))

passed = 0
failed = 0


def test(name, condition, detail=''):
    global passed, failed
    if condition:
        print(f'  ✅ {name}')
        passed += 1
    else:
        print(f'  ❌ {name} {detail}')
        failed += 1


def test_phase1_database():
    """Phase 1: 数据库进化 — SQLite 持久化"""
    print('\n=== Phase 1: 数据库进化 ===')

    from storage.sqlite_backend import SQLiteBackend
    from memory.knowledge_tree import KnowledgeTree
    from memory.memory_system import MemorySystem, MemoryLevel
    from memory.reduction_knowledge import ReductionKnowledgeTree

    # 使用临时数据库
    db_path = os.path.join(PROJECT_ROOT, 'data', 'baize_test_4phase.db')
    if os.path.exists(db_path):
        os.remove(db_path)

    backend = SQLiteBackend(db_path)
    test('SQLiteBackend 初始化', backend is not None)
    test('SQLiteBackend count=0', backend.count('knowledge_nodes') == 0)

    # 知识树持久化
    kt_path = os.path.join(PROJECT_ROOT, 'data', 'knowledge_tree.json')
    kt = KnowledgeTree(str(kt_path), storage_backend=backend)
    node_count = len(kt.nodes)
    test(f'KnowledgeTree 加载 {node_count} 节点', node_count > 0)

    # 重新加载 — 验证持久化
    backend2 = SQLiteBackend(db_path)
    kt2 = KnowledgeTree(str(kt_path), storage_backend=backend2)
    test('KnowledgeTree 持久化验证', len(kt2.nodes) == node_count,
         f'expected {node_count}, got {len(kt2.nodes)}')

    # 记忆系统持久化
    ms = MemorySystem(storage_backend=backend)
    ms.store('test_key', 'test_content', MemoryLevel.L1_WORKING)
    test('MemorySystem 存储记忆', 'test_key' in ms.storage)

    # 重新加载
    ms2 = MemorySystem(storage_backend=backend2)
    entry = ms2.retrieve('test_key')
    test('MemorySystem 持久化验证', entry is not None, '重启后记忆丢失')

    # 记忆维护
    result = ms.run_maintenance()
    test('MemorySystem run_maintenance', 'maintenance' in result)

    # 归约知识树持久化
    rkt = ReductionKnowledgeTree(
        data_dir=os.path.join(PROJECT_ROOT, 'data'),
        storage_backend=backend
    )
    rkt.save()
    # 重新加载
    rkt2 = ReductionKnowledgeTree(
        data_dir=os.path.join(PROJECT_ROOT, 'data'),
        storage_backend=backend2
    )
    test('ReductionKnowledgeTree 持久化验证', len(rkt2.nodes) == len(rkt.nodes))

    # 清理
    backend.close()
    backend2.close()
    for suffix in ['', '-wal', '-shm']:
        p = db_path + suffix
        if os.path.exists(p):
            os.remove(p)

    return True


def test_phase2_memory_evolution():
    """Phase 2: 记忆系统进化 — 遗忘 + 晋升"""
    print('\n=== Phase 2: 记忆系统进化 ===')

    from storage.sqlite_backend import SQLiteBackend
    from memory.memory_system import MemorySystem, MemoryLevel

    db_path = os.path.join(PROJECT_ROOT, 'data', 'baize_test_phase2.db')
    if os.path.exists(db_path):
        os.remove(db_path)

    backend = SQLiteBackend(db_path)
    ms = MemorySystem(storage_backend=backend)

    # 测试自动晋升
    entry = ms.store('promote_test', 'content', MemoryLevel.L1_WORKING)
    # 模拟高频访问
    for _ in range(15):
        entry.record_access(success=True)
    test('记忆访问计数', entry.access_count >= 15)

    # 手动晋升测试
    promoted = ms.promote_to_higher_level('promote_test', MemoryLevel.L2_EXPERIENCE)
    test('记忆手动晋升', promoted)

    # 测试遗忘策略 — 存入低置信记忆
    ms.store('low_conf', 'will_forget', MemoryLevel.L1_WORKING)
    # 不访问，confidence 会很低
    forgotten = ms.cleanup_expired()
    test('遗忘策略执行', isinstance(forgotten, int))

    # 测试 run_maintenance
    result = ms.run_maintenance()
    test('run_maintenance 返回统计', 'total_entries' in result and 'maintenance' in result)
    test('maintenance 含 cleaned', 'cleaned' in result['maintenance'])
    test('maintenance 含 promoted', 'promoted' in result['maintenance'])

    backend.close()
    for suffix in ['', '-wal', '-shm']:
        p = db_path + suffix
        if os.path.exists(p):
            os.remove(p)

    return True


def test_phase3_skill_evolution():
    """Phase 3: AI Skill 进化 — 共现 + 涌现 + 能力树"""
    print('\n=== Phase 3: AI Skill 进化 ===')

    from skills.cooccurrence import CooccurrenceAnalyzer
    from skills.skill_registry import SkillRegistry, Skill, SkillCombiner, SkillEvolutionMonitor
    from evolution.emergence_meter import EmergenceMeter
    from evolution.capability_tree import CapabilityTree

    # 共现分析
    ca = CooccurrenceAnalyzer(window_size=60)
    for _ in range(10):
        ca.record_call('skill_a')
        ca.record_call('skill_b')
    cooc = ca.get_cooccurrence('skill_a', 'skill_b')
    test('CooccurrenceAnalyzer 真共现 > 0', cooc > 0, f'got {cooc}')

    # Skill 注册 + 调用记录
    sr = SkillRegistry(cooccurrence_analyzer=ca)
    skill_a = Skill(id='skill_a', name='A', description='test', category='cat', implementation=lambda: None)
    skill_b = Skill(id='skill_b', name='B', description='test', category='cat', implementation=lambda: None)
    sr.register(skill_a)
    sr.register(skill_b)
    test('SkillRegistry 注册', len(sr.list_all()) == 2)

    # 记录调用（触发共现分析）
    for _ in range(5):
        sr.record_call('skill_a', success=True, duration_ms=10.0)
        sr.record_call('skill_b', success=True, duration_ms=20.0)
    test('Skill 调用计数', sr.get('skill_a').usage_count >= 5)

    # SkillCombiner 使用真共现
    combiner = SkillCombiner(cooccurrence_analyzer=ca)
    test('SkillCombiner 持有 analyzer', combiner.analyzer is not None)

    # 涌现测量
    em = EmergenceMeter(qidi_bridge=None)  # 无 bridge，降级本地
    signals = {
        'fast': [0.5, 0.6, 0.55, 0.58],
        'global': [0.3, 0.4, 0.35, 0.38],
        'meta': [0.7, 0.72, 0.71, 0.73],
    }
    result = em.measure(signals)
    test('EmergenceMeter 测量 F', 'F' in result and isinstance(result['F'], float))
    test('EmergenceMeter 测量 G', 'G' in result and isinstance(result['G'], float))
    test('EmergenceMeter 测量 M', 'M' in result and isinstance(result['M'], float))
    test('EmergenceMeter 降级模式', result['F'] > 0 or result['G'] > 0 or result['M'] > 0)

    # 能力树
    ct = CapabilityTree(qidi_bridge=None)
    level = ct.assess('skill_a', {
        'success_rate': 0.9,
        'usage_count': 200,
        'complexity_handled': 0.8,
        'collaboration_count': 20,
    })
    test('CapabilityTree 评估层级 1-10', 1 <= level <= 10, f'got L{level}')
    test('CapabilityTree 高性能 → 高层级', level >= 7, f'got L{level}')

    return True


def test_phase4_code_growth():
    """Phase 4: 代码自生长 — Teacher + MODULE_MAP + EvolutionEngine"""
    print('\n=== Phase 4: 代码自生长 ===')

    from growth.qidi_teacher_adapter import QidiTeacherAdapter
    from evolution.evolution_engine import EvolutionEngine, RiskLevel

    # Teacher 适配器（无 bridge，降级）
    teacher = QidiTeacherAdapter(qidi_bridge=None)
    test('QidiTeacherAdapter 创建', teacher is not None)
    test('QidiTeacherAdapter.backend=self', teacher.backend is teacher)
    response = teacher.chat([{'role': 'user', 'content': 'test'}])
    test('QidiTeacherAdapter 降级返回空', response == '')

    # SelfEvolve MODULE_MAP 验证
    from growth.self_evolve import SelfEvolve
    test('MODULE_MAP 包含启迪白泽文件', 'memory/knowledge_tree.py' in SelfEvolve.MODULE_MAP)
    test('MODULE_MAP 不含旧文件', 'worm_swarm.py' not in SelfEvolve.MODULE_MAP)
    test('MODULE_MAP 含 8 个模块', len(SelfEvolve.MODULE_MAP) == 8,
         f'got {len(SelfEvolve.MODULE_MAP)}')

    # 验证 MODULE_MAP 中的文件实际存在
    src_dir = os.path.join(PROJECT_ROOT, 'src')
    existing = 0
    for filename in SelfEvolve.MODULE_MAP:
        filepath = os.path.join(src_dir, filename)
        if os.path.exists(filepath):
            existing += 1
    test(f'MODULE_MAP 文件存在性 {existing}/8', existing >= 6,
         f'only {existing} files exist')

    # OPTIMIZATION_RULES 验证
    test('OPTIMIZATION_RULES 含记忆规则',
         any(r['name'] == '记忆膨胀检测' for r in SelfEvolve.OPTIMIZATION_RULES))
    test('OPTIMIZATION_RULES 含 Skill 规则',
         any(r['name'] == 'Skill成功率低' for r in SelfEvolve.OPTIMIZATION_RULES))
    test('OPTIMIZATION_RULES 含共现规则',
         any(r['name'] == '高共现未组合' for r in SelfEvolve.OPTIMIZATION_RULES))

    # EvolutionEngine
    from evolution.emergence_meter import EmergenceMeter
    em = EmergenceMeter(qidi_bridge=None)
    engine = EvolutionEngine(emergence_meter=em)
    test('EvolutionEngine 持有 emergence_meter', engine.emergence_meter is not None)

    # 分析测试
    metrics = {
        'tool_stats': {'call_count': 150},
        'code_metrics': {'line_count': 120, 'duplicate_lines': 25},
        'skill_usage': {'cooccurrence': 0.85},
    }
    suggestions = engine.analyze(metrics)
    test('EvolutionEngine 生成建议', len(suggestions) > 0, f'got {len(suggestions)}')

    # _rollback 验证（不实际回滚，验证方法存在且可调用）
    test('EvolutionEngine _rollback 可调用', hasattr(engine, '_rollback'))

    return True


def test_main_integration():
    """验证 main.py 接线完整性"""
    print('\n=== main.py 接线验证 ===')

    # 读取 main.py 检查关键 import 和初始化
    main_path = os.path.join(PROJECT_ROOT, 'src', 'main.py')
    with open(main_path, 'r', encoding='utf-8') as f:
        content = f.read()

    test('main.py import SQLiteBackend', 'from storage.sqlite_backend import SQLiteBackend' in content)
    test('main.py 初始化 self.storage', 'self.storage = SQLiteBackend' in content)
    test('main.py MemorySystem 传 backend', 'MemorySystem(storage_backend=self.storage)' in content)
    test('main.py KnowledgeTree 传 backend', 'storage_backend=self.storage' in content)
    test('main.py 初始化 EmbeddingsStore', 'EmbeddingsStore(storage_backend=self.storage)' in content)
    test('main.py import CooccurrenceAnalyzer', 'from skills.cooccurrence import CooccurrenceAnalyzer' in content)
    test('main.py import CapabilityRegistry', 'from capability.registry import CapabilityRegistry' in content)
    test('main.py import EmergenceMeter', 'from evolution.emergence_meter import EmergenceMeter' in content)
    test('main.py import CapabilityTree', 'from evolution.capability_tree import CapabilityTree' in content)
    test('main.py import QidiTeacherAdapter', 'from growth.qidi_teacher_adapter import QidiTeacherAdapter' in content)
    test('main.py 注入 Teacher', 'self.self_evolve.teacher = self.teacher' in content)
    test('main.py 注入 EmergenceMeter', 'self.evolution.emergence_meter = self.emergence_meter' in content)
    test('main.py 周期维护', 'run_maintenance' in content)

    return True


def main():
    print('=' * 60)
    print('  4重进化架构 — 端到端集成验证')
    print('=' * 60)

    try:
        test_phase1_database()
    except Exception as e:
        print(f'  ❌ Phase 1 异常: {e}')
        import traceback
        traceback.print_exc()

    try:
        test_phase2_memory_evolution()
    except Exception as e:
        print(f'  ❌ Phase 2 异常: {e}')
        import traceback
        traceback.print_exc()

    try:
        test_phase3_skill_evolution()
    except Exception as e:
        print(f'  ❌ Phase 3 异常: {e}')
        import traceback
        traceback.print_exc()

    try:
        test_phase4_code_growth()
    except Exception as e:
        print(f'  ❌ Phase 4 异常: {e}')
        import traceback
        traceback.print_exc()

    try:
        test_main_integration()
    except Exception as e:
        print(f'  ❌ main.py 验证异常: {e}')
        import traceback
        traceback.print_exc()

    print('\n' + '=' * 60)
    total = passed + failed
    print(f'  结果: {passed}/{total} 通过, {failed} 失败')
    if failed == 0:
        print('  🎉 4重进化架构全部验证通过！')
    else:
        print(f'  ⚠️  {failed} 项未通过')
    print('=' * 60)

    return 0 if failed == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
