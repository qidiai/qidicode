"""清理迁移来源的垃圾节点（小说片段/施工数据/游戏文本）"""
import json
from pathlib import Path
from collections import Counter

KT_PATH = Path(r'F:\代码\启迪白泽\data\knowledge_tree.json')
data = json.loads(KT_PATH.read_text(encoding='utf-8'))
nodes = data.get('nodes', [])

# 删除所有"迁移"来源节点（全是小说/施工/游戏垃圾）
to_delete = {n['id'] for n in nodes if n.get('source') == '迁移' and n['id'] != 'root'}
print(f'[迁移垃圾] 删除 {len(to_delete)} 个')

surviving = [n for n in nodes if n['id'] not in to_delete]
surviving_ids = {n['id'] for n in surviving}
for n in surviving:
    n['children_ids'] = [c for c in n.get('children_ids', []) if c in surviving_ids]
    if n.get('parent_id') and n['parent_id'] not in surviving_ids:
        n['parent_id'] = 'root'

# 重新计算 depth
def recompute_depth(nodes_list):
    by_id = {n['id']: n for n in nodes_list}
    for n in nodes_list:
        depth = 0
        cur = n
        visited = set()
        while cur.get('parent_id') and cur['parent_id'] in by_id and cur['parent_id'] not in visited:
            visited.add(cur['id'])
            depth += 1
            cur = by_id[cur['parent_id']]
            if depth > 10:
                break
        n['depth'] = depth

recompute_depth(surviving)

data['nodes'] = surviving
data['metadata'] = {
    'totalNodes': len(surviving),
    'totalHits': sum(n.get('hit_count', 0) for n in surviving),
}
KT_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

new_size = KT_PATH.stat().st_size
print(f'\n[最终结果] {len(surviving)} 节点, {new_size/1024:.1f} KB')
print(f'[深度] {dict(sorted(Counter(n.get("depth",0) for n in surviving).items()))}')
print(f'[来源] {dict(Counter(n.get("source","") for n in surviving))}')

print(f'\n[保留的精华节点]')
for n in surviving:
    if n['id'] != 'root':
        topic = (n.get('topic') or '')[:60]
        print(f'  d{n.get("depth",0)} h{n.get("hit_count",0):>3} [{n.get("source",""):<7}] {topic}')
