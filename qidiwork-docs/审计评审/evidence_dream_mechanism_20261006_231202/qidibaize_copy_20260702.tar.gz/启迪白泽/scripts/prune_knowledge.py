"""清理知识树垃圾节点"""
import sys
sys.path.insert(0, 'src')

from memory.knowledge_tree import KnowledgeTree

# 加载知识树
kt = KnowledgeTree('data/knowledge_tree.json')

# 获取清理前统计
stats_before = kt.get_stats()
print(f'清理前: {stats_before}')

# 执行清理
deleted = kt.prune_junk(max_junk=100)
print(f'已删除 {len(deleted)} 个垃圾节点')
print(f'删除的节点ID: {deleted}')

# 强制保存
kt.save(force=True)

# 获取清理后统计
stats_after = kt.get_stats()
print(f'清理后: {stats_after}')
print(f'\n节点数变化: {stats_before["total_nodes"]} → {stats_after["total_nodes"]}')
print(f'Dying节点变化: {stats_before["dying_nodes"]} → {stats_after["dying_nodes"]}')
