"""
Capability 统一层 + MCP 进化 — 端到端验证

验证内容:
  1. Capability 基类统计逻辑
  2. CapabilityRegistry.invoke 自动记录
  3. BridgeCapabilityAdapter 包装
  4. MCPCapability + StdioMCPTransport（mock）
  5. MCPDiscovery 配置加载
  6. 进化机制复用（共现 + 能力树）
  7. 回归：4phase 测试仍通过
"""
import sys
import os
import json
import time

# 设置路径
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(PROJECT_ROOT, 'src'))

passed = 0
failed = 0


def test(name, condition, detail=''):
    global passed, failed
    if condition:
        print(f'  ✅ {name}')
        passed += 1
    else:
        print(f'  ❌ {name} {detail}')
        failed += 1


# ============ Mock 类 ============

class MockTransport:
    """Mock MCP Transport"""
    def __init__(self, tools_response=None, call_response=None):
        self.tools_response = tools_response or []
        self.call_response = call_response or {'result': 'ok'}
        self.connected = True
        self.call_count = 0

    def connect(self):
        return True

    def call_tool(self, name, args=None):
        self.call_count += 1
        return self.call_response

    def list_tools(self):
        return self.tools_response

    def is_connected(self):
        return self.connected

    def disconnect(self):
        self.connected = False


class MockBridge:
    """Mock Bridge"""
    def __init__(self):
        self.connected = True
        self.call_count = 0

    def preflight(self, files):
        self.call_count += 1
        return {'safe': True, 'files': files}

    def impact(self, node_id, depth=3):
        self.call_count += 1
        return {'impacts': [], 'node_id': node_id}

    def is_connected(self):
        return self.connected


# ============ 测试函数 ============

def test_capability_base():
    """测试 Capability 基类"""
    print('\n=== 1. Capability 基类 ===')
    from capability.base import Capability

    class TestCap(Capability):
        def invoke(self, args, context=None):
            return args

    cap = TestCap(id='test', name='测试', category='test', tags=['t'])
    cap.record_call(True, 100)
    cap.record_call(False, 200)

    test('Capability 创建', cap.id == 'test')
    test('Capability 统计 usage_count', cap.usage_count == 2)
    test('Capability 统计 success_count', cap.success_count == 1)
    test('Capability success_rate', abs(cap.success_rate - 0.5) < 0.01)
    test('Capability avg_response_time', abs(cap.avg_response_time - 150) < 1)
    test('Capability invoke', cap.invoke({'a': 1}) == {'a': 1})
    test('Capability last_used 更新', cap.last_used > 0)


def test_mcp_capability():
    """测试 MCPCapability"""
    print('\n=== 2. MCPCapability ===')
    from capability.mcp_capability import MCPCapability

    transport = MockTransport(call_response={'status': 'ok'})
    cap = MCPCapability(
        id='mcp.test.tool',
        name='Test Tool',
        tool_name='test_tool',
        transport=transport,
        category='test',
        tags=['mock']
    )

    result = cap.invoke({'param': 'value'})
    test('MCPCapability invoke 返回结果', result == {'status': 'ok'})
    test('MCPCapability transport 被调用', transport.call_count == 1)
    test('MCPCapability 统计 usage_count', cap.usage_count == 1)
    test('MCPCapability 统计 success_count', cap.success_count == 1)
    test('MCPCapability tool_name', cap.tool_name == 'test_tool')


def test_bridge_adapter():
    """测试 BridgeCapabilityAdapter"""
    print('\n=== 3. BridgeCapabilityAdapter ===')
    from capability.bridge_adapter import BridgeCapabilityAdapter

    bridge = MockBridge()
    adapter = BridgeCapabilityAdapter(
        id='bridge.mock.preflight',
        name='Mock Preflight',
        bridge=bridge,
        method_name='preflight',
        category='code_graph',
        tags=['mock']
    )

    result = adapter.invoke({'files': ['a.py', 'b.py']})
    test('BridgeAdapter invoke 返回结果', result == {'safe': True, 'files': ['a.py', 'b.py']})
    test('BridgeAdapter bridge 被调用', bridge.call_count == 1)
    test('BridgeAdapter 统计 usage_count', adapter.usage_count == 1)
    test('BridgeAdapter 统计 success_count', adapter.success_count == 1)

    # 测试 impact 方法（不同参数）
    adapter2 = BridgeCapabilityAdapter(
        id='bridge.mock.impact', name='Mock Impact',
        bridge=bridge, method_name='impact'
    )
    result2 = adapter2.invoke({'node_id': 'node1', 'depth': 5})
    test('BridgeAdapter 不同方法', result2 == {'impacts': [], 'node_id': 'node1'})


def test_capability_registry():
    """测试 CapabilityRegistry 统一调用 + 进化机制"""
    print('\n=== 4. CapabilityRegistry 统一调用 ===')
    from capability.registry import CapabilityRegistry
    from capability.mcp_capability import MCPCapability
    from capability.bridge_adapter import BridgeCapabilityAdapter
    from skills.cooccurrence import CooccurrenceAnalyzer

    cooc = CooccurrenceAnalyzer(window_size=60)
    registry = CapabilityRegistry(cooccurrence_analyzer=cooc)

    # 注册 MCPCapability
    transport = MockTransport(call_response={'data': 'result'})
    mcp_cap = MCPCapability(
        id='mcp.svc.tool1', name='Tool1',
        tool_name='tool1', transport=transport, category='test'
    )
    registry.register(mcp_cap)

    # 注册 BridgeCapabilityAdapter
    bridge = MockBridge()
    bridge_cap = BridgeCapabilityAdapter(
        id='bridge.mock.preflight', name='Preflight',
        bridge=bridge, method_name='preflight', category='code'
    )
    registry.register(bridge_cap)

    test('CapabilityRegistry 注册 MCPCapability', registry.get('mcp.svc.tool1') is not None)
    test('CapabilityRegistry 注册 BridgeCapabilityAdapter', registry.get('bridge.mock.preflight') is not None)
    test('CapabilityRegistry list_all 数量', len(registry.list_all()) == 2)

    # 统一调用
    result1 = registry.invoke('mcp.svc.tool1', {'arg': 1})
    test('CapabilityRegistry invoke MCP', result1 == {'data': 'result'})
    test('CapabilityRegistry invoke 后统计', registry.get('mcp.svc.tool1').usage_count == 1)

    result2 = registry.invoke('bridge.mock.preflight', {'files': ['x.py']})
    test('CapabilityRegistry invoke Bridge', result2 == {'safe': True, 'files': ['x.py']})

    # 共现分析验证
    cooc_stats = cooc.get_stats()
    test('CapabilityRegistry 共现分析记录', cooc_stats['total_calls'] >= 2)


def test_mcp_transport():
    """测试 StdioMCPTransport（不实际连接，验证类结构）"""
    print('\n=== 5. StdioMCPTransport 结构 ===')
    from capability.mcp_transport import StdioMCPTransport

    transport = StdioMCPTransport(
        command='fake.exe',
        args=['serve'],
        protocol='mcp'
    )
    test('StdioMCPTransport 创建', transport is not None)
    test('StdioMCPTransport protocol', transport.protocol == 'mcp')
    test('StdioMCPTransport command', transport.command == 'fake.exe')
    test('StdioMCPTransport 未连接', not transport.is_connected())

    # 测试 list_tools 在未连接时返回空
    tools = transport.list_tools()
    test('StdioMCPTransport list_tools 未连接返回空', tools == [])


def test_mcp_discovery_config():
    """测试 MCPDiscovery 配置加载"""
    print('\n=== 6. MCPDiscovery 配置 ===')
    from capability.mcp_discovery import MCPDiscovery
    from capability.registry import CapabilityRegistry

    registry = CapabilityRegistry()
    discovery = MCPDiscovery(registry)

    # 测试默认配置路径
    config_path = discovery.config_path
    test('MCPDiscovery 配置路径存在', os.path.exists(config_path), f'path: {config_path}')

    # 测试配置加载
    config = discovery._load_config()
    test('MCPDiscovery 配置加载', config is not None)
    if config:
        services = config.get('services', [])
        test('MCPDiscovery 服务数量', len(services) >= 1)
        # 验证 hologram 服务配置
        hologram = next((s for s in services if s['id'] == 'hologram'), None)
        test('MCPDiscovery hologram 配置', hologram is not None)
        if hologram:
            test('MCPDiscovery hologram protocol=mcp', hologram.get('protocol') == 'mcp')
            test('MCPDiscovery hologram auto_discover', hologram.get('auto_discover') == True)


def test_evolution_mechanism_reuse():
    """测试进化机制对 MCP 的复用"""
    print('\n=== 7. 进化机制复用 ===')
    from capability.registry import CapabilityRegistry
    from capability.mcp_capability import MCPCapability
    from skills.cooccurrence import CooccurrenceAnalyzer
    from evolution.capability_tree import CapabilityTree

    # 模拟高频共现调用
    cooc = CooccurrenceAnalyzer(window_size=60)
    registry = CapabilityRegistry(cooccurrence_analyzer=cooc)

    transport = MockTransport(call_response={'ok': True})
    cap_a = MCPCapability(id='mcp.svc.a', name='A', tool_name='a', transport=transport, category='test')
    cap_b = MCPCapability(id='mcp.svc.b', name='B', tool_name='b', transport=transport, category='test')
    registry.register(cap_a)
    registry.register(cap_b)

    # 连续调用两个工具（触发共现）
    for _ in range(10):
        registry.invoke('mcp.svc.a', {})
        registry.invoke('mcp.svc.b', {})

    # 验证共现分析
    cooc_val = cooc.get_cooccurrence('mcp.svc.a', 'mcp.svc.b')
    test('共现分析 MCP 工具对', cooc_val > 0, f'got {cooc_val}')

    # 验证能力树评估（MCP 工具也能被评估）
    ct = CapabilityTree(qidi_bridge=None)
    level = ct.assess('mcp.svc.a', {
        'success_rate': 0.9,
        'usage_count': 10,
        'complexity_handled': 0.8,
        'collaboration_count': 10,
    })
    test('能力树评估 MCP 工具', 1 <= level <= 10, f'got L{level}')


def test_skill_compatibility():
    """测试 Skill 与 CapabilityRegistry 兼容性"""
    print('\n=== 8. Skill 兼容性 ===')
    from capability.registry import CapabilityRegistry
    from skills.skill_registry import Skill

    registry = CapabilityRegistry()

    # Skill 是 dataclass，与 Capability 鸭子类型兼容
    skill = Skill(
        id='skill.test',
        name='Test Skill',
        description='测试技能',
        category='test',
        implementation=lambda args: args,
    )
    registry.register(skill)

    test('Skill 注册到 CapabilityRegistry', registry.get('skill.test') is not None)
    test('Skill 在 list_all 中', any(s.id == 'skill.test' for s in registry.list_all()))

    # Skill 有 Capability 所需的所有属性
    test('Skill 有 usage_count', hasattr(skill, 'usage_count'))
    test('Skill 有 success_rate', hasattr(skill, 'success_rate'))
    test('Skill 有 record_call', hasattr(skill, 'record_call'))
    test('Skill 有 avg_response_time', hasattr(skill, 'avg_response_time'))


def test_main_integration():
    """验证 main.py 接线"""
    print('\n=== 9. main.py 接线验证 ===')
    main_path = os.path.join(PROJECT_ROOT, 'src', 'main.py')
    with open(main_path, 'r', encoding='utf-8') as f:
        content = f.read()

    test('main.py import CapabilityRegistry', 'from capability.registry import CapabilityRegistry' in content)
    test('main.py 创建 capability_registry', 'self.capability_registry = CapabilityRegistry' in content)
    test('main.py skill_registry 别名', 'self.skill_registry = self.capability_registry' in content)
    test('main.py import BridgeCapabilityAdapter', 'from capability.bridge_adapter import BridgeCapabilityAdapter' in content)
    test('main.py import MCPDiscovery', 'from capability.mcp_discovery import MCPDiscovery' in content)
    test('main.py 包装 HologramBridge', 'bridge.hologram.' in content)
    test('main.py 包装 QidiBridge', 'bridge.qidi.' in content)
    test('main.py MCPDiscovery 调用', 'discover_and_register()' in content)
    test('main.py 能力统计', '能力体系' in content)


def main():
    print('=' * 60)
    print('  Capability 统一层 + MCP 进化 — 端到端验证')
    print('=' * 60)

    for test_fn in [
        test_capability_base,
        test_mcp_capability,
        test_bridge_adapter,
        test_capability_registry,
        test_mcp_transport,
        test_mcp_discovery_config,
        test_evolution_mechanism_reuse,
        test_skill_compatibility,
        test_main_integration,
    ]:
        try:
            test_fn()
        except Exception as e:
            print(f'  ❌ {test_fn.__name__} 异常: {e}')
            import traceback
            traceback.print_exc()

    print('\n' + '=' * 60)
    total = passed + failed
    print(f'  结果: {passed}/{total} 通过, {failed} 失败')
    if failed == 0:
        print('  🎉 Capability统一层全部验证通过！')
    else:
        print(f'  ⚠️  {failed} 项未通过')
    print('=' * 60)

    return 0 if failed == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
