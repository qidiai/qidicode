import sys
sys.path.insert(0, r'F:\代码\启迪白泽\src')

from capability.mcp_transport import StdioMCPTransport
import json

print('=== 直接测试 CodeGraph MCP 连接 ===')

transport = StdioMCPTransport(
    command='code-graph-mcp',
    args=[],
    protocol='mcp'
)

if transport.connect():
    print('连接成功')
    
    tools = transport.list_tools()
    print(f'\n发现工具: {len(tools)} 个')
    for t in tools:
        print(f'  - {t.get("name")}: {t.get("description", "")[:30]}...')
    
    print('\n=== 调用 get_usage_guide ===')
    result = transport.call_tool('get_usage_guide', {})
    if result:
        print('调用成功!')
        print(json.dumps(result, ensure_ascii=False, indent=2)[:500] + '...')
    else:
        print('调用失败')
    
    print('\n=== 调用 project_statistics ===')
    result = transport.call_tool('project_statistics', {
        'project_root': r'F:\代码\启迪白泽\src'
    })
    if result:
        print('调用成功!')
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print('调用失败')
    
    transport.disconnect()
else:
    print('连接失败')
