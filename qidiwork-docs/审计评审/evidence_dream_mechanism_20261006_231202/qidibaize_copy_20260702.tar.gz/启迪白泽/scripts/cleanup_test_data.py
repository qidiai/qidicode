"""清理测试数据节点 (测试主题X / 编程知识X 这种明显占位符命名)"""
import json
import re
from pathlib import Path

KT_PATH = Path(r'F:\代码\启迪白泽\data\knowledge_tree.json')
data = json.loads(KT_PATH.read_text(encoding='utf-8'))
nodes = data.get('nodes', [])

# 匹配测试数据 topic: "测试主题数字" / "编程知识数字" / "知识数字" 等
TEST_PATTERNS = [
    re.compile(r'^测试主题\d+$'),
    re.compile(r'^编程知识\d+$'),
    re.compile(r'^知识\d+$'),
    re.compile(r'^主题\d+$'),
    re.compile(r'^test\d*$', re.IGNORECASE),
]

to_delete = set()
for n in nodes:
    if n['id'] == 'root':
        continue
    topic = (n.get('topic') or '').strip()
    for pat in TEST_PATTERNS:
        if pat.match(topic):
            to_delete.add(n['id'])
            break

print(f'[测试数据] 删除 {len(to_delete)} 个:')
for n in nodes:
    if n['id'] in to_delete:
        print(f'  - {n["topic"]} (hits={n.get("hit_count",0)})')

# 执行删除 + 清理引用
surviving = [n for n in nodes if n['id'] not in to_delete]
surviving_ids = {n['id'] for n in surviving}
for n in surviving:
    n['children_ids'] = [c for c in n.get('children_ids', []) if c in surviving_ids]

data['nodes'] = surviving
data['metadata'] = {
    'totalNodes': len(surviving),
    'totalHits': sum(n.get('hit_count', 0) for n in surviving),
}
KT_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

from collections import Counter
new_size = KT_PATH.stat().st_size
print(f'\n[结果] {len(surviving)} 节点, {new_size/1024:.1f} KB')
print(f'[深度] {dict(sorted(Counter(n.get("depth",0) for n in surviving).items()))}')
print(f'[来源] {dict(Counter(n.get("source","unknown") for n in surviving))}')

# 列出保留的节点
print(f'\n[保留节点]')
for n in surviving:
    if n['id'] != 'root':
        topic = (n.get('topic') or '')[:50]
        print(f'  d{n.get("depth",0)} h{n.get("hit_count",0):>2} [{n.get("source",""):<6}] {topic}')
