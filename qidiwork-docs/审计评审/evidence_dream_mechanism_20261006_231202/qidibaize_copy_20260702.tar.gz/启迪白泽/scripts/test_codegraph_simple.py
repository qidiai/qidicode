import sys
sys.path.insert(0, r'F:\代码\启迪白泽\src')

from main import BaizeSystem
import json

print('=== 启动启迪白泽系统 ===')
baize = BaizeSystem()

print('\n=== 测试 CodeGraph MCP 调用 ===')

result1 = baize.capability_registry.invoke('mcp.codegraph.get_usage_guide', {})

if result1:
    print('get_usage_guide 调用成功')
else:
    print('get_usage_guide 调用失败')

print('\n=== 项目统计 ===')
result2 = baize.capability_registry.invoke('mcp.codegraph.project_statistics', {
    'project_root': r'F:\代码\启迪白泽\src'
})

if result2:
    print(json.dumps(result2, ensure_ascii=False, indent=2))
else:
    print('project_statistics 调用失败')

print('\n=== 查找符号定义 ===')
result3 = baize.capability_registry.invoke('mcp.codegraph.find_definition', {
    'name': 'BaizeSystem',
    'project_root': r'F:\代码\启迪白泽\src'
})

if result3:
    print(json.dumps(result3, ensure_ascii=False, indent=2))
else:
    print('find_definition 调用失败')

print('\n=== 测试完成 ===')
