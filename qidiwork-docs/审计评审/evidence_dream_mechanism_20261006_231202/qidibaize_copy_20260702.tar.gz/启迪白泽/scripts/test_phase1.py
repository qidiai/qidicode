"""Phase 1 验证脚本 — 测试 SQLiteBackend 基本功能"""
import sys
import os
from pathlib import Path

# 设置路径
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from storage.sqlite_backend import SQLiteBackend

# 测试用临时数据库
db_path = Path(__file__).parent.parent / 'data' / 'baize_test.db'
if db_path.exists():
    db_path.unlink()

backend = SQLiteBackend(str(db_path))
print(f'[1/6] SQLiteBackend 初始化成功: {db_path}')

# 测试 upsert
backend.upsert('knowledge_nodes', 'kn_test_1', {
    'id': 'kn_test_1',
    'topic': '测试节点',
    'content': '这是测试内容',
    'depth': 1,
    'hit_count': 5,
    'source': 'test',
    'embedding': '[0.1, 0.2, 0.3]',
})
assert backend.count('knowledge_nodes') == 1
print('[2/6] upsert 成功')

# 测试 load_table
rows = backend.load_table('knowledge_nodes')
assert len(rows) == 1
assert rows[0]['topic'] == '测试节点'
assert rows[0]['hit_count'] == 5
print(f'[3/6] load_table 成功: topic={rows[0]["topic"]}, hits={rows[0]["hit_count"]}')

# 测试 query
results = backend.query('knowledge_nodes', {'source': 'test'})
assert len(results) == 1
results = backend.query('knowledge_nodes', {'source': 'nonexistent'})
assert len(results) == 0
print('[4/6] query 成功')

# 测试 update (upsert 同一 key)
backend.upsert('knowledge_nodes', 'kn_test_1', {
    'id': 'kn_test_1',
    'topic': '更新后的标题',
    'content': '更新后的内容',
    'depth': 2,
    'hit_count': 10,
    'source': 'test',
})
rows = backend.load_table('knowledge_nodes')
assert len(rows) == 1  # 还是1条，不是2条
assert rows[0]['topic'] == '更新后的标题'
assert rows[0]['hit_count'] == 10
print('[5/6] upsert 更新成功')

# 测试 delete
backend.delete('knowledge_nodes', 'kn_test_1')
assert backend.count('knowledge_nodes') == 0
print('[6/6] delete 成功')

# 测试 memory_entries 表
backend.upsert('memory_entries', 'mem_test', {
    'key': 'mem_test',
    'content': '{"data": "test"}',
    'level': 'L1_WORKING',
    'created_at': 1234567890,
    'updated_at': 1234567890,
    'access_count': 3,
    'tags': 'test,phase1',
})
assert backend.count('memory_entries') == 1
mem_rows = backend.query('memory_entries', {'level': 'L1_WORKING'})
assert len(mem_rows) == 1
print('\n[附加] memory_entries 表验证通过')

# 测试 skill_calls 表
backend.upsert('skill_calls', '1', {
    'skill_id': 's1',
    'skill_name': '搜索',
    'timestamp': 1234567890,
    'success': 1,
    'duration_ms': 100.5,
})
backend.upsert('skill_calls', '2', {
    'skill_id': 's2',
    'skill_name': '解析',
    'timestamp': 1234567891,
    'success': 1,
    'duration_ms': 50.0,
})
assert backend.count('skill_calls') == 2
print('[附加] skill_calls 表验证通过')

# 测试 evolution_log 表
backend.upsert('evolution_log', '1', {
    'timestamp': 1234567890,
    'evolution_type': 'rule',
    'description': '稀疏连接补强',
    'action': 'applied',
})
assert backend.count('evolution_log') == 1
print('[附加] evolution_log 表验证通过')

backend.close()

# 清理测试数据库
db_path.unlink()
for suffix in ('-wal', '-shm'):
    p = Path(str(db_path) + suffix)
    if p.exists():
        p.unlink()

print('\n✓ Phase 1 SQLiteBackend 验证全部通过！')
