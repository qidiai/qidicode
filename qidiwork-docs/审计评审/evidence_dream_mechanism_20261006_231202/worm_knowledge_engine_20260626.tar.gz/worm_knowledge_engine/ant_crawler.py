"""
蚁群爬虫 — 信息素驱动 + 蠕虫大脑指挥
整合自: F:\代码\爬虫\v99_ant_crawler.py
- 信息素引擎：URL 聚类 + 蚂蚁行走 + 路径规划
- 蠕虫大脑决策：动态调整延迟/并发/退避
- 知识树记忆：爬取经验持久化
"""
import asyncio
import json
import time
import hashlib
import heapq
import logging
import random
from datetime import datetime
from collections import defaultdict

logger = logging.getLogger('AntCrawler')


class PheromoneEngine:
    """信息素引擎 — URL 聚类 + 路径规划"""

    def __init__(self, n_clusters=50):
        self.n_clusters = n_clusters
        self.url_pheromone = {}      # url -> 信息素浓度
        self.url_cluster = {}        # url -> 聚类ID
        self.cluster_pheromone = defaultdict(float)  # 聚类 -> 总信息素
        self.cluster_urls = defaultdict(list)         # 聚类 -> URLs

    def add_url(self, url, weight=1.0):
        """添加URL并分配聚类"""
        if url in self.url_pheromone:
            return
        self.url_pheromone[url] = weight
        # 按URL哈希分配聚类
        h = int(hashlib.md5(url.encode()).hexdigest(), 16)
        cluster_id = h % self.n_clusters
        self.url_cluster[url] = cluster_id
        self.cluster_urls[cluster_id].append(url)
        self.cluster_pheromone[cluster_id] += weight

    def generate_crawl_plan(self, base_url, top_k=5):
        """生成爬取计划 — 信息素高的聚类优先"""
        # 按聚类信息素排序
        ranked = sorted(
            self.cluster_pheromone.items(),
            key=lambda x: x[1], reverse=True
        )
        plan = []
        for cluster_id, _ in ranked[:top_k]:
            urls = self.cluster_urls.get(cluster_id, [])
            # 信息素高的URL优先
            urls_sorted = sorted(
                urls, key=lambda u: self.url_pheromone.get(u, 0), reverse=True
            )
            plan.extend(urls_sorted[:3])  # 每聚类取前3
        return plan[:top_k * 3]

    def update_pheromone(self, url, success=True, reward=0.1):
        """更新信息素 — 成功则加强，失败则蒸发"""
        if url not in self.url_pheromone:
            return
        if success:
            self.url_pheromone[url] += reward
            cluster_id = self.url_cluster[url]
            self.cluster_pheromone[cluster_id] += reward * 0.5
        else:
            self.url_pheromone[url] *= 0.8  # 蒸发

    def regenerate_path(self, blocked_url):
        """被阻断后重新规划路径"""
        if blocked_url in self.url_pheromone:
            self.url_pheromone[blocked_url] *= 0.3  # 大幅降低
        # 从同聚类找替代
        cluster_id = self.url_cluster.get(blocked_url)
        if cluster_id is not None:
            alternatives = [
                u for u in self.cluster_urls[cluster_id]
                if u != blocked_url and self.url_pheromone.get(u, 0) > 0.1
            ]
            if alternatives:
                return random.choice(alternatives)
        return None


class WorkerAnt:
    """工蚁 — 执行爬取任务"""

    def __init__(self, worker_id, role='scout'):
        self.worker_id = worker_id
        self.role = role  # scout / collector / analyst
        self.tasks_done = 0
        self.success_rate = 0.5

    async def execute(self, url, delay=1.0):
        """执行爬取（简化版 — 实际用 playwright）"""
        await asyncio.sleep(delay * random.uniform(0.5, 1.5))
        # 模拟结果
        success = random.random() > 0.2
        data = {
            'url': url, 'success': success,
            'timestamp': datetime.now().isoformat(),
            'content_length': random.randint(500, 50000) if success else 0,
        }
        self.tasks_done += 1
        if success:
            self.success_rate = 0.9 * self.success_rate + 0.1
        else:
            self.success_rate = 0.9 * self.success_rate
        return data


class QueenController:
    """蚁后调度器 — 分配任务给工蚁"""

    def __init__(self, max_workers=5):
        self.workers = []
        self.task_queue = []
        self.results = []
        self.max_workers = max_workers
        self._id_counter = 0

    def spawn_workers(self, n=None):
        """孵化工蚁"""
        if n is None:
            n = self.max_workers
        for i in range(n):
            self._id_counter += 1
            role = ['scout', 'collector', 'analyst'][i % 3]
            self.workers.append(WorkerAnt(self._id_counter, role))

    def add_task(self, url, priority=1.0):
        """添加任务 — 优先级队列"""
        heapq.heappush(self.task_queue, (-priority, url))

    def get_task(self):
        """获取最高优先级任务"""
        if self.task_queue:
            _, url = heapq.heappop(self.task_queue)
            return url
        return None


class AntCrawler:
    """蚁群爬虫 — 整合信息素 + 蠕虫大脑 + 知识树"""

    def __init__(self, worm_brain=None, knowledge_tree=None):
        self.pheromone = PheromoneEngine()
        self.queen = QueenController()
        self.worm_brain = worm_brain
        self.knowledge_tree = knowledge_tree
        self.crawl_history = []
        self.is_running = False

    def add_seed_urls(self, urls):
        """添加种子URL"""
        for url in urls:
            self.pheromone.add_url(url, weight=1.0)
            self.queen.add_task(url, priority=1.0)

    async def crawl_one(self, url, delay=1.0):
        """爬取单个URL"""
        # 蠕虫大脑决策
        if self.worm_brain:
            decision = self.worm_brain.decide()
            delay = decision.get('delay', delay)

        # 选择工蚁执行
        if not self.queen.workers:
            self.queen.spawn_workers()
        worker = random.choice(self.queen.workers)
        result = await worker.execute(url, delay)

        # 更新信息素
        self.pheromone.update_pheromone(
            url, success=result['success'],
            reward=0.1 if result['success'] else -0.05
        )

        # 蠕虫大脑反馈
        if self.worm_brain:
            score = 1.0 if result['success'] else 0.2
            self.worm_brain.reward(
                decision.get('expert', 'crawl'), score
            )

        # 知识树学习
        if self.knowledge_tree and result['success']:
            self.knowledge_tree.learn(
                topic=f'爬取: {url[:50]}',
                content=json.dumps(result, ensure_ascii=False)[:500],
                source='crawl'
            )

        self.crawl_history.append(result)
        return result

    async def run(self, max_tasks=20):
        """运行爬取循环"""
        self.is_running = True
        self.queen.spawn_workers()

        # 生成爬取计划
        plan = []
        if self.queen.task_queue:
            for _ in range(min(max_tasks, len(self.queen.task_queue))):
                url = self.queen.get_task()
                if url:
                    plan.append(url)

        # 蠕虫大脑感知环境
        if self.worm_brain:
            success_rate = 0.5
            if self.crawl_history:
                success_rate = sum(
                    1 for r in self.crawl_history if r.get('success')
                ) / len(self.crawl_history)
            self.worm_brain.perceive(
                load=len(self.queen.task_queue) / 100,
                task_queue_len=len(self.queen.task_queue),
                success_rate=success_rate,
            )
            decision = self.worm_brain.decide()
            concurrency = decision.get('concurrency', 3)
        else:
            concurrency = 3

        # 并发爬取
        results = []
        for i in range(0, len(plan), concurrency):
            batch = plan[i:i + concurrency]
            tasks = [self.crawl_one(url) for url in batch]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in batch_results:
                if isinstance(r, Exception):
                    logger.error(f'爬取异常: {r}')
                else:
                    results.append(r)

        self.is_running = False
        return results

    def get_status(self):
        return {
            'is_running': self.is_running,
            'pheromone_urls': len(self.pheromone.url_pheromone),
            'workers': len(self.queen.workers),
            'tasks_pending': len(self.queen.task_queue),
            'history_size': len(self.crawl_history),
        }
