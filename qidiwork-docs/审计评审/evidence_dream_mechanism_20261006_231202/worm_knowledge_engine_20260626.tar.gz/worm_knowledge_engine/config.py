"""
蠕虫知识引擎 — 集中配置

所有散落在各模块的魔法数字/超时/门槛/路径集中到这里,
改一处生效全局, 不用翻7个文件找参数。
"""

# ============ 知识树 ============
SP_DIM = 24                # V10三速源池: 每速24维, 三速共72维
RECALL_MIN_SCORE = 0.25    # recall 相似度门槛 (低于此视为不相关)
RECALL_MIN_TOPIC_LEN = 2   # topic 最短有效长度
RECALL_DEFAULT_TOP_K = 5   # recall 默认返回条数
PRUNE_MAX_JUNK = 50        # 单次清理最多删多少节点
PRUNE_DYING_AGE = 3600     # 多久没访问(秒)标记衰退
PRUNE_DYING_HITS = 2       # 命中低于此数标记衰退
MERGE_CONTENT_RATIO = 1.3  # merge_knowledge 新内容要长于旧的倍数

# ============ 嵌入引擎 ============
EMBED_DIM = 1024           # V10嵌入向量维度 (1024, 不要截断!)
EMBED_CACHE_SIZE = 500     # 嵌入缓存最大条数
EMBED_SIM_THRESHOLD = 0.15 # 联网学习相关度门槛
EMBED_SIM_THRESHOLD_V10 = 0.25  # V10引擎下更严的门槛

# ============ 联网搜索 ============
WEB_COOLDOWN = 60          # 联网冷却秒数
WEB_DAILY_LIMIT = 50       # 每日联网上限
WEB_SEARCH_TIMEOUT = 6     # 搜索超时秒
WEB_FETCH_TIMEOUT = 6      # 抓正文超时秒
WEB_API_TIMEOUT = 5        # DDG API 超时秒
WEB_DIGEST_TOP_K = 5       # digest 搜索取几条
WEB_DIGEST_FETCH_MAX = 3   # digest 最多抓几个正文
WEB_CONTENT_MIN_LEN = 200  # 正文至少多少字符才算真内容
WEB_CONTENT_MIN_CLEAN = 100 # 清洗后至少多少字符
WEB_CONTENT_MAX_LEN = 2000 # 主体正文最长字符
WEB_SNIPPET_MIN_LEN = 100  # 摘要至少多少字符可替代正文

# ============ 本地自学 ============
LOCAL_HUNGER_THRESHOLD = 0.4  # 饥饿>此值触发自学
LOCAL_LEARN_RATIO = 0.1       # 知识树规模<本地可学总量*此比例时触发

# ============ 生物体循环 ============
ORGANISM_HEARTBEAT = 2.0   # 心跳间隔秒
ORGANISM_SLEEP_AFTER = 20  # 每N轮睡一次
ORGANISM_SLEEP_ROUNDS = 3  # 做几轮梦就醒
ORGANISM_HISTORY_MAX = 500 # 历史记录上限
ORGANISM_LEARNED_HISTORY_MAX = 20  # 自学历史上限

# ============ WebUI ============
WEBUI_ASYNC_TIMEOUT = 120  # _run_async 超时秒
WEBUI_REFRESH_INTERVAL = 2000  # 前端轮询间隔毫秒

# ============ 自进化 ============
EVOLVE_TEST_TIMEOUT = 30   # 自测超时秒
EVOLVE_BACKUP_MAX = 10     # 最大备份数

# ============ 数据路径 ============
import os
_DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
KNOWLEDGE_TREE_PATH = os.path.join(_DATA_DIR, 'knowledge_tree.json')
CUBE_STATE_PATH = os.path.join(_DATA_DIR, 'cube_state.json')
LOCAL_KNOWLEDGE_ROOT = r'E:\训练数据'  # 本地知识源根目录

# ============ 垃圾关键词 (知识树清理用) ============
JUNK_KEYWORDS = [
    # 施工/工程垃圾
    '开挖', '脚手架', '浇筑', '桩基', '模板', '钢筋绑扎', '混凝土',
    # 百科杂条
    '明朝', '清朝', '皇帝', '朝代', '年号', '进士', '状元',
    # 通用垃圾
    '测试', 'TODO', 'TMP', '迁移知识', '未命名', '新建',
    # 代码碎片
    'VERSION HISTORY', 'npm install', 'function(',
]

# ============ 科学术语保护 (不被误删) ============
SCIENCE_PROTECT_KEYWORDS = [
    '哲学', '数学', '物理', '化学', '生物', '地理',
    '历史', '政治', '经济', '法律', '医学', '药理',
    '分子', '量子', '相对论', '统计', '粒子',
    '算法', '编程', '开发', '数据库', '网络',
    '深度学习', '机器学习',
]

# ============ 搜索端点 ============
BING_URL = 'https://www.bing.com/search'
DDG_API_URL = 'https://api.duckduckgo.com/'
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
