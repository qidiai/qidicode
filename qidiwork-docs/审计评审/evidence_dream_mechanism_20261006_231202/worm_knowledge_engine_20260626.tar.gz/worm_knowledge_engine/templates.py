"""
蠕虫知识引擎 — WebUI HTML/CSS/JS 模板

从 webui.py 抽出, 方便独立修改前端而不碰后端逻辑。
"""


def get_page_html() -> str:
    """返回完整的单页 HTML (内含 CSS + JS)"""
    return _CSS + _BODY + _JS


# ============ CSS ============

_CSS = r"""<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>蠕虫知识引擎</title>
<style>
:root{--bg:#0a0e14;--card:#111820;--card-hover:#1a2230;--border:#1e2a3a;--border-soft:#253040;
--text:#c5cdd8;--text-dim:#6b7a8d;--text-muted:#4a5568;--accent:#00ff9c;--info:#5ab8ff;
--warn:#ff5c5c;--purple:#b889ff;--transition:0.2s}
*{margin:0;padding:0;box-sizing:border-box}
body{background:var(--bg);color:var(--text);font-family:'Segoe UI',system-ui,sans-serif;font-size:13px;line-height:1.5}
.container{max-width:1200px;margin:0 auto;padding:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px}
.card{background:var(--card);border:1px solid var(--border);border-radius:8px;padding:12px;overflow:hidden}
.card:hover{border-color:var(--border-soft)}
h2{font-size:14px;color:var(--accent);margin-bottom:8px;font-weight:600}
.stat-row{display:flex;justify-content:space-between;padding:2px 0;font-size:12px}
.stat-val{color:var(--info);font-weight:600}
.bar{height:4px;background:var(--border);border-radius:2px;margin:3px 0 5px;overflow:hidden}
.bar-fill{height:100%;border-radius:2px;transition:width var(--transition)}
.bar-hunger .bar-fill{background:linear-gradient(90deg,#ff5c5c,#ff9c5c)}
.bar-success .bar-fill{background:linear-gradient(90deg,var(--accent),#5aff9c)}
.empty{color:var(--text-muted);font-size:11px;font-style:italic;padding:4px 0}
/* 卡片收起/展开 */
.card h2{cursor:pointer;user-select:none;display:flex;align-items:center;justify-content:space-between}
.card h2::after{content:'▾';font-size:12px;color:var(--text-dim);transition:transform .2s}
.card.collapsed h2::after{transform:rotate(-90deg)}
.card.collapsed .card-body{display:none}
.card-body{overflow-y:auto;max-height:260px}
.card-body::-webkit-scrollbar{width:4px}
.card-body::-webkit-scrollbar-track{background:var(--bg)}
.card-body::-webkit-scrollbar-thumb{background:var(--border-soft);border-radius:2px}
.card-body::-webkit-scrollbar-thumb:hover{background:var(--text-dim)}
.concept{display:inline-block;padding:3px 8px;margin:2px;border-radius:4px;font-size:11px;
background:rgba(0,255,156,.06);border:1px solid rgba(0,255,156,.15);transition:transform var(--transition)}
.concept:hover{transform:translateY(-1px)}
.concept strong{color:var(--accent);font-weight:600}
.dream-event{padding:4px 0;color:var(--purple);font-size:12px;line-height:1.7}
.history-item{padding:5px 7px;border-radius:4px;font-size:12px;transition:background var(--transition)}
.history-item:hover{background:var(--card-hover)}
.history-item.mark-ok{color:var(--accent)}
.history-item.mark-fail{color:var(--warn)}
#chat-log{max-height:280px;overflow-y:auto;margin-bottom:8px}
.chat-msg{padding:6px 10px;margin:3px 0;border-radius:6px;font-size:12px;animation:slideIn .2s}
@keyframes slideIn{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
.chat-user{background:linear-gradient(90deg,rgba(0,255,156,.1),rgba(0,255,156,.03));border-left:2px solid var(--accent);text-align:right}
.chat-bot{background:rgba(90,184,255,.07);border-left:2px solid var(--info)}
.chat-dream{background:rgba(184,137,255,.07);border-left:2px solid var(--purple);font-style:italic;color:var(--purple)}
#input-row{display:flex;gap:8px;margin-bottom:10px}
#msg-input{flex:1;background:var(--bg);border:1px solid var(--border);border-radius:6px;padding:6px 10px;color:var(--text);font-size:13px;outline:none}
#msg-input:focus{border-color:var(--accent)}
.btn-row{display:flex;gap:6px;flex-wrap:wrap}
.btn-row button{background:var(--card);border:1px solid var(--border);border-radius:6px;padding:5px 12px;
color:var(--text);font-size:12px;cursor:pointer;transition:all var(--transition)}
.btn-row button:hover{border-color:var(--accent);color:var(--accent)}
#toast{position:fixed;top:12px;right:12px;background:var(--card);border:1px solid var(--accent);
border-radius:8px;padding:8px 16px;color:var(--accent);font-size:12px;z-index:999;
opacity:0;transition:opacity .3s;pointer-events:none}
#toast.show{opacity:1}
.col-span-2{grid-column:span 2}
@media(max-width:768px){.container{grid-template-columns:1fr}.col-span-2{grid-column:span 1}}
</style>
</head>
"""

# ============ BODY ============

_BODY = r"""<body>
<div id="toast"></div>
<div class="container">

<div class="card">
  <h2>🧬 状态</h2>
  <div class="card-body" id="status"></div>
</div>

<div class="card">
  <h2>🧠 大脑</h2>
  <div class="card-body" id="brain"></div>
</div>

<div class="card col-span-2">
  <h2>💬 对话</h2>
  <div class="card-body">
    <div id="chat-log"></div>
    <div id="input-row">
      <input id="msg-input" placeholder="说点什么..." autocomplete="off">
      <button onclick="sendMsg()">发送</button>
    </div>
    <div class="btn-row">
      <button onclick="learnTopic()">📚 学习</button>
      <button onclick="setGoal()">🎯 目标</button>
      <button onclick="liveCycles(20)">▶ 活20轮</button>
      <button onclick="sendCmd('/api/stop','{}')">⏹ 停止</button>
      <button onclick="doEvolve()">🧬 进化</button>
      <button onclick="location.href='/knowledge-tree'">✦ 知识星空</button>
    </div>
  </div>
</div>

<div class="card">
  <h2>📚 自学进度</h2>
  <div class="card-body" id="selflearn-stats"></div>
</div>

<div class="card">
  <h2>🌐 联网学习</h2>
  <div class="card-body" id="weblearn-stats"></div>
</div>

<div class="card">
  <h2>📜 自学历史</h2>
  <div class="card-body" id="selflearn-log"></div>
</div>

<div class="card">
  <h2>🌙 做梦</h2>
  <div class="card-body" id="dreams"></div>
</div>

<div class="card">
  <h2>📊 循环历史</h2>
  <div class="card-body" id="history"></div>
</div>

<div class="card">
  <h2>🧬 进化记录</h2>
  <div class="card-body" id="evolve-stats"></div>
</div>

</div>
"""

# ============ JS ============

_JS = r"""<script>
function $(id){return document.getElementById(id)}
function esc(s){return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2000)}

// 卡片收起/展开
document.addEventListener('click',e=>{const h=e.target.closest('.card h2');if(h){h.parentElement.classList.toggle('collapsed')}});

function addChat(type,text){
  const log=$('chat-log');
  const cls=type==='dream'?'chat-dream':type==='user'?'chat-user':'chat-bot';
  const div=document.createElement('div');
  div.className='chat-msg '+cls;
  div.textContent=text;
  log.appendChild(div);
  log.scrollTop=log.scrollHeight;
}

function sendMsg(){
  const input=$('msg-input');
  const text=input.value.trim();
  if(!text)return;
  input.value='';
  addChat('user',text);
  fetch('/api/say',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text})})
    .then(r=>r.json()).then(d=>{addChat('bot',d.reply||JSON.stringify(d));refreshAll()})
    .catch(()=>toast('发送失败'));
}

function sendCmd(url,body){
  fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body})
    .then(r=>r.json()).then(d=>{addChat('bot',JSON.stringify(d));refreshAll()}).catch(()=>toast('请求失败'));
}

function learnTopic(){
  const t=prompt('学习主题:');
  if(!t)return;
  toast('学习中: '+t);
  fetch('/api/learn_topic',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:t})})
    .then(r=>r.json()).then(d=>{addChat('bot','📚 '+(d.summary||JSON.stringify(d)));refreshAll()})
    .catch(()=>toast('学习失败'));
}

function setGoal(){
  const g=prompt('目标:');
  if(!g)return;
  fetch('/api/say',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:'目标: '+g})})
    .then(r=>r.json()).then(d=>{addChat('bot',d.reply||'目标已设定');refreshAll()})
    .catch(()=>toast('设定失败'));
}

function liveCycles(n){
  toast('开始活 '+n+' 轮...');
  fetch('/api/live',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cycles:n})})
    .then(r=>r.json()).then(d=>{addChat('bot','▶ '+JSON.stringify(d));refreshAll()})
    .catch(()=>toast('启动失败'));
}

function doEvolve(){
  toast('正在进化...');
  fetch('/api/evolve',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'})
    .then(r=>r.json()).then(d=>{
      const results=Array.isArray(d)?d:[d];
      const adopted=results.filter(x=>x.adopted).length;
      const rejected=results.filter(x=>x.rejected).length;
      const failed=results.filter(x=>x.adopted===false&&!x.rejected).length;
      let msg='🧬 进化完成: ';
      if(adopted)msg+=`采纳${adopted}项 `;
      if(rejected)msg+=`守卫拒绝${rejected}项 `;
      if(failed)msg+=`测试失败${failed}项 `;
      if(!results.length)msg+='无问题需修改';
      addChat('bot',msg);
      results.filter(x=>x.rejected).forEach(x=>{
        addChat('bot',`⚠ 守卫拒绝 [${esc(x.file||'?')}]: ${esc(x.reason||'?')}`);
      });
      refreshAll();
    }).catch(()=>toast('进化失败'));
}

// 差异化更新
let lastStatus='',lastBrain='',lastHistory='',lastDreams='',lastEvolve='',lastSelfLearn='',lastSelfLog='';
function setIfChanged(el,html,cacheVar){
  if(window[cacheVar]===html)return;
  window[cacheVar]=html; el.innerHTML=html;
}

function refreshAll(){
  fetch('/api/status').then(r=>r.json()).then(d=>{
    const html=`
      <div class="stat-row"><span>活着</span><span class="stat-val">${d.alive?'✓':'✗'}</span></div>
      <div class="stat-row"><span>循环</span><span class="stat-val">${d.cycle}</span></div>
      <div class="stat-row"><span>饥饿</span><span class="stat-val">${(d.hunger*100).toFixed(0)}%</span></div>
      <div class="bar bar-hunger"><div class="bar-fill" style="width:${Math.min(100,d.hunger*100)}%"></div></div>
      <div class="stat-row"><span>成功率</span><span class="stat-val">${(d.success_rate*100).toFixed(0)}%</span></div>
      <div class="bar bar-success"><div class="bar-fill" style="width:${Math.min(100,d.success_rate*100)}%"></div></div>
      <div class="stat-row"><span>知识节点</span><span class="stat-val">${d.body?.total_nodes||0}</span></div>
      <div class="stat-row"><span>蠕虫数</span><span class="stat-val">${d.brain?.swarm?.total_worms||0}</span></div>
      <div class="stat-row"><span>目标</span><span class="stat-val">${d.goals_done||0}/${d.goals_total||0}</span></div>`;
    setIfChanged($('status'),html,'lastStatus');
    const sl=d.self_learn||{};
    const su=sl.summary||{};
    const suHtml=Object.keys(su).length?`
      <div style="margin-bottom:8px;padding:8px;border:1px solid var(--border-soft);border-radius:6px;background:var(--bg-soft)">
        <div style="font-size:12px;color:var(--accent);margin-bottom:5px;font-weight:600">📊 学习程度汇总</div>
        <div class="stat-row"><span>知识节点</span><span class="stat-val">${su.total_nodes||0}</span></div>
        <div class="stat-row"><span>最大深度</span><span class="stat-val">${su.max_depth||0}</span></div>
        <div class="stat-row"><span>累计命中</span><span class="stat-val">${su.total_hits||0} 次</span></div>
        <div class="stat-row"><span>用过节点</span><span class="stat-val">${su.hit_nodes||0}/${su.total_nodes||0} (${((su.coverage||0)*100).toFixed(0)}%)</span></div>
        <div class="bar bar-success" style="margin:4px 0"><div class="bar-fill" style="width:${Math.min(100,(su.coverage||0)*100)}%"></div></div>
        <div class="stat-row"><span>本地自学</span><span class="stat-val">${su.local_learned||0} 条</span></div>
        <div class="stat-row"><span>联网自学</span><span class="stat-val">${su.web_learned||0} 条</span></div>
        ${(()=>{const bs=su.by_source||{};const keys=Object.keys(bs);if(!keys.length)return '';return '<div style="margin-top:4px;font-size:11px;color:var(--text-muted)">来源分布: '+keys.map(k=>esc(k)+':'+bs[k]).join(' / ')+'</div>';})()}
      </div>`:'';
    const slHtml=suHtml+(!sl.available?`<div class="empty">本地知识源不可用</div>`:(()=>{
      const ps=(sl.stats?.parsers||[]).map(p=>{
        const total=sl.stats?.root||'';
        return `<div class="stat-row"><span title="${esc(p.path)}">${esc(p.name)}</span><span class="stat-val">${p.learned||0} 条</span></div>
                <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">最近: ${esc(p.last||'—')}</div>`;
      }).join('')||'<div class="empty">(无解析器)</div>';
      return `<div class="stat-row"><span>知识源</span><span class="stat-val" style="font-size:11px;word-break:break-all">${esc(sl.stats?.root||'')}</span></div>${ps}`;
    })());
    setIfChanged($('selflearn-stats'),slHtml,'lastSelfLearn');
    const emb=sl.embed||{};
    if(emb.is_degraded&&$('selflearn-stats')){
      const warn=document.createElement('div');
      warn.style.cssText='margin-top:6px;padding:6px 10px;border:1px solid rgba(255,92,92,.3);border-radius:6px;background:rgba(255,92,92,.08);font-size:12px;color:var(--warn)';
      warn.textContent='⚠ 嵌入引擎降级: '+esc(emb.engine)+' — '+esc(emb.warning||'');
      const container=$('selflearn-stats');
      if(!container.querySelector('[data-embed-warn]')){warn.setAttribute('data-embed-warn','1');container.appendChild(warn);}
    }
    const web=sl.web||{};
    const webHtml=web.available?`<div class="stat-row"><span>🌐 联网搜索</span><span class="stat-val">${web.learned||0} 条</span></div>${web.last_query?`<div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">最近搜: ${esc(web.last_query)}</div>`:''}`:'<div class="empty">🌐 联网不可用</div>';
    if($('weblearn-stats'))setIfChanged($('weblearn-stats'),webHtml,'lastWeb');
    const hist=sl.history||[];
    const histHtml=hist.length?hist.slice().reverse().map(h=>`<div class="history-item mark-ok">[${esc(h.time||'')}] 📚 ${esc(h.parser||'?')}: ${esc(h.topic||'')}</div>`).join(''):'<div class="empty">(还没自学过 — 等生物体饿了/缺知识时自己会学)</div>';
    setIfChanged($('selflearn-log'),histHtml,'lastSelfLog');
  }).catch(()=>{});
  fetch('/api/brain').then(r=>r.json()).then(d=>{
    const active=(d.active||[]).slice(0,15);
    const html=active.map(([n,a])=>`<div class="concept"><strong>${esc(n)}</strong> ${a.toFixed(2)}</div>`).join('')
      +`<div class="stat-row" style="margin-top:6px"><span>饥饿</span><span class="stat-val">${(d.hunger||0).toFixed(2)}</span></div>`;
    setIfChanged($('brain'),html,'lastBrain');
  }).catch(()=>{});
  fetch('/api/history').then(r=>r.json()).then(d=>{
    const html=d.map(x=>{
      if(x.phase==='dream'){const de=(x.dream_events||[]).join(', ');return`<div class="history-item" style="color:var(--purple)">🌙 做梦: ${esc(de||'安静的一夜')}</div>`;}
      const ok=(x.outcome||0)>0.5;
      return`<div class="history-item ${ok?'mark-ok':'mark-fail'}">${ok?'✓':'✗'} [${x.cycle||'?'}] ${esc(x.decision||'?')} → ${(x.outcome||0).toFixed(2)}</div>`;
    }).join('')||'<div class="empty">(无历史)</div>';
    setIfChanged($('history'),html,'lastHistory');
  }).catch(()=>{});
  fetch('/api/dreams').then(r=>r.json()).then(d=>{
    const html=d.map(x=>{
      const evts=x.events||[];
      const evtStr=evts.length?evts.map(e=>esc(e)).join('<br>'):'<span style="color:var(--text-muted)">(安静的一夜)</span>';
      return`<div class="dream-event"><span style="color:var(--text-dim);font-size:11px">第${x.round||'?'}轮</span><br>${evtStr}</div>`;
    }).join('')||'<div class="empty">(还没做过梦 — 活20轮后会自动睡)</div>';
    setIfChanged($('dreams'),html,'lastDreams');
  }).catch(()=>{});
  fetch('/api/evolve').then(r=>r.json()).then(d=>{
    const html=d.total_changes!==undefined?`
      <div class="stat-row"><span>总修改</span><span class="stat-val">${d.total_changes||0}</span></div>
      <div class="stat-row"><span>已采纳</span><span class="stat-val">${d.adopted||0}</span></div>
      <div class="stat-row"><span>已回滚</span><span class="stat-val">${d.reverted||0}</span></div>
    `:'<div class="empty">(未进化过)</div>';
    setIfChanged($('evolve-stats'),html,'lastEvolve');
  }).catch(()=>{});
}

$('msg-input').addEventListener('keydown',e=>{if(e.key==='Enter')sendMsg()});
setInterval(refreshAll,2000);
refreshAll();
</script>
</body>
</html>
"""
