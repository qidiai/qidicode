"""
Android原生支持 — Kivy界面

用 Buildozer 打包成 .apk:
  buildozer android debug deploy run
"""
import asyncio
import threading

try:
    from kivy.app import App
    from kivy.lang import Builder
    from kivy.clock import Clock
    from kivy.uix.boxlayout import BoxLayout
    HAS_KIVY = True
except ImportError:
    HAS_KIVY = False

from worm_knowledge_engine.organism import Organism
from worm_knowledge_engine.teacher import Teacher, MockBackend
from worm_knowledge_engine.dialogue import Dialogue
from worm_knowledge_engine.self_evolve import SelfEvolve

if not HAS_KIVY:
    print("[!] Kivy未安装, 请: pip install kivy")
    print("[!] 打包APK需要: pip install buildozer")
    raise ImportError("Kivy required for Android app")


KV = '''
<WormRoot>:
    orientation: "vertical"
    padding: dp(8)
    spacing: dp(6)

    Label:
        text: "Worm Knowledge Engine"
        font_size: sp(22)
        color: 0, 1, 0.5, 1
        size_hint_y: None
        height: dp(40)

    BoxLayout:
        size_hint_y: None
        height: dp(30)
        spacing: dp(4)
        Label:
            id: status_label
            text: "init..."
            font_size: sp(12)
            color: 0.7, 0.7, 0.7, 1
            halign: "left"
            text_size: self.size

    ScrollView:
        size_hint_y: 0.4
        Label:
            id: thought_label
            text: ""
            font_size: sp(13)
            color: 0.8, 1, 0.8, 1
            halign: "left"
            valign: "top"
            text_size: self.width - dp(16), None
            size_hint_y: None
            height: max(self.texture_size[1], dp(100))
            padding: dp(8), dp(4)

    ScrollView:
        size_hint_y: 0.35
        Label:
            id: chat_label
            text: "[chat]\\n"
            font_size: sp(14)
            color: 0.9, 0.9, 0.9, 1
            halign: "left"
            valign: "top"
            text_size: self.width - dp(16), None
            size_hint_y: None
            height: max(self.texture_size[1], dp(100))
            padding: dp(8), dp(4)

    BoxLayout:
        size_hint_y: None
        height: dp(44)
        spacing: dp(6)
        TextInput:
            id: msg_input
            hint_text: "say something..."
            multiline: False
            font_size: sp(16)
            on_text_validate: root.send_msg()
        Button:
            text: "Send"
            size_hint_x: None
            width: dp(70)
            font_size: sp(16)
            on_press: root.send_msg()

    BoxLayout:
        size_hint_y: None
        height: dp(40)
        spacing: dp(4)
        Button:
            text: "> Live 10"
            on_press: root.live(10)
        Button:
            text: "# Stop"
            on_press: root.stop()
        Button:
            text: "? Think"
            on_press: root.think()
        Button:
            text: "+ Teach"
            on_press: root.teach()
'''


class WormRoot(BoxLayout):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.organism = None
        self.dialogue = None
        self.teacher = None
        self.evolve = None
        self._chat_text = "[chat]\n"
        self._thought_text = ""
        Clock.schedule_once(self._init_organism, 0.5)

    def _init_organism(self, dt):
        self.organism = Organism(data_dir="data", name="android_worm")
        self.teacher = Teacher(self.organism, backend=MockBackend())
        self.dialogue = Dialogue(self.organism, teacher=self.teacher)
        self.evolve = SelfEvolve(self.organism, teacher=self.teacher)
        self.teacher.auto_teach(max_topics=2)
        self._update_status()
        self._add_chat("SYS", "ready, %d concepts" % len(self.organism.brain.swarm.worms))

    def send_msg(self):
        input_widget = self.ids.msg_input
        text = input_widget.text.strip()
        if not text:
            return
        input_widget.text = ""
        self._add_chat("YOU", text)

        def run():
            reply = asyncio.run(self.dialogue.say(text))
            Clock.schedule_once(lambda dt: self._add_chat("IT", reply), 0)
        threading.Thread(target=run, daemon=True).start()

    def live(self, cycles=10):
        self._add_chat("SYS", "living %d cycles..." % cycles)

        def run():
            asyncio.run(self.organism.live(max_cycles=cycles))
            Clock.schedule_once(lambda dt: self._add_chat("SYS", "done %d cycles" % self.organism.cycle_count), 0)
        threading.Thread(target=run, daemon=True).start()
        Clock.schedule_interval(self._update_status, 1)

    def stop(self):
        if self.organism:
            self.organism.die()
            self._add_chat("SYS", "stopped")

    def think(self):
        if not self.organism:
            return

        def run():
            result = self.organism.brain.think(percepts=[], rounds=5)
            chain = result.get("chain", [])
            text = ""
            for i, snap in enumerate(chain):
                top = list(snap.items())[:5]
                text += "round%d: %s\n" % (i + 1, top)
            decision = result.get("decision", {})
            if decision:
                text += "decision: %s (score=%.3f)" % (decision.get("action", "?"), decision.get("score", 0))
            Clock.schedule_once(lambda dt: self._set_thought(text), 0)
        threading.Thread(target=run, daemon=True).start()

    def teach(self):
        if not self.teacher:
            return

        def run():
            results = self.teacher.auto_teach(max_topics=2)
            total = sum(r.get("new_concepts", 0) for r in results) if results else 0
            msg = "taught, +%d concepts" % total
            Clock.schedule_once(lambda dt: self._add_chat("SYS", msg), 0)
        threading.Thread(target=run, daemon=True).start()

    def _add_chat(self, who, text):
        self._chat_text += "\n[%s] %s" % (who, text)
        self.ids.chat_label.text = self._chat_text

    def _set_thought(self, text):
        self._thought_text = text
        self.ids.thought_label.text = text

    def _update_status(self, dt=None):
        if not self.organism:
            return
        s = self.organism.get_status()
        active = self.organism.brain.swarm.get_active(threshold=0.05)
        top3 = ", ".join("%s(%.2f)" % (n, a) for n, a, v, c in active[:3])
        self.ids.status_label.text = (
            "cycle:%d hunger:%.0f%% success:%.0f%% worms:%d thinking:%s"
            % (s["cycle"], s["hunger"] * 100, s["success_rate"] * 100,
               s["brain"]["swarm"]["total_worms"], top3)
        )


class WormApp(App):
    def build(self):
        Builder.load_string(KV)
        return WormRoot()

    def on_stop(self):
        root = self.root
        if root and hasattr(root, "organism") and root.organism:
            root.organism.die()


if __name__ == "__main__":
    WormApp().run()
