"""
三维立体矩形 — v1.0
三轴: X(行业领域)×Y(三速池)×Z(认知层)

每个格子 = 一个"场", 支持:
  - 写入: V10嵌入映射到场激活
  - 扩散: 三维邻居传播(非沿边)
  - 读出: 查询激活峰
  - 衰减: 每速独立EMA
"""
import json, math, time, os
from copy import deepcopy

# ─── 三轴定义 ────────────────────────────────────
DOMAINS = ["通用","施工","安装","材料","设计","管理"]   # X轴: 行业
SPEEDS  = ["fast","medium","slow"]                     # Y轴: 三速
LAYERS  = ["感知","思维","决策","行动"]                  # Z轴: 认知

NX, NY, NZ = len(DOMAINS), len(SPEEDS), len(LAYERS)

DECAY = {"fast": 0.85, "medium": 0.95, "slow": 0.995}

# ─── 领域关键词库（用于V10映射 → 领域激活） ────────
DOMAIN_KEYWORDS = {
    "通用": [],
    "施工": ["施工","开挖","支护","脚手架","模板","钢筋","混凝土","浇筑","砌体","竣工","土方","基坑"],
    "安装": ["安装","焊接","调试","通风","空调","消防","电梯","弱电","布线","给排水","采暖","燃气","机电","管道"],
    "材料": ["钢筋","混凝土","水泥","砂浆","防水","卷材","保温","钢材","铝合金","门窗","涂料","石材","幕墙","瓷砖"],
    "设计": ["设计","方案","结构","计算","施工图","BIM","建模","节能","规划","消防","给排水","电气","暖通"],
    "管理": ["招标","监理","质量","验收","安全","管理","造价","咨询","结算","索赔","进度","合同"],
}

DOMAIN_WEIGHTS = None  # 缓存


def text_to_domain_weights(text):
    """输入文本 → 6维领域权重向量 (V10优先, 关键词降级)"""
    # 先尝试用V10嵌入做领域分类
    try:
        from v10_embed import embed
        vec = embed(text)
        # 领域质心 (预计算)
        centroids = _get_domain_centroids()
        if centroids:
            sims = [_cos_sim(vec, c) for c in centroids]
            # softmax
            exp_s = [math.exp(s * 5) for s in sims]  # 温度=0.2
            total = sum(exp_s)
            if total > 0:
                return [s / total for s in exp_s]
    except Exception:
        pass

    # 降级: 关键词匹配
    weights = [0.0] * NX
    for i, domain in enumerate(DOMAINS):
        keywords = DOMAIN_KEYWORDS[domain]
        score = sum(2.0 for kw in keywords if kw in text)  # 匹配一个+2分
        weights[i] = score
    weights[0] = 0.1  # 通用域基线很低

    total = sum(weights)
    if total > 0:
        weights = [w / total for w in weights]
    return weights


_domain_centroids = None


def _get_domain_centroids():
    """计算领域质心 (每个领域取代表词的V10嵌入均值)"""
    global _domain_centroids
    if _domain_centroids is not None:
        return _domain_centroids
    try:
        from v10_embed import embed
        reps = {
            "施工": ["土方开挖","脚手架搭设","混凝土浇筑","钢筋绑扎","竣工验收"],
            "安装": ["机电设备安装","管道焊接","电气调试","通风空调","电梯安装"],
            "材料": ["钢筋混凝土","防水卷材","保温材料","钢材","玻璃幕墙"],
            "设计": ["建筑方案设计","施工图设计","BIM建模","结构计算","建筑节能设计"],
            "管理": ["工程招标","质量验收","安全管理","造价咨询","竣工结算"],
        }
        centroids = []
        # 通用域 = 全零(无偏)
        centroids.append([0.0] * 1024)
        for domain in ["施工","安装","材料","设计","管理"]:
            vecs = [embed(t) for t in reps[domain]]
            avg = [sum(v[i] for v in vecs) / len(vecs) for i in range(1024)]
            centroids.append(avg)
        _domain_centroids = centroids
        return centroids
    except Exception:
        return None


def _cos_sim(a, b):
    dot = sum(x * y for x, y in zip(a, b))
    na = sum(x * x for x in a) ** 0.5
    nb = sum(x * x for x in b) ** 0.5
    return dot / (na * nb + 1e-12)


class Cell:
    """三维矩形中的一个场格"""
    __slots__ = ("concentration", "decay")

    def __init__(self, decay=0.95):
        self.concentration = 0.0
        self.decay = decay

    def write(self, value):
        """写入: 叠加新信号"""
        self.concentration = self.decay * self.concentration + (1 - self.decay) * value

    def read(self):
        """读出"""
        return self.concentration

    def step_decay(self):
        """自然衰减"""
        self.concentration *= self.decay

    def to_dict(self):
        return {"c": round(self.concentration, 4), "d": self.decay}


class Cube3D:
    """
    三维立体矩形
    shape: [NX, NY, NZ] = [6, 3, 4] = 72格

    用法:
      cube = Cube3D()
      cube.write(text)               # V10映射写入
      cube.diffuse(steps=3)          # 三维扩散
      peaks = cube.read(query)       # 读出激活峰
      cube.step()                    # 全局衰减
    """

    def __init__(self):
        # 72个场格
        self.grid = [[[Cell(decay=DECAY[speeds])
                       for _ in range(NZ)]
                      for speeds in SPEEDS]
                     for _ in range(NX)]

        self.step_count = 0
        self.history = []

    # ─── 写入 ──────────────────────────────────
    def write(self, text, strength=1.0):
        """文本 → 领域权重 → 写入对应列"""
        weights = text_to_domain_weights(text)

        for x in range(NX):
            w = weights[x]
            if w < 0.05:
                continue
            for y in range(NY):
                for z in range(NZ):
                    # Z层权重: 感知层接收最多, 行动层最少
                    z_weight = [0.5, 0.3, 0.15, 0.05][z]
                    self.grid[x][y][z].write(w * strength * z_weight)

    def write_direct(self, x, y, z, value):
        """直接写入指定场格"""
        self.grid[x][y][z].write(value)

    # ─── 三维扩散 ──────────────────────────────
    def diffuse(self, steps=3):
        """激活值向三维邻居扩散 (不是沿边传播)"""
        for _ in range(steps):
            new_grid = [[[Cell(decay=DECAY[SPEEDS[y]])
                          for _ in range(NZ)]
                         for y in range(NY)]
                        for x in range(NX)]

            for x in range(NX):
                for y in range(NY):
                    for z in range(NZ):
                        val = self.grid[x][y][z].concentration

                        # 自身保留60%, 40%扩散给邻居
                        self_val = val * 0.6
                        diff_val = val * 0.4

                        new_grid[x][y][z].concentration += self_val

                        # 向6个方向扩散(三维)
                        for dx, dy, dz in [(1,0,0),(-1,0,0),
                                           (0,1,0),(0,-1,0),
                                           (0,0,1),(0,0,-1)]:
                            nx, ny, nz = x+dx, y+dy, z+dz
                            if 0 <= nx < NX and 0 <= ny < NY and 0 <= nz < NZ:
                                # 跨领域衰减更大
                                dist_decay = 0.5 if dx != 0 else 0.7
                                new_grid[nx][ny][nz].concentration += \
                                    diff_val / 6 * dist_decay

            self.grid = new_grid

    # ─── 读出 ──────────────────────────────────
    def read(self, query=None, top_k=5):
        """读出激活峰"""
        peaks = []
        for x in range(NX):
            for y in range(NY):
                for z in range(NZ):
                    c = self.grid[x][y][z].concentration
                    if c > 0.01:
                        peaks.append({
                            "domain": DOMAINS[x],
                            "speed": SPEEDS[y],
                            "layer": LAYERS[z],
                            "x": x, "y": y, "z": z,
                            "concentration": round(c, 4),
                        })
        peaks.sort(key=lambda p: p["concentration"], reverse=True)
        return peaks[:top_k]

    def read_domain(self, domain):
        """读某个领域整列的激活状态"""
        x = DOMAINS.index(domain)
        return [{"speed": SPEEDS[y], "layer": LAYERS[z],
                 "concentration": self.grid[x][y][z].concentration}
                for y in range(NY) for z in range(NZ)]

    # ─── 衰减 ──────────────────────────────────
    def step(self):
        """全局自然衰减 + 计时"""
        for x in range(NX):
            for y in range(NY):
                for z in range(NZ):
                    self.grid[x][y][z].step_decay()
        self.step_count += 1

    # ─── 状态 ──────────────────────────────────
    def summary(self):
        """输出概览"""
        lines = []
        lines.append(f"三维立体矩形 | 步数={self.step_count}")
        lines.append(f"  形状: {NX}(领域) x {NY}(池速) x {NZ}(层) = {NX*NY*NZ}格")
        for x in range(NX):
            total = sum(self.grid[x][y][z].concentration
                       for y in range(NY) for z in range(NZ))
            lines.append(f"  {DOMAINS[x]}: Σ={total:.4f}")
        return "\n".join(lines)

    def to_dict(self):
        return {
            "domains": DOMAINS, "speeds": SPEEDS, "layers": LAYERS,
            "step": self.step_count,
            "grid": [[[self.grid[x][y][z].to_dict()
                       for z in range(NZ)]
                      for y in range(NY)]
                     for x in range(NX)]
        }

    def save(self, path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, ensure_ascii=False)

    @classmethod
    def load(cls, path):
        if not os.path.exists(path):
            return cls()
        with open(path) as f:
            data = json.load(f)
        cube = cls()
        cube.step_count = data.get("step", 0)
        for x in range(NX):
            for y in range(NY):
                for z in range(NZ):
                    d = data["grid"][x][y][z]
                    cube.grid[x][y][z].concentration = d["c"]
                    cube.grid[x][y][z].decay = d["d"]
        return cube


# ─── V10桥接 ────────────────────────────────────
def v10_to_cube(cube, text):
    """
    V10嵌入语义 → 三维矩形激活
    1. V10计算1024维向量
    2. 提取领域权重
    3. 写入立体矩形
    """
    cube.write(text)


# ─── 测试 ────────────────────────────────────────
if __name__ == "__main__":
    cube = Cube3D()

    texts = [
        "土方开挖和基坑支护属于施工领域",
        "机电设备安装与管道焊接是安装工程",
        "钢筋混凝土和防水卷材都是建筑材料",
    ]

    for t in texts:
        print(f"\n写入: {t}")
        v10_to_cube(cube, t)
        cube.diffuse(steps=2)

    print(cube.summary())

    print("\n激活峰:")
    for p in cube.read(top_k=10):
        print(f"  [{p['domain']}][{p['speed']}][{p['layer']}] = {p['concentration']:.4f}")

    cube.save("data/cube_state.json")
    print("\n保存: data/cube_state.json")
