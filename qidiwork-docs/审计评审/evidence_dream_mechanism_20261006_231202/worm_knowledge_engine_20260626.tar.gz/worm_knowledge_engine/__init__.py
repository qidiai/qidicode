"""
蠕虫知识引擎 v2.5 — 三维立体生物体

知识树=身体  蠕虫群=大脑  蚁群=感觉  爬虫=触角
三维矩形=场域  三速池=脉搏  自主循环=心跳

模块:
  - organism          生物体: 自主循环的智能体
  - worm_swarm        蠕虫群: 激活扩散引擎(群体思维)
  - worm_brain        蠕虫大脑: 感知→思考→决策→反思
  - knowledge_tree    知识树: 三速池记忆+树形结构+余弦检索
  - cube3d            三维立体矩形: 领域×三速×认知层的场空间
  - ant_crawler       蚁群爬虫: 信息素驱动+蚁后调度
  - mycelial_network  菌丝网络: TCP/UDP分布式通信
  - main              主入口: 交互/命令行/自主循环

使用:
  python -m worm_knowledge_engine              # 交互模式
  python -m worm_knowledge_engine live          # 自主循环(活着)
  python -m worm_knowledge_engine live 10       # 活10轮
  python -m worm_knowledge_engine crawl         # 爬虫模式
  python -m worm_knowledge_engine serve         # 服务节点
"""
from .organism import Organism, Goal
from .worm_swarm import WormSwarm, Worm
from .worm_brain import WormBrain
from .knowledge_tree import KnowledgeTree
from .cube3d import Cube3D, v10_to_cube, text_to_domain_weights
from .ant_crawler import AntCrawler
from .mycelial_network import MycelialNode
from .v9v3_embed import V9v3Embedding, get_embedding_engine
from .knowledge_tree import set_embed_engine, smart_embedding
from .self_evolve import SelfEvolve, CodeChange
from .teacher import Teacher, LLMBackend, OpenAIBackend, LocalBackend, MockBackend
from .webui import OrganismWebUI
from .main import WormKnowledgeEngine, interactive_mode, main

__all__ = [
    'Organism', 'Goal',
    'WormSwarm', 'Worm',
    'WormBrain',
    'KnowledgeTree',
    'Cube3D',
    'AntCrawler',
    'MycelialNode',
    'Dialogue',
    'SelfEvolve', 'CodeChange',
    'Teacher', 'LLMBackend', 'OpenAIBackend', 'LocalBackend', 'MockBackend',
    'OrganismWebUI',
    'WormKnowledgeEngine', 'interactive_mode', 'main',
]
