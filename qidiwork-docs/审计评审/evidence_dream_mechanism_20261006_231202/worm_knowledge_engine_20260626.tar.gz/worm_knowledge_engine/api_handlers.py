"""
蠕虫知识引擎 — API 路由处理

从 webui.py 抽出, 方便独立修改 API 而不碰前端模板。
每个函数签名: (webui, data, send_json, send_html) → None
"""
import time
import json
from datetime import datetime
from urllib.parse import urlparse, parse_qs


def handle_say(webui, data, send_json):
    """POST /api/say — 对话"""
    text = data.get('text', '')
    if webui.dialogue:
        reply = webui._run_async(webui.dialogue.say(text))
    else:
        reply = '(对话模块未加载)'
    webui._add_event('say', {'text': text, 'reply': reply})
    send_json({'reply': reply})


def handle_learn_topic(webui, data, send_json):
    """POST /api/learn_topic — 学习主题"""
    topic = data.get('text', '').strip()
    if not topic:
        send_json({'error': '空主题'})
        return
    org = webui.organism
    summary_parts = []
    # 1. 本地知识
    try:
        from ..config import RECALL_DEFAULT_TOP_K
        hits = org.body.recall(topic, top_k=3)
        if hits:
            scores = [f"{h.get('score', 0):.2f}" for h in hits]
            summary_parts.append(f'本地命中{len(hits)}条 (相似度: {", ".join(scores)})')
        else:
            summary_parts.append('本地无相关知识')
    except Exception:
        pass
    # 2. 联网搜
    try:
        now_t = time.time()
        today = datetime.now().strftime('%Y-%m-%d')
        if org._web_daily_date != today:
            org._web_daily_date = today
            org._web_daily_count = 0
        can = (org.web_learner.available()
               and now_t - org._web_last_time > org._web_cooldown
               and org._web_daily_count < org._web_daily_limit
               and topic not in org._web_searched_queries)
        if can:
            org._web_last_time = now_t
            org._web_daily_count += 1
            org._web_searched_queries.add(topic)
            n = org.web_learner.digest(topic, org.body)
            if n > 0:
                summary_parts.append(f'联网学到{n}条 (更全面已合并)')
                org._last_learned = {'parser': 'web', 'topic': topic, 'source': '联网搜索'}
                org._learned_history.append({'topic': topic, 'parser': 'web',
                    'source': '联网搜索', 'time': datetime.now().strftime('%H:%M:%S')})
                if len(org._learned_history) > 20:
                    org._learned_history = org._learned_history[-20:]
        else:
            summary_parts.append('联网冷却中/达上限/已搜过')
    except Exception as e:
        summary_parts.append(f'联网失败: {e}')
    # 3. 同步大脑
    try:
        org.brain.swarm.spawn(topic, 'self-taught', 0.3)
    except Exception:
        pass
    webui._add_event('learn_topic', {'topic': topic})
    send_json({'ok': True, 'topic': topic, 'summary': '；'.join(summary_parts) or '已学习'})


def handle_evolve(webui, data, send_json):
    """POST /api/evolve — 自进化"""
    results = webui.evolve.evolve()
    webui._add_event('evolve', {'results': results})
    send_json(results)


def handle_live(webui, data, send_json):
    """POST /api/live — 活N轮"""
    import threading
    cycles = data.get('cycles', 10)
    def run_live():
        webui._run_async(webui.organism.live(max_cycles=cycles))
    t = threading.Thread(target=run_live, daemon=True)
    t.start()
    send_json({'ok': True, 'cycles': cycles})


def handle_stop(webui, data, send_json):
    """POST /api/stop — 停止"""
    webui.organism.die()
    send_json({'ok': True})


def handle_teach(webui, data, send_json):
    """POST /api/teach — 教学"""
    topic = data.get('topic', '').strip()
    if not topic:
        send_json({'error': '空主题'})
        return
    if webui.teacher:
        result = webui.teacher.teach(topic)
        if result:
            send_json({'ok': True, 'result': result})
        else:
            send_json({'ok': False, 'error': '教学失败'})
    else:
        send_json({'error': '老师未加载'})


def handle_set_goal(webui, data, send_json):
    """POST /api/set_goal — 设目标"""
    goal = data.get('goal', '').strip()
    if goal:
        webui.organism.set_goal(goal, 'explore')
        send_json({'ok': True, 'goal': goal})
    else:
        send_json({'error': '空目标'})


def handle_toggle_sleep(webui, data, send_json):
    """POST /api/toggle_sleep — 强制入睡/唤醒"""
    org = webui.organism
    action = data.get('action', 'sleep')
    if action == 'sleep' and org.awake:
        org._sleep()
        send_json({'ok': True, 'state': 'sleeping'})
    elif action == 'wake' and not org.awake:
        org._wake()
        send_json({'ok': True, 'state': 'awake'})
    else:
        send_json({'ok': False, 'state': 'already_' + ('awake' if org.awake else 'sleeping')})


def handle_save_state(webui, data, send_json):
    """POST /api/save_state — 手动持久化状态"""
    webui.organism._persist_state()
    send_json({'ok': True, 'message': '状态已保存'})


def handle_self_learn_history(webui, send_json):
    """GET /api/self_learn_history — 自学历史"""
    send_json({
        'history': webui.organism._learned_history,
        'last': webui.organism._last_learned,
    })


# ============ GET 路由 ============

def handle_status(webui, send_json):
    send_json(webui.organism.get_status())

def handle_brain(webui, send_json):
    send_json({
        'active': [(n, round(a, 3)) for n, a, v, c in webui.organism.brain.swarm.get_active()[:20]],
        'stats': webui.organism.brain.swarm.get_stats(),
        'hunger': round(webui.organism.brain.hunger, 3),
    })

def handle_knowledge(webui, send_json):
    send_json(webui.organism.body.get_stats())

def handle_history(webui, send_json):
    send_json(webui.organism.history[-20:])

def handle_dreams(webui, send_json):
    send_json(webui.organism.dream_log[-10:])

def handle_events(webui, send_json):
    send_json(webui._events[-20:])

def handle_evolve_stats(webui, send_json):
    send_json(webui.evolve.get_stats())

def handle_tree(webui, path, query, send_json, get_tree_data_fn):
    if path == '/api/tree':
        send_json(get_tree_data_fn())
    elif path == '/api/node':
        node_id = query.get('id', [None])[0]
        if node_id:
            # 直接在 handler 里取节点详情, 不 import webui
            node = webui.organism.body.nodes.get(node_id)
            if node:
                send_json({
                    'id': node.id, 'topic': node.topic, 'content': node.content,
                    'parent_id': node.parent_id, 'depth': node.depth,
                    'hit_count': node.hit_count, 'is_dying': node.is_dying,
                    'children_ids': node.children_ids,
                    'embedding_dim': len(node.embedding) if node.embedding else 0,
                    'source': getattr(node, 'source', ''),
                })
            else:
                send_json({'error': 'Node not found'})
        else:
            send_json({'error': 'Missing node id'})

def handle_suggest(webui, query, send_json):
    node_id = query.get('id', [None])[0]
    if node_id:
        from .knowledge_tree_visual import make_suggestions
        tree = webui.organism.body
        node = tree.nodes.get(node_id)
        result = make_suggestions(tree, node.topic if node else '')
        send_json({'suggestions': result})
    else:
        send_json({'suggestions': []})


# ============ 路由表 ============

POST_ROUTES = {
    '/api/say': handle_say,
    '/api/learn_topic': handle_learn_topic,
    '/api/evolve': handle_evolve,
    '/api/live': handle_live,
    '/api/stop': handle_stop,
    '/api/teach': handle_teach,
    '/api/set_goal': handle_set_goal,
    '/api/toggle_sleep': handle_toggle_sleep,
    '/api/save_state': handle_save_state,
}

GET_ROUTES = {
    '/api/status': handle_status,
    '/api/brain': handle_brain,
    '/api/knowledge': handle_knowledge,
    '/api/history': handle_history,
    '/api/dreams': handle_dreams,
    '/api/events': handle_events,
    '/api/evolve': handle_evolve_stats,
    '/api/self_learn_history': handle_self_learn_history,
}
