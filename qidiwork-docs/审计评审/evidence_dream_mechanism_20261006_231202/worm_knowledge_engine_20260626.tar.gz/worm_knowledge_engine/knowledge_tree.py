"""
知识树 -- 三速池记忆 + 树形结构 + 语义检索
嵌入引擎: v9v3(优先) → 词袋哈希(降级)
"""
import json
import time
import math
import hashlib
import os
from pathlib import Path

SP_DIM = 24  # V10三速源池: 每速24维, 三速共72维
# 兼容旧V9v3的128维池(编译C库时自动适配)

# ============ 嵌入引擎 ============

_embed_engine = None  # 全局嵌入引擎, 懒加载
_embed_engine_name = '词袋哈希(降级)'  # 当前引擎名称, 供前端展示

def set_embed_engine(engine):
    """设置嵌入引擎(外部调用)"""
    global _embed_engine, _embed_engine_name
    _embed_engine = engine
    _embed_engine_name = '外部引擎'

def _auto_engine():
    """自动获取引擎: V10优先 → v9v3 → 词袋哈希(降级)"""
    global _embed_engine_name
    if _embed_engine is not None:
        return _embed_engine
    try:
        from .v10_embed import embed as _v10_embed, embed_with_pools as _v10_pools
        _embed_engine_name = 'V10'
        class _V10Wrapper:
            @staticmethod
            def embed(t): return _v10_embed(t)
            @staticmethod
            def embed_with_pools(t): return _v10_pools(t)
        return _V10Wrapper()
    except Exception:
        pass
    try:
        from .v9v3_embed import V9V3Embedding
        eng = V9V3Embedding()
        if eng.model is not None:
            _embed_engine_name = 'v9v3'
            return eng
    except Exception:
        pass
    _embed_engine_name = '词袋哈希(降级)'
    return None

def get_embed_status():
    """返回当前嵌入引擎状态, 供前端展示"""
    engine = _auto_engine()
    return {
        'engine': _embed_engine_name,
        'is_degraded': _embed_engine_name == '词袋哈希(降级)',
        'warning': '词袋哈希精度低, recall 门槛已自动抬高, 建议配置 V10/v9v3 嵌入引擎' if _embed_engine_name == '词袋哈希(降级)' else None,
    }

def smart_embedding(text, dim=None):
    """
    智能嵌入 — V10优先 → v9v3 → 词袋哈希(降级)
    dim: 默认从config读EMBED_DIM, V10输出1024维不截断
    """
    if dim is None:
        from .config import EMBED_DIM
        dim = EMBED_DIM
    engine = _auto_engine()
    if engine is not None:
        try:
            vec = engine.embed(text)
            if len(vec) >= dim:
                return vec[:dim]
            return vec + [0.0] * (dim - len(vec))
        except Exception:
            pass
    return _bag_hash_embed(text, dim)

def smart_embedding_with_pools(text):
    """
    
    返回: {'embedding': [...], 'fast_pool': [...], 'medium_pool': [...], 'slow_pool': [...]}
    V10嵌入输出1024维 + 24维三速池, 与原v9v3接口兼容
    """
    engine = _auto_engine()
    if engine is not None:
        try:
            result = engine.embed_with_pools(text)
            for key in ('fast_pool', 'medium_pool', 'slow_pool'):
                v = result[key]
                if len(v) >= SP_DIM:
                    result[key] = v[:SP_DIM]
                else:
                    result[key] = v + [0.0] * (SP_DIM - len(v))
            return result
        except Exception:
            pass
    # 降级: 词袋哈希 + 模拟池
    emb = _bag_hash_embed(text, SP_DIM)
    return {
        'embedding': emb,
        'fast_pool': list(emb),
        'medium_pool': [v * 0.5 for v in emb],
        'slow_pool': [v * 0.1 for v in emb],
    }

def _bag_hash_embed(text, dim=128):
    """词袋哈希嵌入 — 降级方案"""
    emb = [0.0] * dim
    words = []
    for w in text.lower().split():
        words.append(w)
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff':
            words.append(ch)
    for w in words:
        h = hashlib.md5(w.encode('utf-8')).hexdigest()
        idx = int(h[:8], 16) % dim
        emb[idx] += 1.0
    norm = math.sqrt(sum(x * x for x in emb))
    if norm > 1e-9:
        emb = [x / norm for x in emb]
    return emb


def _cosine_similarity(a, b):
    """余弦相似度 — numpy加速(1024维快10x+)"""
    try:
        import numpy as _np
        va = _np.array(a)
        vb = _np.array(b)
        d = _np.dot(va, vb)
        na = _np.linalg.norm(va)
        nb = _np.linalg.norm(vb)
        if na < 1e-9 or nb < 1e-9:
            return 0.0
        return float(d / (na * nb))
    except Exception:
        # numpy不可用时回退纯Python
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        if norm_a < 1e-9 or norm_b < 1e-9:
            return 0.0
        return dot / (norm_a * norm_b)

# 向后兼容
cosine_similarity = _cosine_similarity
simple_embedding = smart_embedding


class KnowledgeNode:
    """知识树节点 — 三速池记忆"""

    def __init__(self, node_id, topic, content='', parent_id=None, depth=0, source=''):
        self.id = node_id
        self.parent_id = parent_id
        self.children_ids = []
        self.topic = topic
        self.content = content
        self.fast_pool = [0.0] * SP_DIM
        self.medium_pool = [0.0] * SP_DIM
        self.slow_pool = [0.0] * SP_DIM
        self.embedding = None
        self.depth = depth
        self.hit_count = 0
        self.is_dying = False
        self.created_at = time.time()
        self.last_accessed = time.time()
        self.source = source  # 知识来源: 'local'/'web'/'manual'/'teacher'/''

    def update_pools(self, signal, decay_fast=0.5, decay_medium=0.9, decay_slow=0.999):
        """三速池 EMA 更新"""
        for i in range(min(len(signal), SP_DIM)):
            self.fast_pool[i] = decay_fast * self.fast_pool[i] + (1 - decay_fast) * signal[i]
            self.medium_pool[i] = decay_medium * self.medium_pool[i] + (1 - decay_medium) * signal[i]
            self.slow_pool[i] = decay_slow * self.slow_pool[i] + (1 - decay_slow) * signal[i]

    def fusion_read(self):
        """三池融合读取 — 深度加权"""
        depth_decay = 0.8 ** self.depth
        result = [0.0] * SP_DIM
        for i in range(SP_DIM):
            result[i] = (
                0.6 * self.fast_pool[i] +
                0.3 * self.medium_pool[i] +
                0.1 * self.slow_pool[i]
            ) * depth_decay
        return result

    def to_dict(self):
        # 优化存储: 只保存必要字段，压缩大字段
        d = {
            'id': self.id, 'parent_id': self.parent_id,
            'children_ids': self.children_ids, 'topic': self.topic,
            'depth': self.depth, 'hit_count': self.hit_count,
            'is_dying': self.is_dying, 'created_at': self.created_at,
            'last_accessed': self.last_accessed, 'source': self.source,
        }
        # 保存内容摘要 (不超过2000字符)
        if self.content:
            d['content'] = self.content[:2000]
        
        # 嵌入向量只保存关键部分
        if self.embedding:
            d['embedding'] = self.embedding[:128]  # 只保存前128维
        
        # 三速池保持原样 (很小，只有72维)
        d['fast_pool'] = self.fast_pool
        d['medium_pool'] = self.medium_pool
        d['slow_pool'] = self.slow_pool
        
        return d


class KnowledgeTree:
    """知识树 — 树形记忆 + 三速池 + 余弦检索"""

    def __init__(self, storage_path='data/knowledge_tree.json'):
        self.nodes = {}
        self.root = None
        self._id_counter = 0
        self._topic_index = {}  # topic -> node_id (快速索引)
        self.storage_path = Path(storage_path)
        self._dirty = False            # 脏标记: 有修改未保存
        self._save_pending = 0         # 待保存计数 (批量保存)
        self._embed_cache = {}         # 嵌入缓存: node_id → embedding
        self._cache_valid = False      # 缓存是否有效
        self._load()

    def _gen_id(self):
        self._id_counter += 1
        return f'kn_{self._id_counter}_{int(time.time()*1000)%100000}'

    def _load(self):
        """从文件加载"""
        self._topic_index = {}  # 清空并重建索引
        if not self.storage_path.exists():
            self.root = KnowledgeNode('root', '知识根节点', 'root', depth=0)
            self.nodes['root'] = self.root
            return
        try:
            data = json.loads(self.storage_path.read_text('utf-8'))
            for nd in data.get('nodes', []):
                node = KnowledgeNode(
                    nd['id'], nd['topic'], nd.get('content', ''),
                    nd.get('parent_id'), nd.get('depth', 0),
                    source=nd.get('source', '')
                )
                node.children_ids = nd.get('children_ids', [])
                node.hit_count = nd.get('hit_count', 0)
                node.is_dying = nd.get('is_dying', False)
                node.embedding = nd.get('embedding')
                node.fast_pool = nd.get('fast_pool', [0.0]*SP_DIM)
                node.medium_pool = nd.get('medium_pool', [0.0]*SP_DIM)
                node.slow_pool = nd.get('slow_pool', [0.0]*SP_DIM)
                self.nodes[node.id] = node
                self._topic_index[node.topic] = node.id  # 建立索引
            root_id = data.get('rootId', 'root')
            self.root = self.nodes.get(root_id)
            if not self.root:
                self.root = KnowledgeNode('root', '知识根节点', 'root', depth=0)
                self.nodes['root'] = self.root
            logger_msg = f'已加载 {len(self.nodes)} 个节点'
            print(f'[KnowledgeTree] {logger_msg}')
        except Exception as e:
            print(f'[KnowledgeTree] 加载失败: {e}，创建新树')
            self.root = KnowledgeNode('root', '知识根节点', 'root', depth=0)
            self.nodes['root'] = self.root

    def _mark_dirty(self):
        """标记脏并批量保存 (累计 N 次 recall 后写一次磁盘)"""
        self._dirty = True
        self._save_pending += 1
        if self._save_pending >= 10:  # 每 10 次修改攒一波
            self.save()

    def save(self, force=False):
        """持久化到文件 — 脏标记+延迟保存: 只在真正修改后保存, 避免recall每次都写磁盘"""
        if not force and not self._dirty:
            return  # 没修改, 跳过
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        data = {
            'version': '1.0.0',
            'updatedAt': time.time(),
            'rootId': self.root.id,
            'nodes': [n.to_dict() for n in self.nodes.values()],
            'metadata': {
                'totalNodes': len(self.nodes),
                'totalHits': sum(n.hit_count for n in self.nodes.values()),
            }
        }
        self.storage_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), 'utf-8')
        self._dirty = False

    def flush(self):
        """强制刷盘 — 做梦/退出时调用, 确保脏数据不丢"""
        self.save(force=True)

    def batch_learn(self, items, batch_size=100):
        """批量学习 — 高性能插入大量知识
        
        items: [(topic, content, parent_id), ...]
        batch_size: 每批保存次数
        """
        for i, (topic, content, parent_id) in enumerate(items):
            self.learn(topic, content, parent_id)
            # 每 batch_size 条保存一次
            if (i + 1) % batch_size == 0:
                self.save()
        # 最后强制保存剩余
        self.flush()

    def learn(self, topic, content, parent_id=None, source='manual'):
        """学习新知识 — 创建节点 + 语义嵌入 + v9v3池 + 自动分类
        
        性能优化: 批量保存，避免每次学习都写盘
        存储优化: 精简存储，只保留必要字段
        """
        # 去重检查 (快速路径)
        if topic in self._topic_index:
            return None  # 重复主题，跳过
        
        # 自动分类
        if parent_id is None:
            parent_id = self._auto_classify(topic, content)
        parent = self.nodes.get(parent_id)
        depth = (parent.depth + 1) if parent else 0

        node = KnowledgeNode(self._gen_id(), topic, content, parent_id, depth, source=source)
        
        # 用v9v3生成语义嵌入 + 三速池状态
        pools = smart_embedding_with_pools(topic + ' ' + content[:200])
        node.embedding = pools['embedding']
        node.fast_pool = pools['fast_pool']
        node.medium_pool = pools['medium_pool']
        node.slow_pool = pools['slow_pool']

        self.nodes[node.id] = node
        if parent:
            parent.children_ids.append(node.id)
        self._topic_index[topic] = node.id
        
        # 标记脏，但不立即保存 (批量保存)
        self._dirty = True
        self._cache_valid = False
        return node

    def merge_knowledge(self, topic, new_content, source='manual'):
        """
        新知识比旧知识更全面时智能合并 — 不新增重复节点, 不丢旧命中

        策略:
          1. 找同 topic 旧节点, 没有就直接 learn 新建
          2. 有旧节点: 新 content 更长更全面 → 更新 content + 重算 embedding
             保留旧节点的 hit_count/parent_id/children_ids (不丢历史)
          3. 新 content 更短或差不多 → 不动 (旧的可能被命中过更有价值)
        返回 (节点, 动作): 动作='created'/'merged'/'kept'
        """
        old = None
        for n in self.nodes.values():
            if n.topic == topic and n.id != 'root':
                old = n
                break
        if not old:
            node = self.learn(topic, new_content, None, source=source)
            return node, 'created'
        old_len = len(old.content or '')
        new_len = len(new_content or '')
        if new_len > old_len * 1.3:  # 新的明显更长更全面
            old.content = new_content
            if source:
                old.source = source
            try:
                pools = smart_embedding_with_pools(topic + ' ' + new_content[:200])
                old.embedding = pools['embedding']
                old.fast_pool = pools['fast_pool']
                old.medium_pool = pools['medium_pool']
                old.slow_pool = pools['slow_pool']
            except Exception:
                pass
            old.last_accessed = time.time()
            self._dirty = True
            self._cache_valid = False
            self.save()
            return old, 'merged'
        elif new_len > 0:  # 即使不更新，也更新source
            if source and not old.source:
                old.source = source
                self._dirty = True
                self.save()
        return old, 'kept'

    def import_node(self, topic, content, parent_id=None,
                    embedding=None, fast_pool=None, medium_pool=None,
                    slow_pool=None, hit_count=0, source_tag=''):
        """
        从外部知识树迁移一个节点进来 — 复用源 embedding (维度匹配时), 否则重算

        与 learn 的区别:
          - learn 总是重算 embedding (用于新学知识)
          - import_node 优先复用源 embedding (迁移快), 维度不匹配才重算
          - 同样只增不改不删, 不动现有节点
        """
        if parent_id is None:
            parent_id = self.root.id
        parent = self.nodes.get(parent_id)
        depth = (parent.depth + 1) if parent else 0

        node = KnowledgeNode(self._gen_id(), topic, content, parent_id, depth, source=source_tag or 'import')
        # 带来源标记, 将来能识别哪些是迁移来的
        if source_tag:
            node.content = f'[{source_tag}] {content}' if content else f'[{source_tag}]'

        # embedding: 源有的话先看维度, 1024 维(V10)直接复用, 否则重算
        if embedding and isinstance(embedding, list) and len(embedding) == 1024:
            node.embedding = embedding
        else:
            pools = smart_embedding_with_pools(topic + ' ' + (content or '')[:200])
            node.embedding = pools['embedding']

        # 三速池: 源有的话复用 (截/补到 SP_DIM=24), 否则从 embedding 切片
        for name, src in [('fast_pool', fast_pool), ('medium_pool', medium_pool), ('slow_pool', slow_pool)]:
            if src and isinstance(src, list) and len(src) > 0:
                v = src[:SP_DIM] if len(src) >= SP_DIM else src + [0.0] * (SP_DIM - len(src))
                setattr(node, name, v)
            else:
                # 没源池就从 embedding 前 24 维近似
                emb = node.embedding or [0.0] * SP_DIM
                setattr(node, name, list(emb[:SP_DIM]))

        node.hit_count = hit_count or 0

        self.nodes[node.id] = node
        if parent:
            parent.children_ids.append(node.id)

        self._dirty = True
        self._cache_valid = False
        self.save()
        return node

    def recall(self, query, top_k=5, min_score=0.25, min_topic_len=2):
        """检索知识 — numpy批量余弦相似度 + 嵌入缓存 + query缓存 + 脏标记延迟保存"""
        # query嵌入缓存: 相同query不重复算
        from .config import EMBED_CACHE_SIZE
        cache_key = query[:50]
        if cache_key in self._embed_cache.get('__queries__', {}):
            query_emb = self._embed_cache['__queries__'][cache_key]
        else:
            query_emb = smart_embedding(query)
            if '__queries__' not in self._embed_cache:
                self._embed_cache['__queries__'] = {}
            self._embed_cache['__queries__'][cache_key] = query_emb
            # LRU: 超限清一半
            if len(self._embed_cache['__queries__']) > EMBED_CACHE_SIZE:
                keys = list(self._embed_cache['__queries__'].keys())
                for k in keys[:len(keys)//2]:
                    del self._embed_cache['__queries__'][k]
        # 构建嵌入矩阵 (只在缓存失效时重建)
        if not self._cache_valid:
            self._embed_cache = {}
            for node in self.nodes.values():
                if node.id == 'root':
                    continue
                self._embed_cache[node.id] = node.embedding or smart_embedding(node.topic + ' ' + node.content[:200])
            self._cache_valid = True
        # 收集候选节点
        candidates = []
        for node in self.nodes.values():
            if node.id == 'root':
                continue
            topic_clean = (node.topic or '').replace('老师教: ', '').strip()
            if len(topic_clean) < min_topic_len:
                continue
            node_emb = self._embed_cache.get(node.id)
            if node_emb is None:
                node_emb = smart_embedding(node.topic + ' ' + node.content[:200])
                self._embed_cache[node.id] = node_emb
            candidates.append((node, node_emb))
        if not candidates:
            return []
        # numpy批量余弦相似度 (一次矩阵运算代替逐节点循环)
        try:
            import numpy as _np
            q_vec = _np.array(query_emb)
            q_norm = _np.linalg.norm(q_vec)
            if q_norm < 1e-9:
                return []
            q_unit = q_vec / q_norm
            # 构建矩阵: shape=(n_nodes, dim)
            mat = _np.array([emb for _, emb in candidates])
            norms = _np.linalg.norm(mat, axis=1)
            norms[norms < 1e-9] = 1.0
            mat_unit = mat / norms[:, None]
            sims = mat_unit @ q_unit  # 批量余弦相似度, shape=(n_nodes,)
        except Exception:
            # numpy不可用时回退逐个算
            sims = [_cosine_similarity(query_emb, emb) for _, emb in candidates]
        # 计算综合分
        results = []
        for i, (node, _) in enumerate(candidates):
            sim = float(sims[i])
            depth_weight = 1.0 / (1.0 + node.depth * 0.2)
            hit_weight = 1.0 + math.log1p(node.hit_count) * 0.1
            score = sim * depth_weight * hit_weight
            results.append({
                'node_id': node.id, 'topic': node.topic,
                'content': node.content, 'similarity': sim,
                'score': score, 'depth': node.depth,
                'hit_count': node.hit_count,
            })
        results.sort(key=lambda x: x['score'], reverse=True)
        results = [r for r in results if r['score'] >= min_score]
        for r in results[:top_k]:
            n = self.nodes.get(r['node_id'])
            if n:
                n.hit_count += 1
                n.last_accessed = time.time()
                self._mark_dirty()
        return results[:top_k]

    def prune_junk(self, max_junk=50):
        """清理垃圾节点 — 删除施工/百科杂条/代码碎片/重复/损坏/hits=0垃圾

        max_junk: 最多删多少个 (防一次删太猛)
        返回: 删掉的节点 id 列表
        """
        from .config import JUNK_KEYWORDS, SCIENCE_PROTECT_KEYWORDS
        to_delete = []
        seen_topics = {}

        for nid, node in self.nodes.items():
            if nid == 'root':
                continue
            topic = (node.topic or '').strip()
            content = (node.content or '').strip()

            # 重复 topic (保留 hits 最高的)
            if topic in seen_topics:
                prev_id = seen_topics[topic]
                prev = self.nodes.get(prev_id)
                if prev and (prev.hit_count >= node.hit_count):
                    to_delete.append(nid)
                    continue
                else:
                    to_delete.append(prev_id)
            seen_topics[topic] = nid

            # 施工数据 (即使 hits>0 也删)
            if any(k in topic for k in ['开挖','脚手架','浇筑','砌筑','抹灰','打桩','钢筋绑扎','模板安装']):
                to_delete.append(nid)
                continue

            # 百科杂条: content 含旅游/食品/地理字段
            baike_fields = ['是否含防腐剂','门票价格','所属城市','所属国家','邮政区码',
                            '开放时间','著名景点','建议游玩时长']
            if any(k in content[:200] for k in baike_fields):
                to_delete.append(nid)
                continue

            # 数据损坏: topic 和 content 不匹配
            is_mismatch = False
            mismatch_pairs = [
                (['深度学习','机器学习','神经网络','AI'],
                 ['Kubernetes','Docker','Terraform','Ansible','Jenkins','nginx','Ingress','Pod','HPA','VPA','CSI']),
                (['量子计算'], ['React','Vue','Express','MySQL','MongoDB']),
            ]
            for topic_kw, content_kw in mismatch_pairs:
                if any(k in topic for k in topic_kw) and any(k in content[:300] for k in content_kw):
                    is_mismatch = True
                    break
            if is_mismatch:
                to_delete.append(nid)
                continue

            # 以下只删 hits=0 的 (被用过的保留)
            if node.hit_count > 0:
                continue

            # 太短
            if len(topic) < 2 or len(content) < 20:
                to_delete.append(nid)
                continue

            # ownthink 百科杂条 ("描述:"/"别名:" 开头且非科学)
            junk_prefixes = ['描述:', '别名:', '中文名称:', '外文名称:']
            if any(content.startswith(p) for p in junk_prefixes):
                science_kw = ['物理','化学','生物','数学','天文','遗传','细胞',
                              '免疫','药理','分子','量子','相对论','统计','粒子',
                              '算法','编程','开发','数据库','网络','深度学习','机器学习']
                if not any(k in topic or k in content[:100] for k in SCIENCE_PROTECT_KEYWORDS):
                    to_delete.append(nid)
                    continue

            # 代码碎片 / 通用垃圾关键词
            if any(k in content[:50] for k in JUNK_KEYWORDS):
                to_delete.append(nid)
                continue

            # 纯英文长标题无中文
            cn = sum(1 for c in topic if '\u4e00' <= c <= '\u9fff')
            if len(topic) > 10 and cn == 0:
                to_delete.append(nid)
                continue

            # 占位符
            if topic.lower() in {'测试','test','todo','tmp','temp','未命名','新建','迁移知识'}:
                to_delete.append(nid)
                continue

        # 限制删除数量
        to_delete = to_delete[:max_junk]

        # 执行删除
        for nid in to_delete:
            node = self.nodes.get(nid)
            if not node:
                continue
            parent = self.nodes.get(node.parent_id)
            if parent and nid in parent.children_ids:
                parent.children_ids.remove(nid)
            for child_id in node.children_ids:
                child = self.nodes.get(child_id)
                if child:
                    child.parent_id = node.parent_id
                    if parent:
                        parent.children_ids.append(child_id)
            del self.nodes[nid]

        if to_delete:
            self.save()
        return to_delete

    def get_stats(self):
        # 按来源统计
        by_source = {}
        for n in self.nodes.values():
            s = n.source or 'unknown'
            by_source[s] = by_source.get(s, 0) + 1
        return {
            'total_nodes': len(self.nodes),
            'total_hits': sum(n.hit_count for n in self.nodes.values()),
            'max_depth': max((n.depth for n in self.nodes.values()), default=0),
            'dying_nodes': sum(1 for n in self.nodes.values() if n.is_dying),
            'by_source': by_source,
        }

    def _auto_classify(self, topic, content):
        """自动分类 — 按语义相似度把新节点挂到最匹配的分类父节点下"""
        # 找所有 depth=1 的分类节点
        cats = [n for n in self.nodes.values() if n.depth == 1 and n.id != 'root']
        if not cats:
            return self.root.id
        text = (topic or '') + ' ' + (content or '')[:200]
        text_emb = smart_embedding(text)
        best_id = self.root.id
        best_sim = 0.15  # 最低门槛, 不够就挂root
        for cat in cats:
            cat_emb = cat.embedding or smart_embedding(cat.topic)
            sim = _cosine_similarity(text_emb, cat_emb)
            if sim > best_sim:
                best_sim = sim
                best_id = cat.id
        return best_id

    def reembed_all(self):
        """重嵌入所有节点 — V10维度变更后调用, 旧128维节点重算为1024维"""
        from .config import EMBED_DIM
        changed = 0
        for node in self.nodes.values():
            if node.id == 'root':
                continue
            old_dim = len(node.embedding) if node.embedding else 0
            if old_dim != EMBED_DIM:
                try:
                    pools = smart_embedding_with_pools(node.topic + ' ' + (node.content or '')[:200])
                    node.embedding = pools['embedding']
                    node.fast_pool = pools['fast_pool']
                    node.medium_pool = pools['medium_pool']
                    node.slow_pool = pools['slow_pool']
                    changed += 1
                except Exception:
                    pass
        if changed:
            self._dirty = True
            self._cache_valid = False
            self.save()
        return changed

    def get_embed_status(self):
        """返回当前嵌入引擎状态, 供前端展示"""
        return get_embed_status()
