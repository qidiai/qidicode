"""
V9v3 发布保护方案 — 社区版

4层保护:
  1. C源码编译成二进制 — 只给 .so/.dll，不给 .c
  2. 模型权重加密 — 运行时解密，内存中不留明文
  3. API极简化 — 只暴露 encode() 一个接口
  4. 自定义许可证 — 禁止逆向工程
"""
import ctypes
import os
import struct
import hashlib
import platform
import logging

logger = logging.getLogger('V9v3Community')


# ============ 第1层: 二进制分发 ============
# 只给编译好的动态库, 不给C源码
# 社区版C接口极简, 隐藏内部结构

V9V3_COMMUNITY_C = r"""
/* v9v3_community.c — 社区版API
 * 只暴露3个函数, 内部实现全部隐藏
 * 编译: gcc -O2 -shared -fPIC -o libv9v3.so v9v3_community.c -lm
 */
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* 内部结构体 — 不暴露给头文件 */
typedef struct {
    void* internal;  /* 不透明指针, 外部无法访问 */
} V9v3Handle;

/* 模型权重 — 运行时解密加载 */
static float* g_weights = NULL;
static int g_initialized = 0;

/* ============ 社区版API (只暴露这3个) ============ */

/* 初始化: 加载加密模型 */
int v9v3_init(const char* model_path, const char* key);

/* 推理: 文本 → 向量 (唯一的核心接口) */
int v9v3_encode(const char* text, float* out_vec, int out_dim);

/* 释放资源 */
void v9v3_free(void);
"""


# ============ 第2层: 权重加密 ============

def encrypt_weights(input_baize_path, output_path, password):
    """
    加密 .baize 权重文件
    
    方法: XOR流加密 + SHA256密钥派生
    - 没有密码无法解密
    - 每次加密密钥流不同(加盐)
    - 性能开销极小(解密<1ms)
    """
    with open(input_baize_path, 'rb') as f:
        data = bytearray(f.read())
    
    # 从密码派生密钥
    salt = os.urandom(16)  # 随机盐
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    
    # XOR流加密
    key_stream = _generate_keystream(key, len(data))
    for i in range(len(data)):
        data[i] ^= key_stream[i % len(key_stream)]
    
    # 写入: 魔数 + 盐 + 加密数据
    with open(output_path, 'wb') as f:
        f.write(b'V9E1')  # 魔数: V9v3 Encrypted v1
        f.write(salt)
        f.write(struct.pack('!I', len(data)))
        f.write(data)
    
    print(f'[加密] {input_baize_path} → {output_path} ({len(data)} bytes)')
    return output_path


def _generate_keystream(key, length):
    """生成密钥流 — SHA256循环哈希"""
    stream = bytearray()
    current = key
    while len(stream) < length:
        current = hashlib.sha256(current).digest()
        stream.extend(current)
    return bytes(stream[:length])


def decrypt_weights(encrypted_path, password):
    """运行时解密 — 只在内存中存在明文"""
    with open(encrypted_path, 'rb') as f:
        magic = f.read(4)
        if magic != b'V9E1':
            raise ValueError('不是加密的V9v3模型文件')
        salt = f.read(16)
        data_len = struct.unpack('!I', f.read(4))[0]
        data = bytearray(f.read(data_len))
    
    # 派生密钥
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    
    # XOR解密
    key_stream = _generate_keystream(key, len(data))
    for i in range(len(data)):
        data[i] ^= key_stream[i % len(key_stream)]
    
    return bytes(data)  # 明文只在内存中, 不写磁盘


# ============ 第3层: 社区版API包装 ============

class V9v3Community:
    """
    V9v3 社区版 — 极简API
    
    只暴露一个功能: 文本 → 语义向量
    内部结构完全隐藏
    """
    
    def __init__(self, model_path, key=None):
        self._lib = None
        self._handle = None
        self._output_dim = 256  # 社区版固定256维
        self._model_path = model_path
        self._key = key
        self._initialized = False
        
        # 尝试加载C库
        self._try_load()
    
    def _try_load(self):
        """加载编译好的二进制库"""
        lib_names = {
            'Windows': ['v9v3_community.dll'],
            'Darwin': ['libv9v3_community.dylib'],
            'Linux': ['libv9v3_community.so'],
        }
        
        base = os.path.dirname(os.path.abspath(__file__))
        for name in lib_names.get(platform.system(), []):
            path = os.path.join(base, name)
            if os.path.exists(path):
                try:
                    self._lib = ctypes.CDLL(path)
                    self._setup_api()
                    # 初始化(传入加密密钥)
                    key_bytes = (self._key or '').encode('utf-8')
                    ret = self._lib.v9v3_init(
                        self._model_path.encode('utf-8'),
                        key_bytes
                    )
                    if ret == 0:
                        self._initialized = True
                    break
                except Exception as e:
                    logger.warning(f'C库加载失败: {e}')
    
    def _setup_api(self):
        """设置API签名 — 只暴露3个函数"""
        self._lib.v9v3_init.restype = ctypes.c_int
        self._lib.v9v3_init.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
        
        self._lib.v9v3_encode.restype = ctypes.c_int
        self._lib.v9v3_encode.argtypes = [
            ctypes.c_char_p,
            ctypes.POINTER(ctypes.c_float),
            ctypes.c_int,
        ]
        
        self._lib.v9v3_free.restype = None
        self._lib.v9v3_free.argtypes = []
    
    def encode(self, text):
        """
        文本 → 语义向量 (社区版唯一接口)
        
        输入: 任意文本
        输出: 256维浮点向量
        """
        if not self._initialized:
            return self._fallback_encode(text)
        
        out = (ctypes.c_float * self._output_dim)()
        n = self._lib.v9v3_encode(
            text.encode('utf-8'), out, self._output_dim
        )
        if n > 0:
            return list(out)[:n]
        return self._fallback_encode(text)
    
    def _fallback_encode(self, text):
        """降级: 词袋哈希(无C库时)"""
        import math, hashlib
        dim = self._output_dim
        emb = [0.0] * dim
        for ch in text:
            h = hashlib.sha256(ch.encode('utf-8')).hexdigest()
            idx = int(h[:8], 16) % dim
            emb[idx] += 1.0
        norm = math.sqrt(sum(x*x for x in emb))
        if norm > 1e-9:
            emb = [x/norm for x in emb]
        return emb
    
    def similarity(self, text_a, text_b):
        """计算两段文本的语义相似度"""
        a = self.encode(text_a)
        b = self.encode(text_b)
        dot = sum(x*y for x,y in zip(a, b))
        na = sum(x*x for x in a) ** 0.5
        nb = sum(x*x for x in b) ** 0.5
        if na < 1e-9 or nb < 1e-9:
            return 0.0
        return dot / (na * nb)
    
    def __del__(self):
        if self._initialized and self._lib:
            try:
                self._lib.v9v3_free()
            except:
                pass


# ============ 第4层: 许可证 ============

LICENSE_TEXT = """
V9v3 Community Edition License
================================

Copyright (c) 2024-2026 All Rights Reserved.

GRANTED:
  - Use this software to generate embeddings
  - Integrate into your applications
  - Share unmodified binary packages

FORBIDDEN:
  - Reverse engineer the model architecture
  - Decompile or disassemble the binary
  - Extract or analyze the model weights
  - Reconstruct the training methodology
  - Remove or modify any license notices
  - Use as a base to create competing models

The internal architecture (including but not limited to
CubicSourcePool, three-speed memory, pheromone routing,
and concept merging) is a TRADE SECRET.

Violations will be prosecuted to the full extent of law.

NO WARRANTY. USE AT YOUR OWN RISK.
"""


def get_license():
    return LICENSE_TEXT


# ============ 发布打包 ============

def create_release_package(
    baize_model_path,
    output_dir='v9v3_community_release',
    password=None,
):
    """
    创建社区版发布包
    
    产出:
      v9v3_community_release/
      ├── lib/v9v3_community.so|dll|dylib   ← 编译好的二进制
      ├── model/v9v3_encrypted.v9e          ← 加密权重
      ├── python/v9v3_community.py          ← Python接口(这个文件)
      ├── LICENSE                           ← 许可证
      ├── README.md                         ← 使用说明
      └── example.py                        ← 示例代码
    """
    import shutil
    
    pkg_dir = os.path.join(output_dir)
    os.makedirs(pkg_dir, exist_ok=True)
    os.makedirs(os.path.join(pkg_dir, 'lib'), exist_ok=True)
    os.makedirs(os.path.join(pkg_dir, 'model'), exist_ok=True)
    os.makedirs(os.path.join(pkg_dir, 'python'), exist_ok=True)
    
    # 1. 加密模型
    if password and os.path.exists(baize_model_path):
        encrypt_weights(
            baize_model_path,
            os.path.join(pkg_dir, 'model', 'v9v3_encrypted.v9e'),
            password,
        )
    
    # 2. 写许可证
    with open(os.path.join(pkg_dir, 'LICENSE'), 'w', encoding='utf-8') as f:
        f.write(LICENSE_TEXT)
    
    # 3. 写README
    readme = """# V9v3 Community Edition

## 快速开始

```python
from v9v3_community import V9v3Community

model = V9v3Community('model/v9v3_encrypted.v9e', key='your-license-key')
vec = model.encode('你好世界')
print(f'向量维度: {len(vec)}')

sim = model.similarity('爬虫失败', 'crawler error')
print(f'相似度: {sim:.3f}')
```

## API

| 方法 | 说明 |
|------|------|
| `encode(text)` | 文本 → 256维语义向量 |
| `similarity(a, b)` | 两段文本的语义相似度 |

## 许可证

见 LICENSE 文件。禁止逆向工程。
"""
    with open(os.path.join(pkg_dir, 'README.md'), 'w', encoding='utf-8') as f:
        f.write(readme)
    
    # 4. 写示例
    example = '''"""V9v3 社区版示例"""
from v9v3_community import V9v3Community

model = V9v3Community('model/v9v3_encrypted.v9e', key='demo')

# 语义嵌入
vec = model.encode("今天天气很好")
print(f"向量: [{vec[0]:.4f}, {vec[1]:.4f}, ...] (256维)")

# 语义相似度
print(f"中英相似度: {model.similarity('爬虫失败', 'crawler error'):.3f}")
print(f"无关相似度: {model.similarity('天气', '编程'):.3f}")
'''
    with open(os.path.join(pkg_dir, 'example.py'), 'w', encoding='utf-8') as f:
        f.write(example)
    
    print(f'\n[发布包] 已创建: {pkg_dir}/')
    print(f'  需要手动放入:')
    print(f'    lib/v9v3_community.so (或 .dll / .dylib)')
    print(f'    model/v9v3_encrypted.v9e (加密权重)')
    if password:
        print(f'  许可证密钥: {password}')
    print(f'\n  分发时只给这个目录, 不给C源码和.baize原文')


if __name__ == '__main__':
    # 演示: 创建发布包
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', help='原始.baize模型路径')
    parser.add_argument('--password', help='加密密码')
    parser.add_argument('--output', default='v9v3_community_release')
    args = parser.parse_args()
    
    if args.model:
        pwd = args.password or hashlib.sha256(
            str(time.time()).encode()
        ).hexdigest()[:16]
        create_release_package(args.model, args.output, pwd)
    else:
        # 无模型时只生成框架
        create_release_package('', args.output)
