"""
生物体 — 自主循环 + 睡眠做梦

知识树 = 身体（记忆/血管）
蠕虫群 = 大脑
蚁群   = 感觉器官
爬虫   = 触角/手脚

自主循环 = 心跳 — 不用人戳，自己活着
睡眠做梦 = 夜间维护 — 不是关机，是整理记忆

白天: 感知 → 思考 → 行动 → 观察 → 反思 → 再感知 → ...
夜晚: 做梦(重放经历) → 巩固记忆 → 修剪废话 → 灵感(偶尔)

睡觉条件:
  - 连续多轮没新任务
  - 饥饿度低（不饿）
  - 目标都完成了
  - 或者强制: 每N轮必须睡一次
"""
import asyncio
import time
import json
import logging
import threading
from pathlib import Path
from datetime import datetime

from .knowledge_tree import KnowledgeTree
from .cube3d import Cube3D, v10_to_cube
from .worm_brain import WormBrain
from .ant_crawler import AntCrawler
from .mycelial_network import MycelialNode
from .local_learner import LocalLearner
from .web_learner import WebLearner
from .config import (WEB_COOLDOWN, WEB_DAILY_LIMIT, ORGANISM_HEARTBEAT,
                     ORGANISM_SLEEP_AFTER, ORGANISM_SLEEP_ROUNDS, ORGANISM_HISTORY_MAX,
                     ORGANISM_LEARNED_HISTORY_MAX, LOCAL_HUNGER_THRESHOLD,
                     PRUNE_DYING_AGE, PRUNE_DYING_HITS, PRUNE_MAX_JUNK)

logger = logging.getLogger('Organism')


class Goal:
    """目标"""

    def __init__(self, description, goal_type='explore', target=None, priority=0.5):
        self.description = description
        self.goal_type = goal_type  # explore / collect / learn / monitor
        self.target = target        # 具体目标（URL、关键词等）
        self.priority = priority
        self.progress = 0.0         # 0~1
        self.created_at = time.time()
        self.sub_goals = []

    def is_done(self):
        return self.progress >= 1.0

    def to_dict(self):
        return {
            'description': self.description,
            'type': self.goal_type,
            'target': self.target,
            'progress': round(self.progress, 3),
            'priority': self.priority,
        }


class Organism:
    """
    生物体 — 自主循环的智能体

    不用人喊，自己会:
    1. 感知环境（蚁群侦察）
    2. 思考（蠕虫群激活扩散）
    3. 行动（爬虫采集 / 学习 / 分析）
    4. 观察结果
    5. 反思（调整大脑连接）
    6. 循环
    """

    def __init__(self, data_dir='data', name='organism_1'):
        self.name = name
        self.body = KnowledgeTree(f'{data_dir}/knowledge_tree.json')   # 身体
        self.cube = Cube3D()                                            # 场域（三维立体矩形）
        self.brain = WormBrain(knowledge_tree=self.body)               # 大脑
        self.senses = AntCrawler(worm_brain=self.brain, knowledge_tree=self.body)  # 感觉+手脚
        self.network_node = None                                        # 菌丝（通信）

        # 本地知识自主学习器 — 吃 E:\训练数据 里的本地资料
        # 前端不能按钮触发, 只在生物体饿了/缺知识时自己吃
        self.local_learner = LocalLearner()
        self.web_learner = WebLearner()  # 联网搜索学习器 (本地不够时补充)
        self._last_learned = None     # 最近自学的一条 (供前端展示)
        self._learned_history = []    # 自学历史 (最近20条, 供前端滚动日志)
        # 联网搜索限流: 防死循环
        self._web_cooldown = WEB_COOLDOWN   # 联网冷却 (秒, 从config)
        self._web_last_time = 0       # 上次联网时间戳
        self._web_daily_limit = WEB_DAILY_LIMIT  # 每日联网上限 (从config)
        self._web_daily_count = 0     # 今日已联网次数
        self._web_daily_date = None   # 今日日期 (用于每日重置)
        self._web_searched_queries = set()  # 已搜过的词 (去重, 不重复搜)
        # 动态自学阈值: 本地可学量 10%, 实例化时预计算
        try:
            avail = self.local_learner.scan()
            total_avail = sum(p.get('total', 0) for p in avail.values()) if isinstance(avail, dict) else 0
            self._learn_threshold = max(100, min(2000, total_avail // 10))
        except Exception:
            self._learn_threshold = 500

        # 目标
        self.goals = []
        self.current_goal = None

        # 循环状态
        self.alive = False
        self.cycle_count = 0
        self.history = []           # 每轮记录
        self.heartbeat_interval = 2.0  # 心跳间隔（秒）

        # 睡眠
        self.awake = True           # 醒着还是睡着
        self.sleep_after_cycles = ORGANISM_SLEEP_AFTER  # 每N轮睡一次 (从config)
        self.sleep_rounds = 0      # 睡了第几轮
        self.dream_log = []        # 做梦记录
        self._idle_streak = 0      # 连续空闲轮数
        self._last_wake_time = time.time()

        # 内部感知
        self._last_success_rate = 0.5
        self._last_load = 0.0
        self._failure_streak = 0

    # ---- 目标管理 ----

    def set_goal(self, description, goal_type='explore', target=None, priority=0.5):
        """设定目标"""
        goal = Goal(description, goal_type, target, priority)
        self.goals.append(goal)
        if self.current_goal is None:
            self.current_goal = goal
        logger.info(f'目标设定: {description} (类型={goal_type}, 优先级={priority})')
        return goal

    def _pick_goal(self):
        """选择目标 — 优先级最高的未完成目标"""
        undone = [g for g in self.goals if not g.is_done()]
        if not undone:
            # 没目标了 → 饥饿驱动，自己找
            self.brain.hunger = min(1.0, self.brain.hunger + 0.1)
            if self.brain.hunger > 0.5:
                goal = self.set_goal(
                    f'饥饿探索 #{self.cycle_count}',
                    goal_type='explore', priority=self.brain.hunger
                )
                return goal
            return None
        # 按优先级选
        undone.sort(key=lambda g: g.priority, reverse=True)
        return undone[0]

    def _update_goal_progress(self, action, success):
        """更新目标进度"""
        if not self.current_goal:
            return
        goal = self.current_goal
        if success:
            if goal.goal_type == 'explore':
                goal.progress = min(1.0, goal.progress + 0.15)
            elif goal.goal_type == 'collect':
                goal.progress = min(1.0, goal.progress + 0.1)
            elif goal.goal_type == 'learn':
                goal.progress = min(1.0, goal.progress + 0.2)
            elif goal.goal_type == 'monitor':
                goal.progress = min(1.0, goal.progress + 0.05)
        if goal.is_done():
            logger.info(f'目标完成: {goal.description}')

    # ---- 睡眠与做梦 ----

    def _should_sleep(self):
        """该不该睡？"""
        # 强制: 每N轮必须睡
        if self.cycle_count > 0 and self.cycle_count % self.sleep_after_cycles == 0:
            return True
        # 空闲: 连续多轮没新任务
        if self._idle_streak >= 5:
            return True
        # 目标全完成 + 不饿
        all_done = all(g.is_done() for g in self.goals) if self.goals else True
        if all_done and self.brain.hunger < 0.3:
            return True
        return False

    def _sleep(self):
        """入睡"""
        self.awake = False
        self.sleep_rounds = 0
        logger.info(f'{self.name} 入睡...')

    def _dream(self):
        """
        做梦 — 不是关机，是夜间维护

        做梦做什么:
        1. 重放: 随机抽取白天经历，重新激活，加强重要记忆
        2. 巩固: 知识树节点 hit_count 高的 → 加强 baseline
        3. 修剪: hit_count 极低 + 很久没访问的 → 标记 dying
        4. 灵感: 随机激活几个不相关的概念，看能不能产生新连接
        """
        self.sleep_rounds += 1
        dream_record = {'round': self.sleep_rounds, 'events': []}

        # 1. 重放: 从历史中随机抽一条，重新走一遍激活
        if self.history:
            idx = min(len(self.history) - 1, int(abs(hash(str(time.time()) + str(self.sleep_rounds))) % len(self.history)))
            old = self.history[idx]
            decision = old.get('decision')
            if decision:
                # 重新激活这个决策相关的概念
                self.brain.swarm.think({decision: 0.5}, rounds=2, decay=0.5)
                dream_record['events'].append(f'重放: {decision}')
                # 如果这条经历是成功的，加强连接
                if old.get('outcome', 0) > 0.5:
                    w = self.brain.swarm.get(decision)
                    if w:
                        w.reinforce(0.3)
                        dream_record['events'].append(f'巩固: {decision}')

        # 2. 巩固: 高命中节点的 baseline 提升
        for node in self.body.nodes.values():
            if node.hit_count > 5:
                old_bl = node.hit_count * 0.001
                node.fast_pool = [v * 0.95 for v in node.fast_pool]  # 快池微衰减
                # 中池→慢池 搬运
                for i in range(len(node.slow_pool)):
                    node.slow_pool[i] = 0.98 * node.slow_pool[i] + 0.02 * node.medium_pool[i]
                dream_record['events'].append(f'巩固记忆: {node.topic[:20]}')

        # 3. 修剪: 很久没访问且命中极低的 → dying
        now = time.time()
        pruned = 0
        for node in self.body.nodes.values():
            if node.id == 'root':
                continue
            age = now - node.last_accessed
            if age > PRUNE_DYING_AGE and node.hit_count < PRUNE_DYING_HITS:
                node.is_dying = True
                pruned += 1
        if pruned > 0:
            dream_record['events'].append(f'修剪: {pruned}条记忆标记衰退')

        # 3.5 垃圾清理: 删除 hits=0 的百科杂条/施工/代码碎片/重复节点
        try:
            junk_ids = self.body.prune_junk(max_junk=PRUNE_MAX_JUNK)
            if junk_ids:
                dream_record['events'].append(f'清理垃圾: {len(junk_ids)}条')
                self.body.flush()  # 垃圾清理后强制刷盘
        except Exception as e:
            logger.warning(f'垃圾清理失败: {e}')

        # 4. 灵感: 随机激活2个不相关的概念，看能不能连上新线
        import random
        all_names = [w.name for w in self.brain.swarm.worms.values()]
        if len(all_names) >= 2:
            a, b = random.sample(all_names, 2)
            wa = self.brain.swarm.get(a)
            wb = self.brain.swarm.get(b)
            if wa and wb and wb.id not in wa.links:
                # 从未连接的两个概念，在做梦中随机连上
                # 但只有在做梦重放中它们恰好同时被激活时才连
                if wa.activation > 0.05 and wb.activation > 0.05:
                    strength = min(wa.activation, wb.activation) * 0.3
                    self.brain.swarm.link(a, b, strength)
                    dream_record['events'].append(f'灵感: {a}<->{b} ({strength:.3f})')

        # 5. 清理大脑激活 — 梦境消散
        for w in self.brain.swarm.worms.values():
            w.decay(rate=0.3)  # 快速衰减，梦是模糊的

        self.dream_log.append(dream_record)
        return dream_record

    def _wake(self):
        """醒来"""
        self.awake = True
        self._idle_streak = 0
        self._last_wake_time = time.time()
        logger.info(f'{self.name} 醒来，睡了{self.sleep_rounds}轮')

    # ---- 自主循环 ----

    def _perceive(self):
        """感知 — 蚁群侦察 + 环境状态"""
        # 内部感知
        crawler_status = self.senses.get_status()
        brain_status = self.brain.get_status()
        body_status = self.body.get_stats()

        load = crawler_status.get('tasks_pending', 0) / 100
        knowledge_hits = body_status.get('total_hits', 0)

        # 构建感知信号
        percepts = []
        if load > 0.7:
            percepts.append('high_load')
        elif load < 0.3:
            percepts.append('low_load')

        if self._last_success_rate > 0.7:
            percepts.append('task_success')
        elif self._last_success_rate < 0.3:
            percepts.append('task_failure')

        if brain_status['hunger'] > 0.6:
            percepts.append('high_hunger')
        elif brain_status['hunger'] < 0.3:
            percepts.append('low_hunger')

        # 知识库有无经验
        if knowledge_hits > 10:
            percepts.append('knowledge_hit')
        else:
            percepts.append('knowledge_miss')

        return percepts, {
            'load': load,
            'hunger': brain_status['hunger'],
            'success_rate': self._last_success_rate,
            'knowledge_hits': knowledge_hits,
        }

    def _think(self, percepts, env_data):
        """思考 — 蠕虫群激活扩散"""
        result = self.brain.think(
            percepts=percepts,
            rounds=5,
            **env_data
        )
        return result

    async def _act(self, decision_result):
        """行动 — 大脑决定做什么，手脚去做"""
        decision = decision_result.get('decision')
        if not decision:
            return None

        action = decision['action']
        score = decision['score']
        result = None

        if action == '爬取':
            # 手伸出去爬
            if self.current_goal and self.current_goal.target:
                urls = [self.current_goal.target]
            elif self.senses.pheromone.url_pheromone:
                # 信息素高的URL
                plan = self.senses.pheromone.generate_crawl_plan('', top_k=3)
                urls = plan[:3] if plan else ['https://example.com']
            else:
                urls = ['https://example.com']
            self.senses.add_seed_urls(urls)
            result = await self.senses.run(max_tasks=5)

        elif action == '学习':
            # 把最近经验写入知识树
            if self.senses.crawl_history:
                last = self.senses.crawl_history[-1]
                self.body.learn(
                    topic=f'经验: {last.get("url", "unknown")[:30]}',
                    content=json.dumps(last, ensure_ascii=False, default=str)[:500],
                    source='experience'
                )
            result = {'action': 'learn', 'stored': True}

        elif action == '分析':
            # 分析知识库中的模式
            stats = self.body.get_stats()
            top_concepts = self.brain.swarm.get_active(threshold=0.1)
            self.body.learn(
                topic=f'分析 #{self.cycle_count}',
                content=f'活跃概念: {[c[0] for c in top_concepts[:5]]}, 统计: {stats}',
                source='analysis'
            )
            result = {'action': 'analyze', 'concepts': len(top_concepts)}

        elif action == '整理记忆':
            # 整理知识树 — 清理dying节点
            dying = [n for n in self.body.nodes.values() if n.is_dying]
            result = {'action': '整理记忆', 'dying_count': len(dying)}

        elif action == '休息':
            result = {'action': 'rest', 'duration': 1.0}

        elif action == '换目标':
            # 放弃当前目标，换一个
            if self.current_goal:
                self.current_goal.priority *= 0.5
            self.current_goal = self._pick_goal()
            result = {'action': 'switch_goal', 'new_goal': self.current_goal.description if self.current_goal else None}

        elif action == '求助':
            # 通过菌丝网络求助
            if self.network_node and self.network_node.neighbors:
                result = {'action': '求助', 'neighbors': len(self.network_node.neighbors)}
            else:
                result = {'action': '求助', 'neighbors': 0}

        else:
            # 降速、加速、调度 — 调整参数
            result = {'action': action, 'score': score}

        return result

    def _observe(self, action_result):
        """观察行动结果"""
        if action_result is None:
            return 0.3  # 没行动，低分

        if isinstance(action_result, list):
            # 爬取结果列表
            if not action_result:
                return 0.2
            success_count = sum(1 for r in action_result if isinstance(r, dict) and r.get('success'))
            rate = success_count / len(action_result)
            return rate

        if isinstance(action_result, dict):
            return 0.6 if action_result.get('stored') or action_result.get('action') in ('分析', '整理记忆') else 0.4

        return 0.5

    def _reflect(self, decision_result, outcome_score):
        """反思 — 调整大脑连接"""
        decision = decision_result.get('decision')
        if not decision:
            return

        action = decision['action']
        self.brain.reward(action, outcome_score)

        # 更新目标进度
        success = outcome_score > 0.5
        self._update_goal_progress(action, success)

        if success:
            self._failure_streak = 0
            self._last_success_rate = 0.9 * self._last_success_rate + 0.1
        else:
            self._failure_streak += 1
            self._last_success_rate = 0.9 * self._last_success_rate

        # 危机 → 考虑合体
        if self._failure_streak >= 3 and self.brain._sub_brains:
            logger.info('连续失败，重新合体...')
            for sub in self.brain._sub_brains:
                self.brain.swarm.fuse_with(sub)
            self.brain._sub_brains = []
            self._failure_streak = 0

    # ---- 自学本地知识 ----

    def _self_learn(self):
        """
        自学一条本地知识 → 灌进知识树 + 同步到大脑蠕虫群

        源文件只读 (LocalLearner 不写源), 当前知识树只增不改.
        嵌入走 V10 (body.learn 内部已调 smart_embedding_with_pools), 不碰 ollama.
        返回自学记录 dict, 没东西吃返回 None.
        """
        try:
            learned = self.local_learner.digest_next(self.body)
        except Exception as e:
            logger.warning(f'自学失败: {e}')
            learned = None
        if not learned:
            # 本地吃完了 → 联网搜索补充 (限流防死循环)
            # ① 冷却 5 分钟 ② 每日上限 50 条 ③ 重复词不搜
            try:
                now = time.time()
                today = datetime.now().strftime('%Y-%m-%d')
                if self._web_daily_date != today:
                    self._web_daily_date = today
                    self._web_daily_count = 0
                query = self._pick_web_query()
                can_search = (query
                              and self.web_learner.available()
                              and now - self._web_last_time > self._web_cooldown
                              and self._web_daily_count < self._web_daily_limit
                              and query not in self._web_searched_queries)
                if can_search:
                    self._web_last_time = now
                    self._web_daily_count += 1
                    self._web_searched_queries.add(query)
                    n = self.web_learner.digest(query, self.body)
                    if n > 0:
                        learned = {'parser': 'web', 'topic': query,
                                   'source': '联网搜索', 'parent': query, 'node_id': '?'}
            except Exception as e:
                logger.warning(f'联网学习失败: {e}')
            return learned
        # 同步到大脑: 为新学的 topic 生成一条蠕虫, 类型 'self-taught'
        topic = learned.get('topic', '')
        if topic:
            try:
                existing = self.brain.swarm.get(topic)
                if not existing:
                    self.brain.swarm.spawn(topic, 'self-taught', 0.3)
                else:
                    # 已存在就激活一下 (hit_count + baseline 抬一点)
                    existing.baseline = min(1.0, existing.baseline + 0.1)
                    existing.last_active = time.time()
            except Exception as e:
                logger.warning(f'蠕虫同步失败: {e}')
        
        self._last_learned = learned
        if learned:
            self._learned_history.append({'topic': learned.get('topic',''),
                                           'parser': learned.get('parser',''),
                                           'source': learned.get('source',''),
                                           'time': datetime.now().strftime('%H:%M:%S')})
            logger.info(f'🧠 自学: [{learned.get("parser")}] {topic[:40]}')
        else:
            logger.debug('无新知识可学')
        
        if len(self._learned_history) > ORGANISM_LEARNED_HISTORY_MAX:
            self._learned_history = self._learned_history[-ORGANISM_LEARNED_HISTORY_MAX:]
        return learned

    def _pick_web_query(self):
        """选联网搜索词: 优先当前目标, 其次最近对话, 最后挑有价值的知识树叶子扩展"""
        if self.current_goal and not self.current_goal.is_done():
            return self.current_goal.description[:30]
        # 最近对话
        try:
            recent = self.history[-5:] if self.history else []
            for h in reversed(recent):
                d = h.get('decision') if isinstance(h, dict) else None
                if d and len(str(d)) > 2:
                    return str(d)[:30]
        except Exception:
            pass
        # 挑有价值的知识树叶子扩展 (跳过垃圾: hits=0/太短/施工/百科杂条)
        try:
            leaves = [n for n in self.body.nodes.values()
                      if n.depth >= 1
                      and not n.children_ids
                      and n.hit_count >= 1       # 被用过至少1次
                      and len(n.topic) >= 3       # topic 不太短
                      and not any(k in n.topic for k in ['开挖','脚手架','浇筑','测试','TODO'])
                      ]
            if leaves:
                import random
                return random.choice(leaves).topic[:30]
        except Exception:
            pass
        return None

    async def _one_cycle(self):
        """一个完整循环: 感知→思考→行动→观察→反思 (或 睡觉→做梦)"""
        self.cycle_count += 1

        # 检查是否该睡了
        if self.awake and self._should_sleep():
            self._sleep()

        # 1.5 自学本地知识 — 无论醒睡都能学 (做梦时也能消化, 做梦就是整理记忆)
        #    触发条件 (满足任一即学, 每轮最多1条):
        #      a. 饿了 (hunger>0.4) — 饥饿驱动, 知识缺口
        #      b. 知识树规模小 (total_nodes < 动态阈值) — 明显无知
        #    动态阈值 = 本地可学总量的 10%, 自适应不同知识源规模
        #    到阈值后停盲目学, 只靠饥饿驱动, 避免无脑全灌
        #    前端无按钮, 纯自主
        self_learn_record = None
        try:
            stats = self.body.get_stats()
            total_nodes = stats.get('total_nodes', 0)
            hunger = self.brain.hunger
            # 阈值在 __init__ 已预计算 (self._learn_threshold)
            if hunger > LOCAL_HUNGER_THRESHOLD or total_nodes < self._learn_threshold:
                self_learn_record = self._self_learn()
        except Exception as e:
            logger.warning(f'自学触发失败: {e}')

        if not self.awake:
            # 睡觉中 → 做梦
            dream = self._dream()
            # 做几轮梦就醒
            if self.sleep_rounds >= ORGANISM_SLEEP_ROUNDS:
                self._wake()
            cycle_record = {
                'cycle': self.cycle_count,
                'phase': 'dream',
                'dream_events': dream.get('events', []),
                'hunger': round(self.brain.hunger, 3),
                'time': datetime.now().isoformat(),
            }
            if self_learn_record:
                cycle_record['self_learn'] = self_learn_record
            self.history.append(cycle_record)
            if len(self.history) > ORGANISM_HISTORY_MAX:
                self.history = self.history[-ORGANISM_HISTORY_MAX:]
            return cycle_record

        # 醒着 → 正常循环
        # 2. 选择目标
        if not self.current_goal or self.current_goal.is_done():
            self.current_goal = self._pick_goal()

        # 3. 感知
        percepts, env_data = self._perceive()

        # 4. 思考
        decision_result = self._think(percepts, env_data)

        # 4. 行动
        action_result = await self._act(decision_result)

        # 5. 观察
        outcome = self._observe(action_result)

        # 6. 反思
        self._reflect(decision_result, outcome)

        # 空闲检测
        if outcome < 0.3:
            self._idle_streak += 1
        else:
            self._idle_streak = 0

        # 记录
        cycle_record = {
            'cycle': self.cycle_count,
            'phase': 'awake',
            'goal': self.current_goal.to_dict() if self.current_goal else None,
            'percepts': percepts,
            'decision': decision_result.get('decision', {}).get('action') if decision_result.get('decision') else None,
            'outcome': round(outcome, 3),
            'hunger': round(self.brain.hunger, 3),
            'success_rate': round(self._last_success_rate, 3),
            'time': datetime.now().isoformat(),
        }
        if self_learn_record:
            cycle_record['self_learn'] = self_learn_record
        self.history.append(cycle_record)

        if len(self.history) > 500:
            self.history = self.history[-500:]

        return cycle_record

    async def live(self, max_cycles=None, goal_description=None):
        """
        活着 — 自主循环

        max_cycles: 最多循环几轮（None=无限）
        goal_description: 初始目标描述
        """
        if goal_description:
            self.set_goal(goal_description, goal_type='explore')

        self.alive = True
        logger.info(f'{self.name} 开始活着...')

        try:
            while self.alive:
                if max_cycles and self.cycle_count >= max_cycles:
                    logger.info(f'达到最大循环数 {max_cycles}，停止')
                    break

                record = await self._one_cycle()
                self._print_cycle(record)

                # 心跳间隔
                await asyncio.sleep(self.heartbeat_interval)

        except KeyboardInterrupt:
            logger.info('被中断，停止')
        finally:
            self.die()

    def _print_cycle(self, record):
        """打印循环摘要"""
        phase = record.get('phase', 'awake')
        if phase == 'dream':
            events = record.get('dream_events', [])
            events_str = ', '.join(events[:3]) if events else '(无梦)'
            print(f'  [{record["cycle"]:03d}] ~ 做梦: {events_str}')
            return
        decision = record.get('decision', '?')
        outcome = record.get('outcome', 0)
        hunger = record.get('hunger', 0)
        goal = record.get('goal', {})
        goal_desc = goal.get('description', '?')[:20] if goal else '?'
        goal_prog = goal.get('progress', 0) if goal else 0
        mark = '+' if outcome > 0.5 else '-'
        print(f'  [{record["cycle"]:03d}] {mark} 决策={decision:6s} 结果={outcome:.2f} '
              f'饥饿={hunger:.2f} 目标={goal_desc}({goal_prog:.0%})')

    def die(self):
        """停止 + 持久化"""
        self.alive = False
        self._persist_state()  # 退出前保存状态
        logger.info(f'{self.name} 停止，共循环 {self.cycle_count} 轮')

    def _persist_state(self):
        """持久化生物体状态 — 重启后恢复"""
        try:
            state = {
                'goals': [g.to_dict() for g in self.goals],
                'current_goal_idx': (
                    next(i for i, g in enumerate(self.goals) if g is self.current_goal)
                    if self.current_goal else -1
                ),
                'hunger': self.brain.hunger,
                'success_rate': self._last_success_rate,
                'failure_streak': self._failure_streak,
                'idle_streak': self._idle_streak,
                'web_daily_count': self._web_daily_count,
                'web_daily_date': self._web_daily_date,
                'web_cooldown': self._web_cooldown,
                'web_daily_limit': self._web_daily_limit,
                'web_searched_queries': list(self._web_searched_queries)[:50],  # 最多保留50个
                'cycle_count': self.cycle_count,
            }
            state_path = Path(self.body.storage_path).parent / 'organism_state.json'
            state_path.parent.mkdir(parents=True, exist_ok=True)
            state_path.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
        except Exception as e:
            logger.warning(f'状态持久化失败: {e}')

    def restore_state(self):
        """从文件恢复生物体状态"""
        try:
            state_path = Path(self.body.storage_path).parent / 'organism_state.json'
            if not state_path.exists():
                return False
            data = json.loads(state_path.read_text('utf-8'))
            # 恢复目标
            for gd in data.get('goals', []):
                g = Goal.from_dict(gd)
                self.goals.append(g)
            cidx = data.get('current_goal_idx', -1)
            if 0 <= cidx < len(self.goals):
                self.current_goal = self.goals[cidx]
            # 恢复内部状态
            self.brain.hunger = data.get('hunger', 0.5)
            self._last_success_rate = data.get('success_rate', 0.5)
            self._failure_streak = data.get('failure_streak', 0)
            self._idle_streak = data.get('idle_streak', 0)
            self._web_daily_count = data.get('web_daily_count', 0)
            self._web_daily_date = data.get('web_daily_date')
            self._web_cooldown = data.get('web_cooldown', WEB_COOLDOWN)
            self._web_daily_limit = data.get('web_daily_limit', WEB_DAILY_LIMIT)
            # 恢复已搜索词集合 (从列表还原)
            queried = data.get('web_searched_queries', [])
            if queried:
                self._web_searched_queries = set(queried)
            logger.info('状态已恢复')
            return True
        except Exception as e:
            logger.warning(f'状态恢复失败: {e}')
            return False

    # ---- 菌丝网络 ----

    def start_network(self, port=0):
        self.network_node = MycelialNode(self.name, port=port)
        self.network_node.start()
        return self.network_node.port

    # ---- 状态 ----

    def _learn_summary(self):
        """学习程度汇总 — 给前端直观展示: 总节点/总命中/来源占比/覆盖率"""
        body_stats = self.body.get_stats()
        total_nodes = body_stats.get('total_nodes', 0)
        total_hits = body_stats.get('total_hits', 0)
        max_depth = body_stats.get('max_depth', 0)
        by_source = body_stats.get('by_source', {})  # 节点级来源统计 (持久化)
        local_count = self.local_learner.get_stats().get('learned', 0) if hasattr(self.local_learner, 'get_stats') else 0
        web_count = self.web_learner.get_stats().get('learned', 0)
        # 覆盖率: 有命中的节点占比 (被 recall 命中过的节点 / 总节点)
        hit_nodes = sum(1 for n in self.body.nodes.values() if n.hit_count > 0)
        coverage = round(hit_nodes / total_nodes, 3) if total_nodes > 0 else 0.0
        return {
            'total_nodes': total_nodes,
            'total_hits': total_hits,
            'max_depth': max_depth,
            'hit_nodes': hit_nodes,
            'coverage': coverage,
            'local_learned': local_count,
            'web_learned': web_count,
            'by_source': by_source,
        }

    def get_status(self):
        return {
            'name': self.name,
            'alive': self.alive,
            'cycle': self.cycle_count,
            'hunger': round(self.brain.hunger, 3),
            'success_rate': round(self._last_success_rate, 3),
            'failure_streak': self._failure_streak,
            'current_goal': self.current_goal.to_dict() if self.current_goal else None,
            'goals_done': sum(1 for g in self.goals if g.is_done()),
            'goals_total': len(self.goals),
            'body': self.body.get_stats(),
            'brain': self.brain.get_status(),
            'senses': self.senses.get_status(),
            'self_learn': {
                'available': self.local_learner.available(),
                'last': self._last_learned,
                'history': self._learned_history,
                'stats': self.local_learner.get_stats(),
                'web': self.web_learner.get_stats(),
                # 学习程度汇总 — 直观展示学了多少/来源占比/覆盖率
                'summary': self._learn_summary(),
                # 嵌入引擎状态 — 降级时前端提示
                'embed': self.body.get_embed_status() if hasattr(self.body, 'get_embed_status') else {},
            },
        }
