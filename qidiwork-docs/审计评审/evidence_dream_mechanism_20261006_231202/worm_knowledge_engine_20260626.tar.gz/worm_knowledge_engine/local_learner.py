"""
本地知识自主学习器 — 让生物体主动消化 E:/训练数据 里的本地资料

设计原则:
  1. 源文件只读, 永不写回 (E:/训练数据 是别人的资料, 不能动)
  2. 当前知识树只增不改不删 (只调 body.learn, 不调 update/delete)
  3. 嵌入用已集成的 V10 (smart_embedding_with_pools), 不碰 ollama, 不做摘要
  4. 触发权在生物体自己, 前端不按钮化
  5. 按优先级吃, 不是无脑全灌: 学到命中率上来 / 饥饿下去就停

可学来源 (按优先级):
  1. wikipedia-cn-20230720-filtered.jsonl   维基百科词条
  2. ownthink_v2/ownthink_v2.csv            中文知识图谱 (实体-属性-值)
  3. .hermes/feed_data/小学/初中/高中知识.txt  教材
  4. .hermes/feed_data/*.epub                山海经/道德经/易传/鲁班全书

显式不学 (污染知识树, 注册表里不登记):
  teacher1/*, teacher_vectors/* (训练向量, 不是知识)
  *.pkl, *.zip, *.pdf (二进制/压缩, 改动大后期再补)
  小说 txt (娱乐内容, 占空间无知识价值)
"""
import os
import csv
import json
import time
import logging
import threading
from pathlib import Path

logger = logging.getLogger('LocalLearner')

# ─── 默认本地知识源配置 ─────────────────────────────
DEFAULT_ROOT = r'E:\训练数据'

# ─── 外部知识树源 (只读迁移) ─────────────────────
EXTERNAL_KNOWLEDGE_TREE = r'C:\Users\ASUS\CodeBuddy\Claw\Claw-Assistant\data\knowledge_tree.json'

# ─── 多模态训练数据路径 ─────────────────────
MULTIMODAL_VECTORS_PATH = r'E:\训练数据\teacher_vectors'

# ─── 排除的噪音源 ─────────────────────────────
# ownthink 知识图谱 - 质量太差，全是百科杂条
SKIP_OWNTHINK = True

# 小说/娱乐内容
SKIP_NOVELS = True

# 实验数据/日志/metrics
SKIP_EXPERIMENT_DATA = True

# ─── 进度持久化文件 ─────────────────────────────
PROGRESS_FILE = r'F:\代码\导入数据\闲置算力系统\data\self_learn_progress.json'


# ─── 解析器统一接口 ─────────────────────────────
class KnowledgeParser:
    """所有本地知识解析器的基类"""
    name = 'base'

    def __init__(self, path):
        self.path = Path(path)

    def exists(self):
        return self.path.exists()

    def scan(self):
        """返回可学条数 (不读全文, 只数) — 子类实现"""
        raise NotImplementedError

    def iter_items(self):
        """生成器: 逐条产出 {topic, content, parent_topic, source} — 子类实现"""
        raise NotImplementedError


# ─── 维基百科 jsonl 解析器 ──────────────────────
class WikiJsonlParser(KnowledgeParser):
    """维基百科中文 dump 的 jsonl 格式: 每行一个 {title, text, ...}"""
    name = 'wikipedia'

    def __init__(self, path):
        super().__init__(path)
        self._count = None

    def _iter_lines(self):
        # 用迭代器逐行读, 不一次性加载 (文件可能上 GB)
        with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if line:
                    yield line

    def scan(self):
        if self._count is not None:
            return self._count
        if not self.exists():
            self._count = 0
            return 0
        # 大文件估算 (数行数要几分钟, 估算秒级)
        try:
            size = self.path.stat().st_size
            n = size // 200  # 维基词条平均 200 字节/行
        except Exception as e:
            logger.warning(f'Wiki扫描失败 {self.path}: {e}')
            n = 0
        self._count = n
        logger.info(f'[Wiki] {self.path.name}: ~{n} 条 (估算)')
        return n

    def iter_items(self):
        if not self.exists():
            return
        for line in self._iter_lines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            # 字段自动探测: 维基 dump 常用 title/text, 也有叫 名称/正文 的
            title = (item.get('title') or item.get('名称')
                     or item.get('name') or item.get('Title'))
            text = (item.get('text') or item.get('body')
                    or item.get('content') or item.get('正文')
                    or item.get('abstract') or '')
            if not title or not text:
                continue
            # 维基正文可能带 markdown 标记, 简单清一下
            text = text.strip()
            if len(text) < 20:
                continue  # 太短, 没营养
            # 切到合理长度, 避免一个节点撑爆嵌入 (V10 取前 96 字符做 ids, 但内容存全)
            yield {
                'topic': str(title).strip()[:80],
                'content': text[:2000],
                'parent_topic': '维基百科',
                'source': f'wiki:{self.path.name}',
            }


# ─── ownthink 知识图谱 csv 解析器 ───────────────
class OwnthinkCsvParser(KnowledgeParser):
    """ownthink_v2.csv: 实体,属性,值 三列"""
    name = 'ownthink'

    def __init__(self, path):
        super().__init__(path)
        self._count = None

    def scan(self):
        if self._count is not None:
            return self._count
        if not self.exists():
            self._count = 0
            return 0
        try:
            with open(self.path, 'r', encoding='utf-8', errors='ignore') as f:
                # 不数全行 (ownthink csv 几千万行, 数一次要好几分钟)
                # 估个数: 文件大小 / 平均行长 (经验值 80 字节)
                size = self.path.stat().st_size
                n = size // 80
            self._count = n
            logger.info(f'[Ownthink] {self.path.name}: ~{n} 条 (估算)')
        except Exception as e:
            logger.warning(f'Ownthink扫描失败: {e}')
            self._count = 0
        return self._count

    def iter_items(self):
        if not self.exists():
            return
        # 同实体的多行合并成一个节点, 避免知识树被几千万碎片撑爆
        # 用生成器 + 当前缓冲实体, 实体变了就产出
        current_entity = None
        attrs = []
        try:
            with open(self.path, 'r', encoding='utf-8', errors='ignore', newline='') as f:
                reader = csv.reader(f)
                for row in reader:
                    if len(row) < 3:
                        continue
                    entity, attr, value = row[0].strip(), row[1].strip(), row[2].strip()
                    if not entity:
                        continue
                    if current_entity is None:
                        current_entity = entity
                    if entity != current_entity:
                        if attrs:
                            item = self._make_item(current_entity, attrs)
                            if item: yield item
                        current_entity = entity
                        attrs = []
                    attrs.append((attr, value))
                # 收尾
                if current_entity and attrs:
                    item = self._make_item(current_entity, attrs)
                    if item: yield item
        except Exception as e:
            logger.warning(f'Ownthink读取失败: {e}')

    def _make_item(self, entity, attrs):
        # 跳过通用名 (ownthink csv 第一行表头常是"实体"这种)
        if entity in ('实体', '属性', '值', '名称', '描述'):
            return None
        # 把同实体的属性聚成一段可读文本
        lines = [f'{a}: {v}' for a, v in attrs[:30]]  # 限 30 条, 避免过长
        content = '\n'.join(lines)[:2000]
        if len(content) < 5:
            return None
        return {
            'topic': entity[:80],
            'content': content,
            'parent_topic': 'ownthink知识图谱',
            'source': f'ownthink:{self.path.name}',
        }


# ─── 教材 txt 解析器 ────────────────────────────
class TextBookParser(KnowledgeParser):
    """小学/初中/高中知识.txt: 按空行分段, 每段一个节点"""
    name = 'textbook'

    def __init__(self, path):
        super().__init__(path)

    def scan(self):
        if not self.exists():
            return 0
        try:
            text = self.path.read_text('utf-8', errors='ignore')
            # 按空行分段, 数段数
            paras = [p.strip() for p in text.split('\n\n') if p.strip()]
            return len(paras)
        except Exception as e:
            logger.warning(f'TextBook扫描失败 {self.path.name}: {e}')
            return 0

    def iter_items(self):
        if not self.exists():
            return
        try:
            text = self.path.read_text('utf-8', errors='ignore')
        except Exception as e:
            logger.warning(f'TextBook读取失败: {e}')
            return
        # 按空行切块
        for para in text.split('\n\n'):
            para = para.strip()
            if len(para) < 15:
                continue
            # topic: 取第一行, 去掉可能的标题符号
            first_line = para.split('\n')[0].strip()
            topic = first_line.lstrip('#一二三四五六七八九十、·.- ').strip()[:60]
            if not topic:
                topic = self.path.stem + '片段'
            yield {
                'topic': topic,
                'content': para[:1500],
                'parent_topic': self.path.stem,  # 小学知识/初中部分/高中部分
                'source': f'textbook:{self.path.name}',
            }


# ─── epub 电子书解析器 ──────────────────────────
class EpubBookParser(KnowledgeParser):
    """山海经/道德经/易传/鲁班全书.epub: 按章节切块"""
    name = 'epub'

    def __init__(self, path):
        super().__init__(path)

    def exists(self):
        return self.path.exists()

    def _extract_chapters(self):
        # epub 是 zip, 里面是 xhtml. 用 zipfile + 简单正则抽文本, 不依赖 ebooklib
        import zipfile
        import re
        chapters = []
        try:
            with zipfile.ZipFile(self.path, 'r') as zf:
                html_files = [n for n in zf.namelist()
                              if n.endswith(('.xhtml', '.html', '.htm'))]
                for hf in html_files:
                    try:
                        raw = zf.read(hf).decode('utf-8', errors='ignore')
                    except Exception:
                        continue
                    # 去 HTML 标签
                    text = re.sub(r'<[^>]+>', ' ', raw)
                    text = re.sub(r'\s+', ' ', text).strip()
                    if len(text) > 50:
                        chapters.append((hf, text))
        except Exception as e:
            logger.warning(f'Epub解析失败 {self.path.name}: {e}')
        return chapters

    def scan(self):
        if not self.exists():
            return 0
        return len(self._extract_chapters())

    def iter_items(self):
        if not self.exists():
            return
        book_title = self.path.stem  # 山海经/道德经/...
        for hf, text in self._extract_chapters():
            # 章节名: 取文件名, 去扩展名和路径
            ch_name = Path(hf).stem
            if len(text) < 50:
                continue
            yield {
                'topic': f'{book_title}·{ch_name}'[:80],
                'content': text[:2000],
                'parent_topic': book_title,
                'source': f'epub:{self.path.name}',
            }


# ─── 通用文件解析器 (txt/md/json/csv) ───────────
class GenericFileParser(KnowledgeParser):
    """吃任意 txt/md/json/csv 文件 — 按段落切块, 文件名做父节点"""
    name = 'files'

    def __init__(self, path):
        super().__init__(path)

    def _read_text(self):
        try:
            return self.path.read_text('utf-8', errors='ignore')
        except Exception:
            return ''

    def scan(self):
        if not self.exists():
            return 0
        text = self._read_text()
        paras = [p.strip() for p in text.split('\n\n') if p.strip() and len(p.strip()) > 15]
        return len(paras) or 1

    def iter_items(self):
        if not self.exists():
            return
        text = self._read_text()
        if not text:
            return
        parent = self.path.stem  # 文件名做父节点
        # json 特殊处理: 试着解析成 dict, 每个顶层 key 一个节点
        if self.path.suffix.lower() == '.json':
            try:
                obj = json.loads(text)
                if isinstance(obj, dict):
                    for k, v in obj.items():
                        content = json.dumps(v, ensure_ascii=False)[:1500] if not isinstance(v, str) else v[:1500]
                        yield {'topic': str(k)[:60], 'content': content, 'parent_topic': parent,
                               'source': f'file:{self.path.name}'}
                    return
            except json.JSONDecodeError:
                pass  # 不是合法 json 就按文本切块
        # csv: 每行一条, 第一行当表头
        if self.path.suffix.lower() == '.csv':
            try:
                import csv as _csv
                with open(self.path, 'r', encoding='utf-8', errors='ignore', newline='') as f:
                    reader = _csv.reader(f)
                    rows = list(reader)
                    if len(rows) < 2:
                        return
                    header = rows[0]
                    for row in rows[1:50]:  # 限 50 行, 避免大 csv 撑爆
                        content = '\n'.join(f'{h}: {v}' for h, v in zip(header, row) if v)
                        if len(content) > 15:
                            yield {'topic': f'{parent}·{row[0][:30]}' if row else parent,
                                   'content': content[:1500], 'parent_topic': parent,
                                   'source': f'file:{self.path.name}'}
                    return
            except Exception:
                pass
        # txt/md: 按空行分段
        for para in text.split('\n\n'):
            para = para.strip()
            if len(para) < 15:
                continue
            first = para.split('\n')[0].strip().lstrip('#一二三四五六七八九十、·.- ').strip()
            topic = (first[:60] if first else parent + '片段')
            yield {'topic': topic, 'content': para[:1500], 'parent_topic': parent,
                   'source': f'file:{self.path.name}'}


# ─── 外部知识树迁移解析器 ───────────────────────
class KnowledgeTreeMigrator(KnowledgeParser):
    """
    从另一份 knowledge_tree.json 整树迁移节点过来

    原版只读不删不减: 只读源 JSON, 不写回; 当前知识树只增不改.
    复用源 embedding (V10 1024维), 维度不匹配才重算.
    保持父子关系: 源父 topic 在当前树找到同名节点就挂上去, 找不到挂 root.
    """
    name = 'knowledge_tree_migrate'

    def __init__(self, path):
        super().__init__(path)
        self._data = None
        self._items = None

    def _load(self):
        if self._data is not None:
            return self._data
        if not self.exists():
            return None
        try:
            self._data = json.loads(self.path.read_text('utf-8', errors='ignore'))
            logger.info(f'[迁移] 源树: {len(self._data.get("nodes", []))} 个节点')
        except Exception as e:
            logger.warning(f'迁移源读取失败: {e}')
            self._data = {}
        return self._data

    def scan(self):
        data = self._load()
        if not data:
            return 0
        # root 不算, 只数实际知识节点
        return max(0, len(data.get('nodes', [])) - 1)

    def iter_items(self):
        data = self._load()
        if not data:
            return
        nodes = data.get('nodes', [])
        if not nodes:
            return
        # 建 id → node 索引, 用于查父 topic
        id_map = {n.get('id'): n for n in nodes}
        for n in nodes:
            if n.get('id') == 'root' or n.get('id') == data.get('rootId'):
                continue
            topic = (n.get('topic') or '').strip()
            content = n.get('content') or ''
            if not topic:
                continue
            # 源父 topic (用于在当前树找挂载点)
            parent_id = n.get('parent_id')
            parent_topic = ''
            if parent_id and parent_id in id_map:
                parent_topic = (id_map[parent_id].get('topic') or '').strip()
            yield {
                'topic': topic[:80],
                'content': content[:2000],
                'parent_topic': parent_topic or '迁移知识',
                'source': f'migrate:{self.path.name}',
                # 携带源 embedding 和三速池, 让 import_node 复用
                'embedding': n.get('embedding'),
                'fast_pool': n.get('fast_pool'),
                'medium_pool': n.get('medium_pool'),
                'slow_pool': n.get('slow_pool'),
                'hit_count': n.get('hit_count', 0),
            }


# ─── 多模态向量数据解析器 ───────────────────────
class MultimodalVectorParser(KnowledgeParser):
    """从 teacher_vectors 加载向量-文本对，作为高质量知识"""
    name = 'multimodal_vectors'
    
    def __init__(self, path):
        super().__init__(path)
        self._data = None
    
    def _load_data(self):
        if self._data is not None:
            return self._data
        if not self.exists():
            return []
        
        data = []
        try:
            # 只加载前1000条，避免内存爆炸
            count = 0
            for fname in sorted(os.listdir(self.path))[:3]:  # 只取前3个文件
                if fname.endswith('.jsonl'):
                    fpath = os.path.join(self.path, fname)
                    with open(fpath, 'r', encoding='utf-8') as f:
                        for line in f:
                            if count >= 1000:  # 限制总数
                                break
                            try:
                                item = json.loads(line.strip())
                                if 'text' in item and 'teacher_embedding' in item:
                                    data.append(item)
                                    count += 1
                            except json.JSONDecodeError:
                                continue
        except Exception as e:
            logger.warning(f'多模态向量数据加载失败: {e}')
        
        self._data = data
        logger.info(f'[Multimodal] 加载 {len(data)} 条向量-文本对')
        return data
    
    def scan(self):
        return len(self._load_data())
    
    def iter_items(self):
        data = self._load_data()
        for item in data:
            text = item.get('text', '').strip()
            if not text or len(text) < 20:
                continue
            # 生成 topic: 取文本前20字
            topic = text[:20] + '...'
            yield {
                'topic': topic,
                'content': text[:500],  # 保留足够上下文
                'parent_topic': '多模态训练数据',
                'source': f'multimodal:{self.path.name}',
                'embedding': item.get('teacher_embedding'),  # 携带向量
            }


# ─── 本地学习器主类 ─────────────────────────────
class LocalLearner:
    """
    本地知识自主学习器

    生物体饿了/缺知识时调 digest_next(body) 吃一条, 自己往知识树里灌.
    源文件全程只读, 当前知识树只增不改.
    """

    def __init__(self, root_dir=DEFAULT_ROOT):
        self.root_dir = Path(root_dir)
        self.MULTIMODAL_VECTORS_PATH = MULTIMODAL_VECTORS_PATH
        self.EXTERNAL_KNOWLEDGE_TREE = EXTERNAL_KNOWLEDGE_TREE
        # 解析器注册表 (按优先级) — 启动时扫描注册
        self.parsers = []
        self._lock = threading.Lock()        # 多线程安全 (webui 异步循环可能并发)
        self._iterators = {}                  # parser.name -> iter对象 (惰性打开)
        self._learned_count = {}              # parser.name -> 已学条数
        self._last_item = {}                  # parser.name -> 最近学的 topic
        self._scanned = False
        self._build_registry()

    def _build_registry(self):
        """按优先级注册高质量解析器 — 只学对大模型训练有用的知识"""
        root = self.root_dir
        
        # 1. 维基百科 jsonl (最高优先级) - 结构化知识
        for fname in ['wikipedia-cn-20230720-filtered.jsonl',
                      'wikipedia-cn-20230720-filtered.json']:
            p = root / fname
            if p.exists():
                self.parsers.append(WikiJsonlParser(p))
                break
        
        # 2. 多模态向量数据 (如果有)
        if os.path.exists(self.MULTIMODAL_VECTORS_PATH):
            self.parsers.append(MultimodalVectorParser(self.MULTIMODAL_VECTORS_PATH))
        
        # 3. 教材 txt (中小学知识)
        feed = root / '.hermes' / 'feed_data'
        if feed.exists():
            for txt_name in ['小学知识.txt', '初中部分.txt', '高中部分.txt']:
                p = feed / txt_name
                if p.exists():
                    self.parsers.append(TextBookParser(p))
        
        # 4. epub 国学典籍 (高质量传统文化知识)
        if feed.exists():
            for epub_name in ['book-22-山海经.epub', 'book-28-道德经.epub',
                              'book-43-易传.epub', 'book-8281-鲁班全书.epub']:
                p = feed / epub_name
                if p.exists():
                    self.parsers.append(EpubBookParser(p))
        
        # 5. 外部知识树迁移 (如果存在)
        if os.path.exists(self.EXTERNAL_KNOWLEDGE_TREE):
            self.parsers.append(KnowledgeTreeMigrator(self.EXTERNAL_KNOWLEDGE_TREE))
        
        # 跳过: ownthink (质量差)、小说 (娱乐)、实验数据 (噪音)
        
        # 进度持久化
        self._load_progress()
        for ps in self.parsers:
            if ps.name not in self._learned_count:
                self._learned_count[ps.name] = 0
            if ps.name not in self._last_item:
                self._last_item[ps.name] = None
        logger.info(f'LocalLearner 注册 {len(self.parsers)} 个高质量解析器: '
                    f'{[p.name for p in self.parsers]}')

    def _load_progress(self):
        """从 PROGRESS_FILE 读已学进度, 重启续学"""
        try:
            if os.path.exists(PROGRESS_FILE):
                d = json.loads(open(PROGRESS_FILE, encoding='utf-8').read())
                self._learned_count = d.get('learned_count', {})
                self._last_item = d.get('last_item', {})
                # 已学条数转成跳过: 每个解析器启动时跳过已学条数
                self._skip_counts = dict(self._learned_count)
                logger.info(f'恢复自学进度: {self._learned_count}')
        except Exception as e:
            logger.warning(f'进度读取失败: {e}')
        self._skip_counts = getattr(self, '_skip_counts', {})

    def _save_progress(self):
        """持久化进度到 PROGRESS_FILE"""
        try:
            os.makedirs(os.path.dirname(PROGRESS_FILE), exist_ok=True)
            d = {'learned_count': self._learned_count, 'last_item': self._last_item,
                 'saved_at': time.time()}
            open(PROGRESS_FILE, 'w', encoding='utf-8').write(json.dumps(d, ensure_ascii=False))
        except Exception as e:
            logger.warning(f'进度保存失败: {e}')

    def available(self):
        """本地知识源是否可用"""
        return self.root_dir.exists() and len(self.parsers) > 0

    def scan(self):
        """扫描所有源, 返回 {name: {total, path}} — 不读全文"""
        result = {}
        for ps in self.parsers:
            total = ps.scan()
            result[ps.name] = {
                'total': total,
                'learned': self._learned_count.get(ps.name, 0),
                'last': self._last_item.get(ps.name),
                'path': str(ps.path),
                'exists': ps.exists(),
            }
        self._scanned = True
        return result

    def digest(self, query, knowledge_tree):
        """Learner 接口实现 — 消化一条本地知识"""
        return self.digest_next(knowledge_tree)

    def digest_next(self, knowledge_tree):
        """
        生物体吃一条本地知识 → 灌进知识树

        只读源, 只增知识树. 返回灌进去的节点 dict, 没东西吃返回 None.
        调用方 (organism) 负责把 topic 同步到大脑蠕虫群.
        """
        if not self.available():
            return None
        with self._lock:
            for ps in self.parsers:
                # 惰性取迭代器
                it = self._iterators.get(ps.name)
                if it is None:
                    try:
                        it = ps.iter_items()
                        self._iterators[ps.name] = it
                        # 跳过已学条数 (重启续学)
                        skip = self._skip_counts.get(ps.name, 0)
                        for _ in range(skip):
                            try:
                                next(it)
                            except StopIteration:
                                break
                    except Exception as e:
                        logger.warning(f'{ps.name} 迭代器打开失败: {e}')
                        continue
                # 取一条
                try:
                    item = next(it)
                except StopIteration:
                    # 这个源吃完了, 移到下一个
                    continue
                except Exception as e:
                    logger.warning(f'{ps.name} 取条失败: {e}')
                    continue
                if not item:
                    continue
                # 质量门: 跳过明显垃圾条 (太短/无实质内容/纯导航/百科杂条)
                if not self._is_quality_item(item):
                    self._learned_count[ps.name] = self._learned_count.get(ps.name, 0) + 1
                    self._skip_counts[ps.name] = self._skip_counts.get(ps.name, 0) + 1
                    self._save_progress()
                    continue
                # 找父节点: 用 parent_topic 在知识树里找同名节点, 找不到就挂 root
                parent_id = self._find_or_create_parent(
                    knowledge_tree, item.get('parent_topic'))
                # 灌进去 — 只增不改
                # 迁移项 (带 embedding) 走 import_node 复用源嵌入; 其他走 learn 重算
                if item.get('embedding'):
                    node = knowledge_tree.import_node(
                        topic=item['topic'],
                        content=item['content'],
                        parent_id=parent_id,
                        embedding=item.get('embedding'),
                        fast_pool=item.get('fast_pool'),
                        medium_pool=item.get('medium_pool'),
                        slow_pool=item.get('slow_pool'),
                        hit_count=item.get('hit_count', 0),
                        source_tag='迁移',
                    )
                else:
                    node = knowledge_tree.learn(
                        topic=item['topic'],
                        content=item['content'],
                        parent_id=parent_id,
                        source='local'
                    )
                self._learned_count[ps.name] = self._learned_count.get(ps.name, 0) + 1
                self._last_item[ps.name] = item['topic']
                self._save_progress()  # 持久化进度, 重启续学
                logger.info(f'[自学] {ps.name}: {item["topic"][:30]} '
                            f'(累计 {self._learned_count[ps.name]})')
                return {
                    'parser': ps.name,
                    'topic': item['topic'],
                    'source': item.get('source', ''),
                    'parent': item.get('parent_topic', ''),
                    'node_id': node.id,
                }
        return None

    def _is_quality_item(self, item):
        """质量门 — 只保留对大模型训练真正有价值的知识"""
        topic = (item.get('topic') or '').strip()
        content = (item.get('content') or '').strip()
        
        # 1. 太短不算知识
        if len(topic) < 2 or len(content) < 30:
            return False
        
        # 2. 软件名/电影名/小说名 (噪音) — 优先过滤
        software_indicators = ['[电脑版软件]', '[手机版]', '[安卓版]', '播放器', 'APP', '下载']
        if any(ind in topic for ind in software_indicators):
            return False
        
        # 3. ownthink 百科杂条过滤 — 这是噪音重灾区
        #    特征: content 以 "描述:" 开头，且 topic 是具体名词/软件名/人名
        if content.startswith('描述:') or content.startswith('别名:'):
            # 允许科学类通过 (物理/化学/生物/数学等)
            science_keywords = ['物理','化学','生物','数学','天文','遗传','细胞',
                               '免疫','药理','分子','量子','相对论','统计','粒子',
                               '凝聚态','有机合成','神经','算法','编程','开发',
                               '数据库','网络','深度学习','机器学习','AI','前端','后端',
                               '哲学','历史','经济','法律','医学','地理','疫苗','病毒',
                               '计算机','软件','硬件','系统','理论','原理','方法']
            # 检查 topic 和 content 前100字
            check_text = topic + ' ' + content[:100]
            if any(k in check_text for k in science_keywords):
                return True  # 科学类通过
            else:
                return False  # 挡掉旅游/食品/软件/名人等杂条
        
        # 4. 施工/建筑数据 (噪音)
        construction_kw = ['开挖', '脚手架', '浇筑', '砌筑', '抹灰', '打桩', '钢筋绑扎',
                           '模板安装', '基坑', '防水层', '施工方案', '检验批']
        if any(k in topic for k in construction_kw):
            return False
        
        # 5. 代码碎片 (噪音)
        code_junk = ['VERSION HISTORY', 'function(', 'var ', 'npm install',
                     'pip install', 'import ', 'from ', 'class ', 'def ']
        if any(k in content[:50] for k in code_junk):
            return False
        
        # 6. 纯英文长标题且无中文 (大概率是噪音)
        cn_chars = sum(1 for c in topic if '\u4e00' <= c <= '\u9fff')
        if len(topic) > 10 and cn_chars == 0:
            return False
        
        # 7. topic 是占位符
        placeholder_topics = {'测试', 'test', 'TODO', 'tmp', 'temp', '未命名', '新建'}
        if topic.lower() in placeholder_topics:
            return False
        
        # 8. 软件名/电影名/小说名 (噪音) — 已在前面过滤，这里保留检查
        software_indicators = ['[电脑版软件]', '[手机版]', '[安卓版]', '播放器', 'APP', '下载']
        if any(ind in topic for ind in software_indicators):
            return False
        
        return True

    def _find_or_create_parent(self, tree, parent_topic):
        """按 topic 名找父节点; 找不到就在 root 下建一个分类节点"""
        if not parent_topic:
            return tree.root.id
        # 先找同名节点
        for node in tree.nodes.values():
            if node.topic == parent_topic and node.depth <= 2:
                return node.id
        # 找不到就建一个 (也走 learn, 只增)
        parent_node = tree.learn(parent_topic, f'分类: {parent_topic}', tree.root.id, source='local')
        return parent_node.id

    def get_stats(self):
        """供前端展示自学进度"""
        stats = {
            'root': str(self.root_dir),
            'available': self.available(),
            'parsers': [],
        }
        if not self.available():
            return stats
        for ps in self.parsers:
            stats['parsers'].append({
                'name': ps.name,
                'path': str(ps.path),
                'learned': self._learned_count.get(ps.name, 0),
                'last': self._last_item.get(ps.name),
            })
        return stats
