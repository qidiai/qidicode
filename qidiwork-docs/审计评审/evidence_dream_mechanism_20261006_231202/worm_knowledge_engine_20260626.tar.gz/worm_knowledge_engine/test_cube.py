from cube3d import Cube3D, v10_to_cube

cube = Cube3D()

inputs = [
    ("土方开挖和基坑支护是施工领域", "施工"),
    ("机电设备安装和管道焊接是安装工程", "安装"),
    ("钢筋混凝土和防水卷材是建筑材料", "材料"),
    ("这个工地需要做深基坑支护设计", "施工"),
    ("BIM建模和施工图设计都是设计工作", "设计"),
]

for text, expected in inputs:
    v10_to_cube(cube, text)
    cube.diffuse(steps=1)
    peaks = cube.read(top_k=3)
    top = peaks[0]["domain"] if peaks else "?"
    ok = "OK" if top == expected else f"->{top}"
    print(f"  {text[:20]:20s} -> {expected:4s} {ok}")

cube.step()
print()
print(cube.summary())
print()
print("Top-3:", [(p["domain"], p["concentration"]) for p in cube.read(top_k=3)])
