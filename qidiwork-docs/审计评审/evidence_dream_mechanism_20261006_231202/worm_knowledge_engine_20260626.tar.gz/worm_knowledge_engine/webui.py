"""
WebUI — 生物体的可视化界面

架构: templates.py(前端) + api_handlers.py(路由) + 本文件(服务器骨架)
换前端改 templates.py, 加API改 api_handlers.py, 服务器逻辑在这里。
"""
import asyncio
import json
import time
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor

from . import api_handlers
from .templates import get_page_html
from .config import WEBUI_ASYNC_TIMEOUT


class OrganismWebUI:
    """生物体Web界面"""

    def __init__(self, organism, teacher=None, dialogue=None, evolve=None, port=8080):
        self.organism = organism
        self.teacher = teacher
        self.dialogue = dialogue
        self.port = port
        self._server = None
        self._thread = None
        self._events = []
        self._loop = None
        self._loop_thread = None
        self._executor = ThreadPoolExecutor(max_workers=4)

        if evolve is None:
            from .self_evolve import SelfEvolve
            self.evolve = SelfEvolve(organism, teacher=teacher)
        else:
            self.evolve = evolve

    def _add_event(self, event_type, data):
        self._events.append({
            'type': event_type,
            'data': data,
            'time': time.time(),
        })
        if len(self._events) > 100:
            self._events = self._events[-100:]

    def start(self, port=None):
        if port:
            self.port = port
        self._loop = asyncio.new_event_loop()
        self._loop_thread = threading.Thread(target=self._run_loop, daemon=True)
        self._loop_thread.start()

        handler = _make_handler(self)
        self._server = HTTPServer(('127.0.0.1', self.port), handler)
        self._server.timeout = 0.1
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()
        return self.port

    def _run_loop(self):
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def _run_async(self, coro):
        future = asyncio.run_coroutine_threadsafe(coro, self._loop)
        return future.result(timeout=WEBUI_ASYNC_TIMEOUT)

    def stop(self):
        if self._server:
            self._server.shutdown()
        if self._loop:
            self._loop.call_soon_threadsafe(self._loop.stop)
        self._executor.shutdown(wait=False)


def _make_handler(webui):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            path = urlparse(self.path).path
            query = parse_qs(urlparse(self.path).query)

            if path == '/' or path == '/index.html':
                self._send_html()
            elif path in api_handlers.GET_ROUTES:
                api_handlers.GET_ROUTES[path](webui, self._send_json)
            elif path == '/api/tree' or path == '/api/node':
                api_handlers.handle_tree(webui, path, query, self._send_json, self._get_tree_data)
            elif path == '/api/suggest':
                api_handlers.handle_suggest(webui, query, self._send_json)
            elif path == '/knowledge-tree' or path == '/knowledge-tree-3d':
                from .knowledge_tree_visual import get_knowledge_tree_page
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(get_knowledge_tree_page().encode('utf-8'))
            else:
                self.send_error(404)

        def do_POST(self):
            path = urlparse(self.path).path
            length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(length).decode('utf-8') if length > 0 else ''

            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {'text': body}

            if path in api_handlers.POST_ROUTES:
                api_handlers.POST_ROUTES[path](webui, data, self._send_json)
            # 知识树 CRUD — 兼容两种路由格式:
            #   旧: POST /api/node  body={action:'update',...}
            #   新: POST /api/node/update  body={...}
            elif path == '/api/node':
                action = data.get('action', '')
                if action == 'update':
                    self._update_node(data)
                elif action == 'add':
                    self._add_node(data)
                elif action == 'delete':
                    self._delete_node(data)
                else:
                    self.send_error(400)
            elif path == '/api/node/update':
                self._update_node(data)
            elif path == '/api/node/add':
                self._add_node(data)
            elif path == '/api/node/delete':
                self._delete_node(data)
            elif path == '/api/interact':
                self._handle_interact(data)
            else:
                self.send_error(404)

        # ---- 知识树 CRUD ----

        def _get_tree_data(self):
            tree = webui.organism.body
            nodes = []
            for n in tree.nodes.values():
                nodes.append({
                    'id': n.id, 'topic': n.topic, 'parent_id': n.parent_id,
                    'depth': n.depth, 'hit_count': n.hit_count,
                    'children_ids': n.children_ids,
                    'is_dying': n.is_dying, 'source': getattr(n, 'source', ''),
                })
            return {'nodes': nodes, 'rootId': tree.root.id, 'root_id': tree.root.id,
                    'stats': tree.get_stats()}

        def _get_node_detail(self, node_id):
            node = webui.organism.body.nodes.get(node_id)
            if not node:
                return {'error': 'Node not found'}
            return {
                'id': node.id, 'topic': node.topic, 'content': node.content,
                'parent_id': node.parent_id, 'depth': node.depth,
                'hit_count': node.hit_count, 'is_dying': node.is_dying,
                'children_ids': node.children_ids,
                'embedding_dim': len(node.embedding) if node.embedding else 0,
                'source': getattr(node, 'source', ''),
            }

        def _update_node(self, data):
            tree = webui.organism.body
            node = tree.nodes.get(data.get('id'))
            if node:
                if 'topic' in data:
                    node.topic = data['topic']
                if 'content' in data:
                    node.content = data['content']
                tree._dirty = True
                tree._cache_valid = False
                tree.save()
                self._send_json({'ok': True})
            else:
                self._send_json({'error': 'Node not found'})

        def _add_node(self, data):
            tree = webui.organism.body
            parent_id = data.get('parent_id', tree.root.id)
            node = tree.learn(
                data.get('topic', '新节点'),
                data.get('content', ''),
                parent_id,
                source='manual'
            )
            self._send_json({'ok': True, 'id': node.id})

        def _delete_node(self, data):
            tree = webui.organism.body
            node_id = data.get('id')
            node = tree.nodes.get(node_id)
            if not node or node_id == 'root':
                self._send_json({'error': 'Cannot delete'})
                return
            # 子节点挂到父
            parent = tree.nodes.get(node.parent_id)
            if parent and node_id in parent.children_ids:
                parent.children_ids.remove(node_id)
            for child_id in node.children_ids:
                child = tree.nodes.get(child_id)
                if child:
                    child.parent_id = node.parent_id
                    if parent:
                        parent.children_ids.append(child_id)
            del tree.nodes[node_id]
            tree.save()
            self._send_json({'ok': True})

        def _handle_interact(self, data):
            """知识节点互动 — 两个节点语义关联"""
            tree = webui.organism.body
            a_id = data.get('a')
            b_id = data.get('b')
            if not a_id or not b_id:
                self._send_json({'error': '缺节点id'})
                return
            na = tree.nodes.get(a_id)
            nb = tree.nodes.get(b_id)
            if not na or not nb:
                self._send_json({'error': '节点不存在'})
                return
            # 计算语义相似度
            from .knowledge_tree import smart_embedding, _cosine_similarity
            a_emb = na.embedding or smart_embedding(na.topic + ' ' + (na.content or '')[:200])
            b_emb = nb.embedding or smart_embedding(nb.topic + ' ' + (nb.content or '')[:200])
            sim = _cosine_similarity(a_emb, b_emb)
            self._send_json({
                'a': {'id': na.id, 'topic': na.topic},
                'b': {'id': nb.id, 'topic': nb.topic},
                'similarity': round(sim, 4),
                'related': sim > 0.2,
            })

        # ---- 响应工具 ----

        def _send_html(self):
            html = get_page_html()
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))

        def _send_json(self, data):
            body = json.dumps(data, ensure_ascii=False, default=str).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', len(body))
            self.end_headers()
            self.wfile.write(body)

        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header('Access-Control-Allow-Origin', '*')
            self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
            self.send_header('Access-Control-Allow-Headers', 'Content-Type')
            self.end_headers()

        def log_message(self, format, *args):
            pass  # 静默HTTP日志

    return Handler
