"""
worm_c.py — C核心的Python绑定 (ctypes)

编译C核心:
  Windows: cd c_core && cl /O2 /LD worm_core.c /Fe:worm_core.dll
  Linux:   cd c_core && gcc -O2 -shared -fPIC worm_core.c -o libworm_core.so -lm
  macOS:   cd c_core && gcc -O2 -shared -fPIC worm_core.c -o libworm_core.dylib -lm

如果C库不存在，自动降级到纯Python实现
"""
import ctypes
import os
import sys
import platform
import logging
import numpy as np

logger = logging.getLogger('WormC')

# ============ 查找C库 ============

_C_LIB = None
_C_DIR = os.path.dirname(os.path.abspath(__file__))


def _find_c_lib():
    """查找已编译的C动态库"""
    names = []
    if platform.system() == 'Windows':
        names = ['worm_core.dll']
    elif platform.system() == 'Darwin':
        names = ['libworm_core.dylib', 'libworm_core.so']
    else:
        names = ['libworm_core.so']

    for sub in ['c_core', '.', '..']:
        for name in names:
            path = os.path.join(_C_DIR, sub, name)
            if os.path.exists(path):
                return path
    return None


def _load_c_lib():
    """加载C库"""
    global _C_LIB
    path = _find_c_lib()
    if not path:
        return None
    try:
        lib = ctypes.CDLL(path)
        # 设置函数签名
        lib.wc_swarm_create.restype = ctypes.c_void_p
        lib.wc_swarm_create.argtypes = []

        lib.wc_swarm_destroy.restype = None
        lib.wc_swarm_destroy.argtypes = [ctypes.c_void_p]

        lib.wc_spawn.restype = ctypes.c_uint32
        lib.wc_spawn.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_float]

        lib.wc_get_by_name.restype = ctypes.c_void_p
        lib.wc_get_by_name.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        lib.wc_get_by_id.restype = ctypes.c_void_p
        lib.wc_get_by_id.argtypes = [ctypes.c_void_p, ctypes.c_uint32]

        lib.wc_link.restype = ctypes.c_int
        lib.wc_link.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_float]

        lib.wc_unlink.restype = ctypes.c_int
        lib.wc_unlink.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]

        lib.wc_activate.restype = None
        lib.wc_activate.argtypes = [ctypes.c_void_p, ctypes.c_float]

        lib.wc_decay.restype = None
        lib.wc_decay.argtypes = [ctypes.c_void_p, ctypes.c_float]

        lib.wc_spread.restype = None
        lib.wc_spread.argtypes = [ctypes.c_void_p, ctypes.c_float, ctypes.c_float]

        lib.wc_cosine_similarity.restype = ctypes.c_float
        lib.wc_cosine_similarity.argtypes = [ctypes.POINTER(ctypes.c_float), ctypes.POINTER(ctypes.c_float), ctypes.c_int]

        lib.wc_simple_embedding.restype = None
        lib.wc_simple_embedding.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]

        lib.wc_get_stats.restype = None
        lib.wc_get_stats.argtypes = [
            ctypes.c_void_p,
            ctypes.POINTER(ctypes.c_uint32),
            ctypes.POINTER(ctypes.c_uint32),
            ctypes.POINTER(ctypes.c_uint32),
            ctypes.POINTER(ctypes.c_float),
        ]

        lib.wc_save.restype = ctypes.c_int
        lib.wc_save.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

        lib.wc_load.restype = ctypes.c_void_p
        lib.wc_load.argtypes = [ctypes.c_char_p]

        lib.wc_reflect.restype = None
        lib.wc_reflect.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int]

        logger.info(f'C核心已加载: {path}')
        return lib
    except Exception as e:
        logger.warning(f'C核心加载失败: {e}，使用Python降级')
        return None


_C_LIB = _load_c_lib()
C_AVAILABLE = _C_LIB is not None


# ============ Python包装 ============

def c_cosine_similarity(a, b):
    """C版余弦相似度"""
    if not C_AVAILABLE:
        return _py_cosine_similarity(a, b)
    n = min(len(a), len(b))
    ca = (ctypes.c_float * n)(*a[:n])
    cb = (ctypes.c_float * n)(*b[:n])
    return _C_LIB.wc_cosine_similarity(ca, cb, n)


def c_simple_embedding(text, dim=128):
    """C版简单嵌入"""
    if not C_AVAILABLE:
        return _py_simple_embedding(text, dim)
    out = (ctypes.c_float * dim)()
    _C_LIB.wc_simple_embedding(text.encode('utf-8'), out, dim)
    return list(out)


def c_available():
    """C核心是否可用"""
    return C_AVAILABLE


def compile_c_core():
    """编译C核心"""
    c_dir = os.path.join(_C_DIR, 'c_core')
    c_file = os.path.join(c_dir, 'worm_core.c')

    if not os.path.exists(c_file):
        logger.error(f'找不到C源码: {c_file}')
        return False

    system = platform.system()
    try:
        if system == 'Windows':
            # 用MSVC编译
            dll_path = os.path.join(c_dir, 'worm_core.dll')
            cmd = f'cl /O2 /LD /Fe:"{dll_path}" "{c_file}"'
        elif system == 'Darwin':
            so_path = os.path.join(c_dir, 'libworm_core.dylib')
            cmd = f'gcc -O2 -shared -fPIC -o "{so_path}" "{c_file}" -lm'
        else:
            so_path = os.path.join(c_dir, 'libworm_core.so')
            cmd = f'gcc -O2 -shared -fPIC -o "{so_path}" "{c_file}" -lm'

        logger.info(f'编译: {cmd}')
        ret = os.system(cmd)
        if ret == 0:
            global _C_LIB, C_AVAILABLE
            _C_LIB = _load_c_lib()
            C_AVAILABLE = _C_LIB is not None
            logger.info('C核心编译成功!')
            return True
        else:
            logger.error(f'编译失败 (退出码={ret})')
            return False
    except Exception as e:
        logger.error(f'编译异常: {e}')
        return False


# ============ Python降级实现 ============

def _py_cosine_similarity(a, b):
    """Python降级: 余弦相似度"""
    import math
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    return dot / (na * nb)


def _py_simple_embedding(text, dim=128):
    """Python降级: 简单嵌入"""
    import hashlib
    emb = [0.0] * dim
    import math
    words = []
    for w in text.lower().split():
        words.append(w)
    for ch in text:
        if '\u4e00' <= ch <= '\u9fff':
            words.append(ch)
    for w in words:
        h = hashlib.md5(w.encode('utf-8')).hexdigest()
        idx = int(h[:8], 16) % dim
        emb[idx] += 1.0
    norm = math.sqrt(sum(x * x for x in emb))
    if norm > 1e-9:
        emb = [x / norm for x in emb]
    return emb
