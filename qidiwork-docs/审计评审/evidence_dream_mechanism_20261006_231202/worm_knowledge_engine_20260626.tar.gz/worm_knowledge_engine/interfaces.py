"""
蠕虫知识引擎 — 可插拔接口层 (ABC)

换搜索引擎/嵌入引擎/LLM后端/知识存储,只需实现对应接口,
不用改 organism/webui 等业务代码。
"""
from abc import ABC, abstractmethod


# ============ 搜索引擎 ============

class SearchEngine(ABC):
    """搜索引擎接口 — Bing/DDG/SearXNG/自定义均可"""

    @abstractmethod
    def search(self, query: str, top_k: int = 5) -> list:
        """搜一个关键词 → 返回 [{title, snippet, url}] 列表"""
        ...

    @abstractmethod
    def available(self) -> bool:
        """是否可用"""
        ...


# ============ 嵌入引擎 ============

class EmbedEngine(ABC):
    """嵌入引擎接口 — V10/v9v3/词袋哈希/OpenAI embedding 均可"""

    @abstractmethod
    def embed(self, text: str) -> list:
        """文本 → 嵌入向量"""
        ...

    def embed_with_pools(self, text: str) -> dict:
        """文本 → {embedding, fast_pool, medium_pool, slow_pool} (可选覆写)"""
        emb = self.embed(text)
        return {'embedding': emb, 'fast_pool': list(emb), 'medium_pool': list(emb), 'slow_pool': list(emb)}

    @property
    def name(self) -> str:
        return self.__class__.__name__


# ============ LLM 后端 ============

class LLMBackend(ABC):
    """大模型后端接口 — OpenAI/本地/Ollama/自定义均可"""

    @abstractmethod
    def chat(self, messages: list, temperature: float = 0.7, max_tokens: int = 2000) -> str:
        """对话 → 返回文本"""
        ...

    @property
    def name(self) -> str:
        return self.__class__.__name__


# ============ 知识存储 ============

class KnowledgeStore(ABC):
    """知识存储接口 — 当前用 JSON, 将来可换 SQLite/向量库"""

    @abstractmethod
    def save(self, data: dict) -> None:
        """保存整个知识树"""
        ...

    @abstractmethod
    def load(self) -> dict:
        """加载整个知识树"""
        ...


# ============ 学习器 ============

class Learner(ABC):
    """学习器接口 — 本地/联网/手动均可"""

    @abstractmethod
    def digest(self, query: str, knowledge_tree) -> int:
        """消化一条知识 → 返回灌入节点数"""
        ...

    @abstractmethod
    def available(self) -> bool:
        """是否可用"""
        ...

    def get_stats(self) -> dict:
        """状态 (可选覆写)"""
        return {'available': self.available()}
