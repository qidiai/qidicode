"""
菌丝网络 — 多节点分布式通信
整合自: F:\代码\导入数据\蠕虫特点学习\蠕虫菌丝.py
- TCP 节点间通信
- UDP 广播发现邻居
- 链路强度衰减与增强
- 饥饿驱动任务请求
"""
import socket
import struct
import json
import threading
import time
import logging
import random

logger = logging.getLogger('MycelialNetwork')

# ============ 协议工具 ============

def send_msg(sock, msg):
    """发送长度前缀的JSON消息"""
    data = json.dumps(msg, ensure_ascii=False).encode('utf-8')
    sock.sendall(struct.pack('!I', len(data)) + data)


def recv_msg(sock):
    """接收长度前缀的JSON消息"""
    raw_len = recv_all(sock, 4)
    if not raw_len:
        return None
    msg_len = struct.unpack('!I', raw_len)[0]
    data = recv_all(sock, msg_len)
    if not data:
        return None
    return json.loads(data.decode('utf-8'))


def recv_all(sock, n):
    """确保读取n字节"""
    buf = b''
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


class MycelialNode:
    """菌丝节点 — 一个分布式计算单元"""

    def __init__(self, node_id, task_type='general', capacity=10, port=0):
        self.node_id = node_id
        self.task_type = task_type
        self.capacity = capacity
        self.port = port
        self.hunger = 0.0  # 饥饿度
        self.neighbors = {}       # addr -> link_strength
        self.link_history = {}    # addr -> [success/fail]
        self.running = False
        self._server = None
        self._threads = []

    def inject_neighbors(self, neighbor_list):
        """注入邻居节点"""
        for addr in neighbor_list:
            if addr not in self.neighbors:
                self.neighbors[addr] = 0.5  # 初始链路强度

    def update_hunger(self):
        """更新饥饿度 — 空闲时饥饿增加"""
        self.hunger = min(1.0, self.hunger + 0.02)

    def feed(self, amount=0.1):
        """喂食 — 完成任务后降低饥饿"""
        self.hunger = max(0.0, self.hunger - amount)

    def _select_neighbor(self, task):
        """选择邻居 — 链路强度加权"""
        if not self.neighbors:
            return None
        # 按链路强度加权随机选择
        addrs = list(self.neighbors.keys())
        weights = [self.neighbors[a] for a in addrs]
        total = sum(weights)
        if total < 1e-9:
            return random.choice(addrs)
        probs = [w / total for w in weights]
        return random.choices(addrs, weights=probs, k=1)[0]

    def _update_link_strength(self, addr, success):
        """更新链路强度"""
        if addr not in self.neighbors:
            self.neighbors[addr] = 0.5
        if success:
            self.neighbors[addr] = min(1.0, self.neighbors[addr] + 0.05)
        else:
            self.neighbors[addr] = max(0.0, self.neighbors[addr] - 0.1)
        # 记录历史
        if addr not in self.link_history:
            self.link_history[addr] = []
        self.link_history[addr].append(success)
        if len(self.link_history[addr]) > 100:
            self.link_history[addr] = self.link_history[addr][-100:]

    def _handle_request(self, conn, addr):
        """处理请求"""
        try:
            msg = recv_msg(conn)
            if not msg:
                return
            cmd = msg.get('cmd')

            if cmd == 'ping':
                send_msg(conn, {'status': 'ok', 'node_id': self.node_id, 'hunger': self.hunger})

            elif cmd == 'task':
                # 接收任务执行
                task = msg.get('task', {})
                result = self._execute_task(task)
                send_msg(conn, {'status': 'done', 'result': result})
                self.feed(0.1)

            elif cmd == 'discover':
                # 返回已知邻居
                send_msg(conn, {'neighbors': list(self.neighbors.keys())})

            else:
                send_msg(conn, {'status': 'unknown_cmd'})

        except Exception as e:
            logger.error(f'处理请求异常: {e}')
        finally:
            conn.close()

    def _execute_task(self, task):
        """执行任务（由子类或外部覆盖）"""
        task_type = task.get('type', 'unknown')
        logger.info(f'节点 {self.node_id} 执行任务: {task_type}')
        # 简化：返回确认
        return {'task_type': task_type, 'node_id': self.node_id, 'done': True}

    def _tcp_loop(self, server):
        """TCP服务循环"""
        while self.running:
            try:
                server.settimeout(1.0)
                conn, addr = server.accept()
                t = threading.Thread(target=self._handle_request, args=(conn, addr), daemon=True)
                t.start()
                self._threads.append(t)
            except socket.timeout:
                continue
            except Exception as e:
                if self.running:
                    logger.error(f'TCP异常: {e}')

    def _udp_broadcast(self):
        """UDP广播 — 发现邻居"""
        while self.running:
            try:
                msg = json.dumps({
                    'node_id': self.node_id,
                    'port': self.port,
                    'task_type': self.task_type,
                    'hunger': self.hunger,
                }).encode('utf-8')
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                sock.sendto(msg, ('<broadcast>', 9999))
                sock.close()
            except Exception:
                pass
            time.sleep(5)

    def _udp_listener(self):
        """UDP监听 — 接收邻居广播"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.bind(('', 9999))
            sock.settimeout(2.0)
            while self.running:
                try:
                    data, addr = sock.recvfrom(4096)
                    info = json.loads(data.decode('utf-8'))
                    neighbor_addr = f"{addr[0]}:{info.get('port', 5000)}"
                    if neighbor_addr not in self.neighbors:
                        self.neighbors[neighbor_addr] = 0.3
                        logger.info(f'发现邻居: {neighbor_addr}')
                except socket.timeout:
                    continue
            sock.close()
        except Exception as e:
            logger.error(f'UDP监听异常: {e}')

    def _hunger_loop(self):
        """饥饿驱动循环 — 饥饿时主动请求任务"""
        while self.running:
            self.update_hunger()
            if self.hunger > 0.7 and self.neighbors:
                neighbor = self._select_neighbor('task_request')
                if neighbor:
                    self._request_task(neighbor)
            time.sleep(3)

    def _request_task(self, neighbor_addr):
        """向邻居请求任务"""
        try:
            host, port = neighbor_addr.split(':')
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5.0)
            sock.connect((host, int(port)))
            send_msg(sock, {'cmd': 'ping'})
            resp = recv_msg(sock)
            sock.close()
            self._update_link_strength(neighbor_addr, resp is not None)
        except Exception:
            self._update_link_strength(neighbor_addr, False)

    def start(self):
        """启动节点"""
        self.running = True
        # TCP服务器
        self._server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server.bind(('0.0.0.0', self.port or 0))
        self._server.listen(10)
        self.port = self._server.getsockname()[1]
        logger.info(f'菌丝节点 {self.node_id} 启动于端口 {self.port}')

        # 启动各线程
        threading.Thread(target=self._tcp_loop, args=(self._server,), daemon=True).start()
        threading.Thread(target=self._udp_broadcast, daemon=True).start()
        threading.Thread(target=self._udp_listener, daemon=True).start()
        threading.Thread(target=self._hunger_loop, daemon=True).start()

    def stop(self):
        """停止节点"""
        self.running = False
        if self._server:
            self._server.close()

    def get_status(self):
        return {
            'node_id': self.node_id, 'port': self.port,
            'hunger': self.hunger, 'neighbors': len(self.neighbors),
            'task_type': self.task_type, 'running': self.running,
        }
