"""
对话接口 — 用自然语言跟生物体说话

你: "帮我爬豆瓣电影Top250"
它: "好的，我需要代理池，先教我..."

流程:
  你的话 → 大模型理解意图 → 激活概念/设定目标/教学 → 执行 → 大模型组织回复
"""
import json
import time
import logging
import asyncio

logger = logging.getLogger('Dialogue')


class Dialogue:
    """
    对话 — 自然语言交互

    你说话 → 它听懂 → 它行动 → 它回复
    """

    SYSTEM_PROMPT = """你是一个AI生物体的语言接口。这个生物体有:
- 大脑: 蠕虫群激活扩散，概念之间有关联
- 身体: 知识树，三速池记忆
- 触角: 蚁群爬虫
- 老师: 可以教它新概念

用户跟你说话，你需要:
1. 理解用户意图
2. 转化成对生物体的操作
3. 执行后把结果用自然语言回复

【重要】reply 字段必须紧扣用户问题回答。用户问"分布式智能体"就回答分布式智能体,
绝不允许回答彩票、天气、美食等无关话题。如果不知道就 reply="我不太了解这个,
可以教教我吗"。

用JSON格式回复(必须是合法JSON,不要在JSON外加任何文字):
{
  "intent": "teach/ask/command/chat",
  "concepts_to_activate": {"概念名": 激活强度},
  "goal": "目标描述(如果有)",
  "teach_topic": "要教的主题(如果有)",
  "reply": "给用户的自然语言回复"
}"""

    def __init__(self, organism, teacher=None):
        self.organism = organism
        self.teacher = teacher
        self.conversation = []

    def _parse_llm_response(self, response):
        """
        解析大模型回复 — 多重兜底, 防跑题:
          1. 剥 markdown ```json ... ``` 包裹
          2. 完整 json.loads
          3. 正则提取最外层 { ... }
          4. 补齐右括号 (max_tokens 截断时)
          5. 都失败 → 当纯文本回复 (intent=chat, reply=response)
        返回 dict, 至少含 intent + reply
        """
        import re
        def _try(s):
            try:
                return json.loads(s)
            except json.JSONDecodeError:
                return None

        # 1. 剥 markdown 包裹
        cleaned = response.strip()
        if cleaned.startswith('```'):
            cleaned = re.sub(r'^```(?:json)?\s*', '', cleaned)
            cleaned = re.sub(r'\s*```$', '', cleaned)

        # 2. 完整解析
        d = _try(cleaned)
        if d and 'reply' in d:
            return d

        # 3. 正则提取
        m = re.search(r'\{.*\}', response, re.DOTALL)
        if m:
            d = _try(m.group())
            if d and 'reply' in d:
                return d
            # 4. 补齐右括号
            snippet = m.group()
            opens = snippet.count('{')
            closes = snippet.count('}')
            if opens > closes:
                d = _try(snippet + '}' * (opens - closes))
                if d and 'reply' in d:
                    return d

        # 5. 兜底 — 纯文本回复, intent=chat
        # 但如果纯文本里没有用户问的关键词, 说明跑题了, 加提示
        return {'intent': 'chat', 'reply': response.strip()}

    def _build_messages(self, user_input):
        messages = [
            {'role': 'system', 'content': self.SYSTEM_PROMPT},
        ]
        # 上下文: 最近5轮对话
        for turn in self.conversation[-5:]:
            messages.append({'role': 'user', 'content': turn['user']})
            messages.append({'role': 'assistant', 'content': turn['assistant']})

        # 当前状态
        status = self.organism.get_status()
        active = self.organism.brain.swarm.get_active(threshold=0.05)
        active_names = [f'{n}({a:.2f})' for n, a, v, c in active[:10]]

        context = f'当前状态: 饥饿={status["hunger"]:.2f}, 成功率={status["success_rate"]:.2f}\n'
        context += f'活跃概念: {", ".join(active_names)}\n'
        context += f'知识节点: {status["body"]["total_nodes"]}, 蠕虫数: {status["brain"]["swarm"]["total_worms"]}'
        if self.organism.current_goal:
            context += f'\n当前目标: {self.organism.current_goal.description}'

        messages.append({'role': 'user', 'content': f'{context}\n\n用户说: {user_input}'})
        return messages

    async def say(self, user_input):
        """
        你说话 → 它回复

        返回: 它的回复文本
        """
        # 如果有老师(大模型)，用它理解
        if self.teacher and self.teacher.backend:
            messages = self._build_messages(user_input)
            response = self.teacher.backend.chat(messages, temperature=0.5, max_tokens=1500)

            if response:
                data = self._parse_llm_response(response)
            else:
                data = {'intent': 'chat', 'reply': '...我还在想'}
        else:
            # 没有大模型，用规则匹配
            data = self._rule_based_understand(user_input)

        # 执行意图
        reply = await self._execute(data, user_input)

        # 记录对话
        self.conversation.append({
            'user': user_input,
            'assistant': reply,
            'time': time.time(),
        })

        return reply

    def _rule_based_understand(self, text):
        """无大模型时，规则匹配理解"""
        text_lower = text.lower()
        data = {'intent': 'chat', 'concepts_to_activate': {}, 'reply': ''}

        if any(w in text_lower for w in ['爬', 'crawl', '抓取', '采集']):
            data['intent'] = 'command'
            data['concepts_to_activate'] = {'爬取': 0.8, '饥饿': 0.5}
            data['goal'] = text
        elif any(w in text_lower for w in ['学', 'learn', '教', 'teach']):
            data['intent'] = 'teach'
            data['teach_topic'] = text
        elif any(w in text_lower for w in ['分析', 'analyze', '统计', '看看']):
            data['intent'] = 'command'
            data['concepts_to_activate'] = {'分析': 0.7}
        elif any(w in text_lower for w in ['状态', 'status', '怎么样', '如何']):
            data['intent'] = 'ask'
        elif any(w in text_lower for w in ['休息', 'sleep', '睡觉', '做梦']):
            data['intent'] = 'command'
            data['concepts_to_activate'] = {'休息': 0.7, '满足': 0.5}
        else:
            data['reply'] = f'我听到了: "{text}"，让我想想...'

        return data

    async def _execute(self, data, raw_input):
        """执行理解后的意图"""
        intent = data.get('intent', 'chat')

        # 激活概念
        concepts = data.get('concepts_to_activate', {})
        if concepts:
            chain = self.organism.brain.swarm.think(concepts, rounds=3)
            active = self.organism.brain.swarm.get_active(threshold=0.05)
            if active and not data.get('reply'):
                top = active[0]
                data['reply'] = f'我想到了{top[0]}(激活{top[1]:.2f})'

        # 设定目标
        goal = data.get('goal')
        if goal:
            self.organism.set_goal(goal, 'explore')

        # 教学
        teach_topic = data.get('teach_topic')
        if teach_topic and self.teacher:
            result = self.teacher.teach(teach_topic)
            if result:
                data['reply'] = f'学会了! +{result["new_concepts"]}个新概念, +{result["new_connections"]}条新连接'

        # 查询状态
        if intent == 'ask':
            status = self.organism.get_status()
            active = self.organism.brain.swarm.get_active(threshold=0.05)
            reply = f'状态: 饥饿={status["hunger"]:.2f}, 成功率={status["success_rate"]:.2f}\n'
            reply += f'知识: {status["body"]["total_nodes"]}节点, 蠕虫: {status["brain"]["swarm"]["total_worms"]}条\n'
            if active:
                reply += f'在想: {", ".join(f"{n}({a:.2f})" for n, a, v, c in active[:5])}'
            # 检索知识树, 把命中的本地知识塞进回复 (为你所用)
            try:
                hits = self.organism.body.recall(raw_input, top_k=3)
                if hits:
                    reply += '\n\n📚 我学过的相关知识:\n'
                    for h in hits:
                        topic = h.get('topic', '') if isinstance(h, dict) else getattr(h, 'topic', '')
                        content = (h.get('content', '') if isinstance(h, dict) else getattr(h, 'content', ''))[:80]
                        score = h.get('score', 0) if isinstance(h, dict) else getattr(h, 'score', 0)
                        reply += f'  · [{score:.2f}] {topic}: {content}\n'
                else:
                    reply += '\n\n📚 本地无相关知识 (需联网搜)\n'
            except Exception:
                pass
            data['reply'] = reply

        # chat 意图也检索知识树, 让对话能引用学过的知识 (闭环: 学了能用上)
        if intent == 'chat' and not data.get('reply'):
            try:
                hits = self.organism.body.recall(raw_input, top_k=2)
                if hits:
                    topics = []
                    for h in hits:
                        t = h.get('topic', '') if isinstance(h, dict) else getattr(h, 'topic', '')
                        if t:
                            topics.append(t)
                    if topics:
                        data['reply'] = f'关于"{raw_input}", 我联想到: {", ".join(topics)}'
                    else:
                        data['reply'] = f'关于"{raw_input}", 本地无相关知识'
                else:
                    data['reply'] = f'关于"{raw_input}", 本地无相关知识 (需联网搜)'
            except Exception:
                pass

        return data.get('reply', '...')
