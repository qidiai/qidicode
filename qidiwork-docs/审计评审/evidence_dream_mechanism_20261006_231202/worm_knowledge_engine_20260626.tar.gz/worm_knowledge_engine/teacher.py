"""
老师 — 用大模型教育生物体

前期: 生物体只有30个先天概念，啥也不懂
      老师教它新概念、建连接、给经验
      像教小孩：先教基础，再教进阶，慢慢放手

中期: 概念图长了上千个概念，能自己学了
      老师只在遇到新领域时才介入

后期: 概念图足够密，自己就是中枢
      老师变成语言器官，只做翻译

教学方式:
  1. 教概念 — "反爬有这几种策略" → 长出新概念
  2. 教连接 — "失败通常因为反爬" → 建连接
  3. 教经验 — "上次豆瓣爬取成功是因为降速" → 写入知识树
  4. 评价决策 — "你选了休息，但应该选爬取" → 调整valence
  5. 给embedding — 用语义向量替换词袋哈希
"""
import json
import logging
import hashlib
import time

logger = logging.getLogger('Teacher')


class LLMBackend:
    """大模型后端 — 抽象接口"""

    def chat(self, messages, temperature=0.7, max_tokens=500):
        """
        调用大模型

        messages: [{"role": "system"/"user"/"assistant", "content": "..."}]
        返回: 文本字符串
        """
        raise NotImplementedError


class OpenAIBackend(LLMBackend):
    """OpenAI / 兼容API"""

    def __init__(self, api_key=None, base_url=None, model='gpt-3.5-turbo'):
        self.api_key = api_key
        self.base_url = base_url or 'https://api.openai.com/v1'
        self.model = model

    def chat(self, messages, temperature=0.7, max_tokens=500):
        try:
            import openai
            client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)
            resp = client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
            )
            return resp.choices[0].message.content
        except Exception as e:
            logger.error(f'OpenAI调用失败: {e}')
            return None


class LocalBackend(LLMBackend):
    """本地模型 (ollama / llama.cpp 等)"""

    def __init__(self, base_url='http://localhost:11434', model='qwen2.5:7b'):
        self.base_url = base_url
        self.model = model

    def chat(self, messages, temperature=0.7, max_tokens=500):
        try:
            import requests
            resp = requests.post(
                f'{self.base_url}/api/chat',
                json={
                    'model': self.model,
                    'messages': messages,
                    'stream': False,
                    'options': {'temperature': temperature, 'num_predict': max_tokens}
                },
                timeout=60
            )
            if resp.status_code == 200:
                return resp.json()['message']['content']
            else:
                logger.error(f'本地模型返回 {resp.status_code}: {resp.text[:200]}')
                return None
        except Exception as e:
            logger.error(f'本地模型调用失败: {e}')
            return None


class MockBackend(LLMBackend):
    """模拟后端 — 没有大模型时用，返回预设回复"""

    TEACHINGS = {
        '爬虫': {
            'concepts': ['代理轮换', '模拟浏览器', '请求头伪装', 'Cookie池', '验证码识别', 'JS渲染', '异步并发', '增量爬取', '去重策略', '断点续爬'],
            'connections': [
                ('失败', '代理轮换', 0.8), ('失败', '模拟浏览器', 0.7),
                ('失败', '请求头伪装', 0.6), ('失败', '验证码识别', 0.5),
                ('代理轮换', '爬取', 0.7), ('模拟浏览器', '爬取', 0.6),
                ('请求头伪装', '爬取', 0.5), ('异步并发', '加速', 0.7),
                ('增量爬取', '降速', 0.4), ('去重策略', '学习', 0.3),
                ('验证码识别', '学习', 0.5), ('JS渲染', '模拟浏览器', 0.6),
                ('Cookie池', '代理轮换', 0.5), ('断点续爬', '爬取', 0.4),
            ],
        },
        '分析': {
            'concepts': ['数据清洗', '模式识别', '趋势分析', '异常检测', '关联挖掘', '文本分类', '情感分析', '关键词提取'],
            'connections': [
                ('分析', '数据清洗', 0.8), ('分析', '模式识别', 0.7),
                ('分析', '趋势分析', 0.6), ('分析', '异常检测', 0.5),
                ('数据清洗', '学习', 0.5), ('模式识别', '学习', 0.4),
                ('异常检测', '失败', 0.6), ('关联挖掘', '学习', 0.5),
                ('情感分析', '分析', 0.5), ('关键词提取', '学习', 0.4),
            ],
        },
        '通用': {
            'concepts': ['优先级排序', '时间管理', '资源分配', '风险评估', '复盘总结', '自动化', '监控告警', '日志分析'],
            'connections': [
                ('优先级排序', '调度', 0.7), ('时间管理', '休息', 0.4),
                ('资源分配', '调度', 0.6), ('风险评估', '小心', 0.7),
                ('复盘总结', '整理记忆', 0.8), ('自动化', '加速', 0.6),
                ('监控告警', '求助', 0.5), ('日志分析', '分析', 0.6),
                ('复盘总结', '学习', 0.7), ('风险评估', '失败', 0.5),
            ],
        },
    }

    def chat(self, messages, temperature=0.7, max_tokens=500):
        # 提取用户消息中的关键词
        user_msg = ''
        for m in messages:
            if m['role'] == 'user':
                user_msg += m['content']

        # 根据关键词返回教学
        for key, teaching in self.TEACHINGS.items():
            if key in user_msg:
                concepts = teaching['concepts']
                connections = teaching['connections']
                return json.dumps({
                    'new_concepts': concepts,
                    'new_connections': [[a, b, s] for a, b, s in connections],
                    'advice': f'关于{key}，你应该先掌握这些基础概念，然后多练习'
                }, ensure_ascii=False)

        # 默认
        return json.dumps({
            'new_concepts': ['观察', '等待', '再试一次'],
            'new_connections': [['失败', '再试一次', 0.5], ['观察', '学习', 0.4]],
            'advice': '遇到不懂的多观察，别急着行动'
        }, ensure_ascii=False)


class Teacher:
    """
    老师 — 教育生物体

    用大模型:
    1. 教新概念
    2. 建连接
    3. 给经验
    4. 评价决策
    5. 给embedding

    教学进度:
    - 第1阶段 (概念<100): 密集教学，主动喂知识
    - 第2阶段 (概念100~500): 按需教学，遇到新领域才教
    - 第3阶段 (概念>500): 放手，只做翻译
    """

    SYSTEM_PROMPT = """你是一个老师的角色，正在教育一个由概念图组成的AI生物体。

这个生物体的"大脑"是一个概念网络：
- 概念节点之间有关联，关联有强度
- 激活从高到低扩散，形成思维
- 好的经历加强连接，坏的经历削弱连接

你需要教它：
1. 新概念 — 它不知道的东西
2. 新连接 — 概念之间应该怎么关联
3. 经验 — 什么情况下该做什么

请用JSON格式回复：
{
  "new_concepts": ["概念1", "概念2", ...],
  "new_connections": [["概念A", "概念B", 关联强度0~1], ...],
  "advice": "给它的一句话建议"
}

关联强度参考：
- 0.8~1.0: 强关联，几乎总是一起出现
- 0.5~0.7: 中等关联，经常相关
- 0.2~0.4: 弱关联，偶尔相关
"""

    def __init__(self, organism, backend=None):
        self.organism = organism
        self.backend = backend or MockBackend()
        self.teachings = []  # 教学记录

    def _get_phase(self):
        """当前教学阶段"""
        n = len(self.organism.brain.swarm.worms)
        if n < 100:
            return 1  # 密集教学
        elif n < 500:
            return 2  # 按需教学
        else:
            return 3  # 放手

    def teach(self, topic):
        """
        教一个主题 — 让大模型生成概念和连接，注入生物体

        topic: 要教的主题，如"爬虫"、"分析"
        """
        phase = self._get_phase()

        # 构建消息
        existing = [w.name for w in self.organism.brain.swarm.worms.values()]
        user_msg = f'请教我关于"{topic}"的知识。\n'
        user_msg += f'我已经知道的概念: {", ".join(existing[:50])}{"..." if len(existing) > 50 else ""}\n'
        if phase == 1:
            user_msg += '我是初学者，请多教一些基础概念和它们的关联。'
        elif phase == 2:
            user_msg += '我有一些基础了，请教我进阶概念。'
        else:
            user_msg += '我很有经验了，请只教我我不知道的高级概念。'

        messages = [
            {'role': 'system', 'content': self.SYSTEM_PROMPT},
            {'role': 'user', 'content': user_msg},
        ]

        # 调用大模型
        response = self.backend.chat(messages, temperature=0.7)
        if not response:
            logger.warning('大模型无响应')
            return None

        # 解析 — Agnes 等真模型偶尔因 max_tokens 截断或包 markdown 代码块导致 json.loads 失败
        # 多重兜底: 剥代码块 → 完整解析 → 正则提取 → 补齐右括号 → 失败
        import re
        def _try_parse(s):
            try:
                return json.loads(s)
            except json.JSONDecodeError:
                return None

        data = None
        # 1. 剥 markdown ```json ... ``` 包裹
        cleaned = response.strip()
        if cleaned.startswith('```'):
            cleaned = re.sub(r'^```(?:json)?\s*', '', cleaned)
            cleaned = re.sub(r'\s*```$', '', cleaned)
        data = _try_parse(cleaned)
        if data: 
            return self._inject_teach(topic, phase, data, response)

        # 2. 正则提取最外层 { ... }
        match = re.search(r'\{.*\}', response, re.DOTALL)
        if match:
            data = _try_parse(match.group())
            if data:
                return self._inject_teach(topic, phase, data, response)

        # 3. 补齐右括号 — JSON 被截断时数 { } 差补 } 再试
        snippet = cleaned if not match else match.group()
        opens = snippet.count('{')
        closes = snippet.count('}')
        if opens > closes:
            patched = snippet + ('}' * (opens - closes))
            data = _try_parse(patched)
            if data:
                logger.info(f'JSON 补齐 {opens-closes} 个右括号后解析成功')
                return self._inject_teach(topic, phase, data, response)

        logger.warning(f'大模型回复无JSON: {response[:120]}')
        return None

    def _inject_teach(self, topic, phase, data, raw_response):
        """teach 的后半段 — 把解析好的 data 注入生物体 (从 teach 抽出避免上面多重 return 重复)"""
        time_ref = time.time()

        # 注入生物体
        new_concepts = data.get('new_concepts', [])
        new_connections = data.get('new_connections', [])
        advice = data.get('advice', '')

        added_concepts = 0
        added_connections = 0

        for name in new_concepts:
            w = self.organism.brain.swarm.get(name)
            if not w:
                self.organism.brain.swarm.spawn(name, 'taught', 0.0)
                added_concepts += 1

        for conn in new_connections:
            if len(conn) >= 3:
                a, b, strength = conn[0], conn[1], float(conn[2])
                wa = self.organism.brain.swarm.get(a)
                wb = self.organism.brain.swarm.get(b)
                if wa and wb:
                    self.organism.brain.swarm.link(a, b, min(1.0, max(0.0, strength)))
                    added_connections += 1
                elif not wa or not wb:
                    # 缺的概念先创建
                    if not wa:
                        self.organism.brain.swarm.spawn(a, 'taught', 0.0)
                        added_concepts += 1
                    if not wb:
                        self.organism.brain.swarm.spawn(b, 'taught', 0.0)
                        added_concepts += 1
                    self.organism.brain.swarm.link(a, b, min(1.0, max(0.0, strength)))
                    added_connections += 1

        # 写入知识树
        if advice:
            self.organism.body.learn(
                topic=f'老师教: {topic}',
                content=f'概念: {new_concepts}, 连接: {new_connections}, 建议: {advice}',
                source='teacher'
            )

        record = {
            'topic': topic, 'phase': phase,
            'new_concepts': added_concepts, 'new_connections': added_connections,
            'advice': advice, 'time': time_ref,
        }
        self.teachings.append(record)
        logger.info(f'教了"{topic}": +{added_concepts}概念, +{added_connections}连接')
        return record

    def evaluate(self, decision_result, outcome):
        """
        评价决策 — 大模型给反馈

        决策后调用，让大模型评价这个决策好不好
        """
        phase = self._get_phase()
        if phase == 3:
            return None  # 放手阶段不评价

        decision = decision_result.get('decision', {})
        action = decision.get('action', '?')
        score = decision.get('score', 0)

        messages = [
            {'role': 'system', 'content': self.SYSTEM_PROMPT},
            {'role': 'user', 'content': f'我做了决策"{action}"(分数{score:.2f})，结果是{"成功" if outcome > 0.5 else "失败"}。这个决策好不好？如果有更好的选择请告诉我。'},
        ]

        response = self.backend.chat(messages, temperature=0.5, max_tokens=300)
        if not response:
            return None

        # 调整valence
        if outcome > 0.5:
            w = self.organism.brain.swarm.get(action)
            if w:
                w.valence = min(1.0, w.valence + 0.05)
        else:
            w = self.organism.brain.swarm.get(action)
            if w:
                w.valence = max(-1.0, w.valence - 0.05)

        return response

    def explain(self, text):
        """
        解释内容 — 大模型理解一段文本，提取概念

        爬虫抓到网页后调用
        """
        messages = [
            {'role': 'system', 'content': '你是内容分析专家。提取关键概念和它们之间的关系。用JSON格式: {"concepts": [...], "connections": [[A,B,strength],...], "summary": "..."}'},
            {'role': 'user', 'content': f'分析这段内容:\n{text[:2000]}'},
        ]

        response = self.backend.chat(messages, temperature=0.3, max_tokens=500)
        if not response:
            return None

        try:
            import re
            match = re.search(r'\{.*\}', response, re.DOTALL)
            if match:
                data = json.loads(match.group())
            else:
                return None
        except json.JSONDecodeError:
            return None

        # 注入
        concepts = data.get('concepts', [])
        connections = data.get('connections', [])
        summary = data.get('summary', '')

        for name in concepts:
            if not self.organism.brain.swarm.get(name):
                self.organism.brain.swarm.spawn(name, 'learned', 0.0)

        for conn in connections:
            if len(conn) >= 3:
                self.organism.brain.swarm.link(conn[0], conn[1], min(1.0, max(0.0, float(conn[2]))))

        if summary:
            self.organism.body.learn(topic=f'理解: {summary[:30]}', content=summary, source='teacher')

        return data

    def auto_teach(self, max_topics=5):
        """
        自动教学 — 根据当前阶段自动选主题教

        第1阶段: 教基础（爬虫、分析、学习）
        第2阶段: 教进阶（反爬、数据清洗、分布式）
        第3阶段: 不教
        """
        phase = self._get_phase()
        results = []

        if phase == 1:
            topics = ['爬虫', '分析', '通用']
            for topic in topics[:max_topics]:
                r = self.teach(topic)
                if r:
                    results.append(r)

        elif phase == 2:
            # 找当前最弱的方向教
            active = self.organism.brain.swarm.get_active(threshold=0.01)
            weak_areas = []
            for name in ['爬虫', '分析', '学习', '调度']:
                w = self.organism.brain.swarm.get(name)
                if w and w.baseline < 0.3:
                    weak_areas.append(name)
            for topic in weak_areas[:max_topics]:
                r = self.teach(topic)
                if r:
                    results.append(r)

        return results

    def get_stats(self):
        return {
            'total_teachings': len(self.teachings),
            'concepts_taught': sum(t.get('new_concepts', 0) for t in self.teachings),
            'connections_taught': sum(t.get('new_connections', 0) for t in self.teachings),
            'phase': self._get_phase(),
        }
