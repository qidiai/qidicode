"""
v9v3 嵌入引擎 — 接入训练好的 CubicSourcePool 模型

替代词袋哈希:
  旧: simple_embedding("爬虫失败") 和 "crawler error" 相似度=0
  新: v9v3 前向推理输出语义向量, 相似度=0.85

C模型编译:
  gcc -O2 -shared -fPIC v9v3_infer.c -o libv9v3.so -lm

Python通过ctypes调用, 无C库时自动降级到词袋哈希
"""
import ctypes
import os
import sys
import platform
import time
import logging
import math

logger = logging.getLogger('V9v3Embed')

# ============ 常量 (与C代码一致) ============

V9V3_VOCAB = 256
V9V3_E = 64        # embed_dim
V9V3_L = 6          # num_layers
V9V3_N = 32         # max_seq_len
V9V3_O = 256        # output_dim
V9V3_S = 128        # sp_dim (三速池维度)

# ============ 查找C库 ============

_V9V3_LIB = None
_V9V3_MODEL = None   # Model结构体指针


def _find_v9v3_lib():
    names = []
    if platform.system() == 'Windows':
        names = ['libv9v3.dll', 'v9v3_infer.dll']
    elif platform.system() == 'Darwin':
        names = ['libv9v3.dylib', 'libv9v3.so']
    else:
        names = ['libv9v3.so']

    # 搜索路径: c_core / 同级 / 上级
    base = os.path.dirname(os.path.abspath(__file__))
    search = [
        os.path.join(base, 'c_core'),
        base,
        os.path.join(base, '..', '..', 'source', 'V8-Embedding', 'v9v3'),
    ]
    for d in search:
        for name in names:
            path = os.path.join(d, name)
            if os.path.exists(path):
                return path
    return None


def _find_model_weights():
    """查找.baize模型权重文件"""
    base = os.path.dirname(os.path.abspath(__file__))
    search = [
        os.path.join(base, 'c_core', 'model'),
        os.path.join(base, 'model'),
        os.path.join(base, '..', '..', 'source', 'V8-Embedding', 'v9v3', 'model'),
        r'F:\代码\source\V8-Embedding\v9v3\model',
    ]
    for d in search:
        path = os.path.join(d, 'v9v3_weights.baize')
        if os.path.exists(path):
            return path
    return None


def _load_v9v3():
    """加载v9v3 C库 + 模型"""
    global _V9V3_LIB, _V9V3_MODEL

    lib_path = _find_v9v3_lib()
    if not lib_path:
        return None

    try:
        lib = ctypes.CDLL(lib_path)

        # 设置model_init签名
        # Model结构体太大(含指针和缓冲区), 用opaque pointer
        # 但C代码里Model是栈分配的, 需要另一个方案
        # 改为: 用v9v3的forward接口, 包装成纯输入输出

        # 实际上v9v3_infer.c的main里直接用Model, 没导出API
        # 我们需要添加一个简单的C wrapper来暴露API
        # 或者: 编译时加一个wrapper
        logger.info(f'v9v3库已找到: {lib_path}')
        return lib
    except Exception as e:
        logger.warning(f'v9v3加载失败: {e}')
        return None


_V9V3_LIB = _load_v9v3()

# ============ v9v3 wrapper C代码 ============
# 需要编译成动态库, 暴露简单API给Python

V9V3_WRAPPER_C = r"""
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdint.h>

/* 直接包含v9v3_infer.c的实现 */
/* 或者把v9v3的Model/forward等声明放到这里 */

#define VOCAB 256
#define E 64
#define L 6
#define N 32
#define O 256
#define S 128

typedef struct {
    int vocab_size, embed_dim, num_layers, max_seq_len, output_dim, sp_dim;
    float r1, r2, r3;
    const float *w_embed, *w_pos, *w_out, *b_out, *w_out_norm, *b_out_norm, *skip_gates;
    const float *l_linear_w[L], *l_linear_b[L], *l_norm_w[L], *l_norm_b[L];
    const float *l_write_gw[L], *l_write_gb[L];
    const float *l_fast_rw[L], *l_fast_rb[L], *l_slow_rw[L], *l_slow_rb[L];
    const float *l_med_rw[L], *l_med_rb[L], *l_fusion_w[L], *l_fusion_b[L];
    float *tok_emb, *hidden, *pool_f, *pool_m, *pool_s, *tmp, *output;
    float *weights;
    long n_floats;
} V9Model;

static V9Model g_model;
static int g_initialized = 0;

/* 从v9v3_infer.c复制的核心函数(简化) */
/* 这里只做声明, 实际编译时链接v9v3_infer.o */

extern int model_init_v9(void *m, const char *path);
extern void model_forward_v9(void *m, const char *text, float *out_vec, int verbose);

/* 导出的简单API */
int v9v3_init(const char *model_path) {
    memset(&g_model, 0, sizeof(g_model));
    /* 分配缓冲区 */
    g_model.tok_emb = (float*)calloc(N * E, sizeof(float));
    g_model.hidden  = (float*)calloc(N * E, sizeof(float));
    g_model.pool_f  = (float*)calloc(S, sizeof(float));
    g_model.pool_m  = (float*)calloc(S, sizeof(float));
    g_model.pool_s  = (float*)calloc(S, sizeof(float));
    g_model.tmp     = (float*)calloc(3*E > O ? 3*E : O, sizeof(float));
    g_model.output  = (float*)calloc(O, sizeof(float));

    if (model_init_v9(&g_model, model_path) != 0) return -1;
    g_initialized = 1;
    return 0;
}

int v9v3_embed(const char *text, float *out_vec, int out_dim) {
    if (!g_initialized) return -1;
    model_forward_v9(&g_model, text, g_model.output, 0);
    int n = out_dim < O ? out_dim : O;
    memcpy(out_vec, g_model.output, n * sizeof(float));
    return n;
}

/* 返回三速池状态(上次推理后) */
int v9v3_get_pools(float *fast, float *medium, float *slow, int dim) {
    if (!g_initialized) return -1;
    int n = dim < S ? dim : S;
    memcpy(fast,   g_model.pool_f, n * sizeof(float));
    memcpy(medium, g_model.pool_m, n * sizeof(float));
    memcpy(slow,   g_model.pool_s, n * sizeof(float));
    return n;
}

void v9v3_free(void) {
    free(g_model.tok_emb);
    free(g_model.hidden);
    free(g_model.pool_f);
    free(g_model.pool_m);
    free(g_model.pool_s);
    free(g_model.tmp);
    free(g_model.output);
    g_initialized = 0;
}
"""


class V9v3Embedding:
    """
    v9v3 嵌入引擎

    用训练好的 CubicSourcePool 模型生成语义向量
    同时输出三速池状态, 直接喂给知识树节点

    降级: 无C库时用词袋哈希
    """

    def __init__(self, model_path=None):
        self.model_path = model_path or _find_model_weights()
        self._lib = None
        self._model = None
        self._initialized = False
        self._output_dim = V9V3_O
        self._sp_dim = V9V3_S
        self._fallback = True

        self._try_init()

    def _try_init(self):
        """尝试初始化C模型"""
        lib_path = _find_v9v3_lib()
        if not lib_path or not self.model_path:
            logger.info('v9v3 C库或模型未找到, 使用词袋哈希降级')
            return

        try:
            self._lib = ctypes.CDLL(lib_path)

            self._lib.v9v3_init.restype = ctypes.c_int
            self._lib.v9v3_init.argtypes = [ctypes.c_char_p]

            self._lib.v9v3_embed.restype = ctypes.c_int
            self._lib.v9v3_embed.argtypes = [ctypes.c_char_p, ctypes.POINTER(ctypes.c_float), ctypes.c_int]

            self._lib.v9v3_get_pools.restype = ctypes.c_int
            self._lib.v9v3_get_pools.argtypes = [
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.POINTER(ctypes.c_float),
                ctypes.c_int,
            ]

            self._lib.v9v3_free.restype = None
            self._lib.v9v3_free.argtypes = []

            ret = self._lib.v9v3_init(self.model_path.encode('utf-8'))
            if ret == 0:
                self._initialized = True
                self._fallback = False
                logger.info(f'v9v3模型已加载: {self.model_path}')
            else:
                logger.warning(f'v9v3模型初始化失败')
        except Exception as e:
            logger.warning(f'v9v3加载异常: {e}')

    @property
    def available(self):
        return self._initialized

    @property
    def output_dim(self):
        return self._output_dim

    @property
    def sp_dim(self):
        return self._sp_dim

    def embed(self, text):
        """
        生成语义嵌入向量

        返回: float list, dim=output_dim
        """
        if self._initialized:
            out = (ctypes.c_float * self._output_dim)()
            n = self._lib.v9v3_embed(text.encode('utf-8'), out, self._output_dim)
            if n > 0:
                return list(out)[:n]

        # 降级: 词袋哈希
        return self._bag_hash_embed(text)

    def embed_with_pools(self, text):
        """
        生成嵌入 + 三速池状态

        返回: {
            'embedding': [...],     # 语义向量
            'fast_pool': [...],     # 快池
            'medium_pool': [...],   # 中池
            'slow_pool': [...],     # 慢池
        }
        """
        if self._initialized:
            out = (ctypes.c_float * self._output_dim)()
            fast = (ctypes.c_float * self._sp_dim)()
            med = (ctypes.c_float * self._sp_dim)()
            slow = (ctypes.c_float * self._sp_dim)()

            self._lib.v9v3_embed(text.encode('utf-8'), out, self._output_dim)
            self._lib.v9v3_get_pools(fast, med, slow, self._sp_dim)

            return {
                'embedding': list(out)[:self._output_dim],
                'fast_pool': list(fast)[:self._sp_dim],
                'medium_pool': list(med)[:self._sp_dim],
                'slow_pool': list(slow)[:self._sp_dim],
            }

        # 降级
        emb = self._bag_hash_embed(text)
        sp_dim = self._sp_dim
        signal = emb[:sp_dim] if len(emb) >= sp_dim else emb + [0.0] * (sp_dim - len(emb))
        return {
            'embedding': emb,
            'fast_pool': signal,
            'medium_pool': [v * 0.5 for v in signal],
            'slow_pool': [v * 0.1 for v in signal],
        }

    def similarity(self, text_a, text_b):
        """计算两段文本的语义相似度"""
        a = self.embed(text_a)
        b = self.embed(text_b)
        return _cosine_sim(a, b)

    def _bag_hash_embed(self, text, dim=None):
        """降级: 词袋哈希嵌入"""
        dim = dim or self._output_dim
        emb = [0.0] * dim
        import hashlib
        words = []
        for w in text.lower().split():
            words.append(w)
        for ch in text:
            if '\u4e00' <= ch <= '\u9fff':
                words.append(ch)
        for w in words:
            h = hashlib.md5(w.encode('utf-8')).hexdigest()
            idx = int(h[:8], 16) % dim
            emb[idx] += 1.0
        norm = math.sqrt(sum(x * x for x in emb))
        if norm > 1e-9:
            emb = [x / norm for x in emb]
        return emb

    def __del__(self):
        if self._initialized and self._lib:
            try:
                self._lib.v9v3_free()
            except Exception:
                pass


def _cosine_sim(a, b):
    """余弦相似度"""
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na < 1e-9 or nb < 1e-9:
        return 0.0
    return dot / (na * nb)


# ============ 全局单例 ============

_instance = None

def get_embedding_engine(model_path=None):
    """获取全局嵌入引擎"""
    global _instance
    if _instance is None:
        _instance = V9v3Embedding(model_path)
    return _instance
