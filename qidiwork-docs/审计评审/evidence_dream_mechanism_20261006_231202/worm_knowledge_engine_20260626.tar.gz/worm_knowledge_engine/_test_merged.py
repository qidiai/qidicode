"""实测合并后的统一知识树界面"""
import os, sys, time, json, urllib.request
sys.path.insert(0, r'F:\代码\导入数据\闲置算力系统')
os.chdir(r'F:\代码\导入数据\闲置算力系统')

from worm_knowledge_engine.organism import Organism
from worm_knowledge_engine.teacher import Teacher, MockBackend
from worm_knowledge_engine.dialogue import Dialogue
from worm_knowledge_engine.self_evolve import SelfEvolve
from worm_knowledge_engine.webui import OrganismWebUI

print('启动服务器...')
org = Organism(data_dir='data', name='demo')
teacher = Teacher(org, backend=MockBackend())
dialogue = Dialogue(org, teacher=teacher)
evolve = SelfEvolve(org, teacher=teacher)
try: teacher.auto_teach(max_topics=3)
except Exception as e: print('auto_teach warn:', e)

ui = OrganismWebUI(org, teacher=teacher, dialogue=dialogue, evolve=evolve, port=8088)
ui.start()
print('服务器: http://localhost:8088')
time.sleep(2.5)

def get(p):
    try:
        r = urllib.request.urlopen(f'http://localhost:8088{p}', timeout=8)
        return r.status, r.read()
    except Exception as e:
        return 'ERR', str(e).encode()

def post(p, d):
    try:
        req = urllib.request.Request(f'http://localhost:8088{p}', data=json.dumps(d).encode(),
            headers={'Content-Type':'application/json'}, method='POST')
        r = urllib.request.urlopen(req, timeout=15)
        return r.status, r.read()
    except Exception as e:
        return 'ERR', str(e).encode()

allok = True
print('\n=== 路由合并验证（两个路径应返回同一页面）===')
s1, b1 = get('/knowledge-tree')
s2, b2 = get('/knowledge-tree-3d')
same = b1 == b2 and s1 == 200 and s2 == 200
print(f'  /knowledge-tree: {s1} {len(b1)} bytes')
print(f'  /knowledge-tree-3d: {s2} {len(b2)} bytes')
print(f'  两者一致: {"OK" if same else "FAIL"}')
if not same: allok = False

print('\n=== 合并页面特性 ===')
t = b1.decode('utf-8', errors='ignore')
feats = {
    '左侧列表 sidebar': 'sidebar' in t and 'tree-list' in t,
    '右侧 3D 大树 canvas': 'canvas-wrap' in t,
    '编辑抽屉滑出': 'editor' in t and 'classList' in t and 'show' in t,
    '树干 CylinderGeometry': 'CylinderGeometry' in t,
    '树枝 addBranch': 'addBranch' in t,
    '叶节点 isLeaf': 'isLeaf' in t,
    '颜色按深度 COLORS': 'COLORS' in t,
    '旋转缩放 OrbitControls': 'OrbitControls' in t,
    '拖拽碰撞 checkCollision': 'checkCollision' in t,
    '互动 /api/interact': '/api/interact' in t,
    '列表搜索 onSearch': 'onSearch' in t,
    '关联推测 suggestRelated': 'suggestRelated' in t,
    'Three.js importmap': 'importmap' in t,
}
for k, v in feats.items():
    if not v: allok = False
    print(f'  [{"OK" if v else "FAIL"}] {k}')

print('\n=== API 端点 ===')
for p in ['/api/tree', '/api/status', '/api/brain', '/api/suggest?id=root']:
    s, b = get(p)
    ok = s == 200
    if not ok: allok = False
    print(f'  [{"OK" if ok else "FAIL"}] {p} -> {s} {len(b)}b')

print('\n=== 编辑 + 互动流程 ===')
td = json.loads(get('/api/tree')[1])
ids = [n['id'] for n in td['nodes'] if n['id'] != 'root'][:2]
if len(ids) >= 2:
    # 编辑
    s, b = post('/api/node/update', {'id': ids[0], 'content': '合并测试内容', 'topic': '合并测试'})
    upd = json.loads(b); ok = upd.get('ok')
    print(f'  [{"OK" if ok else "FAIL"}] 编辑节点 {ids[0]}')
    if not ok: allok = False
    # 互动
    s, b = post('/api/interact', {'a': ids[0], 'b': ids[1]})
    ir = json.loads(b); ok = ir.get('ok')
    print(f'  [{"OK" if ok else "FAIL"}] 互动 {ids[0]} x {ids[1]} -> hits={len(ir.get("hits",[]))}')
    if not ok: allok = False
else:
    print('  节点不足，跳过')

print('\n' + '='*40)
print('OVERALL:', 'ALL PASSED' if allok else 'SOME FAILED')

# 保持 30 秒供浏览器访问
print('\n服务器保持 30 秒，可访问 http://localhost:8088/knowledge-tree')
try: time.sleep(30)
except KeyboardInterrupt: pass
ui.stop()
print('已停止')
