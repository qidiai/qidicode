"""
知识树可视化 — 星空版
左侧：树状列表（搜索/编辑/添加）
右侧：3D 星空点（知识像星星闪烁，父子之间用线连）
嵌入 webui.py 使用: from .knowledge_tree_visual import get_knowledge_tree_page
"""
import json, os, time, math
from .v10_embed import embed
from .cube3d import Cube3D, text_to_domain_weights

PAGE_HTML = r"""<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>知识星空</title>
<style>
:root{
  --bg:#050810; --bg-2:#0a1020; --panel:#0d1525; --panel-2:#142036;
  --border:#1a2845; --border-soft:#142036;
  --text:#e6edf3; --dim:#8b9bb4; --muted:#4a5878;
  --accent:#00ff9c; --accent-2:#00cc7a; --glow:rgba(0,255,156,.22);
  --info:#5ab8ff; --warn:#ffb454; --danger:#ff5c5c; --purple:#b889ff;
  --r:10px; --rs:6px;
  --tr:.2s cubic-bezier(.4,0,.2,1);
  --shadow:0 8px 32px rgba(0,0,0,.5);
}
*{margin:0;padding:0;box-sizing:border-box}
html,body{height:100%;overflow:hidden}
body{
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif;
  background:
    radial-gradient(1400px 800px at 80% -10%,rgba(0,255,156,.06),transparent 55%),
    radial-gradient(1000px 700px at -10% 110%,rgba(90,184,255,.05),transparent 55%),
    var(--bg);
  color:var(--text);display:flex;
}

/* ─── 左侧列表 ─────────────────────────────── */
.sidebar{
  width:320px;min-width:320px;background:linear-gradient(180deg,var(--panel),var(--bg-2));
  border-right:1px solid var(--border);display:flex;flex-direction:column;overflow:hidden;
  box-shadow:4px 0 24px rgba(0,0,0,.3);z-index:5;
}
.sidebar-head{
  padding:16px 16px 12px;border-bottom:1px solid var(--border);
  background:linear-gradient(135deg,rgba(0,255,156,.08),transparent);
}
.sidebar-head h2{
  font-size:16px;font-weight:600;display:flex;align-items:center;gap:8px;margin-bottom:6px;
  background:linear-gradient(135deg,var(--accent),var(--info));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
.sidebar-head .stat{
  font-size:11px;color:var(--dim);font-family:"SF Mono",Consolas,monospace;
  display:inline-block;background:var(--bg);padding:3px 10px;border-radius:10px;border:1px solid var(--border-soft);
}
.search-box{padding:10px 12px;border-bottom:1px solid var(--border-soft)}
.search-box input{
  width:100%;background:var(--bg);border:1px solid var(--border);color:var(--text);
  padding:8px 12px;border-radius:20px;font-size:13px;outline:none;
  transition:border-color var(--tr),box-shadow var(--tr);
}
.search-box input:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--glow)}
.list-actions{padding:8px 12px;display:flex;gap:6px;flex-wrap:wrap;border-bottom:1px solid var(--border-soft)}
.list-actions button{
  flex:1;min-width:50px;background:var(--panel-2);border:1px solid var(--border);color:var(--dim);
  padding:5px 6px;border-radius:var(--rs);cursor:pointer;font-size:11px;transition:all var(--tr);
}
.list-actions button:hover{border-color:var(--accent);color:var(--accent);background:rgba(0,255,156,.06)}
#tree-list{flex:1;overflow-y:auto;padding:6px 8px}
#tree-list::-webkit-scrollbar{width:6px}
#tree-list::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
#tree-list::-webkit-scrollbar-thumb:hover{background:var(--muted)}

.tnode{
  padding:6px 8px;margin:2px 0;border-radius:var(--rs);font-size:12px;cursor:pointer;
  display:flex;align-items:center;gap:6px;transition:all var(--tr);border-left:2px solid transparent;
}
.tnode:hover{background:var(--panel-2);border-left-color:var(--accent-2)}
.tnode.active{background:rgba(0,255,156,.12);border-left-color:var(--accent);box-shadow:0 0 12px rgba(0,255,156,.15)}
.tnode.match{background:rgba(255,180,84,.1)}
.tnode .toggle{width:12px;text-align:center;color:var(--muted);font-size:10px;flex-shrink:0;user-select:none}
.tnode .toggle:hover{color:var(--accent)}
.tnode .icon{font-size:11px;flex-shrink:0}
.tnode .label{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tnode .badge{
  font-size:9px;background:var(--border);color:var(--dim);padding:1px 6px;border-radius:8px;flex-shrink:0;
  font-family:"SF Mono",Consolas,monospace;
}
.tnode.dying{opacity:.5}
.tchild{margin-left:12px;border-left:1px dashed var(--border-soft);padding-left:3px}

/* ─── 右侧 3D 区 ───────────────────────────── */
.main{flex:1;display:flex;flex-direction:column;overflow:hidden;position:relative}
.main-head{
  padding:12px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:14px;
  background:linear-gradient(180deg,var(--panel),transparent);z-index:5;
}
.main-head h1{
  font-size:17px;font-weight:600;background:linear-gradient(135deg,var(--accent),var(--info));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
.main-head .controls{display:flex;gap:6px;margin-left:auto;flex-wrap:wrap}
.main-head .controls button{
  background:var(--panel-2);border:1px solid var(--border);color:var(--dim);
  padding:6px 12px;border-radius:var(--rs);cursor:pointer;font-size:11px;transition:all var(--tr);
}
.main-head .controls button:hover{border-color:var(--accent);color:var(--accent);background:rgba(0,255,156,.06)}
.main-head .controls button:active{transform:scale(.96)}

#canvas-wrap{flex:1;position:relative;overflow:hidden;background:radial-gradient(ellipse at center,rgba(0,255,156,.03),transparent 70%)}
#canvas-wrap canvas{display:block;cursor:grab}
#canvas-wrap canvas:active{cursor:grabbing}

#help-tip{
  position:absolute;bottom:12px;right:12px;background:rgba(10,16,32,.88);backdrop-filter:blur(12px);
  border:1px solid var(--border);border-radius:var(--r);padding:10px 14px;font-size:10px;color:var(--dim);
  line-height:1.8;max-width:220px;box-shadow:var(--shadow);z-index:8;
}
#help-tip b{color:var(--accent);font-weight:500}
#node-tip{
  position:absolute;z-index:12;background:rgba(10,16,32,.95);border:1px solid var(--accent);
  border-radius:4px;padding:4px 10px;font-size:11px;color:var(--text);pointer-events:none;display:none;
  box-shadow:0 2px 12px rgba(0,0,0,.5);white-space:nowrap;
}

/* ─── 编辑面板 ─────────────────────────────── */
#editor{
  position:absolute;top:0;right:0;width:380px;max-width:90%;height:100%;z-index:30;
  background:linear-gradient(180deg,var(--panel),var(--bg-2));border-left:1px solid var(--accent);
  box-shadow:-12px 0 48px rgba(0,0,0,.5),0 0 24px var(--glow);
  transform:translateX(100%);transition:transform .28s cubic-bezier(.4,0,.2,1);
  display:flex;flex-direction:column;overflow:hidden;
}
#editor.show{transform:translateX(0)}
.editor-head{
  padding:16px 18px 12px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px;
  background:linear-gradient(135deg,rgba(0,255,156,.08),transparent);
}
.editor-head h3{font-size:15px;color:var(--accent);font-weight:600;flex:1;display:flex;align-items:center;gap:8px}
.editor-head .close{
  width:26px;height:26px;border-radius:50%;background:var(--panel-2);border:1px solid var(--border);
  color:var(--dim);cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:13px;
  transition:all var(--tr);
}
.editor-head .close:hover{color:var(--danger);border-color:var(--danger);transform:rotate(90deg)}
.editor-body{flex:1;overflow-y:auto;padding:18px}
.editor-body::-webkit-scrollbar{width:6px}
.editor-body::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
.editor-body .meta{
  display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;font-size:10px;color:var(--dim);
  font-family:"SF Mono",Consolas,monospace;
}
.editor-body .meta span{background:var(--bg);padding:3px 8px;border-radius:4px;border:1px solid var(--border-soft)}
.editor-body .meta .ok{color:var(--accent);border-color:rgba(0,255,156,.3)}
.editor-body .meta .warn{color:var(--danger);border-color:rgba(255,92,92,.3)}
.editor-body label{display:block;color:var(--dim);font-size:11px;margin-top:12px;margin-bottom:5px;font-weight:500}
.editor-body input,.editor-body textarea{
  width:100%;background:var(--bg);border:1px solid var(--border);color:var(--text);
  padding:9px 11px;border-radius:var(--rs);font-size:12px;outline:none;font-family:inherit;
  transition:border-color var(--tr),box-shadow var(--tr);line-height:1.6;
}
.editor-body input:focus,.editor-body textarea:focus{border-color:var(--accent);box-shadow:0 0 0 3px var(--glow)}
.editor-body textarea{min-height:160px;resize:vertical}
.content-preview{
  white-space:pre-wrap;font-size:12px;line-height:1.7;color:var(--dim);margin-bottom:12px;
  padding:12px;background:var(--bg);border-radius:var(--rs);border:1px solid var(--border-soft);
  max-height:180px;overflow-y:auto;
}
.editor-foot{padding:14px 18px;border-top:1px solid var(--border);display:flex;gap:8px;flex-wrap:wrap;background:var(--panel)}
.editor-foot button{
  padding:8px 14px;border:none;border-radius:var(--rs);cursor:pointer;font-size:12px;font-weight:500;
  transition:all var(--tr);flex:1;min-width:70px;
}
.editor-foot button:hover{transform:translateY(-1px);box-shadow:0 4px 12px rgba(0,0,0,.3)}
.editor-foot button:active{transform:translateY(0)}
.btn-save{background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#001b0e}
.btn-cancel{background:var(--panel-2);color:var(--text);border:1px solid var(--border)}
.btn-add{background:linear-gradient(135deg,var(--info),#3a8ee8);color:#0d1117}
.btn-delete{background:transparent;color:var(--danger);border:1px solid rgba(255,92,92,.4)}
.btn-suggest{background:linear-gradient(135deg,var(--purple),#8a5cff);color:#fff}

#suggestions{
  margin-top:12px;padding:10px;background:var(--bg);border-radius:var(--rs);border:1px solid var(--border-soft);display:none;
}
#suggestions h4{font-size:11px;color:var(--purple);margin-bottom:6px;font-weight:500}
#suggestions .item{
  padding:7px 9px;font-size:11px;color:var(--dim);cursor:pointer;border-radius:4px;
  transition:all var(--tr);display:flex;align-items:center;gap:8px;
}
#suggestions .item:hover{color:var(--purple);background:var(--panel-2)}
#suggestions .item .score{margin-left:auto;font-size:10px;color:var(--muted);font-family:"SF Mono",Consolas,monospace}

#interact{
  position:absolute;bottom:12px;left:12px;z-index:20;background:rgba(10,16,32,.94);
  backdrop-filter:blur(12px);border:1px solid var(--purple);border-radius:var(--r);
  padding:12px 16px;max-width:320px;max-height:42vh;overflow-y:auto;display:none;
  box-shadow:var(--shadow),0 0 20px rgba(184,137,255,.25);
}
#interact h4{color:var(--purple);font-size:11px;margin-bottom:6px;font-weight:500}
#interact .pair{font-size:10px;color:var(--dim);margin-bottom:8px;line-height:1.6}
#interact .pair b{color:var(--accent)}
#interact .hit{
  padding:6px 8px;font-size:11px;color:var(--dim);cursor:pointer;border-radius:4px;
  transition:all var(--tr);display:flex;justify-content:space-between;gap:8px;align-items:center;
}
#interact .hit:hover{color:var(--purple);background:var(--panel-2)}
#interact .hit .score{color:var(--muted);font-family:"SF Mono",Consolas,monospace;font-size:10px}
#interact .close{position:absolute;top:6px;right:10px;cursor:pointer;color:var(--muted);font-size:12px}
#interact .close:hover{color:var(--danger)}

#toast{
  position:fixed;bottom:20px;left:50%;transform:translateX(-50%) translateY(20px);
  background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#001b0e;
  padding:10px 22px;border-radius:20px;font-size:12px;font-weight:500;z-index:200;
  opacity:0;transition:all .3s;pointer-events:none;box-shadow:0 6px 20px var(--glow);
}
#toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

.loading{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:13px;z-index:50;background:var(--bg)}
.loading .spin{display:inline-block;width:26px;height:26px;border:2px solid var(--border);border-top-color:var(--accent);border-radius:50%;animation:rot 1s linear infinite;margin-right:10px}
@keyframes rot{to{transform:rotate(360deg)}}

@media(max-width:900px){
  body{flex-direction:column}
  .sidebar{width:100%;min-width:0;max-height:40vh;border-right:none;border-bottom:1px solid var(--border)}
  #editor{width:100%}
}
</style>
</head>
<body>

<div class="sidebar">
  <div class="sidebar-head">
    <h2>✦ 知识星空</h2>
    <span class="stat" id="stat">加载中…</span>
  </div>
  <div class="search-box">
    <input id="search" placeholder="搜索节点…" oninput="onSearch(this.value)">
  </div>
  <div class="list-actions">
    <button onclick="expandAll()">展开</button>
    <button onclick="collapseAll()">收起</button>
    <button onclick="addRootNode()">+ 新建</button>
    <button onclick="resetView()">复位</button>
  </div>
  <div id="tree-list"></div>
</div>

<div class="main">
  <div class="main-head">
    <h1>✦ 知识星空</h1>
    <div class="controls">
      <button onclick="resetView()">复位视角</button>
      <button onclick="reload()">刷新</button>
      <button onclick="location.href='/'">返回</button>
    </div>
  </div>
  <div id="canvas-wrap">
    <div class="loading" id="loading"><span class="spin"></span>构建星空…</div>
    <div id="help-tip">
      <div><b>拖空白</b> 旋转</div>
      <div><b>滚轮</b> 缩放</div>
      <div><b>点击星点</b> 查看</div>
      <div><b>拖星点碰撞</b> 关联检索</div>
    </div>
    <div id="node-tip"></div>
    <div id="interact">
      <span class="close" onclick="this.parentElement.style.display='none'">✕</span>
      <h4>🔗 互动检索</h4>
      <div class="pair" id="ir-pair"></div>
      <div id="ir-hits"></div>
    </div>
  </div>
</div>

<div id="editor">
  <div class="editor-head">
    <h3 id="e-title">节点</h3>
    <button class="close" onclick="closeEditor()">✕</button>
  </div>
  <div class="editor-body">
    <div class="meta" id="e-meta"></div>
    <div class="content-preview" id="e-preview"></div>
    <label>主题</label>
    <input id="e-topic" placeholder="节点主题">
    <label>内容</label>
    <textarea id="e-content" placeholder="节点内容…"></textarea>
    <div id="suggestions"></div>
  </div>
  <div class="editor-foot">
    <button class="btn-delete" onclick="deleteNode()">删除</button>
    <button class="btn-add" onclick="addChild()">+ 子节点</button>
    <button class="btn-suggest" onclick="suggestRelated()">关联</button>
    <button class="btn-cancel" onclick="closeEditor()">取消</button>
    <button class="btn-save" onclick="saveNode()">保存</button>
  </div>
</div>

<div id="toast"></div>

<script type="importmap">
{
  "imports": {
    "three": "https://unpkg.com/three@0.160.0/build/three.module.js",
    "three/addons/": "https://unpkg.com/three@0.160.0/examples/jsm/"
  }
}
</script>

<script type="module">
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/addons/postprocessing/ShaderPass.js';

const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
function toast(m){const t=$('toast');t.textContent=m;t.classList.add('show');clearTimeout(t._tm);t._tm=setTimeout(()=>t.classList.remove('show'),1800)}

let treeData=null, currentNodeId=null, expandedSet=new Set(), searchQ='';
const nodeById={};

// ═══════════ 左侧列表 ═══════════
async function loadTree(){
  const r=await fetch('/api/tree'); treeData=await r.json();
  treeData.nodes.forEach(n=>nodeById[n.id]=n);
  $('stat').textContent=`${treeData.nodes.length} 节点 · ${treeData.stats?.total_nodes||0}`;
  if(!expandedSet.size && treeData.root_id){const r=nodeById[treeData.root_id];if(r&&(r.children_ids||[]).length)expandedSet.add(r.id)}
  renderList(); buildStarField(); $('loading').style.display='none';
}
function renderList(){
  const c=$('tree-list');
  if(!treeData||!treeData.nodes.length){c.innerHTML='<div style="color:var(--muted);padding:14px;text-align:center">知识树为空</div>';return}
  const root=nodeById[treeData.root_id];
  if(!root){c.innerHTML='<div style="color:var(--muted);padding:14px">找不到根节点</div>';return}
  c.innerHTML=listNodeHTML(root);
}
function listNodeHTML(n){
  const kids=(n.children_ids||[]).map(id=>nodeById[id]).filter(Boolean);
  const hasKids=kids.length>0, exp=expandedSet.has(n.id);
  const tog=hasKids?(exp?'▼':'▶'):'·';
  const isMatch=searchQ&&(n.topic||'').toLowerCase().includes(searchQ.toLowerCase());
  const active=currentNodeId===n.id?' active':'';
  const dying=n.is_dying?' dying':'';
  let h=`<div class="tnode${active}${dying}${isMatch?' match':''}" data-id="${n.id}" onclick="selectNode('${n.id}',true)">
    <span class="toggle" onclick="event.stopPropagation();toggleExpand('${n.id}')">${tog}</span>
    <span class="icon">${n.is_dying?'·':'✦'}</span>
    <span class="label">${esc(n.topic||'未命名')}</span>
    <span class="badge">${n.hit_count||0}</span></div>`;
  if(hasKids&&exp){h+=`<div class="tchild">`;kids.forEach(k=>h+=listNodeHTML(k));h+=`</div>`}
  return h;
}
function toggleExpand(id){if(expandedSet.has(id))expandedSet.delete(id);else expandedSet.add(id);renderList()}
function expandAll(){if(!treeData)return;treeData.nodes.forEach(n=>{if((n.children_ids||[]).length)expandedSet.add(n.id)});renderList()}
function collapseAll(){expandedSet.clear();renderList()}
function onSearch(q){
  searchQ=(q||'').trim();
  if(!searchQ){renderList();clearSearchHighlight();return}
  if(!treeData)return;
  const matches=treeData.nodes.filter(n=>(n.topic||'').toLowerCase().includes(searchQ.toLowerCase()));
  const anc=new Set();
  matches.forEach(m=>{let c=m;while(c&&c.parent_id&&nodeById[c.parent_id]){anc.add(c.parent_id);c=nodeById[c.parent_id]}});
  anc.forEach(id=>expandedSet.add(id));
  renderList();
  // 星空页: 高亮匹配星点 + 飞镜头到第一个匹配
  highlightSearchStars(matches.map(m=>m.id));
  if(matches.length)focusStar(matches[0].id);
}
let searchHighlightedIds=new Set();
function clearSearchHighlight(){searchHighlightedIds.clear();highlightedId=null}
function highlightSearchStars(ids){
  searchHighlightedIds=new Set(ids);
  highlightedId=ids[0]||null;
}
function addRootNode(){const p=prompt('新节点主题:');if(!p)return;addNodeApi(p,'',treeData?treeData.root_id:null)}

// ═══════════ 节点选择 / 编辑 ═══════════
async function selectNode(id,fromList){
  currentNodeId=id;
  document.querySelectorAll('.tnode').forEach(n=>n.classList.remove('active'));
  const el=document.querySelector(`.tnode[data-id="${id}"]`);
  if(el)el.classList.add('active');
  highlightStar(id);
  await openEditor(id);
  if(fromList)focusStar(id);
}
async function openEditor(id){
  const r=await fetch(`/api/node?id=${id}`);const n=await r.json();
  if(n.error){toast(n.error);return}
  currentNodeId=n.id;
  $('e-title').textContent=(n.is_dying?'· ':'✦ ')+(n.topic||'节点');
  $('e-meta').innerHTML=`<span>ID ${esc(n.id)}</span><span>深 ${n.depth||0}</span><span>命中 ${n.hit_count||0}</span><span>子 ${(n.children_ids||[]).length}</span><span class="${n.is_dying?'warn':'ok'}">${n.is_dying?'衰退':'活跃'}</span>`;
  $('e-preview').textContent=n.content||'(空)';
  $('e-topic').value=n.topic||'';
  $('e-content').value=n.content||'';
  $('suggestions').style.display='none';
  $('editor').classList.add('show');
}
function closeEditor(){$('editor').classList.remove('show')}
async function saveNode(){
  const id=currentNodeId;if(!id)return;
  const r=await fetch('/api/node/update',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,topic:$('e-topic').value,content:$('e-content').value})});
  const d=await r.json();if(d.error){toast(d.error);return}
  toast('已保存');closeEditor();await loadTree();
}
async function addChild(){
  const p=prompt('子节点主题:');if(!p)return;
  await addNodeApi(p,'',currentNodeId);
  expandedSet.add(currentNodeId);
  await loadTree();selectNode(currentNodeId,false);
}
async function addNodeApi(topic,content,parent){
  const r=await fetch('/api/node/add',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic,content,parent_id:parent})});
  const d=await r.json();if(d.error){toast(d.error);return false}
  toast('已添加');if(parent)expandedSet.add(parent);await loadTree();return true;
}
async function deleteNode(){
  const id=currentNodeId;if(!id||id==='root'){toast('根节点不可删');return}
  if(!confirm('确定删除此节点及所有子节点？'))return;
  const r=await fetch('/api/node/delete',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})});
  const d=await r.json();if(d.error){toast(d.error);return}
  toast('已删除');closeEditor();currentNodeId=null;await loadTree();
}
async function suggestRelated(){
  if(!currentNodeId)return;
  const box=$('suggestions');box.style.display='block';box.innerHTML='<h4>推测中…</h4>';
  const r=await fetch(`/api/suggest?id=${currentNodeId}`);const d=await r.json();
  const ss=d.suggestions||[];
  if(!ss.length){box.innerHTML='<h4>暂无关联</h4>';return}
  box.innerHTML='<h4>你可能还想了解</h4>'+ss.map(s=>`<div class="item" onclick="selectNode('${esc(s.id)}',false)"><span>✦ ${esc(s.topic)}</span><span class="score">${Math.max(0,(s.score||0)*100).toFixed(0)}%</span></div>`).join('');
}
function reload(){location.reload()}

// ═══════════ 3D 星空场景 ═══════════
const wrap=$('canvas-wrap');
const scene=new THREE.Scene();
scene.fog=new THREE.FogExp2(0x050810,0.005);
const camera=new THREE.PerspectiveCamera(60,1,0.1,2000);
camera.position.set(0,20,80);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setClearColor(0x000000,0);
wrap.appendChild(renderer.domElement);

const controls=new OrbitControls(camera,renderer.domElement);
controls.enableDamping=true;controls.dampingFactor=0.08;
controls.rotateSpeed=0.7;controls.zoomSpeed=1.0;controls.panSpeed=0.7;
controls.minDistance=15;controls.maxDistance=300;

// 背景远星 (营造空间深度) — 三层: 远星场 + 星云尘埃 + 近飘尘
const bgGeo=new THREE.BufferGeometry();
const bgPos=[];for(let i=0;i<800;i++)bgPos.push((Math.random()-0.5)*900,(Math.random()-0.5)*600,(Math.random()-0.5)*900);
bgGeo.setAttribute('position',new THREE.Float32BufferAttribute(bgPos,3));
const bgStars=new THREE.Points(bgGeo,new THREE.PointsMaterial({color:0x2a3a5a,size:0.4,sizeAttenuation:true,transparent:true,opacity:0.5}));
scene.add(bgStars);

// 星云尘埃 — 大颗粒彩色雾, 用 sprite 累加营造星云感
const nebulaGroup=new THREE.Group();scene.add(nebulaGroup);
const nebulaTex=(()=>{const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');const g=x.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(255,255,255,0.8)');g.addColorStop(0.3,'rgba(255,255,255,0.25)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,128,128);return new THREE.CanvasTexture(c)})();
const NEBULA_COLORS=[0x5ab8ff,0xb889ff,0x00ff9c,0xff7ab8];
for(let i=0;i<28;i++){
  const c=NEBULA_COLORS[i%NEBULA_COLORS.length];
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:nebulaTex,color:c,transparent:true,opacity:0.08+Math.random()*0.06,blending:THREE.AdditiveBlending,depthWrite:false}));
  const R=200+Math.random()*200;
  s.position.set((Math.random()-0.5)*R,(Math.random()-0.5)*R*0.6,(Math.random()-0.5)*R);
  s.scale.setScalar(80+Math.random()*120);
  s.userData={drift:Math.random()*0.0008+0.0003,phase:Math.random()*Math.PI*2};
  nebulaGroup.add(s);
}

// 近飘尘 — 细小粒子缓慢漂动, 增加纵深感
const dustGeo=new THREE.BufferGeometry();
const dustPos=[];const dustVel=[];
for(let i=0;i<400;i++){dustPos.push((Math.random()-0.5)*300,(Math.random()-0.5)*200,(Math.random()-0.5)*300);dustVel.push((Math.random()-0.5)*0.02,(Math.random()-0.5)*0.02,(Math.random()-0.5)*0.02)}
dustGeo.setAttribute('position',new THREE.Float32BufferAttribute(dustPos,3));
const dust=new THREE.Points(dustGeo,new THREE.PointsMaterial({color:0x6a8aff,size:0.3,sizeAttenuation:true,transparent:true,opacity:0.35,blending:THREE.AdditiveBlending,depthWrite:false}));
scene.add(dust);

// ═══ 后处理链: RenderPass → UnrealBloomPass(辉光) → Output ═══
let composer=null, bloomPass=null;
function initComposer(){
  if(composer)return;                              // 已初始化, 不重复
  const w=wrap.clientWidth||1, h=wrap.clientHeight||1;   // 防页面刚加载时 0 尺寸
  composer=new EffectComposer(renderer);
  composer.setSize(w,h);
  composer.addPass(new RenderPass(scene,camera));
  bloomPass=new UnrealBloomPass(new THREE.Vector2(w,h),0.9,0.5,0.85);
  // threshold=0.85 只让亮的部分辉光, 暗的保持; strength=0.9 亮度; radius=0.5 柔和度
  composer.addPass(bloomPass);
  // 输出 pass — 保证颜色空间正确
  const outputPass=new ShaderPass({uniforms:{tDiffuse:{value:null}},vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0)}`,fragmentShader:`uniform sampler2D tDiffuse;varying vec2 vUv;void main(){gl_FragColor=texture2D(tDiffuse,vUv)}`,});
  outputPass.material.depthWrite=false;outputPass.renderToScreen=true;
  composer.addPass(outputPass);
}

const starGroup=new THREE.Group();scene.add(starGroup);
let starMeshes=[],linkMeshes=[];

// 按深度颜色 (冷→暖)
const COLORS=[0x00ff9c,0x5ab8ff,0xb889ff,0xffb454,0xff7ab8,0x9cff5a];

function clearStars(){while(starGroup.children.length)starGroup.remove(starGroup.children[0]);starMeshes=[];linkMeshes.forEach(l=>{l.userData.flowMarker=null});linkMeshes=[]}

// 发光晕纹理 (缓存)
let glowTex=null;
function makeGlowTexture(){
  if(glowTex)return glowTex;
  const canvas=document.createElement('canvas');
  canvas.width=canvas.height=64;
  const ctx=canvas.getContext('2d');
  const grad=ctx.createRadialGradient(32,32,0,32,32,32);
  grad.addColorStop(0,'rgba(255,255,255,1)');
  grad.addColorStop(0.2,'rgba(255,255,255,0.6)');
  grad.addColorStop(0.5,'rgba(255,255,255,0.15)');
  grad.addColorStop(1,'rgba(255,255,255,0)');
  ctx.fillStyle=grad;ctx.fillRect(0,0,64,64);
  glowTex=new THREE.CanvasTexture(canvas);
  return glowTex;
}

function buildStarField(){
  if(!treeData||!treeData.nodes.length)return;
  clearStars();
  const root=nodeById[treeData.root_id];if(!root)return;

  // 球面分布布局: 根在中心, 子节点绕父节点球面散开
  const layout={};
  layout[root.id]={x:0,y:0,z:0};
  const queue=[root];
  const baseR=12;
  while(queue.length){
    const node=queue.shift();const pos=layout[node.id];
    const kids=(node.children_ids||[]).map(id=>nodeById[id]).filter(Boolean);
    if(!kids.length)continue;
    const n=kids.length;
    const depth=(node.depth||0)+1;
    const r=baseR*depth;
    kids.forEach((c,i)=>{
      // 斐波那契球面分布, 均匀不聚堆
      const phi=Math.acos(1-2*(i+0.5)/n);
      const theta=Math.PI*(1+Math.sqrt(5))*(i+0.5);
      const ox=Math.sin(phi)*Math.cos(theta)*r*0.55;
      const oy=Math.sin(phi)*Math.sin(theta)*r*0.55;
      const oz=Math.cos(phi)*r*0.55;
      layout[c.id]={
        x:pos.x+ox+(Math.random()-0.5)*1.5,
        y:pos.y+oy+(Math.random()-0.5)*1.5,
        z:pos.z+oz+(Math.random()-0.5)*1.5,
      };
      queue.push(c);
    });
  }

  // 1. 连线 (父子之间细线, 像星座连线)
  treeData.nodes.forEach(n=>{
    if(n.id===root.id)return;
    const pos=layout[n.id];if(!pos)return;
    const parPos=layout[n.parent_id];if(!parPos)return;
    const depth=n.depth||1;
    const color=COLORS[Math.min(depth-1,COLORS.length-1)];
    const pts=[new THREE.Vector3(parPos.x,parPos.y,parPos.z),new THREE.Vector3(pos.x,pos.y,pos.z)];
    const g=new THREE.BufferGeometry().setFromPoints(pts);
    const m=new THREE.LineBasicMaterial({color,transparent:true,opacity:0.3});
    const line=new THREE.Line(g,m);
    line.userData={id:n.id,baseOpacity:0.3,phase:Math.random()*Math.PI*2};
    starGroup.add(line);linkMeshes.push(line);
  });

  // 2. 星点 (每个节点一个发光点)
  const tex=makeGlowTexture();
  treeData.nodes.forEach(n=>{
    const pos=layout[n.id];if(!pos)return;
    const depth=n.depth||0;
    const color=COLORS[Math.min(depth,COLORS.length-1)];
    const isRoot=n.id===root.id;
    const size=isRoot?3.5:1.8;
    // sprite 做发光星点 (比球壳更像星星)
    const mat=new THREE.SpriteMaterial({map:tex,color,transparent:true,opacity:0.9,blending:THREE.AdditiveBlending,depthWrite:false});
    const sprite=new THREE.Sprite(mat);
    sprite.scale.setScalar(size);
    sprite.position.set(pos.x,pos.y,pos.z);
    sprite.userData={id:n.id,topic:n.topic,depth,hit:n.hit_count||0,dying:!!n.is_dying,baseOpacity:0.9,phase:Math.random()*Math.PI*2,isRoot};
    starGroup.add(sprite);
    starMeshes.push({id:n.id,topic:n.topic,mesh:sprite,basePos:sprite.position.clone()});
    // 根节点加个实心核心
    if(isRoot){
      const coreGeo=new THREE.SphereGeometry(0.6,16,16);
      const coreMat=new THREE.MeshBasicMaterial({color});
      const core=new THREE.Mesh(coreGeo,coreMat);
      core.position.set(pos.x,pos.y,pos.z);
      starGroup.add(core);
    }
  });

  fitView();
}

function fitView(){
  if(!starMeshes.length)return;
  const box=new THREE.Box3();
  starMeshes.forEach(n=>box.expandByPoint(n.mesh.position));
  const center=box.getCenter(new THREE.Vector3());
  const size=box.getSize(new THREE.Vector3());
  const maxDim=Math.max(size.x,size.y,size.z,20);
  controls.target.copy(center);
  const dist=Math.max(50,maxDim*1.3);
  camera.position.set(center.x+dist*0.4, center.y+dist*0.3, center.z+dist*0.9);
  controls.update();
}

let highlightedId=null;
function highlightStar(id){
  highlightedId=id;
}
function focusStar(id){
  const n=starMeshes.find(n=>n.id===id);if(!n)return;
  const p=n.mesh.position;
  const start=controls.target.clone(),end=p.clone(),t0=performance.now();
  const anim=()=>{const t=Math.min(1,(performance.now()-t0)/600);controls.target.lerpVectors(start,end,t);controls.update();if(t<1)requestAnimationFrame(anim)};
  anim();
}
function resetView(){fitView()}
window.resetView=resetView;window.reload=reload;window.expandAll=expandAll;window.collapseAll=collapseAll;
window.toggleExpand=toggleExpand;window.selectNode=selectNode;window.addRootNode=addRootNode;
window.closeEditor=closeEditor;window.saveNode=saveNode;window.addChild=addChild;window.deleteNode=deleteNode;
window.suggestRelated=suggestRelated;window.onSearch=onSearch;

// ═══════════ 3D 交互 ═══════════
const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();
let hovered=null,dragging=null,dragMoved=false;
const dragOffset=new THREE.Vector3(),dragStart=new THREE.Vector3();
const tip=$('node-tip');
let lastInteract=0;

function setMouse(e){const r=renderer.domElement.getBoundingClientRect();mouse.x=((e.clientX-r.left)/r.width)*2-1;mouse.y=-((e.clientY-r.top)/r.height)*2+1}
function pickStar(){raycaster.setFromCamera(mouse,camera);const objs=starMeshes.map(n=>n.mesh);const hits=raycaster.intersectObjects(objs,false);return hits.length?hits[0].object:null}

renderer.domElement.addEventListener('pointermove',e=>{
  setMouse(e);
  if(dragging){
    raycaster.setFromCamera(mouse,camera);
    const plane=new THREE.Plane();const cd=new THREE.Vector3();camera.getWorldDirection(cd);
    plane.setFromNormalAndCoplanarPoint(cd,dragStart);
    const tgt=new THREE.Vector3();
    if(raycaster.ray.intersectPlane(plane,tgt)){dragging.position.copy(tgt).add(dragOffset);checkCollision(dragging)}
    if(dragStart.distanceTo(dragging.position)>0.5)dragMoved=true;
    return;
  }
  const m=pickStar();
  if(m!==hovered){
    hovered=m;
    if(hovered){renderer.domElement.style.cursor='pointer';tip.style.display='block';tip.textContent=`${hovered.userData.topic}  [深${hovered.userData.depth} · 命中${hovered.userData.hit}]`}
    else{renderer.domElement.style.cursor='grab';tip.style.display='none'}
  }
  if(hovered){const r=renderer.domElement.getBoundingClientRect();tip.style.left=(e.clientX-r.left+14)+'px';tip.style.top=(e.clientY-r.top+14)+'px'}
});
renderer.domElement.addEventListener('pointerdown',e=>{
  if(e.button!==0)return;
  setMouse(e);const m=pickStar();
  if(m){dragging=m;dragMoved=false;controls.enabled=false;dragStart.copy(m.position);
    raycaster.setFromCamera(mouse,camera);const plane=new THREE.Plane();const cd=new THREE.Vector3();camera.getWorldDirection(cd);
    plane.setFromNormalAndCoplanarPoint(cd,m.position);const hit=new THREE.Vector3();raycaster.ray.intersectPlane(plane,hit);
    dragOffset.copy(m.position).sub(hit);renderer.domElement.style.cursor='grabbing'}
});
renderer.domElement.addEventListener('pointerup',e=>{
  if(!dragging)return;const node=dragging;dragging=null;controls.enabled=true;renderer.domElement.style.cursor='grab';
  if(!dragMoved){selectNode(node.userData.id,false)}
  else{toast('已拖动: '+node.userData.topic)}
});

function checkCollision(moving){
  const now=Date.now();if(now-lastInteract<700)return;
  for(const n of starMeshes){if(n.mesh===moving)continue;if(n.mesh.position.distanceTo(moving.position)<3){lastInteract=now;triggerInteract(moving.userData.id,n.id,moving,n.mesh);return}}
}
async function triggerInteract(a,b,mA,mB){
  flashStar(mA,0xb889ff);flashStar(mB,0xb889ff);drawTempLink(mA.position,mB.position,0xb889ff);
  try{
    const r=await fetch('/api/interact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({a,b})});
    const d=await r.json();if(d.error){toast(d.error);return}showInteract(d);
  }catch(err){toast('互动请求失败')}
}
function flashStar(m,color){const old=m.material.color.getHex(),oldO=m.material.opacity;m.material.color.setHex(color);m.material.opacity=1.3;setTimeout(()=>{m.material.color.setHex(old);m.material.opacity=m.userData.baseOpacity},700)}
function drawTempLink(a,b,color){const pts=[a.clone(),b.clone()];const g=new THREE.BufferGeometry().setFromPoints(pts);const m=new THREE.LineBasicMaterial({color,transparent:true,opacity:1});const l=new THREE.Line(g,m);scene.add(l);let t=0;const an=setInterval(()=>{t+=0.06;m.opacity=1-t;if(t>=1){clearInterval(an);scene.remove(l);g.dispose();m.dispose()}},40)}
function showInteract(d){
  $('ir-pair').innerHTML=`<b>${esc(d.a.topic)}</b> × <b>${esc(d.b.topic)}</b>`;
  const hits=d.hits||[];
  $('ir-hits').innerHTML=hits.length?hits.map(h=>`<div class="hit" onclick="selectNode('${esc(h.node_id)}',false)"><span>✦ ${esc(h.topic)}</span><span class="score">${Math.max(0,(h.score||0)*100).toFixed(0)}%</span></div>`).join(''):'<div style="color:var(--muted);font-size:10px;padding:6px 0">暂无关联</div>';
  $('interact').style.display='block';
}

// ═══════════ 渲染循环: 星点闪烁 + 缓慢自转 ═══════════
function resize(){const w=wrap.clientWidth,h=wrap.clientHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h);if(composer){composer.setSize(w,h);if(bloomPass)bloomPass.setSize(w,h)}}
resize();addEventListener('resize',resize);
initComposer();   // resize 后 wrap 已有尺寸, composer 不会拿到 0
function animate(){
  requestAnimationFrame(animate);controls.update();
  const t=performance.now()*0.001;
  // 每颗星独立闪烁, 像星星眨眼; 搜索匹配的更亮更大
  starMeshes.forEach((n,i)=>{
    const u=n.mesh.userData;
    const isMatch=searchHighlightedIds.has(n.id);
    const flicker=isMatch?1:0.5+0.5*Math.sin(t*2.2+u.phase);
    n.mesh.material.opacity=isMatch?1:u.baseOpacity*(0.5+0.5*flicker);
    const baseScale=u.isRoot?3.5:1.8;
    const scale=isMatch?baseScale*2.2:baseScale*(0.85+0.3*flicker);
    n.mesh.scale.setScalar(scale);
    // 搜索匹配的换暖色
    if(isMatch)n.mesh.material.color.setHex(0xffb454);
  });
  // 连线呼吸
  linkMeshes.forEach((l,i)=>{const u=l.userData;l.material.opacity=u.baseOpacity*(0.5+0.5*Math.sin(t*1.3+u.phase))});
  // 边粒子流动 — 沿父子连线流动的光点, 像知识在传递
  if(linkMeshes.length){
    linkMeshes.forEach((l,i)=>{
      if(!l.userData.flowMarker){
        // 给每条线加一个流动光点 (sprite)
        const fm=new THREE.Sprite(new THREE.SpriteMaterial({map:glowTex||makeGlowTexture(),color:l.material.color.getHex(),transparent:true,opacity:0.9,blending:THREE.AdditiveBlending,depthWrite:false}));
        fm.scale.setScalar(0.5);
        l.userData.flowMarker=fm;
        starGroup.add(fm);
      }
      const fm=l.userData.flowMarker;
      // 沿线流动: 0→1 循环, 每条线速度略不同
      const speed=0.15+l.userData.phase*0.05;
      const prog=((t*speed+l.userData.phase)%1);
      const pts=l.geometry.attributes.position;
      const a=new THREE.Vector3().fromBufferAttribute(pts,0);
      const b=new THREE.Vector3().fromBufferAttribute(pts,1);
      fm.position.lerpVectors(a,b,prog);
      fm.material.opacity=0.4+0.6*Math.sin(prog*Math.PI); // 中段最亮, 两端淡
    });
  }
  // 背景远星缓慢漂移
  bgStars.rotation.y+=0.00015;
  // 星云尘埃缓慢旋转 + 呼吸
  nebulaGroup.rotation.y+=0.00008;
  nebulaGroup.children.forEach(s=>{const u=s.userData;s.material.opacity=0.08+0.06*(0.5+0.5*Math.sin(t*0.3+u.phase))});
  // 近飘尘漂动
  const dp=dust.geometry.attributes.position.array;
  for(let i=0;i<dp.length;i+=3){dp[i]+=dustVel[i];dp[i+1]+=dustVel[i+1];dp[i+2]+=dustVel[i+2];if(Math.abs(dp[i])>150)dp[i]*=-0.9;if(Math.abs(dp[i+1])>100)dp[i+1]*=-0.9;if(Math.abs(dp[i+2])>150)dp[i+2]*=-0.9}
  dust.geometry.attributes.position.needsUpdate=true;
  // 整体缓慢自转, 像星系
  starGroup.rotation.y+=0.0006;
  composer.render();
}
animate();

loadTree().catch(err=>{$('loading').innerHTML='加载失败: '+esc(err.message)});
</script>
</body>
</html>
"""


def make_suggestions(knowledge_tree, topic, top_k=5):
    """使用V10生成关联推测"""
    try:
        from .knowledge_tree import smart_embedding, _cosine_similarity
        query_emb = smart_embedding(topic)
        results = []
        for node in knowledge_tree.nodes.values():
            if node.id == 'root':
                continue
            node_emb = node.embedding or smart_embedding(node.topic + ' ' + (node.content or '')[:200])
            sim = _cosine_similarity(query_emb, node_emb)
            results.append({
                'id': node.id, 'topic': node.topic,
                'score': max(0, sim),
            })
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:top_k]
    except Exception:
        return []


def get_knowledge_tree_page():
    return PAGE_HTML
