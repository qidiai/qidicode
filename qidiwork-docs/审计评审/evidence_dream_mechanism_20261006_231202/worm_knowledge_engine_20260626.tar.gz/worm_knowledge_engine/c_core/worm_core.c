/**
 * worm_core.c — 蠕虫核心 C语言实现
 *
 * 编译:
 *   Windows: cl /O2 /LD worm_core.c /Fe:worm_core.dll
 *   Linux:   gcc -O2 -shared -fPIC worm_core.c -o libworm_core.so
 *   macOS:   gcc -O2 -shared -fPIC worm_core.c -o libworm_core.dylib
 */

#include "worm_core.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <stdio.h>
#include <time.h>
#include <sys/time.h>

/* ============ 内部工具 ============ */

static uint64_t _time_ms(void) {
#ifdef _WIN32
    FILETIME ft;
    GetSystemTimeAsFileTime(&ft);
    return ((uint64_t)ft.dwHighDateTime << 32 | ft.dwLowDateTime) / 10000;
#else
    struct timespec ts;
    if (clock_gettime(CLOCK_REALTIME, &ts) == 0) {
        return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
    }
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (uint64_t)tv.tv_sec * 1000 + tv.tv_usec / 1000;
#endif
}

/* ============ 初始化/释放 ============ */

WCWormSwarm* wc_swarm_create(void) {
    WCWormSwarm* s = (WCWormSwarm*)calloc(1, sizeof(WCWormSwarm));
    if (!s) return NULL;
    s->worm_count = 0;
    s->id_counter = 0;
    strcpy(s->mode, "fused");
    s->thought_count = 0;
    return s;
}

void wc_swarm_destroy(WCWormSwarm* swarm) {
    if (swarm) free(swarm);
}

/* ============ 概念操作 ============ */

uint32_t wc_spawn(WCWormSwarm* swarm, const char* name, const char* category, float valence) {
    if (!swarm || swarm->worm_count >= WC_MAX_WORMS) return 0;
    /* 检查重名 */
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        if (strcmp(swarm->worms[i].name, name) == 0) return swarm->worms[i].id;
    }
    swarm->id_counter++;
    WCWorm* w = &swarm->worms[swarm->worm_count];
    memset(w, 0, sizeof(WCWorm));
    w->id = swarm->id_counter;
    strncpy(w->name, name, WC_MAX_NAME - 1);
    strncpy(w->category, category ? category : "general", WC_MAX_NAME - 1);
    w->valence = valence;
    w->activation = 0.0f;
    w->baseline = 0.0f;
    w->link_count = 0;
    w->activation_count = 0;
    w->last_activated = 0;
    swarm->worm_count++;
    return w->id;
}

WCWorm* wc_get_by_name(WCWormSwarm* swarm, const char* name) {
    if (!swarm || !name) return NULL;
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        if (strcmp(swarm->worms[i].name, name) == 0) return &swarm->worms[i];
    }
    return NULL;
}

WCWorm* wc_get_by_id(WCWormSwarm* swarm, uint32_t id) {
    if (!swarm) return NULL;
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        if (swarm->worms[i].id == id) return &swarm->worms[i];
    }
    return NULL;
}

/* ============ 连接操作 ============ */

int wc_link(WCWormSwarm* swarm, uint32_t id_a, uint32_t id_b, float strength) {
    WCWorm* a = wc_get_by_id(swarm, id_a);
    WCWorm* b = wc_get_by_id(swarm, id_b);
    if (!a || !b) return -1;
    /* A→B */
    if (a->link_count < WC_MAX_LINKS) {
        a->links[a->link_count].target_id = id_b;
        a->links[a->link_count].strength = strength;
        a->link_count++;
    }
    /* B→A */
    if (b->link_count < WC_MAX_LINKS) {
        b->links[b->link_count].target_id = id_a;
        b->links[b->link_count].strength = strength;
        b->link_count++;
    }
    return 0;
}

int wc_unlink(WCWormSwarm* swarm, uint32_t id_a, uint32_t id_b) {
    WCWorm* a = wc_get_by_id(swarm, id_a);
    WCWorm* b = wc_get_by_id(swarm, id_b);
    if (!a || !b) return -1;
    /* 删A→B */
    for (uint32_t i = 0; i < a->link_count; i++) {
        if (a->links[i].target_id == id_b) {
            a->links[i] = a->links[a->link_count - 1];
            a->link_count--;
            break;
        }
    }
    /* 删B→A */
    for (uint32_t i = 0; i < b->link_count; i++) {
        if (b->links[i].target_id == id_a) {
            b->links[i] = b->links[b->link_count - 1];
            b->link_count--;
            break;
        }
    }
    return 0;
}

/* ============ 激活 ============ */

void wc_activate(WCWorm* worm, float energy) {
    if (!worm) return;
    float remaining = 1.0f - worm->activation;
    worm->activation = worm->activation + energy * remaining;
    if (worm->activation > 1.0f) worm->activation = 1.0f;
    worm->last_activated = _time_ms();
    worm->activation_count++;
}

void wc_decay(WCWorm* worm, float rate) {
    if (!worm) return;
    worm->activation *= rate;
    if (worm->activation < 0.01f) worm->activation = 0.0f;
}

/* ============ 核心: 激活扩散 ============ */

void wc_spread(WCWormSwarm* swarm, float decay, float threshold) {
    if (!swarm) return;
    /* 1. 计算每个概念收到的入射能量 */
    float* incoming = (float*)calloc(swarm->worm_count, sizeof(float));
    if (!incoming) return;

    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        WCWorm* src = &swarm->worms[i];
        if (src->activation < threshold) continue;
        for (uint32_t j = 0; j < src->link_count; j++) {
            /* 找目标在数组中的位置 */
            for (uint32_t k = 0; k < swarm->worm_count; k++) {
                if (swarm->worms[k].id == src->links[j].target_id) {
                    float energy = src->activation * src->links[j].strength * decay;
                    if (energy > 0.01f) incoming[k] += energy;
                    break;
                }
            }
        }
    }

    /* 2. 应用入射能量 + 衰减 */
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        WCWorm* w = &swarm->worms[i];
        if (incoming[i] > 0.0f) {
            float remaining = 1.0f - w->activation;
            w->activation = w->activation + incoming[i] * remaining;
            if (w->activation > 1.0f) w->activation = 1.0f;
            w->activation_count++;
            w->last_activated = _time_ms();
        }
        /* 自然衰减 */
        w->activation *= 0.9f;
        /* baseline保底 */
        if (w->baseline > 0.1f && w->activation < w->baseline * 0.3f) {
            w->activation = w->baseline * 0.1f;
        }
    }

    free(incoming);
}

/* ============ 核心: 思考 ============ */

void wc_think(WCWormSwarm* swarm,
              const char** seed_names, const float* seed_energies, int seed_count,
              int rounds, float decay)
{
    if (!swarm) return;
    /* 激活种子 */
    for (int i = 0; i < seed_count; i++) {
        WCWorm* w = wc_get_by_name(swarm, seed_names[i]);
        if (w) wc_activate(w, seed_energies[i]);
    }
    /* 多轮扩散 */
    for (int r = 0; r < rounds; r++) {
        wc_spread(swarm, decay, 0.05f);
    }
    swarm->thought_count++;
}

/* ============ 三速池 ============ */

void wc_pool_update(WCWorm* worm, const float* signal, int sig_len,
                    float decay_fast, float decay_medium, float decay_slow)
{
    if (!worm || !signal) return;
    int len = sig_len < WC_SP_DIM ? sig_len : WC_SP_DIM;
    for (int i = 0; i < len; i++) {
        worm->fast_pool[i]   = decay_fast   * worm->fast_pool[i]   + (1 - decay_fast)   * signal[i];
        worm->medium_pool[i] = decay_medium  * worm->medium_pool[i] + (1 - decay_medium)  * signal[i];
        worm->slow_pool[i]   = decay_slow    * worm->slow_pool[i]   + (1 - decay_slow)    * signal[i];
    }
}

void wc_pool_fusion_read(const WCWorm* worm, float* out, int out_len) {
    if (!worm || !out) return;
    int len = out_len < WC_SP_DIM ? out_len : WC_SP_DIM;
    float depth_factor = powf(0.8f, 0); /* depth=0, 简化 */
    for (int i = 0; i < len; i++) {
        out[i] = (0.6f * worm->fast_pool[i] +
                  0.3f * worm->medium_pool[i] +
                  0.1f * worm->slow_pool[i]) * depth_factor;
    }
}

/* ============ 余弦相似度 ============ */

float wc_cosine_similarity(const float* a, const float* b, int len) {
    if (!a || !b || len <= 0) return 0.0f;
    float dot = 0.0f, na = 0.0f, nb = 0.0f;
    for (int i = 0; i < len; i++) {
        dot += a[i] * b[i];
        na  += a[i] * a[i];
        nb  += b[i] * b[i];
    }
    float denom = sqrtf(na) * sqrtf(nb);
    if (denom < 1e-9f) return 0.0f;
    return dot / denom;
}

/* ============ 简单嵌入 ============ */

static uint32_t _hash_word(const char* word) {
    uint32_t h = 5381;
    while (*word) {
        h = ((h << 5) + h) + (unsigned char)*word;
        word++;
    }
    return h;
}

void wc_simple_embedding(const char* text, float* out, int out_len) {
    if (!text || !out || out_len <= 0) return;
    memset(out, 0, sizeof(float) * out_len);
    /* 按空格拆词 + 中文按字拆 */
    char buf[256];
    int bi = 0;
    const unsigned char* p = (const unsigned char*)text;
    while (*p) {
        if (*p == ' ' || *p == '\t' || *p == '\n') {
            if (bi > 0) {
                buf[bi] = 0;
                uint32_t h = _hash_word(buf);
                int idx = h % out_len;
                out[idx] += 1.0f;
                bi = 0;
            }
            p++;
        } else if (*p >= 0xE0) {
            /* UTF-8 中文字符 (3字节) */
            if (bi > 0) { buf[bi] = 0; uint32_t h = _hash_word(buf); out[h % out_len] += 1.0f; bi = 0; }
            char ch[4] = {0};
            for (int i = 0; i < 3 && *p; i++) ch[i] = *p++;
            uint32_t h = _hash_word(ch);
            out[h % out_len] += 1.0f;
        } else {
            buf[bi++] = *p++;
            if (bi >= 255) { buf[bi] = 0; uint32_t h = _hash_word(buf); out[h % out_len] += 1.0f; bi = 0; }
        }
    }
    if (bi > 0) { buf[bi] = 0; uint32_t h = _hash_word(buf); out[h % out_len] += 1.0f; }
    /* L2归一化 */
    float norm = 0.0f;
    for (int i = 0; i < out_len; i++) norm += out[i] * out[i];
    norm = sqrtf(norm);
    if (norm > 1e-9f) {
        for (int i = 0; i < out_len; i++) out[i] /= norm;
    }
}

/* ============ 决策读出 ============ */

int wc_read_decision(WCWormSwarm* swarm,
                     const char** categories, int cat_count,
                     uint32_t* out_ids, float* out_scores, int top_k)
{
    if (!swarm || !out_ids || !out_scores) return 0;
    /* 收集所有匹配类别的概念 */
    int count = 0;
    for (uint32_t i = 0; i < swarm->worm_count && count < top_k; i++) {
        WCWorm* w = &swarm->worms[i];
        if (w->activation < 0.02f) continue;
        /* 检查类别 */
        int match = (cat_count == 0);
        for (int c = 0; c < cat_count; c++) {
            if (strcmp(w->category, categories[c]) == 0) { match = 1; break; }
        }
        if (!match) continue;
        float score = w->activation * (1.0f + w->valence);
        /* 插入排序(小top_k够用) */
        int pos = count;
        for (int j = 0; j < count; j++) {
            if (score > out_scores[j]) { pos = j; break; }
        }
        if (count < top_k) count++;
        for (int j = count - 1; j > pos; j--) {
            out_ids[j] = out_ids[j-1];
            out_scores[j] = out_scores[j-1];
        }
        out_ids[pos] = w->id;
        out_scores[pos] = score;
    }
    return count;
}

/* ============ 反思 ============ */

void wc_reflect(WCWormSwarm* swarm, uint32_t action_id, int success) {
    WCWorm* w = wc_get_by_id(swarm, action_id);
    if (!w) return;
    if (success) {
        w->valence = fminf(1.0f, w->valence + 0.1f);
        w->baseline = fminf(1.0f, w->baseline + 0.005f);
        /* 加强连接 */
        for (uint32_t j = 0; j < w->link_count; j++) {
            w->links[j].strength = fminf(1.0f, w->links[j].strength + 0.05f);
        }
    } else {
        w->valence = fmaxf(-1.0f, w->valence - 0.15f);
        /* 削弱连接 */
        for (uint32_t j = 0; j < w->link_count; j++) {
            w->links[j].strength = fmaxf(0.0f, w->links[j].strength - 0.1f);
        }
    }
}

/* ============ 统计 ============ */

void wc_get_stats(WCWormSwarm* swarm,
                  uint32_t* out_total, uint32_t* out_links,
                  uint32_t* out_active, float* out_avg_baseline)
{
    if (!swarm) return;
    uint32_t total = swarm->worm_count;
    uint32_t links = 0;
    uint32_t active = 0;
    float sum_bl = 0.0f;
    for (uint32_t i = 0; i < total; i++) {
        links += swarm->worms[i].link_count;
        if (swarm->worms[i].activation > 0.05f) active++;
        sum_bl += swarm->worms[i].baseline;
    }
    if (out_total) *out_total = total;
    if (out_links) *out_links = links / 2;
    if (out_active) *out_active = active;
    if (out_avg_baseline) *out_avg_baseline = total > 0 ? sum_bl / total : 0.0f;
}

/* ============ 序列化 ============ */

int wc_save(WCWormSwarm* swarm, const char* filepath) {
    if (!swarm || !filepath) return -1;
    FILE* f = fopen(filepath, "wb");
    if (!f) return -1;
    /* 写头 */
    uint32_t magic = 0x574F524D; /* "WORM" */
    fwrite(&magic, 4, 1, f);
    fwrite(&swarm->worm_count, 4, 1, f);
    fwrite(&swarm->id_counter, 4, 1, f);
    /* 写每个概念 */
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        WCWorm* w = &swarm->worms[i];
        fwrite(&w->id, 4, 1, f);
        fwrite(w->name, 1, WC_MAX_NAME, f);
        fwrite(w->category, 1, WC_MAX_NAME, f);
        fwrite(&w->activation, 4, 1, f);
        fwrite(&w->baseline, 4, 1, f);
        fwrite(&w->valence, 4, 1, f);
        fwrite(w->fast_pool, 4, WC_SP_DIM, f);
        fwrite(w->medium_pool, 4, WC_SP_DIM, f);
        fwrite(w->slow_pool, 4, WC_SP_DIM, f);
        fwrite(w->embedding, 4, WC_SP_DIM, f);
        fwrite(&w->link_count, 4, 1, f);
        for (uint32_t j = 0; j < w->link_count; j++) {
            fwrite(&w->links[j].target_id, 4, 1, f);
            fwrite(&w->links[j].strength, 4, 1, f);
        }
    }
    fclose(f);
    return 0;
}

WCWormSwarm* wc_load(const char* filepath) {
    if (!filepath) return NULL;
    FILE* f = fopen(filepath, "rb");
    if (!f) return NULL;
    uint32_t magic;
    fread(&magic, 4, 1, f);
    if (magic != 0x574F524D) { fclose(f); return NULL; }
    WCWormSwarm* swarm = (WCWormSwarm*)calloc(1, sizeof(WCWormSwarm));
    if (!swarm) { fclose(f); return NULL; }
    fread(&swarm->worm_count, 4, 1, f);
    fread(&swarm->id_counter, 4, 1, f);
    for (uint32_t i = 0; i < swarm->worm_count; i++) {
        WCWorm* w = &swarm->worms[i];
        fread(&w->id, 4, 1, f);
        fread(w->name, 1, WC_MAX_NAME, f);
        fread(w->category, 1, WC_MAX_NAME, f);
        fread(&w->activation, 4, 1, f);
        fread(&w->baseline, 4, 1, f);
        fread(&w->valence, 4, 1, f);
        fread(w->fast_pool, 4, WC_SP_DIM, f);
        fread(w->medium_pool, 4, WC_SP_DIM, f);
        fread(w->slow_pool, 4, WC_SP_DIM, f);
        fread(w->embedding, 4, WC_SP_DIM, f);
        fread(&w->link_count, 4, 1, f);
        for (uint32_t j = 0; j < w->link_count; j++) {
            fread(&w->links[j].target_id, 4, 1, f);
            fread(&w->links[j].strength, 4, 1, f);
        }
    }
    fclose(f);
    strcpy(swarm->mode, "fused");
    return swarm;
}
