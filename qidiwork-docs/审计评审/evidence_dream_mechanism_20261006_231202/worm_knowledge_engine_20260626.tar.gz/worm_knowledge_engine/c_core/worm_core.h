/**
 * worm_core.h — 蠕虫核心 C语言实现
 * 
 * 计算密集型核心，编译成动态库供Python调用
 * 激活扩散 / 三速池EMA / 余弦相似度 / 序列化
 */

#ifndef WORM_CORE_H
#define WORM_CORE_H

#include <stdint.h>

/* ============ 常量 ============ */

#define WC_SP_DIM      128     /* 三速池维度 */
#define WC_MAX_NAME    64      /* 概念名最大长度 */
#define WC_MAX_WORMS   65536   /* 最大概念数 */
#define WC_MAX_LINKS   256     /* 每个概念最大连接数 */

/* ============ 数据结构 ============ */

/* 连接 */
typedef struct {
    uint32_t target_id;    /* 目标概念ID */
    float    strength;     /* 连接强度 0~1 */
} WCLink;

/* 概念(蠕虫) */
typedef struct {
    uint32_t id;                         /* 唯一ID */
    char     name[WC_MAX_NAME];          /* 概念名 */
    char     category[WC_MAX_NAME];      /* 类别 */
    float    activation;                 /* 激活度 0~1 */
    float    baseline;                   /* 基线 0~1 */
    float    valence;                    /* 好感度 -1~1 */
    float    fast_pool[WC_SP_DIM];       /* 快池 */
    float    medium_pool[WC_SP_DIM];     /* 中池 */
    float    slow_pool[WC_SP_DIM];       /* 慢池 */
    float    embedding[WC_SP_DIM];       /* 嵌入向量 */
    uint32_t link_count;                 /* 连接数 */
    WCLink   links[WC_MAX_LINKS];        /* 连接列表 */
    uint32_t activation_count;           /* 激活次数 */
    uint64_t last_activated;             /* 上次激活时间(ms) */
} WCWorm;

/* 蠕虫群 */
typedef struct {
    WCWorm  worms[WC_MAX_WORMS];        /* 概念数组 */
    uint32_t worm_count;                 /* 概念总数 */
    uint32_t id_counter;                 /* ID计数器 */
    char     mode[16];                   /* fused / dispersed */
    uint32_t thought_count;              /* 思考次数 */
} WCWormSwarm;

/* ============ API ============ */

#ifdef __cplusplus
extern "C" {
#endif

/* 初始化/释放 */
WCWormSwarm* wc_swarm_create(void);
void         wc_swarm_destroy(WCWormSwarm* swarm);

/* 概念操作 */
uint32_t wc_spawn(WCWormSwarm* swarm, const char* name, const char* category, float valence);
WCWorm*  wc_get_by_name(WCWormSwarm* swarm, const char* name);
WCWorm*  wc_get_by_id(WCWormSwarm* swarm, uint32_t id);

/* 连接操作 */
int wc_link(WCWormSwarm* swarm, uint32_t id_a, uint32_t id_b, float strength);
int wc_unlink(WCWormSwarm* swarm, uint32_t id_a, uint32_t id_b);

/* 激活 */
void wc_activate(WCWorm* worm, float energy);
void wc_decay(WCWorm* worm, float rate);

/* 核心: 激活扩散 — 一轮 */
void wc_spread(WCWormSwarm* swarm, float decay, float threshold);

/* 核心: 思考 — 多轮扩散 */
void wc_think(WCWormSwarm* swarm,
              const char** seed_names, const float* seed_energies, int seed_count,
              int rounds, float decay);

/* 三速池 */
void wc_pool_update(WCWorm* worm, const float* signal, int sig_len,
                    float decay_fast, float decay_medium, float decay_slow);
void wc_pool_fusion_read(const WCWorm* worm, float* out, int out_len);

/* 余弦相似度 */
float wc_cosine_similarity(const float* a, const float* b, int len);

/* 简单嵌入(词袋哈希) */
void wc_simple_embedding(const char* text, float* out, int out_len);

/* 读出决策 — 按激活度排序，返回前top_k个 */
int wc_read_decision(WCWormSwarm* swarm,
                     const char** categories, int cat_count,
                     uint32_t* out_ids, float* out_scores, int top_k);

/* 反思 — 根据结果调整连接和valence */
void wc_reflect(WCWormSwarm* swarm, uint32_t action_id, int success);

/* 统计 */
void wc_get_stats(WCWormSwarm* swarm,
                  uint32_t* out_total, uint32_t* out_links,
                  uint32_t* out_active, float* out_avg_baseline);

/* 序列化/反序列化 */
int  wc_save(WCWormSwarm* swarm, const char* filepath);
WCWormSwarm* wc_load(const char* filepath);

#ifdef __cplusplus
}
#endif

#endif /* WORM_CORE_H */
