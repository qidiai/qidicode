"""
蠕虫知识引擎 — 主入口

使用方式:
  python -m worm_knowledge_engine              # 交互模式
  python -m worm_knowledge_engine live          # 自主循环(活着)
  python -m worm_knowledge_engine live 10       # 活10轮
  python -m worm_knowledge_engine crawl         # 启动爬虫
  python -m worm_knowledge_engine serve         # 启动服务节点
  python -m worm_knowledge_engine webui         # 启动Web界面
  python -m worm_knowledge_engine webui 8080    # 启动Web界面(指定端口)
"""
import asyncio
import sys
import json
import time
from .organism import Organism
from .knowledge_tree import KnowledgeTree
from .worm_brain import WormBrain
from .ant_crawler import AntCrawler
from .mycelial_network import MycelialNode


class WormKnowledgeEngine:
    """蠕虫知识引擎 — 兼容旧接口"""

    def __init__(self, data_dir='data'):
        self._organism = Organism(data_dir=data_dir)
        self.knowledge = self._organism.body
        self.brain = self._organism.brain
        self.crawler = self._organism.senses
        self.node = None

    def start_network(self, node_id='node_1', port=0):
        self.node = MycelialNode(node_id, port=port)
        self.node.start()
        return self.node.port

    async def crawl(self, seed_urls, max_tasks=20):
        self.crawler.add_seed_urls(seed_urls)
        results = await self.crawler.run(max_tasks=max_tasks)
        return results

    def learn(self, topic, content):
        return self.knowledge.learn(topic, content)

    def recall(self, query, top_k=5):
        return self.knowledge.recall(query, top_k)

    def decide(self):
        return self.brain.decide()

    def get_status(self):
        status = {
            'knowledge': self.knowledge.get_stats(),
            'brain': self.brain.get_status(),
            'crawler': self.crawler.get_status(),
        }
        if self.node:
            status['network'] = self.node.get_status()
        return status


def interactive_mode():
    """交互模式"""
    org = Organism()
    print('=' * 60)
    print('  蠕虫知识引擎 v2.0 — 生物体')
    print('  知识树=身体  蠕虫群=大脑  蚁群=感觉  爬虫=触角')
    print('=' * 60)

    while True:
        try:
            cmd = input('\n> ').strip()
        except (EOFError, KeyboardInterrupt):
            print('\n再见!')
            break

        if not cmd:
            continue

        parts = cmd.split(maxsplit=1)
        action = parts[0]
        arg = parts[1] if len(parts) > 1 else ''

        if action in ('quit', 'exit', 'q'):
            print('再见!')
            break

        elif action == 'live':
            # 自主循环
            cycles = int(arg) if arg.isdigit() else None
            goal = None
            print(f'  生物体开始活着...' + (f' ({cycles}轮)' if cycles else ' (无限)'))
            asyncio.run(org.live(max_cycles=cycles, goal_description=goal))
            print(f'  停止，共 {org.cycle_count} 轮')

        elif action == 'goal':
            if arg:
                org.set_goal(arg)
                print(f'  目标设定: {arg}')
            else:
                g = org.current_goal
                if g:
                    print(f'  当前目标: {g.description} (进度={g.progress:.0%})')
                else:
                    print('  (无目标)')

        elif action == 'learn':
            if '|' in arg:
                topic, content = arg.split('|', 1)
            else:
                topic, content = arg[:30], arg
            node = org.body.learn(topic.strip(), content.strip())
            print(f'  + 已学习: {node.topic} (id={node.id})')

        elif action == 'recall':
            results = org.body.recall(arg, top_k=5)
            if not results:
                print('  (无结果)')
            for i, r in enumerate(results):
                print(f'  {i+1}. [{r["score"]:.3f}] {r["topic"]}')

        elif action == 'crawl':
            urls = [u.strip() for u in arg.split(',') if u.strip()]
            if not urls:
                urls = ['https://example.com', 'https://httpbin.org/get']
            print(f'  开始爬取 {len(urls)} 个种子URL...')
            org.senses.add_seed_urls(urls)
            results = asyncio.run(org.senses.run(max_tasks=10))
            success = sum(1 for r in results if r.get('success'))
            print(f'  + 完成: {success}/{len(results)} 成功')

        elif action == 'think':
            result = org.brain.think(percepts=[], rounds=5)
            d = result.get('decision')
            if d:
                print(f'  决策: {d["action"]} (分数={d["score"]:.3f})')
            chain = result.get('chain', [])
            if chain:
                print(f'  思维链 ({len(chain)}轮):')
                for i, snap in enumerate(chain):
                    top3 = list(snap.items())[:3]
                    print(f'    轮{i+1}: {top3}')

        elif action == 'status':
            s = org.get_status()
            print(f'  活着: {s["alive"]}')
            print(f'  循环: {s["cycle"]}')
            print(f'  饥饿: {s["hunger"]:.2f}')
            print(f'  成功率: {s["success_rate"]:.2f}')
            print(f'  知识节点: {s["body"]["total_nodes"]}')
            print(f'  蠕虫数: {s["brain"]["swarm"]["total_worms"]}')
            print(f'  模式: {s["brain"]["mode"]}')

        elif action == 'network':
            port = org.start_network()
            print(f'  + 菌丝节点启动于端口 {port}')

        elif action == 'webui':
            from .webui import OrganismWebUI
            port = int(arg) if arg.isdigit() else 8080
            webui = OrganismWebUI(org, port=port)
            webui.start()
            org._webui = webui
            print(f'  + Web界面已启动: http://localhost:{port}')
            print(f'  输入 stopwebui 停止')

        elif action == 'stopwebui':
            if hasattr(org, '_webui') and org._webui:
                org._webui.stop()
                print(f'  + Web界面已停止')
            else:
                print(f'  (Web界面未启动)')

        elif action == 'help':
            print('  命令:')
            print('    live [N]           -- 自主循环N轮(无限则不填)')
            print('    goal 描述          -- 设定目标')
            print('    learn 主题|内容    -- 学习知识')
            print('    recall 查询        -- 检索知识')
            print('    crawl url1,url2   -- 启动爬虫')
            print('    think             -- 思考(看思维链)')
            print('    status            -- 查看状态')
            print('    network           -- 启动菌丝网络')
            print('    webui [端口]       -- 启动Web界面')
            print('    stopwebui         -- 停止Web界面')
            print('    quit              -- 退出')

        else:
            print(f'  未知命令: {action}，输入 help 查看帮助')


def main():
    if len(sys.argv) > 1:
        cmd = sys.argv[1]

        if cmd == 'live':
            org = Organism()
            max_cycles = int(sys.argv[2]) if len(sys.argv) > 2 else None
            goal = sys.argv[3] if len(sys.argv) > 3 else None
            asyncio.run(org.live(max_cycles=max_cycles, goal_description=goal))
            print(json.dumps(org.get_status(), ensure_ascii=False, indent=2, default=str))

        elif cmd == 'crawl':
            engine = WormKnowledgeEngine()
            urls = sys.argv[2:] if len(sys.argv) > 2 else ['https://example.com']
            results = asyncio.run(engine.crawl(urls))
            print(json.dumps(results, ensure_ascii=False, indent=2, default=str))

        elif cmd == 'serve':
            engine = WormKnowledgeEngine()
            port = int(sys.argv[2]) if len(sys.argv) > 2 else 0
            engine.start_network(port=port)
            print(f'服务节点已启动，按 Ctrl+C 退出')
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass

        elif cmd == 'webui':
            from .webui import OrganismWebUI
            org = Organism()
            port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080
            webui = OrganismWebUI(org, port=port)
            webui.start()
            print(f'Web界面已启动: http://localhost:{port}')
            print(f'按 Ctrl+C 退出')
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                webui.stop()
                print('\n已停止')

        else:
            print(f'未知命令: {cmd}')
    else:
        interactive_mode()


if __name__ == '__main__':
    main()
