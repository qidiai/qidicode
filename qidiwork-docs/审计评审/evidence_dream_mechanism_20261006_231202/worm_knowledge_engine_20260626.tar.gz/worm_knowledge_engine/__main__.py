"""支持 python -m worm_knowledge_engine 运行"""
from .main import main
main()
